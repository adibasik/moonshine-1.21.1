package moonshine.manager;

import lombok.Getter;
import moonshine.client.draggables.HudManager;
import moonshine.command.CommandManager;
import moonshine.events.api.EventManager;
import moonshine.modules.impl.combat.aura.attack.StrikerConstructor;
import moonshine.modules.module.*;
import moonshine.screens.clickgui.ClickGui;
import moonshine.util.config.ConfigSystem;
import moonshine.util.config.impl.bind.BindConfig;
import moonshine.util.config.impl.blockesp.BlockESPConfig;
import moonshine.util.config.impl.drag.DragConfig;
import moonshine.util.config.impl.friend.FriendConfig;
import moonshine.util.config.impl.prefix.PrefixConfig;
import moonshine.util.config.impl.proxy.ProxyConfig;
import moonshine.util.config.impl.staff.StaffConfig;
import moonshine.util.modules.ModuleProvider;
import moonshine.util.modules.ModuleSwitcher;
import moonshine.util.render.shader.RenderCore;
import moonshine.util.render.shader.Scissor;
import moonshine.util.render.font.FontInitializer;
import moonshine.util.repository.macro.MacroRepository;
import moonshine.util.repository.way.WayRepository;
import moonshine.util.selfdestruct.SelfDestructManager;
import moonshine.util.tps.TPSCalculate;

/**
 *  © 2026 Copyright Moonshine Client 2.0
 *        All Rights Reserved ®
 */

@Getter
public class Manager {
    public StrikerConstructor attackPerpetrator = new StrikerConstructor();
    private EventManager eventManager;
    private RenderCore renderCore;
    private Scissor scissor;
    private ModuleProvider moduleProvider;
    private ModuleRepository moduleRepository;
    private ModuleSwitcher moduleSwitcher;
    private ClickGui clickgui;
    private ConfigSystem configSystem;
    private CommandManager commandManager;
    private TPSCalculate tpsCalculate;
    private HudManager hudManager = new HudManager();
    private boolean runtimeConfigsLoaded;

    public void init() {
        SelfDestructManager.init();

        loadRuntimeConfigs();

        FontInitializer.register();

        tpsCalculate = new TPSCalculate();

        clickgui = new ClickGui();
        eventManager = new EventManager();
        renderCore = new RenderCore();
        scissor = new Scissor();
        hudManager = new HudManager();
        hudManager.initElements();
        moduleRepository = new ModuleRepository();
        moduleRepository.setup();
        moduleProvider = new ModuleProvider(moduleRepository.modules());
        moduleSwitcher = new ModuleSwitcher(moduleRepository.modules(), eventManager);
        configSystem = new ConfigSystem();
        configSystem.init();
        commandManager = new CommandManager();
        commandManager.init();
    }

    public void loadRuntimeConfigs() {
        if (runtimeConfigsLoaded || SelfDestructManager.isLocked()) {
            return;
        }

        MacroRepository.getInstance().init();
        WayRepository.getInstance().init();
        BlockESPConfig.getInstance().load();
        FriendConfig.getInstance().load();
        PrefixConfig.getInstance().load();
        StaffConfig.getInstance().load();
        ProxyConfig.getInstance().load();
        DragConfig.getInstance().load();
        BindConfig.getInstance();
        runtimeConfigsLoaded = true;
    }
}
