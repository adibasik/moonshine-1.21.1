package moonshine.util.interfaces;

public interface IBuiltChunkAnimator {
    float getAnimation();
    void setAnimation(float value);
}