package moonshine.screens.account;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.GameProfile;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import net.minecraft.class_1071;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_8685;

@SuppressWarnings("unchecked")
public class SkinManager {

    private static final Map<String, class_2960> SKIN_CACHE = new ConcurrentHashMap<>();
    private static final Map<String, Boolean> LOADING = new ConcurrentHashMap<>();
    private static final class_2960 STEVE_SKIN = class_2960.method_60655("minecraft", "textures/entity/player/wide/steve.png");
    private static final class_2960 ALEX_SKIN = class_2960.method_60655("minecraft", "textures/entity/player/wide/alex.png");

    private static final Executor EXECUTOR = Executors.newFixedThreadPool(3, r -> {
        Thread t = new Thread(r, "SkinLoader");
        t.setDaemon(true);
        return t;
    });

    public static class_2960 getSkin(String playerName) {
        if (playerName == null || playerName.isEmpty()) {
            return STEVE_SKIN;
        }

        String key = playerName.toLowerCase();
        class_2960 cached = SKIN_CACHE.get(key);
        if (cached != null) {
            return cached;
        }

        if (!LOADING.containsKey(key)) {
            LOADING.put(key, true);
            loadSkinAsync(playerName);
        }

        return getDefaultSkin(playerName);
    }

    private static class_2960 getDefaultSkin(String playerName) {
        UUID offlineUUID = UUID.nameUUIDFromBytes(("OfflinePlayer:" + playerName).getBytes());
        return (offlineUUID.hashCode() & 1) == 0 ? STEVE_SKIN : ALEX_SKIN;
    }

    private static void loadSkinAsync(String playerName) {
        String key = playerName.toLowerCase();

        CompletableFuture.runAsync(() -> {
            try {
                UUID uuid = fetchUUID(playerName);
                if (uuid == null) {
                    LOADING.remove(key);
                    return;
                }

                class_310 client = class_310.method_1551();
                if (client == null) {
                    LOADING.remove(key);
                    return;
                }

                GameProfile profile = new GameProfile(uuid, playerName);
                class_1071 provider = client.method_1582();

                CompletableFuture<Optional<class_8685>> skinFuture = provider.method_52863(profile);
                Optional<class_8685> texturesOpt = skinFuture.join();

                if (texturesOpt.isPresent()) {
                    class_8685 textures = texturesOpt.get();
                    if (textures.comp_1626() != null) {
                        class_2960 skinId = textures.comp_1626().comp_3627();
                        if (skinId != null) {
                            SKIN_CACHE.put(key, skinId);
                        }
                    }
                }
            } catch (Exception ignored) {
            } finally {
                LOADING.remove(key);
            }
        }, EXECUTOR);
    }

    private static UUID fetchUUID(String playerName) {
        try {
            URL url = new URL("https://api.mojang.com/users/profiles/minecraft/" + playerName);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.setRequestProperty("User-Agent", "Mozilla/5.0");

            int responseCode = connection.getResponseCode();
            if (responseCode != 200) {
                connection.disconnect();
                return null;
            }

            try (InputStreamReader reader = new InputStreamReader(connection.getInputStream())) {
                JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();
                if (json.has("id")) {
                    String id = json.get("id").getAsString();
                    connection.disconnect();
                    return parseUUID(id);
                }
            }
            connection.disconnect();
        } catch (Exception ignored) {
        }
        return null;
    }

    private static UUID parseUUID(String id) {
        try {
            if (id.length() == 32) {
                id = id.substring(0, 8) + "-" + id.substring(8, 12) + "-" +
                        id.substring(12, 16) + "-" + id.substring(16, 20) + "-" + id.substring(20);
            }
            return UUID.fromString(id);
        } catch (Exception e) {
            return null;
        }
    }

    public static void clearCache() {
        SKIN_CACHE.clear();
        LOADING.clear();
    }

    public static void removeSkin(String playerName) {
        if (playerName != null) {
            SKIN_CACHE.remove(playerName.toLowerCase());
            LOADING.remove(playerName.toLowerCase());
        }
    }

    public static void reloadSkin(String playerName) {
        removeSkin(playerName);
        getSkin(playerName);
    }
}