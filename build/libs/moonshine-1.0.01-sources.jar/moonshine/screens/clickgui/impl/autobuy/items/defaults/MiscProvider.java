package moonshine.screens.clickgui.impl.autobuy.items.defaults;

import moonshine.screens.clickgui.impl.autobuy.AutoBuyableItem;
import moonshine.screens.clickgui.impl.autobuy.items.price.Defaultpricec;
import moonshine.screens.clickgui.impl.autobuy.util.KrushItem;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import java.util.ArrayList;
import java.util.List;

public class MiscProvider {
    public static List<AutoBuyableItem> getMisc() {
        List<AutoBuyableItem> misc = new ArrayList<>();
        misc.add(new KrushItem("Золотое яблоко", class_1802.field_8463, new class_1799(class_1802.field_8463), Defaultpricec.getPrice("Золотое яблоко")));
        misc.add(new KrushItem("Яблоко", class_1802.field_8279, new class_1799(class_1802.field_8279), Defaultpricec.getPrice("Яблоко")));
        misc.add(new KrushItem("Зачарованное золотое яблоко", class_1802.field_8367, new class_1799(class_1802.field_8367), Defaultpricec.getPrice("Зачарованное золотое яблоко")));
        misc.add(new KrushItem("Порох", class_1802.field_8054, new class_1799(class_1802.field_8054), Defaultpricec.getPrice("Порох")));
        misc.add(new KrushItem("Бирка", class_1802.field_8448, new class_1799(class_1802.field_8448), Defaultpricec.getPrice("Бирка")));
        misc.add(new KrushItem("Трезубец", class_1802.field_8547, new class_1799(class_1802.field_8547), Defaultpricec.getPrice("Трезубец")));
        misc.add(new KrushItem("Незеритовый слиток", class_1802.field_22020, new class_1799(class_1802.field_22020), Defaultpricec.getPrice("Незеритовый слиток")));
        misc.add(new KrushItem("Незеритовое улучшение", class_1802.field_41946, new class_1799(class_1802.field_41946), Defaultpricec.getPrice("Незеритовое улучшение")));
        misc.add(new KrushItem("Алмаз", class_1802.field_8477, new class_1799(class_1802.field_8477), Defaultpricec.getPrice("Алмаз")));
        misc.add(new KrushItem("Алмазный блок", class_1802.field_8603, new class_1799(class_1802.field_8603), Defaultpricec.getPrice("Алмазный блок")));
        misc.add(new KrushItem("Золотой слиток", class_1802.field_8695, new class_1799(class_1802.field_8695), Defaultpricec.getPrice("Золотой слиток")));
        misc.add(new KrushItem("Блок золота", class_1802.field_8494, new class_1799(class_1802.field_8494), Defaultpricec.getPrice("Блок золота")));
        misc.add(new KrushItem("Маяк", class_1802.field_8668, new class_1799(class_1802.field_8668), Defaultpricec.getPrice("Маяк")));
        misc.add(new KrushItem("Пузырёк опыта", class_1802.field_8287, new class_1799(class_1802.field_8287), Defaultpricec.getPrice("Пузырёк опыта")));
        misc.add(new KrushItem("Звезда Незера", class_1802.field_8137, new class_1799(class_1802.field_8137), Defaultpricec.getPrice("Звезда Незера")));
        misc.add(new KrushItem("Шалкеровый ящик", class_1802.field_8545, new class_1799(class_1802.field_8545), Defaultpricec.getPrice("Шалкеровый ящик")));
        misc.add(new KrushItem("Железный слиток", class_1802.field_8620, new class_1799(class_1802.field_8620), Defaultpricec.getPrice("Железный слиток")));
        misc.add(new KrushItem("Железный блок", class_1802.field_8773, new class_1799(class_1802.field_8773), Defaultpricec.getPrice("Железный блок")));
        misc.add(new KrushItem("Незеритовый блок", class_1802.field_22018, new class_1799(class_1802.field_22018), Defaultpricec.getPrice("Незеритовый блок")));
        misc.add(new KrushItem("Спавнер", class_1802.field_8849, new class_1799(class_1802.field_8849), Defaultpricec.getPrice("Спавнер")));
        misc.add(new KrushItem("Элитры", class_1802.field_8833, new class_1799(class_1802.field_8833), Defaultpricec.getPrice("Элитры")));
        misc.add(new KrushItem("Эндер жемчуг", class_1802.field_8634, new class_1799(class_1802.field_8634), Defaultpricec.getPrice("Эндер жемчуг")));
        misc.add(new KrushItem("Обсидиан", class_1802.field_8281, new class_1799(class_1802.field_8281), Defaultpricec.getPrice("Обсидиан")));
        misc.add(new KrushItem("Тотем бессмертия", class_1802.field_8288, new class_1799(class_1802.field_8288), Defaultpricec.getPrice("Тотем бессмертия")));
        misc.add(new KrushItem("Палка ифрита", class_1802.field_8894, new class_1799(class_1802.field_8894), Defaultpricec.getPrice("Палка ифрита")));
        misc.add(new KrushItem("Динамит", class_1802.field_8626, new class_1799(class_1802.field_8626), Defaultpricec.getPrice("Динамит")));
        misc.add(new KrushItem("Яйцо зомби-жителя", class_1802.field_8136, new class_1799(class_1802.field_8136), Defaultpricec.getPrice("Яйцо зомби-жителя")));
        misc.add(new KrushItem("Голова скелета", class_1802.field_8398, new class_1799(class_1802.field_8398), Defaultpricec.getPrice("Голова скелета")));
        misc.add(new KrushItem("Голова зомби", class_1802.field_8470, new class_1799(class_1802.field_8470), Defaultpricec.getPrice("Голова зомби")));
        misc.add(new KrushItem("Голова крипера", class_1802.field_8681, new class_1799(class_1802.field_8681), Defaultpricec.getPrice("Голова крипера")));
        misc.add(new KrushItem("Голова визер-скелета", class_1802.field_8791, new class_1799(class_1802.field_8791), Defaultpricec.getPrice("Голова визер-скелета")));
        misc.add(new KrushItem("Голова пиглина", class_1802.field_41304, new class_1799(class_1802.field_41304), Defaultpricec.getPrice("Голова пиглина")));
        misc.add(new KrushItem("Голова дракона", class_1802.field_8712, new class_1799(class_1802.field_8712), Defaultpricec.getPrice("Голова дракона")));
        misc.add(new KrushItem("Алмазная руда", class_1802.field_8787, new class_1799(class_1802.field_8787), Defaultpricec.getPrice("Алмазная руда")));
        misc.add(new KrushItem("Изумрудная руда", class_1802.field_8837, new class_1799(class_1802.field_8837), Defaultpricec.getPrice("Изумрудная руда")));
        misc.add(new KrushItem("Торт", class_1802.field_17534, new class_1799(class_1802.field_17534), Defaultpricec.getPrice("Торт")));
        misc.add(new KrushItem("Фейерверк", class_1802.field_8639, new class_1799(class_1802.field_8639), Defaultpricec.getPrice("Фейерверк")));
        misc.add(new KrushItem("Яйцо жителя", class_1802.field_8086, new class_1799(class_1802.field_8086), Defaultpricec.getPrice("Яйцо жителя")));
        misc.add(new KrushItem("Яйцо вихря", class_1802.field_47313, new class_1799(class_1802.field_47313), Defaultpricec.getPrice("Яйцо вихря")));
        misc.add(new KrushItem("Мешок", class_1802.field_27023, new class_1799(class_1802.field_27023), Defaultpricec.getPrice("Мешок")));
        misc.add(new KrushItem("Булава", class_1802.field_49814, new class_1799(class_1802.field_49814), Defaultpricec.getPrice("Булава")));
        misc.add(new KrushItem("Зловещий ключ испытаний", class_1802.field_50139, new class_1799(class_1802.field_50139), Defaultpricec.getPrice("Зловещий ключ испытаний")));
        misc.add(new KrushItem("Ключ испытаний", class_1802.field_47315, new class_1799(class_1802.field_47315), Defaultpricec.getPrice("Ключ испытаний")));
        misc.add(new KrushItem("Заряд ветра", class_1802.field_49098, new class_1799(class_1802.field_49098), Defaultpricec.getPrice("Заряд ветра")));
        misc.add(new KrushItem("Стержень вихря", class_1802.field_49821, new class_1799(class_1802.field_49821), Defaultpricec.getPrice("Стержень вихря")));
        return misc;
    }
}