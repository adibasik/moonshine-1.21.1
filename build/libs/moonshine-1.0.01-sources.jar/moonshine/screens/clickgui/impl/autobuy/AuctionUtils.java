package moonshine.screens.clickgui.impl.autobuy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_1887;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

public class AuctionUtils {
    public static final Pattern funTimePricePattern = Pattern.compile("\\$([\\d]+(?:[\\s,][\\d]{3})*(?:\\.[\\d]{2})?)");
    private static final Pattern digitPattern = Pattern.compile("([\\d][\\d\\s,.]*)");

    public static int getPrice(class_1799 stack) {
        String priceStr = null;
        var lore = stack.method_58694(class_9334.field_49632);
        if (lore != null && !lore.comp_2400().isEmpty()) {
            for (class_2561 line : lore.comp_2400()) {
                String lineStr = line.getString();
                if (lineStr.contains("$") || lineStr.toLowerCase().contains("цена")) {
                    Matcher matcher = funTimePricePattern.matcher(lineStr);
                    if (matcher.find()) {
                        priceStr = matcher.group(1);
                        break;
                    }
                    matcher = digitPattern.matcher(lineStr);
                    if (matcher.find()) {
                        priceStr = matcher.group(1);
                        break;
                    }
                }
            }
        }
        if (priceStr == null || priceStr.isEmpty()) {
            String itemName = stack.method_7964().getString();
            if (itemName != null) {
                Matcher matcher = funTimePricePattern.matcher(itemName);
                if (matcher.find()) {
                    priceStr = matcher.group(1);
                }
            }
        }
        if (priceStr == null || priceStr.isEmpty()) {
            var components = stack.method_57353();
            if (components != null) {
                String componentString = components.toString();
                if (componentString.contains("$")) {
                    Matcher matcher = funTimePricePattern.matcher(componentString);
                    if (matcher.find()) {
                        priceStr = matcher.group(1);
                    }
                }
            }
        }
        if (priceStr == null || priceStr.isEmpty()) return -1;
        try {
            priceStr = priceStr.replaceAll("[\\s,.$]", "").trim();
            if (priceStr.isEmpty()) return -1;
            return Integer.parseInt(priceStr);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static String cleanString(String str) {
        if (str == null) return "";
        return str.toLowerCase().trim()
                .replaceAll("§.", "")
                .replaceAll("[^a-zа-яё0-9\\s\\[\\]★⚒+()]", "")
                .replaceAll("\\s+", " ");
    }

    private static List<String> getLoreStrings(class_1799 stack) {
        var lore = stack.method_58694(class_9334.field_49632);
        if (lore == null || lore.comp_2400().isEmpty()) {
            return List.of();
        }
        return lore.comp_2400().stream()
                .map(text -> text.getString().toLowerCase())
                .collect(Collectors.toList());
    }

    private static boolean loreContains(class_1799 stack, String phrase) {
        List<String> loreLines = getLoreStrings(stack);
        String phraseLower = phrase.toLowerCase();
        for (String line : loreLines) {
            if (line.contains(phraseLower)) {
                return true;
            }
        }
        return false;
    }

    private static boolean loreContainsAny(class_1799 stack, String... phrases) {
        List<String> loreLines = getLoreStrings(stack);
        for (String phrase : phrases) {
            String phraseLower = phrase.toLowerCase();
            for (String line : loreLines) {
                if (line.contains(phraseLower)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static String extractChunkLoaderSize(class_1799 stack) {
        List<String> loreLines = getLoreStrings(stack);
        for (String line : loreLines) {
            if (line.contains("(1x1)") || line.contains("области (1x1)")) return "1x1";
            if (line.contains("(3x3)") || line.contains("области (3x3)")) return "3x3";
            if (line.contains("(5x5)") || line.contains("области (5x5)")) return "5x5";
        }
        return null;
    }

    private static boolean isTntBlackType(class_1799 stack) {
        return loreContains(stack, "обсидиан") || loreContains(stack, "способен взорвать обсидиан");
    }

    private static String getLockpickType(class_1799 stack) {
        List<String> loreLines = getLoreStrings(stack);
        for (String line : loreLines) {
            if (line.contains("с сферами") || line.contains("сферами")) return "spheres";
            if (line.contains("с ключами") || line.contains("ключами")) return "keys";
            if (line.contains("с монетами") || line.contains("монетами")) return "coins";
        }
        return "unknown";
    }

    private static boolean isDragonSkin(class_1799 stack) {
        return loreContains(stack, "драконий скин");
    }

    private static String getSkinType(class_1799 stack) {
        List<String> loreLines = getLoreStrings(stack);
        for (String line : loreLines) {
            if (line.contains("драконий скин")) return "dragon";
            if (line.contains("ледяной скин")) return "ice";
            if (line.contains("огненный скин")) return "fire";
        }
        return "unknown";
    }

    private static boolean isValidTrap(class_1799 stack) {
        return loreContains(stack, "нерушимая клетка");
    }

    private static String getTrapSkinType(class_1799 stack) {
        if (!isValidTrap(stack)) {
            return "invalid";
        }
        List<String> loreLines = getLoreStrings(stack);
        for (String line : loreLines) {
            if (line.contains("драконий") || line.contains("dragon")) return "dragon";
            if (line.contains("ледяной") || line.contains("ледян") || line.contains("ice")) return "ice";
            if (line.contains("огненный") || line.contains("fire")) return "fire";
        }
        return "standard";
    }

    private static String getSignalFireLootLevel(class_1799 stack) {
        List<String> loreLines = getLoreStrings(stack);
        for (String line : loreLines) {
            if (line.contains("уровень лута:") || line.contains("уровень лута")) {
                if (line.contains("легендарный")) return "legendary";
                if (line.contains("богатый")) return "moonshine";
                if (line.contains("обычный")) return "ordinary";
                if (line.contains("случайный")) return "random";
            }
        }
        return "unknown";
    }

    private static boolean isSignalFire(class_1799 stack) {
        return stack.method_7909() == class_1802.field_17346 || stack.method_7909() == class_1802.field_23842;
    }

    private static boolean isValidSignalFire(class_1799 stack) {
        return isSignalFire(stack) && loreContains(stack, "мистический сундук");
    }

    private static boolean isValidLockpick(class_1799 stack) {
        return loreContainsAny(stack, "открыть хранилище", "этой отмычкой можно");
    }

    private static boolean isValidExperienceBottle(class_1799 stack) {
        return loreContainsAny(stack, "содержит", "ур опыта", "ур. опыта");
    }

    private static boolean isValidTnt(class_1799 stack) {
        return loreContains(stack, "динамит взрывается");
    }

    private static boolean isValidDragonSkin(class_1799 stack) {
        return loreContains(stack, "драконий скин");
    }

    private static boolean isValidChunkLoader(class_1799 stack) {
        return loreContains(stack, "прогружает чанк");
    }

    public static boolean isArmorItem(class_1799 stack) {
        return stack.method_7909() == class_1802.field_22027 ||
                stack.method_7909() == class_1802.field_22028 ||
                stack.method_7909() == class_1802.field_22029 ||
                stack.method_7909() == class_1802.field_22030 ||
                stack.method_7909() == class_1802.field_8805 ||
                stack.method_7909() == class_1802.field_8058 ||
                stack.method_7909() == class_1802.field_8348 ||
                stack.method_7909() == class_1802.field_8285 ||
                stack.method_7909() == class_1802.field_8743 ||
                stack.method_7909() == class_1802.field_8523 ||
                stack.method_7909() == class_1802.field_8396 ||
                stack.method_7909() == class_1802.field_8660 ||
                stack.method_7909() == class_1802.field_8862 ||
                stack.method_7909() == class_1802.field_8678 ||
                stack.method_7909() == class_1802.field_8416 ||
                stack.method_7909() == class_1802.field_8753 ||
                stack.method_7909() == class_1802.field_8283 ||
                stack.method_7909() == class_1802.field_8873 ||
                stack.method_7909() == class_1802.field_8218 ||
                stack.method_7909() == class_1802.field_8313 ||
                stack.method_7909() == class_1802.field_8267 ||
                stack.method_7909() == class_1802.field_8577 ||
                stack.method_7909() == class_1802.field_8570 ||
                stack.method_7909() == class_1802.field_8370 ||
                stack.method_7909() == class_1802.field_8090;
    }

    public static boolean hasThornsEnchantment(class_1799 stack) {
        var enchants = stack.method_58694(class_9334.field_49633);
        if (enchants == null || enchants.method_57543()) {
            return false;
        }
        for (class_6880<class_1887> entry : enchants.method_57534()) {
            String enchantId = entry.method_55840();
            if (enchantId != null) {
                String lowerEnchantId = enchantId.toLowerCase();
                if (lowerEnchantId.contains("thorns") || lowerEnchantId.contains("шип")) {
                    return true;
                }
            }
        }
        var lore = stack.method_58694(class_9334.field_49632);
        if (lore != null) {
            for (class_2561 line : lore.comp_2400()) {
                String loreStr = line.getString().toLowerCase();
                if (loreStr.contains("thorns") || loreStr.contains("шип")) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean hasVanishingCurse(class_1799 stack) {
        var enchants = stack.method_58694(class_9334.field_49633);
        if (enchants == null || enchants.method_57543()) {
            return false;
        }
        for (class_6880<class_1887> entry : enchants.method_57534()) {
            String enchantId = entry.method_55840();
            if (enchantId != null && enchantId.toLowerCase().contains("vanishing")) {
                return true;
            }
        }
        return false;
    }

    public static boolean isUnbreakableItem(class_1799 stack) {
        var customData = stack.method_58694(class_9334.field_49628);
        if (customData != null) {
            class_2487 nbt = customData.method_57461();
            if (nbt.method_68566("Unbreakable", false)) {
                return true;
            }
        }
        String name = stack.method_7964().getString().toLowerCase();
        return name.contains("нерушим") || name.contains("[⚒]");
    }

    public static boolean isSplashPotion(class_1799 stack) {
        return stack.method_7909() == class_1802.field_8436 || stack.method_7909() == class_1802.field_8150;
    }

    public static Map<class_6880<class_1291>, EffectData> getPotionEffects(class_1799 stack) {
        Map<class_6880<class_1291>, EffectData> effects = new HashMap<>();
        class_1844 potionContents = stack.method_58694(class_9334.field_49651);
        if (potionContents == null) {
            return effects;
        }
        for (class_1293 effect : potionContents.comp_2380()) {
            effects.put(effect.method_5579(), new EffectData(effect.method_5578(), effect.method_5584()));
        }
        return effects;
    }

    public static boolean hasEffect(class_1799 stack, class_6880<class_1291> effectType, int minAmplifier) {
        Map<class_6880<class_1291>, EffectData> effects = getPotionEffects(stack);
        EffectData data = effects.get(effectType);
        return data != null && data.amplifier >= minAmplifier;
    }

    public static boolean matchesPotionEffects(class_1799 auctionItem, List<PotionEffectRequirement> requirements) {
        if (!isSplashPotion(auctionItem)) {
            return false;
        }
        Map<class_6880<class_1291>, EffectData> auctionEffects = getPotionEffects(auctionItem);
        if (auctionEffects.isEmpty()) {
            return false;
        }
        for (PotionEffectRequirement req : requirements) {
            EffectData data = auctionEffects.get(req.effect);
            if (data == null) {
                return false;
            }
            if (data.amplifier < req.minAmplifier) {
                return false;
            }
        }
        return true;
    }

    public static class EffectData {
        public final int amplifier;
        public final int duration;

        public EffectData(int amplifier, int duration) {
            this.amplifier = amplifier;
            this.duration = duration;
        }
    }

    public static class PotionEffectRequirement {
        public final class_6880<class_1291> effect;
        public final int minAmplifier;

        public PotionEffectRequirement(class_6880<class_1291> effect, int minAmplifier) {
            this.effect = effect;
            this.minAmplifier = minAmplifier;
        }
    }

    public static boolean compareItem(class_1799 a, class_1799 b) {
        if (a.method_7909() != b.method_7909()) {
            if (isSignalFire(a) && isSignalFire(b)) {
            } else {
                return false;
            }
        }

        if (isArmorItem(a) && hasThornsEnchantment(a)) {
            return false;
        }

        if (a.method_7909() == class_1802.field_22021) {
            if (!isValidTrap(a)) {
                return false;
            }
            if (!isValidTrap(b)) {
                return true;
            }
            String aType = getTrapSkinType(a);
            String bType = getTrapSkinType(b);
            if (bType.equals("standard")) {
                return aType.equals("standard") || aType.equals("dragon") || aType.equals("ice") || aType.equals("fire");
            }
            return aType.equals(bType);
        }

        if (isSignalFire(a) && isSignalFire(b)) {
            if (!isValidSignalFire(a)) {
                return false;
            }
            String aLevel = getSignalFireLootLevel(a);
            String bLevel = getSignalFireLootLevel(b);
            if (!bLevel.equals("unknown")) {
                if (!aLevel.equals(bLevel)) {
                    return false;
                }
            }
            return true;
        }

        if (a.method_7909() == class_1802.field_8238) {
            if (!isValidChunkLoader(a)) {
                return false;
            }
            String aSize = extractChunkLoaderSize(a);
            String bSize = extractChunkLoaderSize(b);
            if (bSize != null) {
                if (aSize == null || !aSize.equals(bSize)) {
                    return false;
                }
            }
            return true;
        }

        if (a.method_7909() == class_1802.field_8626) {
            if (!isValidTnt(a)) {
                return false;
            }
            boolean aIsBlack = isTntBlackType(a);
            boolean bIsBlack = isTntBlackType(b);
            if (aIsBlack != bIsBlack) {
                return false;
            }
            return true;
        }

        if (a.method_7909() == class_1802.field_8366) {
            if (!isValidLockpick(a)) {
                return false;
            }
            String aType = getLockpickType(a);
            String bType = getLockpickType(b);
            if (!bType.equals("unknown")) {
                if (!aType.equals(bType)) {
                    return false;
                }
            }
            return true;
        }

        if (a.method_7909() == class_1802.field_8407) {
            boolean bIsDragon = isDragonSkin(b);
            if (bIsDragon) {
                if (!isValidDragonSkin(a)) {
                    return false;
                }
            }
            String aType = getSkinType(a);
            String bType = getSkinType(b);
            if (!bType.equals("unknown")) {
                if (!aType.equals(bType)) {
                    return false;
                }
            }
            return true;
        }

        if (a.method_7909() == class_1802.field_8287) {
            var bLoreComp = b.method_58694(class_9334.field_49632);
            if (bLoreComp != null && !bLoreComp.comp_2400().isEmpty()) {
                if (!isValidExperienceBottle(a)) {
                    return false;
                }
                String aExpLevel = getExperienceLevel(a);
                String bExpLevel = getExperienceLevel(b);
                if (!bExpLevel.equals("unknown") && !aExpLevel.equals(bExpLevel)) {
                    return false;
                }
            }
            return true;
        }

        String aName = a.method_7964().getString();
        aName = funTimePricePattern.matcher(aName).replaceAll("").trim();
        String bName = b.method_7964().getString();
        String aNameClean = cleanString(aName);
        String bNameClean = cleanString(bName);

        if (bNameClean.contains("⚒") || bNameClean.contains("нерушим")) {
            if (!isUnbreakableItem(a) && !hasVanishingCurse(a)) {
                return false;
            }
            if (aNameClean.contains("нерушим") && bNameClean.contains("нерушим")) {
                return aNameClean.contains("элитр") && bNameClean.contains("элитр");
            }
        }

        var aLore = a.method_58694(class_9334.field_49632);
        var bLoreComp = b.method_58694(class_9334.field_49632);
        boolean hasLore = bLoreComp != null && !bLoreComp.comp_2400().isEmpty();

        if (isSplashPotion(a) && isSplashPotion(b)) {
            return comparePotionsByEffects(a, b);
        }

        if (hasLore) {
            List<class_2561> expectedLore = bLoreComp.comp_2400();
            if (aLore == null || aLore.comp_2400().isEmpty()) {
                return false;
            }

            List<String> auctionLoreStrings = aLore.comp_2400().stream()
                    .map(text -> cleanString(text.getString()))
                    .filter(s -> !s.isEmpty())
                    .collect(Collectors.toList());

            String auctionLoreJoined = String.join(" ", auctionLoreStrings);

            List<String> criticalPhrases = List.of(
                    "с сферами",
                    "сферами",
                    "драконий скин",
                    "обсидиан",
                    "способен взорвать обсидиан",
                    "области (1x1)",
                    "области (3x3)",
                    "области (5x5)",
                    "нерушимая клетка",
                    "tier black",
                    "tier white",
                    "уровень лута легендарный",
                    "уровень лута богатый",
                    "уровень лута обычный",
                    "уровень лута случайный",
                    "мистический сундук",
                    "прогружает чанк",
                    "динамит взрывается",
                    "открыть хранилище"
            );

            for (class_2561 expected : expectedLore) {
                String expectedStr = cleanString(expected.getString());
                if (expectedStr.isEmpty()) continue;

                for (String critical : criticalPhrases) {
                    if (expectedStr.contains(critical)) {
                        boolean foundInAuction = false;
                        for (String auctionLine : auctionLoreStrings) {
                            if (auctionLine.contains(critical)) {
                                foundInAuction = true;
                                break;
                            }
                        }
                        if (!foundInAuction && !auctionLoreJoined.contains(critical)) {
                            return false;
                        }
                    }
                }
            }

            boolean hasOriginalMarker = false;
            boolean hasUnbreakableMarker = false;
            for (String line : auctionLoreStrings) {
                if (line.contains("оригинальный предмет") || line.contains("★")) {
                    hasOriginalMarker = true;
                }
                if (line.contains("нерушим") || line.contains("⚒")) {
                    hasUnbreakableMarker = true;
                }
            }

            int matchCount = 0;
            int requiredMatches = 0;

            for (class_2561 expected : expectedLore) {
                String expectedStr = cleanString(expected.getString());
                if (expectedStr.isEmpty()) continue;

                boolean isOriginalMarker = expectedStr.contains("оригинальный предмет") || expectedStr.contains("★");
                boolean isUnbreakableMarker = expectedStr.contains("нерушим") || expectedStr.contains("⚒");

                if (isOriginalMarker) {
                    if (!hasOriginalMarker) {
                        return false;
                    }
                    matchCount++;
                    requiredMatches++;
                    continue;
                }

                if (isUnbreakableMarker) {
                    if (!hasUnbreakableMarker && !isUnbreakableItem(a) && !hasVanishingCurse(a)) {
                        return false;
                    }
                    matchCount++;
                    requiredMatches++;
                    continue;
                }

                requiredMatches++;
                boolean found = false;

                for (String auctionLine : auctionLoreStrings) {
                    if (auctionLine.contains(expectedStr) || expectedStr.contains(auctionLine)) {
                        found = true;
                        break;
                    }
                }

                if (!found && auctionLoreJoined.contains(expectedStr)) {
                    found = true;
                }

                if (found) {
                    matchCount++;
                }
            }

            double matchRatio = requiredMatches > 0 ? (double) matchCount / requiredMatches : 1.0;
            if (matchRatio < 0.7) {
                return false;
            }

            if (hasOriginalMarker) {
                var aEnchants = a.method_58694(class_9334.field_49633);
                var bEnchants = b.method_58694(class_9334.field_49633);

                if (bEnchants != null && !bEnchants.method_57543()) {
                    if (aEnchants == null || aEnchants.method_57543()) {
                        return false;
                    }

                    Map<String, Integer> aEnchantMap = new HashMap<>();
                    for (class_6880<class_1887> entry : aEnchants.method_57534()) {
                        String enchantId = entry.method_55840();
                        if (enchantId != null) {
                            String enchantName = enchantId.replace("minecraft:", "").toLowerCase();
                            int level = aEnchants.method_57536(entry);
                            aEnchantMap.put(enchantName, level);
                        }
                    }

                    Map<String, Integer> bEnchantMap = new HashMap<>();
                    for (class_6880<class_1887> entry : bEnchants.method_57534()) {
                        String enchantId = entry.method_55840();
                        if (enchantId != null) {
                            String enchantName = enchantId.replace("minecraft:", "").toLowerCase();
                            int level = bEnchants.method_57536(entry);
                            bEnchantMap.put(enchantName, level);
                        }
                    }

                    if (bEnchantMap.isEmpty()) {
                        return true;
                    }

                    int enchantMatchCount = 0;
                    for (Map.Entry<String, Integer> bEntry : bEnchantMap.entrySet()) {
                        String bEnchantName = bEntry.getKey();
                        Integer aLevel = aEnchantMap.get(bEnchantName);
                        if (aLevel != null && aLevel >= 1) {
                            enchantMatchCount++;
                        }
                    }

                    double enchantMatchRatio = (double) enchantMatchCount / bEnchantMap.size();
                    if (enchantMatchRatio < 1) {
                        return false;
                    }
                }
            }
        } else {
            if (!aNameClean.contains(bNameClean) && !bNameClean.contains(aNameClean)) {
                return false;
            }
        }

        return true;
    }

    private static String getExperienceLevel(class_1799 stack) {
        List<String> loreLines = getLoreStrings(stack);
        for (String line : loreLines) {
            if (line.contains("15")) return "15";
            if (line.contains("30")) return "30";
            if (line.contains("50")) return "50";
        }
        return "unknown";
    }

    private static boolean comparePotionsByEffects(class_1799 auctionPotion, class_1799 templatePotion) {
        Map<class_6880<class_1291>, EffectData> auctionEffects = getPotionEffects(auctionPotion);
        Map<class_6880<class_1291>, EffectData> templateEffects = getPotionEffects(templatePotion);

        if (templateEffects.isEmpty()) {
            return false;
        }
        if (auctionEffects.isEmpty()) {
            return false;
        }

        for (Map.Entry<class_6880<class_1291>, EffectData> entry : templateEffects.entrySet()) {
            class_6880<class_1291> requiredEffect = entry.getKey();
            int requiredAmplifier = entry.getValue().amplifier;
            EffectData auctionData = auctionEffects.get(requiredEffect);
            if (auctionData == null) {
                return false;
            }
            if (auctionData.amplifier < requiredAmplifier) {
                return false;
            }
        }
        return true;
    }
}