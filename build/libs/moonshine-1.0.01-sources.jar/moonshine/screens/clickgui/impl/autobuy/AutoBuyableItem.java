package moonshine.screens.clickgui.impl.autobuy;

import moonshine.screens.clickgui.impl.autobuy.settings.AutoBuyItemSettings;
import net.minecraft.class_1799;

public interface AutoBuyableItem {
    String getDisplayName();
    class_1799 createItemStack();
    int getPrice();
    boolean isEnabled();
    void setEnabled(boolean enabled);
    AutoBuyItemSettings getSettings();
}