package moonshine.screens.clickgui.impl.autobuy.originalitems;

import moonshine.screens.clickgui.impl.autobuy.AutoBuyableItem;
import moonshine.screens.clickgui.impl.autobuy.items.customitem.CustomItem;
import moonshine.screens.clickgui.impl.autobuy.items.price.Defaultpricec;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PotionProvider {
    public static List<AutoBuyableItem> getPotions() {
        List<AutoBuyableItem> potions = new ArrayList<>();

        List<class_2561> hlopushkaLore = List.of(class_2561.method_43470("Хлопушка"));
        List<class_1293> hlopushkaEffects = List.of(
                new class_1293(class_1294.field_5909, 200, 9),
                new class_1293(class_1294.field_5904, 400, 4),
                new class_1293(class_1294.field_5919, 100, 9),
                new class_1293(class_1294.field_5912, 3600, 0)
        );
        potions.add(new CustomItem("[★] Хлопушка", null, class_1802.field_8436, Defaultpricec.getPrice("Хлопушка"),
                new class_1844(Optional.empty(), Optional.of(0xFF69B4), hlopushkaEffects, Optional.empty()), hlopushkaLore));

        List<class_2561> holyWaterLore = List.of(class_2561.method_43470("Святая вода"));
        List<class_1293> holyWaterEffects = List.of(
                new class_1293(class_1294.field_5924, 1200, 2),
                new class_1293(class_1294.field_5905, 12000, 1),
                new class_1293(class_1294.field_5915, 0, 1)
        );
        potions.add(new CustomItem("[★] Святая вода", null, class_1802.field_8436, Defaultpricec.getPrice("Святая вода"),
                new class_1844(Optional.empty(), Optional.of(0xFFFFFF), holyWaterEffects, Optional.empty()), holyWaterLore));

        List<class_2561> gnevLore = List.of(class_2561.method_43470("Зелье Гнева"));
        List<class_1293> gnevEffects = List.of(
                new class_1293(class_1294.field_5910, 600, 4),
                new class_1293(class_1294.field_5909, 600, 3)
        );
        potions.add(new CustomItem("[★] Зелье Гнева", null, class_1802.field_8436, Defaultpricec.getPrice("Зелье Гнева"),
                new class_1844(Optional.empty(), Optional.of(0x993333), gnevEffects, Optional.empty()), gnevLore));

        List<class_2561> paladinLore = List.of(class_2561.method_43470("Зелье Палладина"));
        List<class_1293> paladinEffects = List.of(
                new class_1293(class_1294.field_5907, 12000, 0),
                new class_1293(class_1294.field_5918, 12000, 0),
                new class_1293(class_1294.field_5905, 18000, 0),
                new class_1293(class_1294.field_5914, 1200, 2)
        );
        potions.add(new CustomItem("[★] Зелье Палладина", null, class_1802.field_8436, Defaultpricec.getPrice("Зелье Палладина"),
                new class_1844(Optional.empty(), Optional.of(0x00FFFF), paladinEffects, Optional.empty()), paladinLore));

        List<class_2561> assassinLore = List.of(class_2561.method_43470("Зелье Ассасина"));
        List<class_1293> assassinEffects = List.of(
                new class_1293(class_1294.field_5910, 1200, 3),
                new class_1293(class_1294.field_5904, 6000, 2),
                new class_1293(class_1294.field_5917, 1200, 0),
                new class_1293(class_1294.field_5921, 1, 1)
        );
        potions.add(new CustomItem("[★] Зелье Ассасина", null, class_1802.field_8436, Defaultpricec.getPrice("Зелье Ассасина"),
                new class_1844(Optional.empty(), Optional.of(0x333333), assassinEffects, Optional.empty()), assassinLore));

        List<class_2561> radiationLore = List.of(class_2561.method_43470("Зелье Радиации"));
        List<class_1293> radiationEffects = List.of(
                new class_1293(class_1294.field_5899, 1200, 1),
                new class_1293(class_1294.field_5920, 1200, 1),
                new class_1293(class_1294.field_5909, 1800, 2),
                new class_1293(class_1294.field_5903, 1200, 4),
                new class_1293(class_1294.field_5912, 2400, 0)
        );
        potions.add(new CustomItem("[★] Зелье Радиации", null, class_1802.field_8436, Defaultpricec.getPrice("Зелье Радиации"),
                new class_1844(Optional.empty(), Optional.of(0x32CD32), radiationEffects, Optional.empty()), radiationLore));

        List<class_2561> snotvornoyeLore = List.of(class_2561.method_43470("Снотворное"));
        List<class_1293> snotvornoEffects = List.of(
                new class_1293(class_1294.field_5911, 1800, 1),
                new class_1293(class_1294.field_5901, 200, 1),
                new class_1293(class_1294.field_5920, 1800, 2),
                new class_1293(class_1294.field_5919, 200, 0)
        );
        potions.add(new CustomItem("[★] Снотворное", null, class_1802.field_8436, Defaultpricec.getPrice("Снотворное"),
                new class_1844(Optional.empty(), Optional.of(0x484848), snotvornoEffects, Optional.empty()), snotvornoyeLore));

        List<class_2561> mandarinovySokLore = List.of(class_2561.method_43470("Заряд витаминов и удачи"));
        List<class_1293> mandarinovySokEffects = List.of(
                new class_1293(class_1294.field_5918, 3600, 0),
                new class_1293(class_1294.field_5913, 3600, 1),
                new class_1293(class_1294.field_5926, 3600, 0),
                new class_1293(class_1294.field_5917, 3600, 1)
        );
        potions.add(new CustomItem("[🍹] Мандариновый сок", null, class_1802.field_8574, Defaultpricec.getPrice("Мандариновый сок"),
                new class_1844(Optional.empty(), Optional.of(0xD6CE43), mandarinovySokEffects, Optional.empty()), mandarinovySokLore));

        return potions;
    }
}