package moonshine.screens.clickgui.impl.autobuy.originalitems;

import moonshine.screens.clickgui.impl.autobuy.AutoBuyableItem;
import moonshine.screens.clickgui.impl.autobuy.items.customitem.CustomItem;
import moonshine.screens.clickgui.impl.autobuy.items.price.Defaultpricec;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import java.util.ArrayList;
import java.util.List;

public class TalismanProvider {
    public static List<AutoBuyableItem> getTalismans() {
        List<AutoBuyableItem> talismans = new ArrayList<>();
        List<class_2561> krushitelLore = List.of(
                class_2561.method_43470("Легендарный символ."),
                class_2561.method_43470("Несокрушимая мощь,"),
                class_2561.method_43470("Ломающая преграды.")
        );
        talismans.add(new CustomItem("[★] Талисман Крушителя", null, class_1802.field_8288, Defaultpricec.getPrice("Талисман Крушителя"), null, krushitelLore, true));
        List<class_2561> razdorLore = List.of(
                class_2561.method_43470("Раздор жаждет хаоса,"),
                class_2561.method_43470("Даруя безумный темп,"),
                class_2561.method_43470("Но разрушая броню")
        );
        talismans.add(new CustomItem("[★] Талисман Раздора", null, class_1802.field_8288, Defaultpricec.getPrice("Талисман Раздора"), null, razdorLore, true));
        List<class_2561> tiranLore = List.of(
                class_2561.method_43470("Тиран подавляет слабых."),
                class_2561.method_43470("Дает защиту и силу,"),
                class_2561.method_43470("Взимая кровавый налог.")
        );
        talismans.add(new CustomItem("[★] Талисман Тирана", null, class_1802.field_8288, Defaultpricec.getPrice("Талисман Тирана"), null, tiranLore, true));
        List<class_2561> yarostLore = List.of(
                class_2561.method_43470("Чистая, дикая агрессия."),
                class_2561.method_43470("Граничит с безумием,"),
                class_2561.method_43470("Меняя жизнь на урон.")
        );
        talismans.add(new CustomItem("[★] Талисман Ярости", null, class_1802.field_8288, Defaultpricec.getPrice("Талисман Ярости"), null, yarostLore, true));
        List<class_2561> vihrLore = List.of(
                class_2561.method_43470("Вихрь не знает покоя,"),
                class_2561.method_43470("Ускоряя владельца"),
                class_2561.method_43470("И закаляя его дух.")
        );
        talismans.add(new CustomItem("[★] Талисман Вихря", null, class_1802.field_8288, Defaultpricec.getPrice("Талисман Вихря"), null, vihrLore, true));
        List<class_2561> mrakLore = List.of(
                class_2561.method_43470("Мрак сгущается рядом,"),
                class_2561.method_43470("Укрывая владельца"),
                class_2561.method_43470("И питая его силы.")
        );
        talismans.add(new CustomItem("[★] Талисман Мрака", null, class_1802.field_8288, Defaultpricec.getPrice("Талисман Мрака"), null, mrakLore, true));
        List<class_2561> demonLore = List.of(
                class_2561.method_43470("Печать разжигает ярость,"),
                class_2561.method_43470("Ускоряя удары сердца"),
                class_2561.method_43470("И силу каждой атаки.")
        );
        talismans.add(new CustomItem("[★] Талисман Демона", null, class_1802.field_8288, Defaultpricec.getPrice("Талисман Демона"), null, demonLore, true));
        List<class_2561> karatelLore = List.of(
                class_2561.method_43470("Несёт строгий приговор,"),
                class_2561.method_43470("Карая всех врагов,"),
                class_2561.method_43470("Но ослабляя тело.")
        );
        talismans.add(new CustomItem("[★] Талисман Карателя", null, class_1802.field_8288, Defaultpricec.getPrice("Талисман Карателя"), null, karatelLore, true));
        List<class_2561> grinchLore = List.of(
                class_2561.method_43470("Похититель праздника легок,"),
                class_2561.method_43470("Его карманы полны удачи,"),
                class_2561.method_43470("Но сердце слишком мало")
        );
        talismans.add(new CustomItem("[★] Талисман Гринча", null, class_1802.field_8288, Defaultpricec.getPrice("Талисман Гринча"), null, grinchLore, true));
        return talismans;
    }
}