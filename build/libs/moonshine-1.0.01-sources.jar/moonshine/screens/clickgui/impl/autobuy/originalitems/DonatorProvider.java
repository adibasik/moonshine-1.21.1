package moonshine.screens.clickgui.impl.autobuy.originalitems;

import moonshine.screens.clickgui.impl.autobuy.AutoBuyableItem;
import moonshine.screens.clickgui.impl.autobuy.items.customitem.CustomItem;
import moonshine.screens.clickgui.impl.autobuy.items.customitem.UnbreakableItem;
import moonshine.screens.clickgui.impl.autobuy.items.price.Defaultpricec;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import java.util.ArrayList;
import java.util.List;

public class DonatorProvider {
    public static List<AutoBuyableItem> getDonator() {
        List<AutoBuyableItem> donator = new ArrayList<>();

        List<class_2561> lightDustLore = List.of(
                class_2561.method_43470("Каст: Световая вспышка"),
                class_2561.method_43470("Радиус: 10 блоков"),
                class_2561.method_43470("Эффекты для противников:"),
                class_2561.method_43470(" • Свечение (00:30)"),
                class_2561.method_43470(" • Слепота (00:01)"),
                class_2561.method_43470("Чем ближе цель, тем дольше длительность эффектов")
        );
        donator.add(new CustomItem("[★] Явная пыль", null, class_1802.field_8479, Defaultpricec.getPrice("Явная пыль"), null, lightDustLore, false, true));

        List<class_2561> disorientationLore = List.of(
                class_2561.method_43470("Чем ближе цель, тем дольше длительность эффектов")
        );
        donator.add(new CustomItem("[★] Дезориентация", null, class_1802.field_8449, Defaultpricec.getPrice("Дезориентация"), null, disorientationLore, false, true));

        List<class_2561> trapkaLore = List.of(
                class_2561.method_43470("Каст: Нерушимая клетка"),
                class_2561.method_43470("Длительность: 15 секунд"),
                class_2561.method_43470("Используйте скины: /tskins")
        );
        donator.add(new CustomItem("[★] Трапка", null, class_1802.field_22021, Defaultpricec.getPrice("Трапка"), null, trapkaLore, false, true));

        List<class_2561> lockpickSpheresLore = List.of(
                class_2561.method_43470("Этой отмычкой можно"),
                class_2561.method_43470("Открыть хранилище"),
                class_2561.method_43470("С Сферами")
        );
        donator.add(new CustomItem("[★] Отмычка к Сферам", null, class_1802.field_8366, Defaultpricec.getPrice("Отмычка к Сферам"), null, lockpickSpheresLore, false, true));

        List<class_2561> plast = List.of(
                class_2561.method_43470("Каст: Нерушимая стена"),
                class_2561.method_43470("Длительность:"),
                class_2561.method_43470("Вертикальный: 20 секунд"),
                class_2561.method_43470("Горизонтальный: 60 секунд")
        );
        donator.add(new CustomItem("[★] Пласт", null, class_1802.field_8551, Defaultpricec.getPrice("Пласт"), null, plast, false, true));

        List<class_2561> exp15Lore = List.of(class_2561.method_43470("Содержит 15 ур опыта"));
        donator.add(new CustomItem("Пузырек опыта [15 ур]", null, class_1802.field_8287, Defaultpricec.getPrice("Пузырек опыта [15 ур]"), null, exp15Lore, false, true));

        List<class_2561> exp30Lore = List.of(class_2561.method_43470("Содержит: 30 Ур. опыта"));
        donator.add(new CustomItem("Пузырёк опыта [30 Ур.]", null, class_1802.field_8287, Defaultpricec.getPrice("Пузырёк опыта [30 Ур.]"), null, exp30Lore, false, true));

        List<class_2561> exp50Lore = List.of(class_2561.method_43470("Содержит 50 ур опыта"));
        donator.add(new CustomItem("Пузырек опыта [50 ур]", null, class_1802.field_8287, Defaultpricec.getPrice("Пузырек опыта [50 ур]"), null, exp50Lore, false, true));

        List<class_2561> tntWhiteLore = List.of(
                class_2561.method_43470("Этот динамит взрывается"),
                class_2561.method_43470("в 10 раз сильнее обычного")
        );
        donator.add(new CustomItem("[★] TNT - TIER WHITE", null, class_1802.field_8626, Defaultpricec.getPrice("TNT - TIER WHITE"), null, tntWhiteLore, false, true));

        List<class_2561> tntBlackLore = List.of(
                class_2561.method_43470("Этот динамит взрывается"),
                class_2561.method_43470("в 10 раз сильнее обычного"),
                class_2561.method_43470("и способен взорвать обсидиан")
        );
        donator.add(new CustomItem("[★] TNT - TIER BLACK", null, class_1802.field_8626, Defaultpricec.getPrice("TNT - TIER BLACK"), null, tntBlackLore, false, true));

        List<class_2561> signalRandomLore = List.of(
                class_2561.method_43470("Уровень лута: Случайный"),
                class_2561.method_43470("При помощи этого предмета"),
                class_2561.method_43470("можно призвать оригинальный"),
                class_2561.method_43470("Мистический Сундук!")
        );
        donator.add(new CustomItem("Сигнальный огонь [Случайный]", null, class_1802.field_17346, Defaultpricec.getPrice("Сигнальный огонь [Случайный]"), null, signalRandomLore));

        List<class_2561> signalOrdinaryLore = List.of(
                class_2561.method_43470("Уровень лута: Обычный"),
                class_2561.method_43470("При помощи этого предмета"),
                class_2561.method_43470("можно призвать оригинальный"),
                class_2561.method_43470("Мистический Сундук!")
        );
        donator.add(new CustomItem("Сигнальный огонь [Обычный]", null, class_1802.field_17346, Defaultpricec.getPrice("Сигнальный огонь [Обычный]"), null, signalOrdinaryLore));

        List<class_2561> signalMoonshineLore = List.of(
                class_2561.method_43470("Уровень лута: Богатый"),
                class_2561.method_43470("При помощи этого предмета"),
                class_2561.method_43470("можно призвать оригинальный"),
                class_2561.method_43470("Мистический Сундук!")
        );
        donator.add(new CustomItem("Сигнальный огонь [Богатый]", null, class_1802.field_17346, Defaultpricec.getPrice("Сигнальный огонь [Богатый]"), null, signalMoonshineLore));

        List<class_2561> signalLegendaryLore = List.of(
                class_2561.method_43470("Уровень лута: Легендарный"),
                class_2561.method_43470("При помощи этого предмета"),
                class_2561.method_43470("можно призвать оригинальный"),
                class_2561.method_43470("Мистический Сундук!")
        );
        donator.add(new CustomItem("Сигнальный огонь [Легендарный]", null, class_1802.field_23842, Defaultpricec.getPrice("Сигнальный огонь [Легендарный]"), null, signalLegendaryLore));

        List<class_2561> blockDamagerLore = List.of(
                class_2561.method_43470("● Каст: Нанесение урона"),
                class_2561.method_43470("● Радиус: 1,5 блока")
        );
        donator.add(new CustomItem("[★] Блок дамагер", null, class_1802.field_16538, Defaultpricec.getPrice("Блок дамагер"), null, blockDamagerLore));

        List<class_2561> chunkLoader1x1Lore = List.of(
                class_2561.method_43470("Прогружает чанк, в котором"),
                class_2561.method_43470("находится этот прогрузчик."),
                class_2561.method_43470("Нажмите на него, чтобы на"),
                class_2561.method_43470("30 секунд увидеть границы"),
                class_2561.method_43470("прогружаемой области (1x1).")
        );
        donator.add(new CustomItem("[★] Прогрузчик чанков [1x1]", null, class_1802.field_8238, Defaultpricec.getPrice("Прогрузчик чанков [1x1]"), null, chunkLoader1x1Lore));

        List<class_2561> chunkLoader3x3Lore = List.of(
                class_2561.method_43470("Прогружает чанк, в котором"),
                class_2561.method_43470("находится этот прогрузчик."),
                class_2561.method_43470("Нажмите на него, чтобы на"),
                class_2561.method_43470("30 секунд увидеть границы"),
                class_2561.method_43470("прогружаемой области (3x3).")
        );
        donator.add(new CustomItem("[★] Прогрузчик чанков [3x3]", null, class_1802.field_8238, Defaultpricec.getPrice("Прогрузчик чанков [3x3]"), null, chunkLoader3x3Lore));

        List<class_2561> chunkLoader5x5Lore = List.of(
                class_2561.method_43470("Прогружает чанк, в котором"),
                class_2561.method_43470("находится этот прогрузчик."),
                class_2561.method_43470("Нажмите на него, чтобы на"),
                class_2561.method_43470("30 секунд увидеть границы"),
                class_2561.method_43470("прогружаемой области (5x5).")
        );
        donator.add(new CustomItem("[★] Прогрузчик чанков [5x5]", null, class_1802.field_8238, Defaultpricec.getPrice("Прогрузчик чанков [5x5]"), null, chunkLoader5x5Lore));

        List<class_2561> mysteriousBeaconLore = List.of(
                class_2561.method_43470("Маяк установит временный"),
                class_2561.method_43470("ивент, раздающий Монеты"),
                class_2561.method_43470("игрокам поблизости.")
        );
        donator.add(new CustomItem("Загадочный маяк", null, class_1802.field_8668, Defaultpricec.getPrice("Загадочный маяк"), null, mysteriousBeaconLore));

        List<class_2561> cursedSoulLore = List.of(
                class_2561.method_43470("Обменяй души на ценные"),
                class_2561.method_43470("ресурсы у Собирателя душ"),
                class_2561.method_43470("/warp soulcollector")
        );
        donator.add(new CustomItem("[★] Проклятая душа", null, class_1802.field_22016, Defaultpricec.getPrice("Проклятая душа"), null, cursedSoulLore, false, true));

        List<class_2561> dragonSkinLore = List.of(
                class_2561.method_43470("Используя этот предмет"),
                class_2561.method_43470("Вы его расходуете"),
                class_2561.method_43470("и получаете Драконий скин взамен"),
                class_2561.method_43470("[ПКМ], чтобы использовать x1 скин"),
                class_2561.method_43470("[SHIFT+ПКМ], чтобы использовать все скины"),
                class_2561.method_43470("Предмет нужно держать в руке")
        );
        donator.add(new CustomItem("[★] Драконий скин", null, class_1802.field_8407, Defaultpricec.getPrice("Драконий скин"), null, dragonSkinLore, false, true));

        List<class_2561> fireWhirlwindLore = List.of(
                class_2561.method_43470("● Каст: Огненная волна"),
                class_2561.method_43470("● Радиус: 10 блоков"),
                class_2561.method_43470(""),
                class_2561.method_43470("● Эффекты для противников:"),
                class_2561.method_43470(" - Поджог (00:03)"),
                class_2561.method_43470(""),
                class_2561.method_43470("Чем ближе цель, тем дольше"),
                class_2561.method_43470("длительность эффектов")
        );
        donator.add(new CustomItem("[★] Огненный смерч", null, class_1802.field_8814, Defaultpricec.getPrice("Огненный смерч"), null, fireWhirlwindLore, false, true));

        List<class_2561> freezingSnowballLore = List.of(
                class_2561.method_43470("● Каст: Ледяная сфера"),
                class_2561.method_43470("● Радиус: 7 блоков"),
                class_2561.method_43470(""),
                class_2561.method_43470("● Эффекты для противников:"),
                class_2561.method_43470(" - Заморозка (00:01)"),
                class_2561.method_43470(" - Слабость (03:00)")
        );
        donator.add(new CustomItem("[★] Снежок заморозка", null, class_1802.field_8543, Defaultpricec.getPrice("Снежок заморозка"), null, freezingSnowballLore, false, true));

        List<class_2561> godsAuraLore = List.of(
                class_2561.method_43470("● Каст: Божественная аура"),
                class_2561.method_43470("● Радиус: 2 блока"),
                class_2561.method_43470(""),
                class_2561.method_43470("● Эффекты для союзников:"),
                class_2561.method_43470(" - Снятие всех эффектов"),
                class_2561.method_43470(" - Невидимость (04:00)"),
                class_2561.method_43470(" - Сила II (03:00)"),
                class_2561.method_43470(" - Скорость II (03:00)")
        );
        donator.add(new CustomItem("[★] Божья аура", null, class_1802.field_8614, Defaultpricec.getPrice("Божья аура"), null, godsAuraLore, false, true));

        List<class_2561> silverLore = List.of(
                class_2561.method_43470("Это валюта для покупки"),
                class_2561.method_43470("отмычек к тайникам"),
                class_2561.method_43470("у Знахаря (/warp stash)")
        );
        donator.add(new CustomItem("[★] Серебро", null, class_1802.field_8675, Defaultpricec.getPrice("Серебро"), null, silverLore, false, true));

        List<class_2561> godsTouchLore = List.of(
                class_2561.method_43470("Божье касание"),
                class_2561.method_43470("Может добыть спавнер,"),
                class_2561.method_43470("но только один раз")
        );
        donator.add(new CustomItem("[★] Божье касание", null, class_1802.field_8335, Defaultpricec.getPrice("Божье касание"), null, godsTouchLore));

        List<class_2561> powerfulHitLore = List.of(
                class_2561.method_43470("Мощный удар"),
                class_2561.method_43470("Может разрушить бедрок,"),
                class_2561.method_43470("но только один раз")
        );
        donator.add(new CustomItem("[★] Мощный удар", null, class_1802.field_8335, Defaultpricec.getPrice("Мощный удар"), null, powerfulHitLore));

        List<class_2561> megaBulldozerLore = List.of(
                class_2561.method_43470("Вскапывает территорию"),
                class_2561.method_43470("размером 9x9x5 блоков")
        );
        donator.add(new CustomItem("[★] Кирка мега-бульдозер", null, class_1802.field_22024, Defaultpricec.getPrice("Кирка мега-бульдозер"), null, megaBulldozerLore));

        List<class_2561> unbreakableElytraLore = List.of(
                class_2561.method_43470("[⚒] Нерушимый предмет")
        );
        donator.add(new UnbreakableItem("[⚒] Нерушимые элитры", class_1802.field_8833, Defaultpricec.getPrice("Нерушимые элитры"), unbreakableElytraLore));

        return donator;
    }
}