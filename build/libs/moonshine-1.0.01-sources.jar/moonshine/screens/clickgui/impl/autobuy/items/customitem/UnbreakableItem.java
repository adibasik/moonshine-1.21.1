package moonshine.screens.clickgui.impl.autobuy.items.customitem;

import moonshine.screens.clickgui.impl.autobuy.AutoBuyableItem;
import moonshine.screens.clickgui.impl.autobuy.settings.AutoBuyItemSettings;
import moonshine.util.config.impl.autobuyconfig.AutoBuyConfig;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import java.util.List;
import java.util.Optional;

public class UnbreakableItem implements AutoBuyableItem {
    private final String displayName;
    private final class_1792 material;
    private final int price;
    private final List<class_2561> loreTexts;
    private final AutoBuyItemSettings settings;
    private boolean enabled;

    public UnbreakableItem(String displayName, class_1792 material, int price, List<class_2561> loreTexts) {
        this.displayName = displayName;
        this.material = material;
        this.price = price;
        this.loreTexts = loreTexts;
        this.settings = new AutoBuyItemSettings(price, material, displayName);
        AutoBuyConfig config = AutoBuyConfig.getInstance();
        if (config.hasItemConfig(displayName)) {
            this.enabled = config.isItemEnabled(displayName);
        } else {
            this.enabled = true;
            config.loadItemSettings(displayName, price);
        }
    }

    @Override
    public String getDisplayName() {
        return displayName;
    }

    @Override
    public class_1799 createItemStack() {
        class_1799 stack = new class_1799(material);
        stack.method_57379(class_9334.field_49631, class_2561.method_43470(displayName).method_27692(class_124.field_1076));
        class_2487 nbt = new class_2487();
        nbt.method_10569("HideFlags", 127);
        nbt.method_10556("Unbreakable", true);
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbt));
        class_310 client = class_310.method_1551();
        if (client.field_1687 != null) {
            try {
                class_7225.class_7874 registryLookup = client.field_1687.method_30349();
                class_7225<class_1887> enchantmentRegistry = registryLookup.method_46762(class_7924.field_41265);
                class_9304.class_9305 builder = new class_9304.class_9305(
                        stack.method_58695(class_9334.field_49633, class_9304.field_49385));
                Optional<class_6880.class_6883<class_1887>> vanishingOpt =
                        enchantmentRegistry.method_46746(class_1893.field_9109);
                if (vanishingOpt.isPresent()) {
                    builder.method_57550(vanishingOpt.get(), 1);
                }
                stack.method_57379(class_9334.field_49633, builder.method_57549());
            } catch (Exception ignored) {}
        }
        if (loreTexts != null && !loreTexts.isEmpty()) {
            stack.method_57379(class_9334.field_49632, new class_9290(loreTexts));
        }
        stack.method_57379(class_9334.field_49641, true);
        return stack;
    }

    @Override
    public int getPrice() {
        return price;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Override
    public AutoBuyItemSettings getSettings() {
        return settings;
    }
}