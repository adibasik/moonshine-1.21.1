package moonshine.screens.clickgui.impl.autobuy.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class KrushItems {

    public static class_1799 getHelmet() {
        class_1799 stack = new class_1799(class_1802.field_22027);
        List<EnchantmentData> enchants = new ArrayList<>();
        enchants.add(new EnchantmentData(class_1893.field_9095, 5));
        enchants.add(new EnchantmentData(class_1893.field_9111, 5));
        enchants.add(new EnchantmentData(class_1893.field_9127, 3));
        enchants.add(new EnchantmentData(class_1893.field_9096, 5));
        enchants.add(new EnchantmentData(class_1893.field_9101, 1));
        enchants.add(new EnchantmentData(class_1893.field_9119, 5));
        enchants.add(new EnchantmentData(class_1893.field_9107, 5));
        enchants.add(new EnchantmentData(class_1893.field_9105, 1));
        addEnchantments(stack, enchants);
        setupItem(stack, createStyledName("Шлем Крушителя"),
                List.of(
                        class_2561.method_43470("[★] Оригинальный предмет").method_27692(class_124.field_1080)
                ));
        return stack;
    }

    public static class_1799 getChestplate() {
        class_1799 stack = new class_1799(class_1802.field_22028);
        List<EnchantmentData> enchants = new ArrayList<>();
        enchants.add(new EnchantmentData(class_1893.field_9111, 5));
        enchants.add(new EnchantmentData(class_1893.field_9107, 5));
        enchants.add(new EnchantmentData(class_1893.field_9095, 5));
        enchants.add(new EnchantmentData(class_1893.field_9096, 5));
        enchants.add(new EnchantmentData(class_1893.field_9119, 5));
        enchants.add(new EnchantmentData(class_1893.field_9101, 1));
        addEnchantments(stack, enchants);
        setupItem(stack, createStyledName("Нагрудник Крушителя"),
                List.of(
                        class_2561.method_43470("[★] Оригинальный предмет").method_27692(class_124.field_1080)
                ));
        return stack;
    }

    public static class_1799 getLeggings() {
        class_1799 stack = new class_1799(class_1802.field_22029);
        List<EnchantmentData> enchants = new ArrayList<>();
        enchants.add(new EnchantmentData(class_1893.field_9095, 5));
        enchants.add(new EnchantmentData(class_1893.field_9096, 5));
        enchants.add(new EnchantmentData(class_1893.field_9111, 5));
        enchants.add(new EnchantmentData(class_1893.field_9101, 1));
        enchants.add(new EnchantmentData(class_1893.field_9119, 5));
        enchants.add(new EnchantmentData(class_1893.field_9107, 5));
        addEnchantments(stack, enchants);
        setupItem(stack, createStyledName("Поножи Крушителя"),
                List.of(
                        class_2561.method_43470("[★] Оригинальный предмет").method_27692(class_124.field_1080)
                ));
        return stack;
    }

    public static class_1799 getBoots() {
        class_1799 stack = new class_1799(class_1802.field_22030);
        List<EnchantmentData> enchants = new ArrayList<>();
        enchants.add(new EnchantmentData(class_1893.field_9095, 5));
        enchants.add(new EnchantmentData(class_1893.field_9111, 5));
        enchants.add(new EnchantmentData(class_1893.field_23071, 3));
        enchants.add(new EnchantmentData(class_1893.field_9129, 4));
        enchants.add(new EnchantmentData(class_1893.field_9128, 3));
        enchants.add(new EnchantmentData(class_1893.field_9096, 5));
        enchants.add(new EnchantmentData(class_1893.field_9101, 1));
        enchants.add(new EnchantmentData(class_1893.field_9119, 5));
        enchants.add(new EnchantmentData(class_1893.field_9107, 5));
        addEnchantments(stack, enchants);
        setupItem(stack, createStyledName("Ботинки Крушителя"),
                List.of(
                        class_2561.method_43470("[★] Оригинальный предмет").method_27692(class_124.field_1080)
                ));
        return stack;
    }

    public static class_1799 getSword() {
        class_1799 stack = new class_1799(class_1802.field_22022);
        List<EnchantmentData> enchants = new ArrayList<>();
        enchants.add(new EnchantmentData(class_1893.field_9118, 7));
        enchants.add(new EnchantmentData(class_1893.field_9112, 7));
        enchants.add(new EnchantmentData(class_1893.field_9124, 2));
        enchants.add(new EnchantmentData(class_1893.field_9115, 3));
        enchants.add(new EnchantmentData(class_1893.field_9101, 1));
        enchants.add(new EnchantmentData(class_1893.field_9110, 5));
        enchants.add(new EnchantmentData(class_1893.field_9123, 7));
        enchants.add(new EnchantmentData(class_1893.field_9119, 5));
        addEnchantments(stack, enchants);
        setupItem(stack, createStyledName("Меч Крушителя"),
                List.of(
                        class_2561.method_43470("Опытный III").method_27692(class_124.field_1080),
                        class_2561.method_43470("Вампиризм II").method_27692(class_124.field_1080),
                        class_2561.method_43470("Окисление II").method_27692(class_124.field_1080),
                        class_2561.method_43470("Яд III").method_27692(class_124.field_1080),
                        class_2561.method_43470("Детекция III").method_27692(class_124.field_1080),
                        class_2561.method_43470("[★] Оригинальный предмет").method_27692(class_124.field_1080)
                ));
        return stack;
    }

    public static class_1799 getPickaxe() {
        class_1799 stack = new class_1799(class_1802.field_22024);
        List<EnchantmentData> enchants = new ArrayList<>();
        enchants.add(new EnchantmentData(class_1893.field_9131, 10));
        enchants.add(new EnchantmentData(class_1893.field_9101, 1));
        enchants.add(new EnchantmentData(class_1893.field_9130, 5));
        enchants.add(new EnchantmentData(class_1893.field_9119, 5));
        addEnchantments(stack, enchants);
        setupItem(stack, createStyledName("Кирка Крушителя"),
                List.of(
                        class_2561.method_43470("Бульдозер II").method_27692(class_124.field_1080),
                        class_2561.method_43470("Опытный III").method_27692(class_124.field_1080),
                        class_2561.method_43470("Магнит").method_27692(class_124.field_1080),
                        class_2561.method_43470("Авто-Плавка").method_27692(class_124.field_1080),
                        class_2561.method_43470("Паутина").method_27692(class_124.field_1080),
                        class_2561.method_43470("Пингер").method_27692(class_124.field_1080),
                        class_2561.method_43470("[★] Оригинальный предмет").method_27692(class_124.field_1080)
                ));
        return stack;
    }

    public static class_1799 getCrossbow() {
        class_1799 stack = new class_1799(class_1802.field_8399);
        List<EnchantmentData> enchants = new ArrayList<>();
        enchants.add(new EnchantmentData(class_1893.field_9108, 1));
        enchants.add(new EnchantmentData(class_1893.field_9101, 1));
        enchants.add(new EnchantmentData(class_1893.field_9132, 5));
        enchants.add(new EnchantmentData(class_1893.field_9119, 3));
        enchants.add(new EnchantmentData(class_1893.field_9098, 3));
        addEnchantments(stack, enchants);
        setupItem(stack, createStyledName("Арбалет Крушителя"),
                List.of(
                        class_2561.method_43470("[★] Оригинальный предмет").method_27692(class_124.field_1080)
                ));
        return stack;
    }

    public static class_1799 getBow() {
        class_1799 stack = new class_1799(class_1802.field_8102);
        List<EnchantmentData> enchants = new ArrayList<>();
        enchants.add(new EnchantmentData(class_1893.field_9103, 7));
        enchants.add(new EnchantmentData(class_1893.field_9116, 3));
        enchants.add(new EnchantmentData(class_1893.field_9126, 1));
        enchants.add(new EnchantmentData(class_1893.field_9125, 1));
        enchants.add(new EnchantmentData(class_1893.field_9119, 5));
        enchants.add(new EnchantmentData(class_1893.field_9101, 1));
        addEnchantments(stack, enchants);
        setupItem(stack, createStyledName("Лук Крушителя"),
                List.of(
                        class_2561.method_43470("Снайпер II").method_27692(class_124.field_1080),
                        class_2561.method_43470("Подрывник").method_27692(class_124.field_1080),
                        class_2561.method_43470("[★] Оригинальный предмет").method_27692(class_124.field_1080)
                ));
        return stack;
    }

    public static class_1799 getTrident() {
        class_1799 stack = new class_1799(class_1802.field_8547);
        List<EnchantmentData> enchants = new ArrayList<>();
        enchants.add(new EnchantmentData(class_1893.field_9117, 1));
        enchants.add(new EnchantmentData(class_1893.field_9118, 7));
        enchants.add(new EnchantmentData(class_1893.field_9124, 2));
        enchants.add(new EnchantmentData(class_1893.field_9101, 1));
        enchants.add(new EnchantmentData(class_1893.field_9119, 5));
        enchants.add(new EnchantmentData(class_1893.field_9120, 3));
        enchants.add(new EnchantmentData(class_1893.field_9106, 5));
        addEnchantments(stack, enchants);
        setupItem(stack, createStyledName("Трезубец Крушителя"),
                List.of(
                        class_2561.method_43470("Скаут III").method_27692(class_124.field_1080),
                        class_2561.method_43470("Опытный III").method_27692(class_124.field_1080),
                        class_2561.method_43470("Вампиризм II").method_27692(class_124.field_1080),
                        class_2561.method_43470("Ступор III").method_27692(class_124.field_1080),
                        class_2561.method_43470("Притяжение II").method_27692(class_124.field_1080),
                        class_2561.method_43470("Окисление II").method_27692(class_124.field_1080),
                        class_2561.method_43470("Возвращение").method_27692(class_124.field_1080),
                        class_2561.method_43470("Подрывник").method_27692(class_124.field_1080),
                        class_2561.method_43470("Яд III").method_27692(class_124.field_1080),
                        class_2561.method_43470("Детекция III").method_27692(class_124.field_1080),
                        class_2561.method_43470("[★] Оригинальный предмет").method_27692(class_124.field_1080)
                ));
        return stack;
    }

    public static class_1799 getMace() {
        class_1799 stack = new class_1799(class_1802.field_49814);
        List<EnchantmentData> enchants = new ArrayList<>();
        enchants.add(new EnchantmentData(class_1893.field_9118, 7));
        enchants.add(new EnchantmentData(class_1893.field_9123, 7));
        enchants.add(new EnchantmentData(class_1893.field_9112, 7));
        enchants.add(new EnchantmentData(class_1893.field_50157, 5));
        enchants.add(new EnchantmentData(class_1893.field_50158, 3));
        enchants.add(new EnchantmentData(class_1893.field_9115, 3));
        enchants.add(new EnchantmentData(class_1893.field_9124, 2));
        enchants.add(new EnchantmentData(class_1893.field_9110, 5));
        enchants.add(new EnchantmentData(class_1893.field_9119, 5));
        enchants.add(new EnchantmentData(class_1893.field_9101, 1));
        addEnchantments(stack, enchants);
        setupItem(stack, createStyledName("Булава Крушителя"),
                List.of(
                        class_2561.method_43470("Опытный III").method_27692(class_124.field_1080),
                        class_2561.method_43470("Вампиризм II").method_27692(class_124.field_1080),
                        class_2561.method_43470("Окисление II").method_27692(class_124.field_1080),
                        class_2561.method_43470("Яд III").method_27692(class_124.field_1080),
                        class_2561.method_43470("Детекция III").method_27692(class_124.field_1080),
                        class_2561.method_43470("[★] Оригинальный предмет").method_27692(class_124.field_1080)
                ));
        return stack;
    }

    public static class_1799 getElytra() {
        class_1799 stack = new class_1799(class_1802.field_8833);
        List<EnchantmentData> enchants = new ArrayList<>();
        enchants.add(new EnchantmentData(class_1893.field_9119, 5));
        enchants.add(new EnchantmentData(class_1893.field_9101, 1));
        addEnchantments(stack, enchants);
        setupItem(stack, createStyledName("Элитры Крушителя"),
                List.of(
                        class_2561.method_43470("[★] Оригинальный предмет").method_27692(class_124.field_1080)
                ));
        return stack;
    }

    private static void addEnchantments(class_1799 stack, List<EnchantmentData> enchantments) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            return;
        }

        try {
            class_7225.class_7874 registryLookup = client.field_1687.method_30349();
            class_7225<class_1887> enchantmentRegistry = registryLookup.method_46762(class_7924.field_41265);
            class_9304.class_9305 builder = new class_9304.class_9305(
                    stack.method_58695(class_9334.field_49633, class_9304.field_49385));

            for (EnchantmentData data : enchantments) {
                try {
                    Optional<class_6880.class_6883<class_1887>> enchantmentOpt =
                            enchantmentRegistry.method_46746(data.key);

                    if (enchantmentOpt.isPresent()) {
                        builder.method_57550(enchantmentOpt.get(), data.level);
                    }
                } catch (Exception ignored) {
                }
            }

            stack.method_57379(class_9334.field_49633, builder.method_57549());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void setupItem(class_1799 stack, class_2561 name, List<class_2561> lore) {
        stack.method_57379(class_9334.field_49631, name);
        class_2487 nbt = new class_2487();
        nbt.method_10569("HideFlags", 127);
        nbt.method_10556("Unbreakable", true);
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbt));
        if (!lore.isEmpty()) {
            stack.method_57379(class_9334.field_49632, new class_9290(lore));
        }
    }

    private static class_2561 createStyledName(String baseName) {
        return class_2561.method_43470(baseName).method_27695(class_124.field_1067, class_124.field_1079);
    }

    private static class EnchantmentData {
        final class_5321<class_1887> key;
        final int level;

        EnchantmentData(class_5321<class_1887> key, int level) {
            this.key = key;
            this.level = level;
        }
    }
}