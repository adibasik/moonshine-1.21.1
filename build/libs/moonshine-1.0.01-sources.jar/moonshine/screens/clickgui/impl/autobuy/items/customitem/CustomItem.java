package moonshine.screens.clickgui.impl.autobuy.items.customitem;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.properties.PropertyMap;
import com.google.common.collect.ImmutableMultimap;
import moonshine.screens.clickgui.impl.autobuy.AutoBuyableItem;
import moonshine.screens.clickgui.impl.autobuy.settings.AutoBuyItemSettings;
import moonshine.util.config.impl.autobuyconfig.AutoBuyConfig;
import net.minecraft.class_1293;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9296;
import net.minecraft.class_9334;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class CustomItem implements AutoBuyableItem {
    private final String displayName;
    private final class_2487 nbt;
    private final class_1792 material;
    private final int price;
    private final class_1844 potionContents;
    private final List<class_2561> loreTexts;
    private final AutoBuyItemSettings settings;
    private final boolean hasGlint;
    private boolean enabled;

    public CustomItem(String displayName, class_2487 nbt, class_1792 material, int price, class_1844 potionContents, List<class_2561> loreTexts) {
        this(displayName, nbt, material, price, potionContents, loreTexts, shouldHaveGlint(material, displayName), false);
    }

    public CustomItem(String displayName, class_2487 nbt, class_1792 material, int price, class_1844 potionContents, List<class_2561> loreTexts, boolean hasGlint) {
        this(displayName, nbt, material, price, potionContents, loreTexts, hasGlint, false);
    }

    public CustomItem(String displayName, class_2487 nbt, class_1792 material, int price, class_1844 potionContents, List<class_2561> loreTexts, boolean hasGlint, boolean canHaveQuantity) {
        this.displayName = displayName;
        this.nbt = nbt;
        this.material = material;
        this.price = price;
        this.potionContents = potionContents;
        this.loreTexts = loreTexts;
        this.hasGlint = hasGlint;
        this.settings = new AutoBuyItemSettings(price, material, displayName, canHaveQuantity);
        AutoBuyConfig config = AutoBuyConfig.getInstance();
        if (config.hasItemConfig(displayName)) {
            this.enabled = config.isItemEnabled(displayName);
        } else {
            this.enabled = true;
            config.loadItemSettings(displayName, price);
        }
    }

    public CustomItem(String displayName, class_2487 nbt, class_1792 material, int price) {
        this(displayName, nbt, material, price, null, null);
    }

    public CustomItem(String displayName, class_2487 nbt, class_1792 material, int price, boolean canHaveQuantity) {
        this(displayName, nbt, material, price, null, null, shouldHaveGlint(material, displayName), canHaveQuantity);
    }

    public CustomItem(String displayName, class_2487 nbt, class_1792 material, int price, class_1844 potionContents, List<class_2561> loreTexts, int minQuantity) {
        this(displayName, nbt, material, price, potionContents, loreTexts, shouldHaveGlint(material, displayName), true);
    }

    private static boolean shouldHaveGlint(class_1792 material, String displayName) {
        if (material == class_1802.field_8288 || material == class_1802.field_8833) {
            return false;
        }
        if (material == class_1802.field_22027 ||
                material == class_1802.field_22028 ||
                material == class_1802.field_22029 ||
                material == class_1802.field_22030 ||
                material == class_1802.field_22022 ||
                material == class_1802.field_22024 ||
                material == class_1802.field_22025 ||
                material == class_1802.field_22023 ||
                material == class_1802.field_22026 ||
                material == class_1802.field_8805 ||
                material == class_1802.field_8058 ||
                material == class_1802.field_8348 ||
                material == class_1802.field_8285 ||
                material == class_1802.field_8802 ||
                material == class_1802.field_8377 ||
                material == class_1802.field_8556 ||
                material == class_1802.field_8250 ||
                material == class_1802.field_8527 ||
                material == class_1802.field_8743 ||
                material == class_1802.field_8523 ||
                material == class_1802.field_8396 ||
                material == class_1802.field_8660 ||
                material == class_1802.field_8371 ||
                material == class_1802.field_8403 ||
                material == class_1802.field_8475 ||
                material == class_1802.field_8699 ||
                material == class_1802.field_8609 ||
                material == class_1802.field_8862 ||
                material == class_1802.field_8678 ||
                material == class_1802.field_8416 ||
                material == class_1802.field_8753 ||
                material == class_1802.field_8845 ||
                material == class_1802.field_8335 ||
                material == class_1802.field_8825 ||
                material == class_1802.field_8322 ||
                material == class_1802.field_8303 ||
                material == class_1802.field_8102 ||
                material == class_1802.field_8399 ||
                material == class_1802.field_8547 ||
                material == class_1802.field_49814 ||
                material == class_1802.field_8255 ||
                material == class_1802.field_8378) {
            return true;
        }
        if (displayName != null && displayName.contains("[★]")) {
            if (material == class_1802.field_8574 || material == class_1802.field_8436 || material == class_1802.field_8150) {
                return true;
            }
        }
        return false;
    }

    public String getDisplayName() {
        return displayName;
    }

    public class_1799 createItemStack() {
        class_1799 stack = new class_1799(material);
        stack.method_57379(class_9334.field_49631, class_2561.method_43470(displayName));
        if (isPotion(material)) {
            if (potionContents != null) {
                stack.method_57379(class_9334.field_49651, potionContents);
            } else {
                int color = getPotionColorByName(displayName);
                stack.method_57379(class_9334.field_49651, new class_1844(
                        Optional.empty(),
                        Optional.of(color),
                        List.<class_1293>of(),
                        Optional.empty()
                ));
            }
        }
        if (loreTexts != null && !loreTexts.isEmpty()) {
            stack.method_57379(class_9334.field_49632, new class_9290(loreTexts));
        }
        if (hasGlint) {
            stack.method_57379(class_9334.field_49641, true);
        }
        if (nbt != null) {
            class_2487 nbtCopy = nbt.method_10553();
            if (material == class_1802.field_8575 && nbtCopy.method_10562("SkullOwner").isPresent()) {
                class_2487 skullOwner = nbtCopy.method_10562("SkullOwner").get();
                Optional<int[]> idArray = skullOwner.method_10561("Id");
                UUID id;
                if (idArray.isPresent()) {
                    int[] arr = idArray.get();
                    id = uuidFromIntArray(arr);
                } else {
                    Optional<String> idString = skullOwner.method_10558("Id");
                    id = idString.map(UUID::fromString).orElse(UUID.randomUUID());
                }
                ImmutableMultimap.Builder<String, Property> builder = ImmutableMultimap.builder();
                Optional<class_2487> propertiesOpt = skullOwner.method_10562("Properties");
                if (propertiesOpt.isPresent()) {
                    class_2487 properties = propertiesOpt.get();
                    Optional<class_2499> texturesOpt = properties.method_10554("textures");
                    if (texturesOpt.isPresent()) {
                        class_2499 textures = texturesOpt.get();
                        if (!textures.isEmpty()) {
                            Optional<class_2487> textureNbtOpt = textures.method_10602(0);
                            if (textureNbtOpt.isPresent()) {
                                Optional<String> valueOpt = textureNbtOpt.get().method_10558("Value");
                                if (valueOpt.isPresent()) {
                                    builder.put("textures", new Property("textures", valueOpt.get()));
                                }
                            }
                        }
                    }
                }
                PropertyMap propertyMap = new PropertyMap(builder.build());
                GameProfile profile = new GameProfile(id, "", propertyMap);
                stack.method_57379(class_9334.field_49617, class_9296.method_73307(profile));
                nbtCopy.method_10551("SkullOwner");
            }
            if (!nbtCopy.method_33133()) {
                stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbtCopy));
            }
        }
        return stack;
    }

    private boolean isPotion(class_1792 item) {
        return item == class_1802.field_8574 || item == class_1802.field_8436 || item == class_1802.field_8150;
    }

    private int getPotionColorByName(String name) {
        return switch (name) {
            case "Зелье отрыжки" -> 0xFF5D00;
            case "Зелье серной кислоты" -> 0x00C200;
            case "Зелье вспышки" -> 0xFFFFFF;
            case "Зелье мочи Флеша" -> 0x5CF7FF;
            case "Зелье победителя" -> 0x00FF00;
            case "Зелье агента" -> 0xFFFB00;
            case "Зелье медика" -> 0xFF00DE;
            case "Зелье киллера" -> 0xFF0000;
            case "[★] Хлопушка" -> 0xFF69B4;
            case "[★] Святая вода" -> 0xFFFFFF;
            case "[★] Зелье Гнева" -> 0x993333;
            case "[★] Зелье Палладина" -> 0x00FFFF;
            case "[★] Зелье Ассасина" -> 0x333333;
            case "[★] Зелье Радиации" -> 0x32CD32;
            case "[★] Снотворное" -> 0x484848;
            case "[🍹] Мандариновый сок" -> 0xD6CE43;
            default -> 0x385DC6;
        };
    }

    private static UUID uuidFromIntArray(int[] arr) {
        if (arr.length != 4) {
            return UUID.randomUUID();
        }
        long mostSig = ((long) arr[0] << 32) | (arr[1] & 0xFFFFFFFFL);
        long leastSig = ((long) arr[2] << 32) | (arr[3] & 0xFFFFFFFFL);
        return new UUID(mostSig, leastSig);
    }

    public int getPrice() {
        return price;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Override
    public AutoBuyItemSettings getSettings() {
        return settings;
    }
}