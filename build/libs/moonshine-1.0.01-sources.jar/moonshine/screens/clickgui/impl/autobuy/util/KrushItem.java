package moonshine.screens.clickgui.impl.autobuy.util;

import moonshine.screens.clickgui.impl.autobuy.AutoBuyableItem;
import moonshine.screens.clickgui.impl.autobuy.settings.AutoBuyItemSettings;
import moonshine.util.config.impl.autobuyconfig.AutoBuyConfig;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_9334;

public class KrushItem implements AutoBuyableItem {
    private final String displayName;
    private final class_1792 material;
    private final class_1799 displayStack;
    private final int defaultPrice;
    private final AutoBuyItemSettings settings;
    private final boolean isKrushItem;
    private boolean enabled;

    public KrushItem(String displayName, class_1792 material, class_1799 displayStack, int defaultPrice) {
        this(displayName, material, displayStack, defaultPrice, true, false);
    }

    public KrushItem(String displayName, class_1792 material, class_1799 displayStack, int defaultPrice, boolean canHaveQuantity) {
        this(displayName, material, displayStack, defaultPrice, canHaveQuantity, false);
    }

    public KrushItem(String displayName, class_1792 material, class_1799 displayStack, int defaultPrice, boolean canHaveQuantity, boolean isKrushItem) {
        this.displayName = displayName;
        this.material = material;
        this.displayStack = displayStack;
        this.defaultPrice = defaultPrice;
        this.isKrushItem = isKrushItem;
        this.settings = new AutoBuyItemSettings(defaultPrice, material, displayName, canHaveQuantity);
        AutoBuyConfig config = AutoBuyConfig.getInstance();
        if (config.hasItemConfig(displayName)) {
            this.enabled = config.isItemEnabled(displayName);
        } else {
            this.enabled = true;
            config.loadItemSettings(displayName, defaultPrice);
        }
    }

    private boolean shouldHaveGlint() {
        if (!isKrushItem) {
            return false;
        }
        return material == class_1802.field_8288 ||
                material == class_1802.field_22027 ||
                material == class_1802.field_22028 ||
                material == class_1802.field_22029 ||
                material == class_1802.field_22030 ||
                material == class_1802.field_22022 ||
                material == class_1802.field_22024 ||
                material == class_1802.field_22025 ||
                material == class_1802.field_22023 ||
                material == class_1802.field_22026 ||
                material == class_1802.field_8805 ||
                material == class_1802.field_8058 ||
                material == class_1802.field_8348 ||
                material == class_1802.field_8285 ||
                material == class_1802.field_8802 ||
                material == class_1802.field_8377 ||
                material == class_1802.field_8556 ||
                material == class_1802.field_8250 ||
                material == class_1802.field_8527 ||
                material == class_1802.field_8743 ||
                material == class_1802.field_8523 ||
                material == class_1802.field_8396 ||
                material == class_1802.field_8660 ||
                material == class_1802.field_8371 ||
                material == class_1802.field_8403 ||
                material == class_1802.field_8475 ||
                material == class_1802.field_8699 ||
                material == class_1802.field_8609 ||
                material == class_1802.field_8862 ||
                material == class_1802.field_8678 ||
                material == class_1802.field_8416 ||
                material == class_1802.field_8753 ||
                material == class_1802.field_8845 ||
                material == class_1802.field_8335 ||
                material == class_1802.field_8825 ||
                material == class_1802.field_8322 ||
                material == class_1802.field_8303 ||
                material == class_1802.field_8102 ||
                material == class_1802.field_8399 ||
                material == class_1802.field_8547 ||
                material == class_1802.field_49814 ||
                material == class_1802.field_8833 ||
                material == class_1802.field_8255 ||
                material == class_1802.field_8378;
    }

    @Override
    public String getDisplayName() {
        return displayName;
    }

    @Override
    public class_1799 createItemStack() {
        class_1799 copy = displayStack.method_7972();
        if (shouldHaveGlint()) {
            copy.method_57379(class_9334.field_49641, true);
        }
        return copy;
    }

    @Override
    public int getPrice() {
        return settings.getBuyBelow();
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Override
    public AutoBuyItemSettings getSettings() {
        return settings;
    }
}