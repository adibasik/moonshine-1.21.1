package moonshine.screens.hud;

import com.mojang.authlib.GameProfile;
import moonshine.client.draggables.AbstractHudElement;
import moonshine.util.ColorUtil;
import moonshine.util.animations.Direction;
import moonshine.util.render.Render2D;
import moonshine.util.render.shader.Scissor;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_640;
import net.minecraft.class_8685;
import moonshine.util.render.font.Fonts;

import java.awt.*;
import java.util.*;
import java.util.regex.Pattern;

public class Staff extends AbstractHudElement {

    private static final Pattern NAME_PATTERN = Pattern.compile("^\\w{3,16}$");
    private static final Pattern DIGIT_ONLY_PATTERN = Pattern.compile("^\\d{1,4}$");
    private static final class_2960 STEVE_SKIN = class_2960.method_60655("moonshine", "textures/entity/player/wide/steve.png");

    private static class StaffInfo {
        String name;
        GameProfile profile;
        class_2960 skin;

        StaffInfo(String name, GameProfile profile, class_2960 skin) {
            this.name = name;
            this.profile = profile;
            this.skin = skin;
        }
    }

    private Map<String, StaffInfo> staffMap = new LinkedHashMap<>();
    private Map<String, Float> staffAnimations = new LinkedHashMap<>();
    private Set<String> activeStaffIds = new HashSet<>();
    private class_2960 cachedRandomSkin = null;
    private boolean skinCached = false;

    private float animatedWidth = 80;
    private float animatedHeight = 23;
    private long lastUpdateTime = System.currentTimeMillis();

    private static final float ANIMATION_SPEED = 8.0f;
    private static final float FACE_SIZE = 8f;
    private static final float CIRCLE_SIZE = 5f;

    public Staff() {
        super("Staff", 300, 150, 80, 23, true);
        stopAnimation();
    }

    @Override
    public boolean visible() {
        return !scaleAnimation.isFinished(Direction.BACKWARDS);
    }

    private class_2960 getSkinFromEntry(class_640 entry) {
        try {
            class_8685 skinTextures = entry.method_52810();
            if (skinTextures != null && skinTextures.comp_1626() != null) {
                class_2960 texturePath = skinTextures.comp_1626().comp_3627();
                if (texturePath != null) {
                    return texturePath;
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private class_2960 findRandomOnlineSkin() {
        if (mc.field_1724 == null || mc.field_1724.field_3944 == null) {
            return STEVE_SKIN;
        }

        List<class_640> players = new ArrayList<>(mc.field_1724.field_3944.method_2880());
        Collections.shuffle(players);

        for (class_640 entry : players) {
            class_2960 skin = getSkinFromEntry(entry);
            if (skin != null) {
                return skin;
            }
        }

        return STEVE_SKIN;
    }

    private class_2960 getCachedSkin() {
        if (!skinCached || cachedRandomSkin == null) {
            if (mc.field_1724 != null && mc.field_1724.field_3944 != null) {
                class_2960 found = findRandomOnlineSkin();
                if (found != null && !found.equals(STEVE_SKIN)) {
                    cachedRandomSkin = found;
                    skinCached = true;
                } else if (cachedRandomSkin == null) {
                    cachedRandomSkin = STEVE_SKIN;
                }
            } else {
                cachedRandomSkin = STEVE_SKIN;
            }
        }
        return cachedRandomSkin;
    }

    @Override
    public void tick() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            staffMap.clear();
            activeStaffIds.clear();
            cachedRandomSkin = null;
            skinCached = false;
            stopAnimation();
            return;
        }

        String myName = mc.field_1724.method_5477().getString();
        activeStaffIds.clear();

        class_269 scoreboard = mc.field_1687.method_8428();
        List<class_268> teams = new ArrayList<>(scoreboard.method_1159());
        teams.sort(Comparator.comparing(class_268::method_1197));

        Collection<class_640> online = mc.field_1724.field_3944.method_2880();
        Set<String> onlineNames = new HashSet<>();
        for (class_640 entry : online) {
            if (entry.method_2966() != null && entry.method_2966().name() != null) {
                onlineNames.add(entry.method_2966().name());
            }
        }

        for (class_268 team : teams) {
            Collection<String> members = team.method_1204();
            if (members.size() != 1) continue;
            String name = members.iterator().next();
            if (!NAME_PATTERN.matcher(name).matches()) continue;
            if (name.equals(myName)) continue;
            if (DIGIT_ONLY_PATTERN.matcher(name).matches()) continue;

            boolean isOnline = onlineNames.contains(name);

            if (!isOnline) {
                activeStaffIds.add(name);

                if (!staffMap.containsKey(name)) {
                    GameProfile fakeProfile = new GameProfile(UUID.randomUUID(), name);
                    class_2960 randomSkin = findRandomOnlineSkin();
                    staffMap.put(name, new StaffInfo(name, fakeProfile, randomSkin));
                }

                if (!staffAnimations.containsKey(name)) {
                    staffAnimations.put(name, 0f);
                }
            }
        }

        boolean hasActiveStaff = !activeStaffIds.isEmpty() || !staffAnimations.isEmpty();
        boolean inChat = isChat(mc.field_1755);

        if (hasActiveStaff || inChat) {
            startAnimation();
        } else {
            stopAnimation();
        }
    }

    private float lerp(float current, float target, float deltaTime) {
        float factor = (float) (1.0 - Math.pow(0.001, deltaTime * ANIMATION_SPEED));
        return current + (target - current) * factor;
    }

    @Override
    public void drawDraggable(class_332 context, int alpha) {
        if (alpha <= 0) return;

        float alphaFactor = alpha / 255.0f;

        long currentTime = System.currentTimeMillis();
        float deltaTime = (currentTime - lastUpdateTime) / 1000.0f;
        lastUpdateTime = currentTime;
        deltaTime = Math.min(deltaTime, 0.1f);

        List<String> toRemove = new ArrayList<>();
        for (Map.Entry<String, Float> entry : staffAnimations.entrySet()) {
            String id = entry.getKey();
            float currentAnim = entry.getValue();
            float targetAnim = activeStaffIds.contains(id) ? 1f : 0f;
            float newAnim = lerp(currentAnim, targetAnim, deltaTime);

            if (Math.abs(newAnim - targetAnim) < 0.01f) {
                newAnim = targetAnim;
            }

            if (newAnim <= 0.01f && targetAnim == 0f) {
                toRemove.add(id);
            } else {
                staffAnimations.put(id, newAnim);
            }
        }
        for (String id : toRemove) {
            staffAnimations.remove(id);
            staffMap.remove(id);
        }

        float x = getX();
        float y = getY();

        boolean hasAnimatingStaff = !staffAnimations.isEmpty();
        boolean showExample = !hasAnimatingStaff && isChat(mc.field_1755);

        int offset = 23;
        float targetWidth = 80;

        if (showExample) {
            offset += 11;
            String name = "ExampleStaff";
            float nameWidth = Fonts.BOLD.getWidth(name, 6);
            targetWidth = Math.max(nameWidth + 55, targetWidth);
        } else if (hasAnimatingStaff) {
            for (Map.Entry<String, Float> entry : staffAnimations.entrySet()) {
                String id = entry.getKey();
                float animation = entry.getValue();
                if (animation <= 0) continue;

                StaffInfo info = staffMap.get(id);
                if (info == null) continue;

                offset += (int) (animation * 11);

                float nameWidth = Fonts.BOLD.getWidth(info.name, 6);
                targetWidth = Math.max(nameWidth + 55, targetWidth);
            }
        }

        float targetHeight = offset + 2;

        animatedWidth = lerp(animatedWidth, targetWidth, deltaTime);
        animatedHeight = lerp(animatedHeight, targetHeight, deltaTime);

        if (Math.abs(animatedWidth - targetWidth) < 0.3f) {
            animatedWidth = targetWidth;
        }
        if (Math.abs(animatedHeight - targetHeight) < 0.3f) {
            animatedHeight = targetHeight;
        }

        setWidth((int) Math.ceil(animatedWidth));
        setHeight((int) Math.ceil(animatedHeight));

        float contentHeight = animatedHeight;
        int bgAlpha = (int) (255 * alphaFactor);

        if (contentHeight > 0) {
            Render2D.gradientRect(x, y, getWidth(), contentHeight,
                    new int[]{
                            moonshine.util.color.ClientColors.primary(bgAlpha),
                            moonshine.util.color.ClientColors.secondary(bgAlpha),
                            moonshine.util.color.ClientColors.primary(bgAlpha),
                            moonshine.util.color.ClientColors.secondary(bgAlpha)
                    },
                    5);
            Render2D.outline(x, y, getWidth(), contentHeight, 0.35f, new Color(90, 90, 90, bgAlpha).getRGB(), 5);
        }

        Scissor.enable(x, y, getWidth(), contentHeight, 2);

        Render2D.gradientRect(x + getWidth() - 18.5f, y + 5, 14, 12,
                new int[]{
                        moonshine.util.color.ClientColors.primary(bgAlpha),
                        moonshine.util.color.ClientColors.primary(bgAlpha),
                        moonshine.util.color.ClientColors.primary(bgAlpha),
                        moonshine.util.color.ClientColors.primary(bgAlpha)
                },
                3);

        Fonts.ICONS.draw("E", x + getWidth() - 15.5f, y + 7.5f, 8, new Color(165, 165, 165, bgAlpha).getRGB());
        Fonts.BOLD.draw("Staff", x + 8, y + 6.5f, 6, new Color(255, 255, 255, bgAlpha).getRGB());

        int moduleOffset = 23;

        class_2960 exampleSkin = getCachedSkin();

        if (showExample) {
            String name = "ExampleStaff";

            float faceX = x + 8;
            float faceY = y + moduleOffset - 2f;

            drawFace(exampleSkin, faceX, faceY, bgAlpha);

            float nameX = x + 8 + FACE_SIZE + 4;
            Fonts.BOLD.draw(name, nameX, y + moduleOffset - 1.5f, 6, new Color(255, 255, 255, bgAlpha).getRGB());

            float circleX = x + getWidth() - 14f;
            float circleY = y + moduleOffset - 0.5f;

            drawStatusCircle(circleX, circleY, bgAlpha);

        } else if (hasAnimatingStaff) {
            for (Map.Entry<String, Float> entry : staffAnimations.entrySet()) {
                String id = entry.getKey();
                float animation = entry.getValue();
                if (animation <= 0) continue;

                StaffInfo info = staffMap.get(id);
                if (info == null) continue;

                class_2960 skinToUse = info.skin != null ? info.skin : STEVE_SKIN;

                int textAlpha = (int) (255 * animation * alphaFactor);

                float faceX = x + 8;
                float faceY = y + moduleOffset - 2f;

                drawFace(skinToUse, faceX, faceY, textAlpha);

                float nameX = faceX + FACE_SIZE + 4;
                Fonts.BOLD.draw(info.name, nameX, y + moduleOffset - 1.5f, 6, new Color(255, 255, 255, textAlpha).getRGB());

                float circleX = x + getWidth() - 14f;
                float circleY = y + moduleOffset - 0.5f;

                drawStatusCircle(circleX, circleY, textAlpha);

                moduleOffset += (int) (animation * 11);
            }
        }

        Scissor.disable();
    }

    private void drawFace(class_2960 skin, float faceX, float faceY, int alpha) {
        int color = new Color(255, 255, 255, alpha).getRGB();

        Render2D.texture(skin, faceX, faceY, FACE_SIZE, FACE_SIZE,
                8f / 64f, 8f / 64f, 16f / 64f, 16f / 64f, color, 0, 2f);

        float hatScale = 1.15f;
        float hatSize = FACE_SIZE * hatScale;
        float hatOffset = (hatSize - FACE_SIZE) / 2f;

        Render2D.texture(skin, faceX - hatOffset, faceY - hatOffset, hatSize, hatSize,
                40f / 64f, 8f / 64f, 48f / 64f, 16f / 64f, color, 0, 2f);

        Render2D.blur(faceX, faceY, 1, 1, 0f, 0, ColorUtil.rgba(0, 0, 0, 0));
    }

    private void drawStatusCircle(float circleX, float circleY, int alpha) {
        Render2D.gradientRect(circleX - 3, circleY - 2, 11, 9,
                new int[]{
                        moonshine.util.color.ClientColors.primary(alpha),
                        moonshine.util.color.ClientColors.primary(alpha),
                        moonshine.util.color.ClientColors.primary(alpha),
                        moonshine.util.color.ClientColors.primary(alpha)
                },
                3);

        Render2D.outline(circleX - 3, circleY - 2, 11, 9, 0.35f, new Color(90, 90, 90, alpha).getRGB(), 3);
        Render2D.rect(circleX, circleY, CIRCLE_SIZE, CIRCLE_SIZE, new Color(255, 80, 80, alpha).getRGB(), CIRCLE_SIZE / 2f);
    }
}