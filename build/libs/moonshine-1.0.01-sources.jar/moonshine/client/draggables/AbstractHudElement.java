package moonshine.client.draggables;

import moonshine.util.animations.Animation;
import moonshine.util.animations.Decelerate;
import moonshine.util.animations.Direction;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_437;

public abstract class AbstractHudElement implements HudElement {

    protected int x, y, width, height;
    protected String name;
    protected boolean enabled = true;
    protected boolean draggable = true;

    protected final class_310 mc = class_310.method_1551();
    protected final Animation scaleAnimation = new Decelerate().setMs(300).setValue(1);
    protected float lastTickDelta = 0f;

    public AbstractHudElement(String name, int x, int y, int width, int height, boolean draggable) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.draggable = draggable;
    }

    @Override
    public void render(class_332 context, float tickDelta) {
        if (!visible()) return;

        this.lastTickDelta = tickDelta;
        scaleAnimation.update();

        int alpha = (int) (scaleAnimation.getOutput().floatValue() * 255);
        if (alpha <= 0) return;

        drawDraggable(context, alpha);
    }

    public abstract void drawDraggable(class_332 context, int alpha);

    @Override
    public void tick() {
    }

    @Override
    public boolean visible() {
        return true;
    }

    public void startAnimation() {
        scaleAnimation.setDirection(Direction.FORWARDS);
    }

    public void stopAnimation() {
        scaleAnimation.setDirection(Direction.BACKWARDS);
    }

    protected boolean isChat(class_437 screen) {
        return screen instanceof class_408;
    }

    public boolean isDraggable() {
        return draggable;
    }

    public float getLastTickDelta() {
        return lastTickDelta;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getX() {
        return x;
    }

    @Override
    public int getY() {
        return y;
    }

    @Override
    public void setX(int x) {
        this.x = x;
    }

    @Override
    public void setY(int y) {
        this.y = y;
    }

    @Override
    public int getWidth() {
        return width;
    }

    @Override
    public int getHeight() {
        return height;
    }

    @Override
    public void setWidth(int width) {
        this.width = width;
    }

    @Override
    public void setHeight(int height) {
        this.height = height;
    }
}