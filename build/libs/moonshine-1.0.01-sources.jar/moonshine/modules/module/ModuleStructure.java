package moonshine.modules.module;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.NonFinal;
import org.lwjgl.glfw.GLFW;
import moonshine.IMinecraft;
import moonshine.Initialization;
import moonshine.events.api.EventManager;
import moonshine.events.impl.ModuleToggleEvent;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.SettingRepository;
import moonshine.modules.impl.render.Hud;
import moonshine.screens.hud.Notifications;
import moonshine.util.animations.Animation;
import moonshine.util.animations.Decelerate;
import moonshine.util.animations.Direction;
import moonshine.util.selfdestruct.SelfDestructManager;
import net.minecraft.class_310;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ModuleStructure extends SettingRepository implements IMinecraft {
    String name;
    String description;
    ModuleCategory category;
    Animation animation = new Decelerate().setMs(175).setValue(1);

    public ModuleStructure(String name, ModuleCategory category) {
        this.name = name;
        this.category = category;
        this.description = "";
    }

    public ModuleStructure(String name, String description, ModuleCategory category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    @NonFinal
    int key = GLFW.GLFW_KEY_UNKNOWN, type = 1;

    @NonFinal
    public boolean state;

    @NonFinal
    public boolean favorite;

    public void switchState() {
        setState(!state);
    }

    public void setState(boolean state) {
        if (state && SelfDestructManager.blocksModuleActivation(this)) {
            return;
        }
        animation.setDirection(state ? Direction.FORWARDS : Direction.BACKWARDS);
        if (state != this.state) {
            this.state = state;
            handleStateChange();
        }
    }

    public void switchFavorite() {
        setFavorite(!favorite);
    }

    public void setFavorite(boolean favorite) {
        this.favorite = favorite;
    }

    private void handleStateChange() {
        class_310 mc = class_310.method_1551();

        if (mc.field_1724 != null && mc.field_1687 != null) {
            Hud hud = Hud.getInstance();
            Notifications notifications = Notifications.getInstance();

            if (hud != null && hud.isState() && notifications != null) {
                if (hud.interfaceSettings.isSelected("Notifications")) {
                    if (state) {
                        notifications.addNotification("Feature "  + name + " - enabled!", 2000);
                    } else {
                        notifications.addNotification("Feature " + name + " - disabled!", 2000);
                    }
                }
            }

            if (state) {
                activate();
            } else {
                deactivate();
            }
        }
        toggleSilent(state);

        ModuleToggleEvent event = new ModuleToggleEvent(this, state);
        EventManager.callEvent(event);
    }

    private void toggleSilent(boolean activate) {
        var eventManager = Initialization.getInstance().getManager().getEventManager();
        if (activate) {
            eventManager.register(this);
        } else {
            eventManager.unregister(this);
        }
    }

    public void activate() {
    }

    public void deactivate() {
    }
}
