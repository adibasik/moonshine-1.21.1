package moonshine.modules.impl.misc;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import org.lwjgl.glfw.GLFW;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.HotBarScrollEvent;
import moonshine.events.impl.InputEvent;
import moonshine.events.impl.KeyEvent;
import moonshine.events.impl.TickEvent;
import moonshine.mixin.ClientWorldAccessor;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BindSetting;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.screens.clickgui.impl.settingsrender.BindComponent;
import moonshine.util.inventory.InventoryUtils;
import moonshine.util.inventory.MovementController;
import moonshine.util.inventory.SwapSettings;
import moonshine.util.string.chat.ChatMessage;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_10192;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_3675;
import net.minecraft.class_7202;
import net.minecraft.class_9334;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ElytraHelper extends ModuleStructure {

    final SelectSetting modeSetting = new SelectSetting("Режим", "Способ свапа")
            .value("Instant", "Legit")
            .selected("Legit");

    final BindSetting swapBind = new BindSetting("Кнопка свапа", "Кнопка для смены элитры/нагрудника");
    final BindSetting fireworkBind = new BindSetting("Кнопка фейерверка", "Кнопка для использования фейерверка");
    final BooleanSetting autoTakeoff = new BooleanSetting("Авто взлёт", "Автоматический взлёт при надетой элитре").setValue(false);
    final BooleanSetting autoFirework = new BooleanSetting("Авто фейерверк", "Автоматическое использование фейерверка при полёте")
            .setValue(false)
            .visible(() -> autoTakeoff.isValue());

    enum SwapPhase {
        IDLE, PRE_STOP, STOPPING, WAIT_STOP, PRE_SWAP, SWAP_ARMOR, POST_SWAP, RESUMING
    }

    enum FireworkPhase {
        IDLE, PRE_STOP, STOPPING, WAIT_STOP, PRE_SWAP, SWAP_TO_HAND, AWAIT_ITEM, USE, POST_USE, SWAP_BACK, RESUMING
    }

    final MovementController swapMovement = new MovementController();
    final MovementController fireworkMovement = new MovementController();

    final StopWatch fireworkCooldown = new StopWatch();
    final StopWatch autoFireworkTimer = new StopWatch();

    SwapPhase swapPhase = SwapPhase.IDLE;
    FireworkPhase fireworkPhase = FireworkPhase.IDLE;

    int armorSlot = -1;
    int fireworkSlot = -1;
    int savedFireworkSlot = -1;
    boolean fireworkFromInventory = false;

    long swapPhaseStartTime = 0;
    long fireworkPhaseStartTime = 0;

    int swapCurrentDelay = 0;
    int fireworkCurrentDelay = 0;

    boolean shouldJumpForTakeoff = false;

    public ElytraHelper() {
        super("ElytraHelper", "Elytra Helper", ModuleCategory.MISC);
        settings(modeSetting, swapBind, fireworkBind);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void onKey(KeyEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1755 != null) return;
        if (e.action() != 1) return;

        if (matchesBind(e, swapBind) && swapPhase == SwapPhase.IDLE) {
            startArmorSwap();
        }

        if (matchesBind(e, fireworkBind) && fireworkPhase == FireworkPhase.IDLE) {
            if (!isElytraEquipped()) {
                return;
            }
            if (fireworkCooldown.finished(500)) {
                useFirework();
                fireworkCooldown.reset();
            }
        }
    }

    @EventHandler
    public void onScroll(HotBarScrollEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1755 != null) return;

        if (matchesScrollBind(e, swapBind) && swapPhase == SwapPhase.IDLE) {
            e.setCancelled(true);
            startArmorSwap();
        }

        if (matchesScrollBind(e, fireworkBind) && fireworkPhase == FireworkPhase.IDLE) {
            if (!isElytraEquipped()) {
                return;
            }
            if (fireworkCooldown.finished(500)) {
                e.setCancelled(true);
                useFirework();
                fireworkCooldown.reset();
            }
        }
    }

    private boolean matchesBind(KeyEvent e, BindSetting bind) {
        int bindKey = bind.getKey();
        int bindType = bind.getType();

        if (bindKey == GLFW.GLFW_KEY_UNKNOWN || bindKey == -1) return false;

        if (bindType == 2) {
            if (bindKey == BindComponent.MIDDLE_MOUSE_BIND
                    && e.type() == class_3675.class_307.field_1672
                    && e.key() == GLFW.GLFW_MOUSE_BUTTON_MIDDLE) {
                return true;
            }
        } else if (bindType == 0 && e.type() == class_3675.class_307.field_1672) {
            return e.key() == bindKey;
        } else if (bindType == 1 && e.type() == class_3675.class_307.field_1668) {
            return e.key() == bindKey;
        }
        return false;
    }

    private boolean matchesScrollBind(HotBarScrollEvent e, BindSetting bind) {
        int bindKey = bind.getKey();
        int bindType = bind.getType();

        if (bindType != 2) return false;

        if (bindKey == BindComponent.SCROLL_UP_BIND && e.getVertical() > 0) {
            return true;
        } else if (bindKey == BindComponent.SCROLL_DOWN_BIND && e.getVertical() < 0) {
            return true;
        }
        return false;
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            resetAllStates();
            return;
        }

        processArmorSwapLoop();
        processFireworkUseLoop();
        processAutoTakeoff();
        processAutoFirework();
    }

    private void processArmorSwapLoop() {
        if (swapPhase == SwapPhase.IDLE) return;

        boolean continueProcessing = true;
        int iterations = 0;

        while (continueProcessing && iterations < 10) {
            iterations++;
            continueProcessing = processArmorSwapTick();
        }
    }

    private void processFireworkUseLoop() {
        if (fireworkPhase == FireworkPhase.IDLE) return;

        boolean continueProcessing = true;
        int iterations = 0;

        while (continueProcessing && iterations < 10) {
            iterations++;
            continueProcessing = processFireworkUseTick();
        }
    }

    @EventHandler
    public void onInput(InputEvent e) {
        if (mc.field_1724 == null) return;

        if (swapMovement.isBlocked()) {
            e.setDirectionalLow(false, false, false, false);
            e.setJumping(false);
        }

        if (fireworkMovement.isBlocked()) {
            e.setDirectionalLow(false, false, false, false);
            e.setJumping(false);
        }

        if (shouldJumpForTakeoff) {
            e.setJumping(true);
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean isElytraEquipped() {
        if (mc.field_1724 == null) return false;
        class_1799 chestStack = mc.field_1724.method_6118(class_1304.field_6174);
        return chestStack.method_7909() == class_1802.field_8833;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean isElytraUsable() {
        if (mc.field_1724 == null) return false;
        class_1799 chestStack = mc.field_1724.method_6118(class_1304.field_6174);
        if (chestStack.method_7909() != class_1802.field_8833) return false;
        if (chestStack.method_7936() <= 0) return true;
        return chestStack.method_7919() < chestStack.method_7936() - 1;
    }

    private boolean isInstantMode() {
        return modeSetting.getSelected().equals("Instant");
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void processAutoTakeoff() {
        if (!autoTakeoff.isValue()) {
            shouldJumpForTakeoff = false;
            return;
        }
        if (swapPhase != SwapPhase.IDLE) {
            shouldJumpForTakeoff = false;
            return;
        }
        if (fireworkPhase != FireworkPhase.IDLE) {
            shouldJumpForTakeoff = false;
            return;
        }
        if (!isElytraEquipped()) {
            shouldJumpForTakeoff = false;
            return;
        }

        if (mc.field_1724.method_24828()) {
            shouldJumpForTakeoff = true;
        } else {
            shouldJumpForTakeoff = false;
            if (isElytraUsable() && !mc.field_1724.method_6128() && !mc.field_1724.method_31549().field_7479) {
                mc.method_1562().method_52787(
                        new class_2848(mc.field_1724, class_2848.class_2849.field_12982)
                );
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void processAutoFirework() {
        if (!autoTakeoff.isValue() || !autoFirework.isValue()) return;
        if (mc.field_1724 == null) return;
        if (!isElytraEquipped()) return;
        if (!mc.field_1724.method_6128()) return;
        if (fireworkPhase != FireworkPhase.IDLE) return;

        if (mc.field_1724.method_6115()) {
            return;
        }

        if (autoFireworkTimer.finished(1000)) {
            useFirework();
            autoFireworkTimer.reset();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void useFirework() {
        if (!isElytraEquipped()) return;

        if (isInstantMode()) {
            useFireworkInstant();
        } else {
            startFireworkUseLegit();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void useFireworkInstant() {
        int hotbarSlot = findItemInHotbar(class_1802.field_8639);
        if (hotbarSlot != -1) {
            int currentSlot = mc.field_1724.method_31548().method_67532();

            if (hotbarSlot != currentSlot) {
                mc.method_1562().method_52787(new class_2868(hotbarSlot));
            }

            sendSequencedPacket(sequence -> new class_2886(
                    class_1268.field_5808,
                    sequence,
                    mc.field_1724.method_36454(),
                    mc.field_1724.method_36455()
            ));

            if (hotbarSlot != currentSlot) {
                mc.method_1562().method_52787(new class_2868(currentSlot));
            }
            return;
        }

        int invSlot = InventoryUtils.findItemInInventory(class_1802.field_8639);
        if (invSlot != -1) {
            int currentHotbarSlot = mc.field_1724.method_31548().method_67532();
            int wrappedSlot = InventoryUtils.wrapSlot(invSlot);

            InventoryUtils.click(wrappedSlot, currentHotbarSlot, class_1713.field_7791);

            sendSequencedPacket(sequence -> new class_2886(
                    class_1268.field_5808,
                    sequence,
                    mc.field_1724.method_36454(),
                    mc.field_1724.method_36455()
            ));

            InventoryUtils.click(wrappedSlot, currentHotbarSlot, class_1713.field_7791);
            InventoryUtils.closeScreen();
        } else {
            ChatMessage.brandmessage("Нету фейерверков");
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void startFireworkUseLegit() {
        savedFireworkSlot = mc.field_1724.method_31548().method_67532();

        int hotbarSlot = findItemInHotbar(class_1802.field_8639);
        if (hotbarSlot != -1) {
            fireworkSlot = hotbarSlot;
            fireworkFromInventory = false;
            InventoryUtils.selectSlot(fireworkSlot);
            startFireworkPhase(FireworkPhase.AWAIT_ITEM, 0);
            return;
        }

        int invSlot = InventoryUtils.findItemInInventory(class_1802.field_8639);
        if (invSlot != -1) {
            fireworkSlot = invSlot;
            fireworkFromInventory = true;

            SwapSettings settings = buildSettings();
            if (settings.shouldStopMovement()) {
                startFireworkPhase(FireworkPhase.PRE_STOP, settings.randomPreStopDelay());
            } else {
                startFireworkPhase(FireworkPhase.SWAP_TO_HAND, 0);
            }
        } else {
            ChatMessage.brandmessage("Нету фейерверков");
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void startArmorSwap() {
        boolean isElytra = isElytraEquipped();
        class_1792 targetItem = isElytra ? null : class_1802.field_8833;

        int slot = findChestArmorSlot(targetItem, isElytra);
        if (slot == -1) {
            String missing = isElytra ? "нагрудника" : "элитры";
            ChatMessage.brandmessage("Нету " + missing);
            return;
        }

        armorSlot = slot;
        String itemName = isElytra ? "Нагрудник" : "Элитру";
        ChatMessage.brandmessage("Свапнул на " + itemName);

        SwapSettings settings = buildSettings();
        if (settings.shouldStopMovement()) {
            startSwapPhase(SwapPhase.PRE_STOP, settings.randomPreStopDelay());
        } else {
            startSwapPhase(SwapPhase.SWAP_ARMOR, 0);
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private int findChestArmorSlot(class_1792 targetItem, boolean isElytraEquipped) {
        for (int i = 0; i < 46; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);

            class_10192 component = stack.method_58694(class_9334.field_54196);
            if (component == null || component.comp_3174() != class_1304.field_6174) continue;

            if (targetItem == null) {
                if (stack.method_7909() != class_1802.field_8833) {
                    return i;
                }
            } else {
                if (stack.method_7909() == targetItem) {
                    return i;
                }
            }
        }
        return -1;
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private boolean processArmorSwapTick() {
        if (mc.field_1724 == null) {
            resetSwapState();
            return false;
        }

        long elapsed = System.currentTimeMillis() - swapPhaseStartTime;
        SwapSettings settings = buildSettings();

        switch (swapPhase) {
            case PRE_STOP -> {
                if (elapsed >= swapCurrentDelay) {
                    swapMovement.saveState();
                    swapMovement.block();
                    if (settings.shouldStopSprint()) {
                        swapMovement.stopSprint();
                    }
                    startSwapPhase(SwapPhase.STOPPING, 0);
                    return true;
                }
            }
            case STOPPING -> {
                swapMovement.block();
                if (settings.shouldStopSprint()) {
                    swapMovement.stopSprint();
                }
                startSwapPhase(SwapPhase.WAIT_STOP, settings.randomWaitStopDelay());
                return swapCurrentDelay == 0;
            }
            case WAIT_STOP -> {
                swapMovement.block();
                boolean stopped = swapMovement.isPlayerStopped(settings.getVelocityThreshold());
                boolean timeout = elapsed >= swapCurrentDelay;

                if (stopped || timeout) {
                    startSwapPhase(SwapPhase.PRE_SWAP, settings.randomPreSwapDelay());
                    return swapCurrentDelay == 0;
                }
            }
            case PRE_SWAP -> {
                swapMovement.block();
                if (elapsed >= swapCurrentDelay) {
                    startSwapPhase(SwapPhase.SWAP_ARMOR, 0);
                    return true;
                }
            }
            case SWAP_ARMOR -> {
                int fromSlot = InventoryUtils.wrapSlot(armorSlot);
                InventoryUtils.swap(fromSlot, 6);
                startSwapPhase(SwapPhase.POST_SWAP, settings.randomPostSwapDelay());
                return swapCurrentDelay == 0;
            }
            case POST_SWAP -> {
                if (elapsed >= swapCurrentDelay) {
                    if (settings.shouldCloseInventory()) {
                        InventoryUtils.closeScreen();
                    }
                    startSwapPhase(SwapPhase.RESUMING, settings.randomResumeDelay());
                    return swapCurrentDelay == 0;
                }
            }
            case RESUMING -> {
                if (elapsed >= swapCurrentDelay) {
                    if (buildSettings().shouldStopMovement()) {
                        swapMovement.restoreFromCurrent();
                    }
                    resetSwapState();
                    return false;
                }
            }
        }
        return false;
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private boolean processFireworkUseTick() {
        if (mc.field_1724 == null) {
            resetFireworkState();
            return false;
        }

        long elapsed = System.currentTimeMillis() - fireworkPhaseStartTime;
        SwapSettings settings = buildSettings();

        switch (fireworkPhase) {
            case PRE_STOP -> {
                if (elapsed >= fireworkCurrentDelay) {
                    fireworkMovement.saveState();
                    fireworkMovement.block();
                    if (settings.shouldStopSprint()) {
                        fireworkMovement.stopSprint();
                    }
                    startFireworkPhase(FireworkPhase.STOPPING, 0);
                    return true;
                }
            }
            case STOPPING -> {
                fireworkMovement.block();
                if (settings.shouldStopSprint()) {
                    fireworkMovement.stopSprint();
                }
                startFireworkPhase(FireworkPhase.WAIT_STOP, settings.randomWaitStopDelay());
                return fireworkCurrentDelay == 0;
            }
            case WAIT_STOP -> {
                fireworkMovement.block();
                boolean stopped = fireworkMovement.isPlayerStopped(settings.getVelocityThreshold());
                boolean timeout = elapsed >= fireworkCurrentDelay;

                if (stopped || timeout) {
                    startFireworkPhase(FireworkPhase.PRE_SWAP, settings.randomPreSwapDelay());
                    return fireworkCurrentDelay == 0;
                }
            }
            case PRE_SWAP -> {
                fireworkMovement.block();
                if (elapsed >= fireworkCurrentDelay) {
                    startFireworkPhase(FireworkPhase.SWAP_TO_HAND, 0);
                    return true;
                }
            }
            case SWAP_TO_HAND -> {
                int hotbarSlot = mc.field_1724.method_31548().method_67532();
                InventoryUtils.click(fireworkSlot, hotbarSlot, class_1713.field_7791);
                startFireworkPhase(FireworkPhase.AWAIT_ITEM, 0);
                return true;
            }
            case AWAIT_ITEM -> {
                if (mc.field_1724.method_6047().method_7909() == class_1802.field_8639) {
                    startFireworkPhase(FireworkPhase.USE, 0);
                    return true;
                }
            }
            case USE -> {
                sendSequencedPacket(sequence -> new class_2886(
                        class_1268.field_5808,
                        sequence,
                        mc.field_1724.method_36454(),
                        mc.field_1724.method_36455()
                ));
                mc.field_1724.method_6104(class_1268.field_5808);
                startFireworkPhase(FireworkPhase.POST_USE, settings.randomPostSwapDelay());
                return fireworkCurrentDelay == 0;
            }
            case POST_USE -> {
                if (elapsed >= fireworkCurrentDelay) {
                    if (fireworkFromInventory) {
                        startFireworkPhase(FireworkPhase.SWAP_BACK, 0);
                        return true;
                    } else {
                        InventoryUtils.selectSlot(savedFireworkSlot);
                        startFireworkPhase(FireworkPhase.RESUMING, settings.randomResumeDelay());
                        return fireworkCurrentDelay == 0;
                    }
                }
            }
            case SWAP_BACK -> {
                int hotbarSlot = mc.field_1724.method_31548().method_67532();
                InventoryUtils.click(fireworkSlot, hotbarSlot, class_1713.field_7791);
                InventoryUtils.selectSlot(savedFireworkSlot);
                if (settings.shouldCloseInventory()) {
                    InventoryUtils.closeScreen();
                }
                startFireworkPhase(FireworkPhase.RESUMING, settings.randomResumeDelay());
                return fireworkCurrentDelay == 0;
            }
            case RESUMING -> {
                if (elapsed >= fireworkCurrentDelay) {
                    if (buildSettings().shouldStopMovement()) {
                        fireworkMovement.restoreFromCurrent();
                    }
                    resetFireworkState();
                    return false;
                }
            }
        }
        return false;
    }

    private int findItemInHotbar(class_1792 item) {
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() == item) {
                return i;
            }
        }
        return -1;
    }

    private void sendSequencedPacket(java.util.function.IntFunction<net.minecraft.class_2596<?>> packetCreator) {
        if (mc.field_1724 == null || mc.method_1562() == null || mc.field_1687 == null) return;

        try {
            ClientWorldAccessor worldAccessor = (ClientWorldAccessor) mc.field_1687;
            class_7202 pendingUpdateManager = worldAccessor.getPendingUpdateManager().method_41937();

            int sequence = pendingUpdateManager.method_41942();
            mc.method_1562().method_52787(packetCreator.apply(sequence));

            pendingUpdateManager.close();
        } catch (Exception e) {
            mc.method_1562().method_52787(packetCreator.apply(0));
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private SwapSettings buildSettings() {
        String mode = modeSetting.getSelected();
        return switch (mode) {
            case "Instant" -> SwapSettings.instant();
            default -> SwapSettings.legit();
        };
    }

    private void startSwapPhase(SwapPhase phase, int delay) {
        this.swapPhase = phase;
        this.swapPhaseStartTime = System.currentTimeMillis();
        this.swapCurrentDelay = delay;
    }

    private void startFireworkPhase(FireworkPhase phase, int delay) {
        this.fireworkPhase = phase;
        this.fireworkPhaseStartTime = System.currentTimeMillis();
        this.fireworkCurrentDelay = delay;
    }

    private void resetSwapState() {
        swapMovement.reset();
        swapPhase = SwapPhase.IDLE;
        armorSlot = -1;
        swapPhaseStartTime = 0;
        swapCurrentDelay = 0;
    }

    private void resetFireworkState() {
        fireworkMovement.reset();
        fireworkPhase = FireworkPhase.IDLE;
        fireworkSlot = -1;
        savedFireworkSlot = -1;
        fireworkFromInventory = false;
        fireworkPhaseStartTime = 0;
        fireworkCurrentDelay = 0;
    }

    private void resetAllStates() {
        resetSwapState();
        resetFireworkState();
        shouldJumpForTakeoff = false;
    }

    public boolean isSwapping() {
        return swapPhase != SwapPhase.IDLE;
    }

    public boolean isUsingFirework() {
        return fireworkPhase != FireworkPhase.IDLE;
    }

    @Override
    public void deactivate() {
        if (swapMovement.isBlocked()) {
            swapMovement.restoreFromCurrent();
        }
        if (fireworkMovement.isBlocked()) {
            fireworkMovement.restoreFromCurrent();
        }
        resetAllStates();
    }
}