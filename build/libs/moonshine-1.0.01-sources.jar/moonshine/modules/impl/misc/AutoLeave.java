package moonshine.modules.impl.misc;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.MultiSelectSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.network.Network;
import moonshine.util.repository.friend.FriendUtils;
import net.minecraft.class_2561;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class AutoLeave extends ModuleStructure {
    SelectSetting leaveType = new SelectSetting("Тип выхода", "Позволяет выбрать тип выхода")
            .value("Hub", "Main Menu").selected("Main Menu");

    MultiSelectSetting triggerSetting = new MultiSelectSetting("Триггеры", "Выберите, в каких случаях произойдет выход")
            .value("Players", "Staff").selected("Players", "Staff");

    SliderSettings distanceSetting = new SliderSettings("Максимальная дистанция", "Максимальная дистанция для активации авто-выхода")
            .setValue(10).range(5, 40).visible(() -> triggerSetting.isSelected("Players"));

    public AutoLeave() {
        super("AutoLeave", "Auto Leave", ModuleCategory.MISC);
        settings(leaveType, triggerSetting, distanceSetting);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (Network.isPvp()) return;

        if (triggerSetting.isSelected("Players"))
            mc.field_1687.method_18456().stream().filter(p -> mc.field_1724.method_5739(p) < distanceSetting.getValue() && mc.field_1724 != p && !FriendUtils.isFriend(p)).findFirst().ifPresent(p -> leave(p.method_5477().method_27661().method_27693(" - Появился рядом " + mc.field_1724.method_5739(p) + "м")));
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    public void leave(class_2561 text) {
        switch (leaveType.getSelected()) {
            case "Hub" -> {
                mc.method_1562().method_45730("hub");
            }
            case "Main Menu" ->
                    mc.method_1562().method_48296().method_10747(class_2561.method_30163("[Auto Leave] \n").method_27661().method_10852(text));
        }
        setState(false);
    }
}