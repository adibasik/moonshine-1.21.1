package moonshine.modules.impl.misc;

import antidaunleak.api.annotation.Native;
import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.PacketEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.modules.module.setting.implement.TextSetting;
import moonshine.util.timer.TimerUtil;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_640;
import net.minecraft.class_7439;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class AutoDuel extends ModuleStructure {

    private final Pattern pattern = Pattern.compile("^\\w{3,16}$");

    private final SelectSetting mode = new SelectSetting("Режим", "Режим дуэли")
            .value("Шары", "Щит", "Шипы 3", "Незеритка", "Читерский рай", "Лук", "Классик", "Тотемы", "Нодебафф")
            .selected("Шары");

    private final SliderSettings slowTime = new SliderSettings("Скорость отправки", "Задержка между запросами")
            .setValue(500F).range(300F, 1000F);

    private final BooleanSetting babki = new BooleanSetting("Играть на деньги", "Ставка монет")
            .setValue(false);

    private final TextSetting money = new TextSetting("Монет", "Количество монет для ставки")
            .setText("10000")
            .visible(() -> babki.isValue());

    private double lastPosX, lastPosY, lastPosZ;

    private final List<String> sent = Lists.newArrayList();
    private final TimerUtil counter = TimerUtil.create();
    private final TimerUtil counter2 = TimerUtil.create();
    private final TimerUtil counterChoice = TimerUtil.create();
    private final TimerUtil counterTo = TimerUtil.create();

    public AutoDuel() {
        super("AutoDuel", "Auto Duel", ModuleCategory.MISC);
        settings(mode, slowTime, babki, money);
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void activate() {
        counter.resetCounter();
        counter2.resetCounter();
        counterChoice.resetCounter();
        counterTo.resetCounter();
        sent.clear();
        super.activate();
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        handleDuelLogic();
        handleScreenInteraction();
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void onPacket(PacketEvent event) {
        if (event.getType() == PacketEvent.Type.RECEIVE && event.getPacket() instanceof class_7439 chat) {
            String text = chat.comp_763().getString();
            if ((text.contains("начало") && text.contains("через") && text.contains("секунд!")) ||
                    (text.contains("дуэли » во время поединка запрещено использовать команды"))) {
                setState(false);
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleDuelLogic() {
        List<String> players = getOnlinePlayers();

        double distance = Math.sqrt(
                Math.pow(lastPosX - mc.field_1724.method_23317(), 2) +
                        Math.pow(lastPosY - mc.field_1724.method_23318(), 2) +
                        Math.pow(lastPosZ - mc.field_1724.method_23321(), 2)
        );

        if (distance > 500) {
            setState(false);
            return;
        }

        lastPosX = mc.field_1724.method_23317();
        lastPosY = mc.field_1724.method_23318();
        lastPosZ = mc.field_1724.method_23321();

        if (counter2.hasTimeElapsed(800L * players.size())) {
            sent.clear();
            counter2.resetCounter();
        }

        for (String player : players) {
            if (!sent.contains(player) && !player.equals(mc.field_1724.method_7334().name())) {
                if (counter.hasTimeElapsed((long) slowTime.getValue())) {
                    sendDuelRequest(player);
                    sent.add(player);
                    counter.resetCounter();
                }
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void sendDuelRequest(String player) {
        if (babki.isValue()) {
            mc.field_1724.field_3944.method_45730("duel " + player + " " + money.getText());
        } else {
            mc.field_1724.field_3944.method_45730("duel " + player);
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void handleScreenInteraction() {
        if (mc.field_1755 != null && mc.field_1724.field_7512 instanceof class_1703 chest) {
            String title = mc.field_1755.method_25440().getString();

            if (title.contains("Выбор набора (1/1)")) {
                if (counterChoice.hasTimeElapsed(150)) {
                    int slotID = getKitSlot();
                    if (slotID >= 0) {
                        mc.field_1761.method_2906(
                                mc.field_1724.field_7512.field_7763,
                                slotID,
                                0,
                                class_1713.field_7794,
                                mc.field_1724
                        );
                    }
                    counterChoice.resetCounter();
                }
            } else if (title.contains("Настройка поединка")) {
                if (counterTo.hasTimeElapsed(150)) {
                    mc.field_1761.method_2906(
                            chest.field_7763,
                            0,
                            0,
                            class_1713.field_7794,
                            mc.field_1724
                    );
                    counterTo.resetCounter();
                }
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private int getKitSlot() {
        return switch (mode.getSelected()) {
            case "Щит" -> 0;
            case "Шипы 3" -> 1;
            case "Лук" -> 2;
            case "Тотемы" -> 3;
            case "Нодебафф" -> 4;
            case "Шары" -> 5;
            case "Классик" -> 6;
            case "Читерский рай" -> 7;
            case "Незеритка" -> 8;
            default -> -1;
        };
    }

    private List<String> getOnlinePlayers() {
        return mc.field_1724.field_3944.method_2880().stream()
                .map(class_640::method_2966)
                .map(GameProfile::name)
                .filter(profileName -> pattern.matcher(profileName).matches())
                .collect(Collectors.toList());
    }
}