package moonshine.modules.impl.misc;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import org.lwjgl.glfw.GLFW;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.HotBarScrollEvent;
import moonshine.events.impl.InputEvent;
import moonshine.events.impl.KeyEvent;
import moonshine.events.impl.TickEvent;
import moonshine.mixin.ClientWorldAccessor;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BindSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.screens.clickgui.impl.settingsrender.BindComponent;
import moonshine.util.inventory.InventoryUtils;
import moonshine.util.inventory.MovementController;
import moonshine.util.inventory.SwapSettings;
import moonshine.util.string.chat.ChatMessage;
import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2886;
import net.minecraft.class_3675;
import net.minecraft.class_7202;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ClickPearl extends ModuleStructure {

    final SelectSetting modeSetting = new SelectSetting("Режим", "Способ броска")
            .value("Instant", "Legit")
            .selected("Legit");

    final BindSetting keySetting = new BindSetting("Кнопка", "Кнопка для броска");

    enum Phase {
        IDLE, PRE_STOP, STOPPING, WAIT_STOP, PRE_SWAP, SWAP_TO_HAND, AWAIT_ITEM, THROW, POST_THROW, SWAP_BACK, RESUMING
    }

    final MovementController movement = new MovementController();

    Phase phase = Phase.IDLE;
    int savedSlot = -1;
    int pearlSlot = -1;
    boolean fromInventory = false;
    long phaseStartTime = 0;
    int currentDelay = 0;
    long lastThrowTime = 0;

    public ClickPearl() {
        super("ClickPearl", "Click Pearl", ModuleCategory.MISC);
        settings(modeSetting, keySetting);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void onKey(KeyEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1755 != null) return;
        if (phase != Phase.IDLE) return;
        if (e.action() != 1) return;

        int bindKey = keySetting.getKey();
        int bindType = keySetting.getType();

        if (bindKey == GLFW.GLFW_KEY_UNKNOWN || bindKey == -1) return;

        boolean matches = false;

        if (bindType == 2) {
            if (bindKey == BindComponent.MIDDLE_MOUSE_BIND
                    && e.type() == class_3675.class_307.field_1672
                    && e.key() == GLFW.GLFW_MOUSE_BUTTON_MIDDLE) {
                matches = true;
            }
        } else if (bindType == 0 && e.type() == class_3675.class_307.field_1672) {
            matches = e.key() == bindKey;
        } else if (bindType == 1 && e.type() == class_3675.class_307.field_1668) {
            matches = e.key() == bindKey;
        }

        if (matches) {
            tryThrowPearl();
        }
    }

    @EventHandler
    public void onScroll(HotBarScrollEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1755 != null) return;
        if (phase != Phase.IDLE) return;

        int bindKey = keySetting.getKey();
        int bindType = keySetting.getType();

        if (bindType != 2) return;

        boolean matches = false;
        if (bindKey == BindComponent.SCROLL_UP_BIND && e.getVertical() > 0) {
            matches = true;
        } else if (bindKey == BindComponent.SCROLL_DOWN_BIND && e.getVertical() < 0) {
            matches = true;
        }

        if (matches) {
            e.setCancelled(true);
            tryThrowPearl();
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void tryThrowPearl() {
        if (System.currentTimeMillis() - lastThrowTime < 100) return;
        lastThrowTime = System.currentTimeMillis();
        startPearlProcess();
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            resetState();
            return;
        }

        if (phase != Phase.IDLE) {
            boolean continueProcessing = true;
            int iterations = 0;

            while (continueProcessing && iterations < 10) {
                iterations++;
                continueProcessing = processTick();
            }
        }
    }

    @EventHandler
    public void onInput(InputEvent e) {
        if (mc.field_1724 == null) return;
        if (movement.isBlocked()) {
            e.setDirectionalLow(false, false, false, false);
            e.setJumping(false);
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void startPearlProcess() {
        savedSlot = mc.field_1724.method_31548().method_67532();

        int hotbarSlot = InventoryUtils.findItemInHotbar(class_1802.field_8634);
        if (hotbarSlot != -1) {
            pearlSlot = hotbarSlot;
            fromInventory = false;
            InventoryUtils.selectSlot(pearlSlot);
            startPhase(Phase.AWAIT_ITEM, 0);
            return;
        }

        int invSlot = InventoryUtils.findItemInInventory(class_1802.field_8634);
        if (invSlot != -1) {
            pearlSlot = invSlot;
            fromInventory = true;

            SwapSettings settings = buildSettings();
            if (settings.shouldStopMovement()) {
                startPhase(Phase.PRE_STOP, settings.randomPreStopDelay());
            } else {
                startPhase(Phase.SWAP_TO_HAND, 0);
            }
        } else {
            ChatMessage.brandmessage("Нету жемчуга");
            resetState();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private boolean processTick() {
        if (mc.field_1724 == null || mc.field_1755 != null) {
            resetState();
            return false;
        }

        long elapsed = System.currentTimeMillis() - phaseStartTime;
        SwapSettings settings = buildSettings();

        switch (phase) {
            case PRE_STOP -> {
                if (elapsed >= currentDelay) {
                    movement.saveState();
                    movement.block();
                    if (settings.shouldStopSprint()) {
                        movement.stopSprint();
                    }
                    startPhase(Phase.STOPPING, 0);
                    return true;
                }
            }
            case STOPPING -> {
                movement.block();
                if (settings.shouldStopSprint()) {
                    movement.stopSprint();
                }
                startPhase(Phase.WAIT_STOP, settings.randomWaitStopDelay());
                return currentDelay == 0;
            }
            case WAIT_STOP -> {
                movement.block();
                boolean stopped = movement.isPlayerStopped(settings.getVelocityThreshold());
                boolean timeout = elapsed >= currentDelay;

                if (stopped || timeout) {
                    startPhase(Phase.PRE_SWAP, settings.randomPreSwapDelay());
                    return currentDelay == 0;
                }
            }
            case PRE_SWAP -> {
                movement.block();
                if (elapsed >= currentDelay) {
                    startPhase(Phase.SWAP_TO_HAND, 0);
                    return true;
                }
            }
            case SWAP_TO_HAND -> {
                int hotbarSlot = mc.field_1724.method_31548().method_67532();
                InventoryUtils.click(pearlSlot, hotbarSlot, class_1713.field_7791);
                startPhase(Phase.AWAIT_ITEM, 0);
                return true;
            }
            case AWAIT_ITEM -> {
                if (mc.field_1724.method_6047().method_7909() == class_1802.field_8634) {
                    startPhase(Phase.THROW, 0);
                    return true;
                }
            }
            case THROW -> {
                sendSequencedPacket(sequence -> new class_2886(
                        class_1268.field_5808,
                        sequence,
                        mc.field_1724.method_36454(),
                        mc.field_1724.method_36455()
                ));
                mc.field_1724.method_6104(class_1268.field_5808);
                startPhase(Phase.POST_THROW, settings.randomPostSwapDelay());
                return currentDelay == 0;
            }
            case POST_THROW -> {
                if (elapsed >= currentDelay) {
                    if (fromInventory) {
                        startPhase(Phase.SWAP_BACK, 0);
                        return true;
                    } else {
                        InventoryUtils.selectSlot(savedSlot);
                        startPhase(Phase.RESUMING, settings.randomResumeDelay());
                        return currentDelay == 0;
                    }
                }
            }
            case SWAP_BACK -> {
                int hotbarSlot = mc.field_1724.method_31548().method_67532();
                InventoryUtils.click(pearlSlot, hotbarSlot, class_1713.field_7791);
                InventoryUtils.selectSlot(savedSlot);
                if (settings.shouldCloseInventory()) {
                    InventoryUtils.closeScreen();
                }
                startPhase(Phase.RESUMING, settings.randomResumeDelay());
                return currentDelay == 0;
            }
            case RESUMING -> {
                if (elapsed >= currentDelay) {
                    if (buildSettings().shouldStopMovement()) {
                        movement.restoreFromCurrent();
                    }
                    resetState();
                    return false;
                }
            }
        }
        return false;
    }

    private void sendSequencedPacket(java.util.function.IntFunction<net.minecraft.class_2596<?>> packetCreator) {
        if (mc.field_1724 == null || mc.method_1562() == null || mc.field_1687 == null) return;

        try {
            ClientWorldAccessor worldAccessor = (ClientWorldAccessor) mc.field_1687;
            class_7202 pendingUpdateManager = worldAccessor.getPendingUpdateManager().method_41937();

            int sequence = pendingUpdateManager.method_41942();
            mc.method_1562().method_52787(packetCreator.apply(sequence));

            pendingUpdateManager.close();
        } catch (Exception e) {
            mc.method_1562().method_52787(packetCreator.apply(0));
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private SwapSettings buildSettings() {
        String mode = modeSetting.getSelected();
        return switch (mode) {
            case "Instant" -> SwapSettings.instant();
            default -> SwapSettings.legit();
        };
    }

    private void startPhase(Phase newPhase, int delay) {
        this.phase = newPhase;
        this.phaseStartTime = System.currentTimeMillis();
        this.currentDelay = delay;
    }

    private void resetState() {
        movement.reset();
        phase = Phase.IDLE;
        savedSlot = -1;
        pearlSlot = -1;
        fromInventory = false;
        phaseStartTime = 0;
        currentDelay = 0;
    }

    public boolean isRunning() {
        return phase != Phase.IDLE;
    }

    @Override
    public void deactivate() {
        if (movement.isBlocked()) {
            movement.restoreFromCurrent();
        }
        resetState();
    }
}