package moonshine.modules.impl.misc;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import org.lwjgl.glfw.GLFW;
import moonshine.events.api.EventHandler;
import moonshine.events.api.types.EventType;
import moonshine.events.impl.HotBarScrollEvent;
import moonshine.events.impl.InputEvent;
import moonshine.events.impl.KeyEvent;
import moonshine.events.impl.RotationUpdateEvent;
import moonshine.events.impl.TickEvent;
import moonshine.mixin.ClientWorldAccessor;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.AngleConfig;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.impl.combat.aura.MathAngle;
import moonshine.modules.impl.combat.aura.impl.LinearConstructor;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BindSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.screens.clickgui.impl.settingsrender.BindComponent;
import moonshine.util.inventory.InventoryUtils;
import moonshine.util.inventory.MovementController;
import moonshine.util.inventory.SwapSettings;
import moonshine.util.math.TaskPriority;
import moonshine.util.string.chat.ChatMessage;
import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2886;
import net.minecraft.class_3675;
import net.minecraft.class_7202;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class WindJump extends ModuleStructure {

    final SelectSetting modeSetting = new SelectSetting("Режим", "Способ броска")
            .value("Instant", "Legit")
            .selected("Legit");

    final BindSetting keySetting = new BindSetting("Кнопка", "Кнопка для заряда ветра");

    enum Phase {
        IDLE, PRE_STOP, STOPPING, WAIT_STOP, PRE_SWAP, SWAP_TO_HAND, AWAIT_ITEM, ROTATE_DOWN, THROW, POST_THROW, SWAP_BACK, RESUMING
    }

    final MovementController movement = new MovementController();
    final float THROW_PITCH = 90f;

    Phase phase = Phase.IDLE;
    int savedSlot = -1;
    int chargeSlot = -1;
    boolean fromInventory = false;
    long phaseStartTime = 0;
    int currentDelay = 0;
    long lastThrowTime = 0;
    int rotationTicks = 0;
    boolean pendingThrow = false;

    public WindJump() {
        super("WindJump", "Wind Jump", ModuleCategory.MISC);
        settings(modeSetting, keySetting);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void onKey(KeyEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1755 != null) return;
        if (phase != Phase.IDLE) return;
        if (e.action() != 1) return;

        int bindKey = keySetting.getKey();
        int bindType = keySetting.getType();

        if (bindKey == GLFW.GLFW_KEY_UNKNOWN || bindKey == -1) return;

        boolean matches = false;

        if (bindType == 2) {
            if (bindKey == BindComponent.MIDDLE_MOUSE_BIND
                    && e.type() == class_3675.class_307.field_1672
                    && e.key() == GLFW.GLFW_MOUSE_BUTTON_MIDDLE) {
                matches = true;
            }
        } else if (bindType == 0 && e.type() == class_3675.class_307.field_1672) {
            matches = e.key() == bindKey;
        } else if (bindType == 1 && e.type() == class_3675.class_307.field_1668) {
            matches = e.key() == bindKey;
        }

        if (matches) {
            tryThrowCharge();
        }
    }

    @EventHandler
    public void onScroll(HotBarScrollEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1755 != null) return;
        if (phase != Phase.IDLE) return;

        int bindKey = keySetting.getKey();
        int bindType = keySetting.getType();

        if (bindType != 2) return;

        boolean matches = false;
        if (bindKey == BindComponent.SCROLL_UP_BIND && e.getVertical() > 0) {
            matches = true;
        } else if (bindKey == BindComponent.SCROLL_DOWN_BIND && e.getVertical() < 0) {
            matches = true;
        }

        if (matches) {
            e.setCancelled(true);
            tryThrowCharge();
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void tryThrowCharge() {
        if (System.currentTimeMillis() - lastThrowTime < 100) return;
        lastThrowTime = System.currentTimeMillis();
        startChargeProcess();
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onRotationUpdate(RotationUpdateEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (event.getType() == EventType.PRE) {
            if (phase == Phase.ROTATE_DOWN || phase == Phase.THROW) {
                Angle throwAngle = new Angle(mc.field_1724.method_36454(), THROW_PITCH);
                AngleConfig config = new AngleConfig(new LinearConstructor(), true, true);

                AngleConnection.INSTANCE.rotateTo(
                        throwAngle,
                        3,
                        config,
                        TaskPriority.HIGH_IMPORTANCE_1,
                        this
                );
            }
        }

        if (event.getType() == EventType.POST) {
            if (pendingThrow) {
                performThrow();
                pendingThrow = false;
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void performThrow() {
        if (mc.field_1724 == null) return;

        Angle rotation = AngleConnection.INSTANCE.getRotation();
        if (rotation == null) {
            rotation = MathAngle.cameraAngle();
        }

        final Angle finalRotation = rotation;
        sendSequencedPacket(sequence -> new class_2886(
                class_1268.field_5808,
                sequence,
                finalRotation.getYaw(),
                finalRotation.getPitch()
        ));

        mc.field_1724.method_6104(class_1268.field_5808);

        SwapSettings settings = buildSettings();
        startPhase(Phase.POST_THROW, settings.randomPostSwapDelay());
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            resetState();
            return;
        }

        if (phase != Phase.IDLE) {
            boolean continueProcessing = true;
            int iterations = 0;

            while (continueProcessing && iterations < 10) {
                iterations++;
                continueProcessing = processTick();
            }
        }
    }

    @EventHandler
    public void onInput(InputEvent e) {
        if (mc.field_1724 == null) return;
        if (movement.isBlocked()) {
            e.setDirectionalLow(false, false, false, false);
            e.setJumping(false);
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void startChargeProcess() {
        savedSlot = mc.field_1724.method_31548().method_67532();

        int hotbarSlot = InventoryUtils.findItemInHotbar(class_1802.field_49098);
        if (hotbarSlot != -1) {
            chargeSlot = hotbarSlot;
            fromInventory = false;
            InventoryUtils.selectSlot(chargeSlot);
            startPhase(Phase.AWAIT_ITEM, 0);
            return;
        }

        int invSlot = InventoryUtils.findItemInInventory(class_1802.field_49098);
        if (invSlot != -1) {
            chargeSlot = invSlot;
            fromInventory = true;

            SwapSettings settings = buildSettings();
            if (settings.shouldStopMovement()) {
                startPhase(Phase.PRE_STOP, settings.randomPreStopDelay());
            } else {
                startPhase(Phase.SWAP_TO_HAND, 0);
            }
        } else {
            ChatMessage.brandmessage("Нету заряда ветра");
            resetState();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private boolean processTick() {
        if (mc.field_1724 == null || mc.field_1755 != null) {
            resetState();
            return false;
        }

        long elapsed = System.currentTimeMillis() - phaseStartTime;
        SwapSettings settings = buildSettings();

        switch (phase) {
            case PRE_STOP -> {
                if (elapsed >= currentDelay) {
                    movement.saveState();
                    movement.block();
                    if (settings.shouldStopSprint()) {
                        movement.stopSprint();
                    }
                    startPhase(Phase.STOPPING, 0);
                    return true;
                }
            }
            case STOPPING -> {
                movement.block();
                if (settings.shouldStopSprint()) {
                    movement.stopSprint();
                }
                startPhase(Phase.WAIT_STOP, settings.randomWaitStopDelay());
                return currentDelay == 0;
            }
            case WAIT_STOP -> {
                movement.block();
                boolean stopped = movement.isPlayerStopped(settings.getVelocityThreshold());
                boolean timeout = elapsed >= currentDelay;

                if (stopped || timeout) {
                    startPhase(Phase.PRE_SWAP, settings.randomPreSwapDelay());
                    return currentDelay == 0;
                }
            }
            case PRE_SWAP -> {
                movement.block();
                if (elapsed >= currentDelay) {
                    startPhase(Phase.SWAP_TO_HAND, 0);
                    return true;
                }
            }
            case SWAP_TO_HAND -> {
                int hotbarSlot = mc.field_1724.method_31548().method_67532();
                InventoryUtils.click(chargeSlot, hotbarSlot, class_1713.field_7791);
                startPhase(Phase.AWAIT_ITEM, 0);
                return true;
            }
            case AWAIT_ITEM -> {
                if (mc.field_1724.method_6047().method_7909() == class_1802.field_49098) {
                    rotationTicks = 0;
                    startPhase(Phase.ROTATE_DOWN, 0);
                    return true;
                }
            }
            case ROTATE_DOWN -> {
                rotationTicks++;

                Angle currentRotation = AngleConnection.INSTANCE.getRotation();
                boolean rotationReady = currentRotation != null && currentRotation.getPitch() >= 80f;
                boolean waitedEnough = rotationTicks >= 2;

                if (rotationReady && waitedEnough) {
                    startPhase(Phase.THROW, 0);
                    return true;
                }

                if (rotationTicks > 10) {
                    resetState();
                    return false;
                }
            }
            case THROW -> {
                pendingThrow = true;
                return false;
            }
            case POST_THROW -> {
                if (elapsed >= currentDelay) {
                    if (fromInventory) {
                        startPhase(Phase.SWAP_BACK, 0);
                        return true;
                    } else {
                        InventoryUtils.selectSlot(savedSlot);
                        startPhase(Phase.RESUMING, settings.randomResumeDelay());
                        return currentDelay == 0;
                    }
                }
            }
            case SWAP_BACK -> {
                int hotbarSlot = mc.field_1724.method_31548().method_67532();
                InventoryUtils.click(chargeSlot, hotbarSlot, class_1713.field_7791);
                InventoryUtils.selectSlot(savedSlot);
                if (settings.shouldCloseInventory()) {
                    InventoryUtils.closeScreen();
                }
                startPhase(Phase.RESUMING, settings.randomResumeDelay());
                return currentDelay == 0;
            }
            case RESUMING -> {
                if (elapsed >= currentDelay) {
                    if (buildSettings().shouldStopMovement()) {
                        movement.restoreFromCurrent();
                    }
                    AngleConnection.INSTANCE.startReturning();
                    resetState();
                    return false;
                }
            }
        }
        return false;
    }

    private void sendSequencedPacket(java.util.function.IntFunction<net.minecraft.class_2596<?>> packetCreator) {
        if (mc.field_1724 == null || mc.method_1562() == null || mc.field_1687 == null) return;

        try {
            ClientWorldAccessor worldAccessor = (ClientWorldAccessor) mc.field_1687;
            class_7202 pendingUpdateManager = worldAccessor.getPendingUpdateManager().method_41937();

            int sequence = pendingUpdateManager.method_41942();
            mc.method_1562().method_52787(packetCreator.apply(sequence));

            pendingUpdateManager.close();
        } catch (Exception e) {
            mc.method_1562().method_52787(packetCreator.apply(0));
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private SwapSettings buildSettings() {
        String mode = modeSetting.getSelected();
        return switch (mode) {
            case "Instant" -> SwapSettings.instant();
            default -> SwapSettings.legit();
        };
    }

    private void startPhase(Phase newPhase, int delay) {
        this.phase = newPhase;
        this.phaseStartTime = System.currentTimeMillis();
        this.currentDelay = delay;
    }

    private void resetState() {
        movement.reset();
        phase = Phase.IDLE;
        savedSlot = -1;
        chargeSlot = -1;
        fromInventory = false;
        phaseStartTime = 0;
        currentDelay = 0;
        rotationTicks = 0;
        pendingThrow = false;
    }

    public boolean isRunning() {
        return phase != Phase.IDLE;
    }

    @Override
    public void deactivate() {
        if (movement.isBlocked()) {
            movement.restoreFromCurrent();
        }
        AngleConnection.INSTANCE.startReturning();
        resetState();
    }
}