package moonshine.modules.impl.misc;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.NonFinal;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_6880;
import net.minecraft.class_9290;
import net.minecraft.class_9334;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.util.math.*;
import org.lwjgl.glfw.GLFW;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.RotationUpdateEvent;
import moonshine.events.impl.WorldRenderEvent;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.MathAngle;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BindSetting;
import moonshine.modules.module.setting.implement.ColorSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.util.ColorUtil;
import moonshine.util.inventory.*;
import moonshine.util.math.MathUtils;
import moonshine.util.render.Render3D;
import moonshine.util.repository.friend.FriendUtils;
import moonshine.util.string.PlayerInteractionHelper;
import moonshine.util.timer.StopWatch;

import java.util.*;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ServerHelper extends ModuleStructure {

    SelectSetting mode = new SelectSetting("Тип сервера", "Позволяет выбрать тип сервера")
            .value("ReallyWorld", "HolyWorld", "FunTime")
            .selected("FunTime");

    SelectSetting swapMode = new SelectSetting("Режим свапа", "Способ свапа предметов")
            .value("Instant", "Legit")
            .selected("Legit");

    ColorSetting boxFillColor = new ColorSetting("Цвет заливки", "Цвет заливки бокса")
            .value(ColorUtil.getColor(130, 32, 16, 40))
            .visible(() -> mode.isSelected("FunTime"));

    ColorSetting boxLineColor = new ColorSetting("Цвет линий", "Цвет линий бокса")
            .value(ColorUtil.getColor(130, 32, 16, 255))
            .visible(() -> mode.isSelected("FunTime"));

    List<KeyBind> keyBindings = new ArrayList<>();

    List<String> potionQueue = new ArrayList<>();
    StopWatch potionTimer = new StopWatch();
    Map<String, ItemInfo> itemConfig = new HashMap<>();
    Map<String, Boolean> lastKeyStates = new HashMap<>();
    Map<String, Boolean> keyPressedThisTick = new HashMap<>();

    @NonFinal int originalSlot = -1;
    @NonFinal int targetSlot = -1;
    @NonFinal ActionState actionState = ActionState.IDLE;
    @NonFinal long actionTimer = 0;
    @NonFinal String pendingItemKey = null;
    @NonFinal long stopMovementUntil = 0;
    @NonFinal boolean keysOverridden = false;
    @NonFinal boolean wasForwardPressed, wasBackPressed, wasLeftPressed, wasRightPressed;
    @NonFinal int originalSourceSlot = -1;

    MovementController movement = new MovementController();

    private enum ActionState {
        IDLE, SLOWING_DOWN, WAITING_STOP, SWAP_TO_ITEM, USE_ITEM, SWAP_BACK, SPEEDING_UP
    }

    private static class EffectRequirement {
        class_6880<class_1291> effect;
        int minAmplifier;

        EffectRequirement(class_6880<class_1291> effect, int minAmplifier) {
            this.effect = effect;
            this.minAmplifier = minAmplifier;
        }
    }

    private static class ItemInfo {
        List<String> loreKeywords;
        String nameFallback;
        class_1792 item;
        String displayName;
        boolean funTimeOnly;
        List<EffectRequirement> effectRequirements;

        ItemInfo(List<String> loreKeywords, String nameFallback, class_1792 item, String displayName, boolean funTimeOnly) {
            this.loreKeywords = loreKeywords;
            this.nameFallback = nameFallback;
            this.item = item;
            this.displayName = displayName;
            this.funTimeOnly = funTimeOnly;
            this.effectRequirements = null;
        }

        ItemInfo(List<String> loreKeywords, String nameFallback, class_1792 item, String displayName, boolean funTimeOnly, List<EffectRequirement> effectRequirements) {
            this.loreKeywords = loreKeywords;
            this.nameFallback = nameFallback;
            this.item = item;
            this.displayName = displayName;
            this.funTimeOnly = funTimeOnly;
            this.effectRequirements = effectRequirements;
        }

        ItemInfo(String nameFallback, class_1792 item, String displayName) {
            this.loreKeywords = null;
            this.nameFallback = nameFallback;
            this.item = item;
            this.displayName = displayName;
            this.funTimeOnly = false;
            this.effectRequirements = null;
        }
    }

    public ServerHelper() {
        super("Server Assist", "Помощник для серверов", ModuleCategory.MISC);
        initialize();
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    public void initialize() {
        settings(mode, swapMode, boxFillColor, boxLineColor);

        keyBindings.add(new KeyBind(class_1802.field_8450, new BindSetting("Анти полет", "Клавиша анти полета")
                .visible(() -> mode.isSelected("ReallyWorld")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8498, new BindSetting("Свиток опыта", "Клавиша свитка опыта")
                .visible(() -> mode.isSelected("ReallyWorld")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8662, new BindSetting("Взрывная трапка", "Клавиша взрывной трапки")
                .visible(() -> mode.isSelected("HolyWorld")), 5));
        keyBindings.add(new KeyBind(class_1802.field_8882, new BindSetting("Обычная трапка", "Клавиша обычной трапки")
                .visible(() -> mode.isSelected("HolyWorld")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8137, new BindSetting("Стан", "Клавиша стана")
                .visible(() -> mode.isSelected("HolyWorld")), 30));
        keyBindings.add(new KeyBind(class_1802.field_8814, new BindSetting("Взрывная штучка", "Клавиша взрывной штучки")
                .visible(() -> mode.isSelected("HolyWorld")), 5));
        keyBindings.add(new KeyBind(class_1802.field_8543, new BindSetting("Снежок заморозка", "Клавиша снежка")
                .visible(() -> mode.isSelected("HolyWorld") || mode.isSelected("FunTime")), 7));
        keyBindings.add(new KeyBind(class_1802.field_8614, new BindSetting("Божья аура", "Клавиша божьей ауры")
                .visible(() -> mode.isSelected("FunTime")), 2));
        keyBindings.add(new KeyBind(class_1802.field_22021, new BindSetting("Трапка", "Клавиша трапки")
                .visible(() -> mode.isSelected("FunTime")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8551, new BindSetting("Пласт", "Клавиша пласта")
                .visible(() -> mode.isSelected("FunTime")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8479, new BindSetting("Явная пыль", "Клавиша явной пыли")
                .visible(() -> mode.isSelected("FunTime")), 10));
        keyBindings.add(new KeyBind(class_1802.field_8814, new BindSetting("Огненный смерч", "Клавиша огненного смерча")
                .visible(() -> mode.isSelected("FunTime")), 10));
        keyBindings.add(new KeyBind(class_1802.field_8449, new BindSetting("Дезориентация", "Клавиша дезориентации")
                .visible(() -> mode.isSelected("FunTime")), 10));
        keyBindings.add(new KeyBind(class_1802.field_8693, new BindSetting("Светильник Джека", "Клавиша светильника Джека")
                .visible(() -> mode.isSelected("HolyWorld")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8287, new BindSetting("Пузырь опыта", "Клавиша пузыря опыта")
                .visible(() -> mode.isSelected("HolyWorld")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8520, new BindSetting("Рюкзак 1 уровня", "Клавиша рюкзака 1 уровня")
                .visible(() -> mode.isSelected("HolyWorld")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8350, new BindSetting("Рюкзак 2 уровня", "Клавиша рюкзака 2 уровня")
                .visible(() -> mode.isSelected("HolyWorld")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8676, new BindSetting("Рюкзак 3 уровня", "Клавиша рюкзака 3 уровня")
                .visible(() -> mode.isSelected("HolyWorld")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8520, new BindSetting("Рюкзак 4 уровня", "Клавиша рюкзака 4 уровня")
                .visible(() -> mode.isSelected("HolyWorld")), 0));

        keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("Хлопушка", "Клавиша хлопушки")
                .visible(() -> mode.isSelected("FunTime")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("Святая вода", "Клавиша святой воды")
                .visible(() -> mode.isSelected("FunTime")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("Зелье Гнева", "Клавиша зелья гнева")
                .visible(() -> mode.isSelected("FunTime")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("Зелье Палладина", "Клавиша зелья палладина")
                .visible(() -> mode.isSelected("FunTime")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("Зелье Ассасина", "Клавиша зелья ассасина")
                .visible(() -> mode.isSelected("FunTime")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("Зелье Радиации", "Клавиша зелья радиации")
                .visible(() -> mode.isSelected("FunTime")), 0));
        keyBindings.add(new KeyBind(class_1802.field_8436, new BindSetting("Снотворное", "Клавиша снотворного")
                .visible(() -> mode.isSelected("FunTime")), 0));

        keyBindings.forEach(bind -> settings(bind.setting));

        itemConfig.put("sugar", new ItemInfo(
                List.of("световая вспышка", "радиус: 10 блоков", "свечение", "слепота"),
                "явная пыль", class_1802.field_8479, "Явная пыль", true));

        itemConfig.put("disorientation", new ItemInfo(
                List.of("чем ближе цель, тем дольше длительность эффектов"),
                "дезориентация", class_1802.field_8449, "Дезориентация", true));

        itemConfig.put("trap", new ItemInfo(
                List.of("нерушимая клетка", "длительность: 15 секунд"),
                "трапка", class_1802.field_22021, "Трапка", true));

        itemConfig.put("plast", new ItemInfo(
                List.of("нерушимая стена", "вертикальный:", "горизонтальный:"),
                "пласт", class_1802.field_8551, "Пласт", true));

        itemConfig.put("fireSwirl", new ItemInfo(
                List.of("огненная волна", "радиус: 10 блоков", "поджог"),
                "огненный смерч", class_1802.field_8814, "Огненный смерч", true));

        itemConfig.put("snow", new ItemInfo(
                List.of("ледяная сфера", "радиус: 7 блоков", "заморозка", "слабость"),
                "снежок заморозка", class_1802.field_8543, "Снежок заморозка", true));

        itemConfig.put("bojaura", new ItemInfo(
                List.of("божественная аура", "радиус: 2 блока", "снятие всех эффектов", "невидимость"),
                "божья аура", class_1802.field_8614, "Божья аура", true));

        itemConfig.put("hlopushka", new ItemInfo(
                null, "хлопушка", class_1802.field_8436, "Хлопушка", true,
                List.of(
                        new EffectRequirement(class_1294.field_5909, 9),
                        new EffectRequirement(class_1294.field_5904, 4),
                        new EffectRequirement(class_1294.field_5919, 9),
                        new EffectRequirement(class_1294.field_5912, 0)
                )));

        itemConfig.put("holywater", new ItemInfo(
                null, "святая вода", class_1802.field_8436, "Святая вода", true,
                List.of(
                        new EffectRequirement(class_1294.field_5924, 2),
                        new EffectRequirement(class_1294.field_5905, 1),
                        new EffectRequirement(class_1294.field_5915, 1)
                )));

        itemConfig.put("gnev", new ItemInfo(
                null, "зелье гнева", class_1802.field_8436, "Зелье Гнева", true,
                List.of(
                        new EffectRequirement(class_1294.field_5910, 4),
                        new EffectRequirement(class_1294.field_5909, 3)
                )));

        itemConfig.put("paladin", new ItemInfo(
                null, "зелье палладина", class_1802.field_8436, "Зелье Палладина", true,
                List.of(
                        new EffectRequirement(class_1294.field_5907, 0),
                        new EffectRequirement(class_1294.field_5918, 0),
                        new EffectRequirement(class_1294.field_5905, 0),
                        new EffectRequirement(class_1294.field_5914, 2)
                )));

        itemConfig.put("assassin", new ItemInfo(
                null, "зелье ассасина", class_1802.field_8436, "Зелье Ассасина", true,
                List.of(
                        new EffectRequirement(class_1294.field_5910, 3),
                        new EffectRequirement(class_1294.field_5904, 2),
                        new EffectRequirement(class_1294.field_5917, 0),
                        new EffectRequirement(class_1294.field_5921, 1)
                )));

        itemConfig.put("radiation", new ItemInfo(
                null, "зелье радиации", class_1802.field_8436, "Зелье Радиации", true,
                List.of(
                        new EffectRequirement(class_1294.field_5899, 1),
                        new EffectRequirement(class_1294.field_5920, 1),
                        new EffectRequirement(class_1294.field_5909, 2),
                        new EffectRequirement(class_1294.field_5903, 4),
                        new EffectRequirement(class_1294.field_5912, 0)
                )));

        itemConfig.put("snotvornoe", new ItemInfo(
                null, "снотворное", class_1802.field_8436, "Снотворное", true,
                List.of(
                        new EffectRequirement(class_1294.field_5911, 1),
                        new EffectRequirement(class_1294.field_5901, 1),
                        new EffectRequirement(class_1294.field_5920, 2),
                        new EffectRequirement(class_1294.field_5919, 0)
                )));

        itemConfig.put("antiflight", new ItemInfo(
                "анти полет", class_1802.field_8450, "Анти полет"));

        itemConfig.put("expscroll", new ItemInfo(
                "свиток опыта", class_1802.field_8498, "Свиток опыта"));

        itemConfig.put("dtrap", new ItemInfo(
                "взрывная трапка", class_1802.field_8662, "Взрывная трапка"));

        itemConfig.put("trap_holy", new ItemInfo(
                "трапка", class_1802.field_8882, "Обычная трапка"));

        itemConfig.put("stan", new ItemInfo(
                "стан", class_1802.field_8137, "Стан"));

        itemConfig.put("ditem", new ItemInfo(
                "взрывная", class_1802.field_8814, "Взрывная штучка"));

        itemConfig.put("tikva", new ItemInfo(
                "светильник джека", class_1802.field_8693, "Светильник Джека"));

        itemConfig.put("exp", new ItemInfo(
                "пузырь опыта", class_1802.field_8287, "Пузырь опыта"));

        itemConfig.put("shulker1", new ItemInfo(
                "рюкзак (i уровень)", class_1802.field_8520, "Рюкзак 1 уровня"));

        itemConfig.put("shulker2", new ItemInfo(
                "рюкзак (ii уровень)", class_1802.field_8350, "Рюкзак 2 уровня"));

        itemConfig.put("shulker3", new ItemInfo(
                "рюкзак (iii уровень)", class_1802.field_8676, "Рюкзак 3 уровня"));

        itemConfig.put("shulker4", new ItemInfo(
                "рюкзак (iv уровень)", class_1802.field_8520, "Рюкзак 4 уровня"));

        itemConfig.keySet().forEach(key -> {
            lastKeyStates.put(key, false);
            keyPressedThisTick.put(key, false);
        });
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void activate() {
        potionQueue.clear();
        potionTimer.reset();
        lastKeyStates.replaceAll((k, v) -> false);
        keyPressedThisTick.replaceAll((k, v) -> false);
        actionState = ActionState.IDLE;
        originalSlot = -1;
        targetSlot = -1;
        originalSourceSlot = -1;
        pendingItemKey = null;
        stopMovementUntil = 0;
        keysOverridden = false;
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void deactivate() {
        lastKeyStates.replaceAll((k, v) -> false);
        keyPressedThisTick.replaceAll((k, v) -> false);
        potionQueue.clear();
        potionTimer.reset();
        actionState = ActionState.IDLE;
        originalSlot = -1;
        targetSlot = -1;
        originalSourceSlot = -1;
        pendingItemKey = null;
        stopMovementUntil = 0;
        if (keysOverridden) {
            mc.field_1690.field_1894.method_23481(false);
            mc.field_1690.field_1881.method_23481(false);
            mc.field_1690.field_1913.method_23481(false);
            mc.field_1690.field_1849.method_23481(false);
        }
        keysOverridden = false;
        movement.reset();
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private SwapSettings buildSettings() {
        return switch (swapMode.getSelected()) {
            case "Instant" -> SwapSettings.instant();
            default -> SwapSettings.legit();
        };
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean isKeyPressed(int keyCode) {
        if (keyCode == -1) return false;
        long handle = mc.method_22683().method_4490();
        if (keyCode >= GLFW.GLFW_MOUSE_BUTTON_1 && keyCode <= GLFW.GLFW_MOUSE_BUTTON_8) {
            return GLFW.glfwGetMouseButton(handle, keyCode) == GLFW.GLFW_PRESS;
        }
        return GLFW.glfwGetKey(handle, keyCode) == GLFW.GLFW_PRESS;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void blockMovement() {
        mc.field_1690.field_1894.method_23481(false);
        mc.field_1690.field_1881.method_23481(false);
        mc.field_1690.field_1913.method_23481(false);
        mc.field_1690.field_1849.method_23481(false);
        if (mc.field_1724 != null && mc.field_1724.method_5624()) {
            mc.field_1724.method_5728(false);
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onRotationUpdate(RotationUpdateEvent e) {
        if (mc.field_1755 != null) return;

        boolean noMoveOrAction = System.currentTimeMillis() < stopMovementUntil || (actionState != ActionState.IDLE && actionState != ActionState.SPEEDING_UP);
        if (noMoveOrAction) {
            blockMovement();
        }

        processKeyBindings();

        if (actionState != ActionState.IDLE) {
            processItemAction();
        }

        processItemQueue();
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void processKeyBindings() {
        for (KeyBind bind : keyBindings) {
            String key = getKeyFromBinding(bind.setting.getName());
            if (key != null && bind.setting.getVisible().get()) {
                boolean currentKey = isKeyPressed(bind.setting.getKey());
                boolean wasPressedLastTick = lastKeyStates.getOrDefault(key, false);

                if (!currentKey && wasPressedLastTick) {
                    ItemInfo info = itemConfig.get(key);
                    if (info != null) {
                        class_1735 slot = findSlotByItem(info);
                        if (slot != null) {
                            class_1799 stack = slot.method_7677();
                            if (!mc.field_1724.method_7357().method_7904(stack)) {
                                if (!potionQueue.contains(key)) {
                                    potionQueue.add(key);
                                }
                            }
                        }
                    }
                }
                lastKeyStates.put(key, currentKey);
                keyPressedThisTick.put(key, currentKey);
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void processItemQueue() {
        if (actionState == ActionState.IDLE && !potionQueue.isEmpty() && potionTimer.finished(150)) {
            String potionKey = potionQueue.remove(0);
            ItemInfo info = itemConfig.get(potionKey);
            if (info != null) {
                class_1735 slot = findSlotByItem(info);
                if (slot != null) {
                    class_1799 stack = slot.method_7677();
                    if (!mc.field_1724.method_7357().method_7904(stack)) {
                        startItemUse(slot, info);
                    }
                }
                potionTimer.reset();
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void startItemUse(class_1735 slot, ItemInfo info) {
        originalSlot = mc.field_1724.method_31548().method_67532();
        originalSourceSlot = slot.field_7874;
        targetSlot = slot.field_7874;
        pendingItemKey = info.displayName;

        boolean needsSwap = !(slot.field_7874 >= 0 && slot.field_7874 < 9) && !(slot.field_7874 >= 36 && slot.field_7874 < 45);

        long handle = mc.method_22683().method_4490();
        wasForwardPressed = GLFW.glfwGetKey(handle, mc.field_1690.field_1894.method_1429().method_1444()) == GLFW.GLFW_PRESS;
        wasBackPressed = GLFW.glfwGetKey(handle, mc.field_1690.field_1881.method_1429().method_1444()) == GLFW.GLFW_PRESS;
        wasLeftPressed = GLFW.glfwGetKey(handle, mc.field_1690.field_1913.method_1429().method_1444()) == GLFW.GLFW_PRESS;
        wasRightPressed = GLFW.glfwGetKey(handle, mc.field_1690.field_1849.method_1429().method_1444()) == GLFW.GLFW_PRESS;

        SwapSettings settings = buildSettings();

        if (needsSwap && settings.shouldStopMovement()) {
            actionState = ActionState.SLOWING_DOWN;
            actionTimer = System.currentTimeMillis();
            stopMovementUntil = System.currentTimeMillis() + settings.randomWaitStopDelay();
            keysOverridden = true;
            movement.saveState();
            movement.block();
        } else {
            actionState = ActionState.SWAP_TO_ITEM;
            actionTimer = System.currentTimeMillis();
            stopMovementUntil = System.currentTimeMillis() + 95;
            keysOverridden = true;
            blockMovement();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void processItemAction() {
        long currentTime = System.currentTimeMillis();
        long elapsed = currentTime - actionTimer;
        SwapSettings settings = buildSettings();

        switch (actionState) {
            case SLOWING_DOWN -> {
                blockMovement();
                if (elapsed > settings.randomPreStopDelay()) {
                    actionState = ActionState.WAITING_STOP;
                }
            }
            case WAITING_STOP -> {
                blockMovement();
                double velocityX = Math.abs(mc.field_1724.method_18798().field_1352);
                double velocityZ = Math.abs(mc.field_1724.method_18798().field_1350);
                if ((velocityX < settings.getVelocityThreshold() && velocityZ < settings.getVelocityThreshold()) || elapsed > settings.randomWaitStopDelay()) {
                    actionState = ActionState.SWAP_TO_ITEM;
                    actionTimer = currentTime;
                }
            }
            case SWAP_TO_ITEM -> {
                if (elapsed > settings.randomPreSwapDelay()) {
                    performSwapToItem();
                    actionState = ActionState.USE_ITEM;
                    actionTimer = currentTime;
                }
            }
            case USE_ITEM -> {
                if (elapsed > 40) {
                    performUseItem();
                    actionState = ActionState.SWAP_BACK;
                    actionTimer = currentTime;
                }
            }
            case SWAP_BACK -> {
                if (elapsed > settings.randomPostSwapDelay()) {
                    performSwapBack();
                    restoreKeyStates();
                    actionState = ActionState.SPEEDING_UP;
                    actionTimer = currentTime;
                }
            }
            case SPEEDING_UP -> {
                if (elapsed > settings.randomResumeDelay()) {
                    actionState = ActionState.IDLE;
                    originalSlot = -1;
                    targetSlot = -1;
                    originalSourceSlot = -1;
                    pendingItemKey = null;
                }
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void performSwapToItem() {
        if (targetSlot >= 0 && targetSlot < 9) {
            mc.field_1724.field_3944.method_52787(new class_2868(targetSlot));
            mc.field_1724.method_31548().method_61496(targetSlot);
        } else if (targetSlot >= 36 && targetSlot < 45) {
            int hotbarSlot = targetSlot - 36;
            mc.field_1724.field_3944.method_52787(new class_2868(hotbarSlot));
            mc.field_1724.method_31548().method_61496(hotbarSlot);
            targetSlot = hotbarSlot;
        } else {
            int swapSlot = 8;
            InventoryUtils.click(targetSlot, swapSlot, class_1713.field_7791);
            targetSlot = swapSlot;
            mc.field_1724.field_3944.method_52787(new class_2868(swapSlot));
            mc.field_1724.method_31548().method_61496(swapSlot);
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void performUseItem() {
        Angle angle = MathAngle.cameraAngle();
        mc.field_1724.field_3944.method_52787(new class_2886(class_1268.field_5808, 0, angle.getYaw(), angle.getPitch()));
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void performSwapBack() {
        boolean wasFromInventory = !(originalSourceSlot >= 0 && originalSourceSlot < 9) && !(originalSourceSlot >= 36 && originalSourceSlot < 45);

        if (wasFromInventory) {
            if (targetSlot >= 0 && targetSlot < 9) {
                InventoryUtils.click(originalSourceSlot, targetSlot, class_1713.field_7791);
            }
        } else {
            if (originalSourceSlot >= 36 && originalSourceSlot < 45) {
                int hotbarSlot = originalSourceSlot - 36;
                if (targetSlot != hotbarSlot) {
                    mc.field_1724.field_3944.method_52787(new class_2868(hotbarSlot));
                    mc.field_1724.method_31548().method_61496(hotbarSlot);
                }
            } else if (originalSourceSlot >= 0 && originalSourceSlot < 9) {
                if (targetSlot != originalSourceSlot) {
                    mc.field_1724.field_3944.method_52787(new class_2868(originalSourceSlot));
                    mc.field_1724.method_31548().method_61496(originalSourceSlot);
                }
            }
        }

        if (mc.field_1724.method_31548().method_67532() != originalSlot) {
            mc.field_1724.field_3944.method_52787(new class_2868(originalSlot));
            mc.field_1724.method_31548().method_61496(originalSlot);
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void restoreKeyStates() {
        if (!keysOverridden) return;

        mc.field_1690.field_1894.method_23481(wasForwardPressed);
        mc.field_1690.field_1881.method_23481(wasBackPressed);
        mc.field_1690.field_1913.method_23481(wasLeftPressed);
        mc.field_1690.field_1849.method_23481(wasRightPressed);

        keysOverridden = false;
        movement.reset();
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        keyBindings.stream()
                .filter(bind -> PlayerInteractionHelper.isKey(bind.setting) && findSlotByBinding(bind) != null)
                .forEach(bind -> {
                    class_2338 playerPos = mc.field_1724.method_24515();
                    class_243 smooth = MathUtils.interpolate(class_243.method_24954(class_2338.method_49637(mc.field_1724.field_6014, mc.field_1724.field_6036, mc.field_1724.field_5969)), class_243.method_24954(playerPos))
                            .method_1020(class_243.method_24954(playerPos));

                    int lineColor = mode.isSelected("FunTime") ? boxLineColor.getColor() : getDefaultLineColor();
                    int fillColor = mode.isSelected("FunTime") ? boxFillColor.getColor() : getDefaultFillColor();

                    switch (bind.setting.getName()) {
                        case "Трапка", "Обычная трапка" -> drawItemCube(playerPos, smooth, 1.99F, lineColor, fillColor);
                        case "Дезориентация", "Огненный смерч", "Явная пыль" -> Render3D.drawRadiusCircle(MathUtils.interpolate(mc.field_1724), bind.distance, validDistance(bind.distance) ? ColorUtil.getFriendColor() : lineColor);
                        case "Взрывная штучка" -> Render3D.drawRadiusCircle(MathUtils.interpolate(mc.field_1724), 5, validDistance(5) ? ColorUtil.getFriendColor() : lineColor);
                        case "Пласт" -> Render3D.drawPlastShape(playerPos, smooth, lineColor, fillColor);
                        case "Взрывная трапка" -> drawItemCube(playerPos, smooth, 3.99F, lineColor, fillColor);
                        case "Стан" -> drawItemCube(playerPos, smooth, 15.01F, lineColor, fillColor);
                        case "Снежок заморозка" -> Render3D.drawRadiusCircle(MathUtils.interpolate(mc.field_1724), 7, validDistance(7) ? ColorUtil.getFriendColor() : lineColor);
                        case "Божья аура" -> Render3D.drawRadiusCircle(MathUtils.interpolate(mc.field_1724), 2, validDistance(2) ? ColorUtil.getFriendColor() : lineColor);
                    }
                });
    }

    private int getDefaultLineColor() {
        return 0xFF822010;
    }

    private int getDefaultFillColor() {
        return 0x28822010;
    }

    private void drawItemCube(class_2338 playerPos, class_243 smooth, float size, int lineColor, int fillColor) {
        class_238 box = new class_238(playerPos.method_10084()).method_997(smooth).method_1014(size);
        boolean inBox = mc.field_1687.method_18456().stream()
                .anyMatch(player -> player != mc.field_1724 && box.method_994(player.method_5829()) && !FriendUtils.isFriend(player));
        if (inBox) {
            Render3D.drawBoxWithCrossFull(box, ColorUtil.getFriendColor(), ColorUtil.multAlpha(ColorUtil.getFriendColor(), 0.15f), 2);
        } else {
            Render3D.drawBoxWithCrossFull(box, lineColor, fillColor, 2);
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private List<String> getLore(class_1799 stack) {
        List<String> lore = new ArrayList<>();
        if (stack == null || stack.method_7960()) return lore;

        try {
            class_9290 loreComponent = stack.method_58694(class_9334.field_49632);
            if (loreComponent != null) {
                for (class_2561 text : loreComponent.comp_2400()) {
                    String line = getCleanName(text);
                    if (!line.isEmpty()) {
                        lore.add(line);
                    }
                }
            }
        } catch (Exception ignored) {}

        return lore;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean matchesLore(class_1799 stack, List<String> keywords) {
        if (keywords == null || keywords.isEmpty()) return false;

        List<String> lore = getLore(stack);
        if (lore.isEmpty()) return false;

        String fullLore = String.join(" ", lore).toLowerCase();

        int matchCount = 0;
        for (String keyword : keywords) {
            if (fullLore.contains(keyword.toLowerCase())) {
                matchCount++;
            }
        }
        return matchCount >= Math.min(2, keywords.size());
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private Map<class_6880<class_1291>, Integer> getPotionEffects(class_1799 stack) {
        Map<class_6880<class_1291>, Integer> effects = new HashMap<>();
        if (stack == null || stack.method_7960()) return effects;

        class_1844 potionContents = stack.method_58694(class_9334.field_49651);
        if (potionContents == null) return effects;

        for (class_1293 effect : potionContents.comp_2380()) {
            effects.put(effect.method_5579(), effect.method_5578());
        }

        return effects;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean matchesPotionEffects(class_1799 stack, List<EffectRequirement> requirements) {
        if (requirements == null || requirements.isEmpty()) return false;
        if (stack.method_7909() != class_1802.field_8436 && stack.method_7909() != class_1802.field_8150) return false;

        Map<class_6880<class_1291>, Integer> effects = getPotionEffects(stack);
        if (effects.isEmpty()) return false;

        int matchCount = 0;
        for (EffectRequirement req : requirements) {
            Integer amplifier = effects.get(req.effect);
            if (amplifier != null && amplifier >= req.minAmplifier) {
                matchCount++;
            }
        }

        return matchCount >= Math.min(2, requirements.size());
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private class_1735 findSlotByItem(ItemInfo info) {
        if (mode.isSelected("FunTime") && info.funTimeOnly) {
            if (info.effectRequirements != null && !info.effectRequirements.isEmpty()) {
                class_1735 effectMatch = InventoryUtils.findSlot(s -> {
                    class_1799 stack = s.method_7677();
                    if (stack.method_7960() || !stack.method_7909().equals(info.item)) return false;
                    return matchesPotionEffects(stack, info.effectRequirements);
                });

                if (effectMatch != null) {
                    return effectMatch;
                }
            }

            if (info.loreKeywords != null && !info.loreKeywords.isEmpty()) {
                class_1735 loreMatch = InventoryUtils.findSlot(s -> {
                    class_1799 stack = s.method_7677();
                    if (stack.method_7960() || !stack.method_7909().equals(info.item)) return false;
                    return matchesLore(stack, info.loreKeywords);
                });

                if (loreMatch != null) {
                    return loreMatch;
                }
            }

            if (info.nameFallback != null && !info.nameFallback.isEmpty()) {
                return InventoryUtils.findSlot(s -> {
                    class_1799 stack = s.method_7677();
                    if (stack.method_7960() || !stack.method_7909().equals(info.item)) return false;
                    List<String> lore = getLore(stack);
                    if (!lore.isEmpty()) {
                        String fullLore = String.join(" ", lore).toLowerCase();
                        return fullLore.contains(info.nameFallback.toLowerCase());
                    }
                    return getCleanName(stack.method_7964()).contains(info.nameFallback.toLowerCase());
                });
            }

            return null;
        }

        if (info.nameFallback != null && !info.nameFallback.isEmpty()) {
            return InventoryUtils.findSlot(s -> {
                class_1799 stack = s.method_7677();
                if (stack.method_7960() || !stack.method_7909().equals(info.item)) return false;
                return getCleanName(stack.method_7964()).contains(info.nameFallback.toLowerCase());
            });
        }

        return null;
    }

    private class_1735 findSlotByBinding(KeyBind bind) {
        String key = getKeyFromBinding(bind.setting.getName());
        if (key != null) {
            ItemInfo info = itemConfig.get(key);
            if (info != null) {
                return findSlotByItem(info);
            }
        }
        return InventoryUtils.findSlot(s -> s.method_7677().method_7909().equals(bind.item));
    }

    private String getCleanName(class_2561 name) {
        return name.getString().toLowerCase().replaceAll("§[0-9a-fk-or]", "");
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private String getKeyFromBinding(String bindingName) {
        return switch (bindingName) {
            case "Анти полет" -> "antiflight";
            case "Свиток опыта" -> "expscroll";
            case "Взрывная трапка" -> "dtrap";
            case "Обычная трапка" -> "trap_holy";
            case "Стан" -> "stan";
            case "Взрывная штучка" -> "ditem";
            case "Снежок заморозка" -> "snow";
            case "Божья аура" -> "bojaura";
            case "Трапка" -> "trap";
            case "Пласт" -> "plast";
            case "Явная пыль" -> "sugar";
            case "Огненный смерч" -> "fireSwirl";
            case "Дезориентация" -> "disorientation";
            case "Светильник Джека" -> "tikva";
            case "Пузырь опыта" -> "exp";
            case "Рюкзак 1 уровня" -> "shulker1";
            case "Рюкзак 2 уровня" -> "shulker2";
            case "Рюкзак 3 уровня" -> "shulker3";
            case "Рюкзак 4 уровня" -> "shulker4";
            case "Хлопушка" -> "hlopushka";
            case "Святая вода" -> "holywater";
            case "Зелье Гнева" -> "gnev";
            case "Зелье Палладина" -> "paladin";
            case "Зелье Ассасина" -> "assassin";
            case "Зелье Радиации" -> "radiation";
            case "Снотворное" -> "snotvornoe";
            default -> null;
        };
    }

    private boolean validDistance(float dist) {
        return dist == 0 || mc.field_1687.method_18456().stream()
                .anyMatch(p -> p != mc.field_1724 && !FriendUtils.isFriend(p) && mc.field_1724.method_5739(p) <= dist);
    }

    public BindSetting getSetting(String name) {
        return keyBindings.stream()
                .filter(bind -> bind.setting().getName().equals(name))
                .map(ServerHelper.KeyBind::setting)
                .findFirst()
                .orElse(null);
    }

    public record KeyBind(class_1792 item, BindSetting setting, float distance) {}
}