package moonshine.modules.impl.misc.autoparser.dev;

import lombok.Getter;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.util.string.chat.ChatMessage;
import net.minecraft.class_1293;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import net.minecraft.class_9290;
import net.minecraft.class_9296;
import net.minecraft.class_9334;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.*;

@Getter
public class ItemParser extends ModuleStructure {
    private static ItemParser instance;

    private final BooleanSetting showInChat = new BooleanSetting("Показывать в чате", "").setValue(true);
    private final BooleanSetting saveToFile = new BooleanSetting("Сохранять в файл", "").setValue(true);

    private int parseCounter = 0;

    private static final Set<String> IGNORED_ITEMS = Set.of(
            "minecraft:glass_pane",
            "minecraft:white_stained_glass_pane",
            "minecraft:orange_stained_glass_pane",
            "minecraft:magenta_stained_glass_pane",
            "minecraft:light_blue_stained_glass_pane",
            "minecraft:yellow_stained_glass_pane",
            "minecraft:lime_stained_glass_pane",
            "minecraft:pink_stained_glass_pane",
            "minecraft:gray_stained_glass_pane",
            "minecraft:light_gray_stained_glass_pane",
            "minecraft:cyan_stained_glass_pane",
            "minecraft:purple_stained_glass_pane",
            "minecraft:blue_stained_glass_pane",
            "minecraft:brown_stained_glass_pane",
            "minecraft:green_stained_glass_pane",
            "minecraft:red_stained_glass_pane",
            "minecraft:black_stained_glass_pane",
            "minecraft:glass",
            "minecraft:white_stained_glass",
            "minecraft:orange_stained_glass",
            "minecraft:magenta_stained_glass",
            "minecraft:light_blue_stained_glass",
            "minecraft:yellow_stained_glass",
            "minecraft:lime_stained_glass",
            "minecraft:pink_stained_glass",
            "minecraft:gray_stained_glass",
            "minecraft:light_gray_stained_glass",
            "minecraft:cyan_stained_glass",
            "minecraft:purple_stained_glass",
            "minecraft:blue_stained_glass",
            "minecraft:brown_stained_glass",
            "minecraft:green_stained_glass",
            "minecraft:red_stained_glass",
            "minecraft:black_stained_glass",
            "minecraft:air",
            "minecraft:barrier"
    );

    private static final Map<String, String> EFFECT_TO_STATUSEFFECTS = Map.ofEntries(
            Map.entry("speed", "StatusEffects.SPEED"),
            Map.entry("slowness", "StatusEffects.SLOWNESS"),
            Map.entry("haste", "StatusEffects.HASTE"),
            Map.entry("mining_fatigue", "StatusEffects.MINING_FATIGUE"),
            Map.entry("strength", "StatusEffects.STRENGTH"),
            Map.entry("instant_health", "StatusEffects.INSTANT_HEALTH"),
            Map.entry("instant_damage", "StatusEffects.INSTANT_DAMAGE"),
            Map.entry("jump_boost", "StatusEffects.JUMP_BOOST"),
            Map.entry("nausea", "StatusEffects.NAUSEA"),
            Map.entry("regeneration", "StatusEffects.REGENERATION"),
            Map.entry("resistance", "StatusEffects.RESISTANCE"),
            Map.entry("fire_resistance", "StatusEffects.FIRE_RESISTANCE"),
            Map.entry("water_breathing", "StatusEffects.WATER_BREATHING"),
            Map.entry("invisibility", "StatusEffects.INVISIBILITY"),
            Map.entry("blindness", "StatusEffects.BLINDNESS"),
            Map.entry("night_vision", "StatusEffects.NIGHT_VISION"),
            Map.entry("hunger", "StatusEffects.HUNGER"),
            Map.entry("weakness", "StatusEffects.WEAKNESS"),
            Map.entry("poison", "StatusEffects.POISON"),
            Map.entry("wither", "StatusEffects.WITHER"),
            Map.entry("health_boost", "StatusEffects.HEALTH_BOOST"),
            Map.entry("absorption", "StatusEffects.ABSORPTION"),
            Map.entry("saturation", "StatusEffects.SATURATION"),
            Map.entry("glowing", "StatusEffects.GLOWING"),
            Map.entry("levitation", "StatusEffects.LEVITATION"),
            Map.entry("luck", "StatusEffects.LUCK"),
            Map.entry("unluck", "StatusEffects.UNLUCK"),
            Map.entry("slow_falling", "StatusEffects.SLOW_FALLING"),
            Map.entry("conduit_power", "StatusEffects.CONDUIT_POWER"),
            Map.entry("dolphins_grace", "StatusEffects.DOLPHINS_GRACE"),
            Map.entry("bad_omen", "StatusEffects.BAD_OMEN"),
            Map.entry("hero_of_the_village", "StatusEffects.HERO_OF_THE_VILLAGE"),
            Map.entry("darkness", "StatusEffects.DARKNESS")
    );

    public ItemParser() {
        super("Item Parser", "Парсинг информации о предметах", ModuleCategory.MISC);
        instance = this;
        settings(showInChat, saveToFile);
    }

    public static ItemParser getInstance() {
        return instance;
    }

    public void parseAllSlots(List<class_1735> slots, int containerSize, String containerTitle) {
        parseCounter++;
        StringBuilder info = new StringBuilder();
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

        info.append("// ПАРСИНГ #").append(parseCounter).append(" | ").append(timestamp).append("\n");
        info.append("// Контейнер: ").append(containerTitle).append("\n\n");

        int itemCount = 0;

        for (int i = 0; i < containerSize && i < slots.size(); i++) {
            class_1735 slot = slots.get(i);
            class_1799 stack = slot.method_7677();

            if (stack.method_7960()) continue;

            String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
            if (IGNORED_ITEMS.contains(itemId)) continue;

            itemCount++;
            info.append("// --- СЛОТ ").append(i).append(" ---\n");
            parseItemCompact(stack, info);
            info.append("\n");
        }

        info.append("// ИТОГО: ").append(itemCount).append(" предметов\n");

        String result = info.toString();

        if (showInChat.isValue()) {
            ChatMessage.autobuymessage("§6Парсинг #" + parseCounter + " | §bПредметов: §f" + itemCount);
        }

        if (saveToFile.isValue()) {
            saveToFile(result, parseCounter);
            ChatMessage.autobuymessageSuccess("Файл: parse_" + parseCounter + ".txt");
        }
    }

    private void parseItemCompact(class_1799 stack, StringBuilder info) {
        String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        class_2561 customName = stack.method_58694(class_9334.field_49631);
        String displayName = customName != null ? customName.getString() : stack.method_7964().getString();

        info.append("// ").append(displayName).append(" (").append(itemId).append(")\n");

        class_9290 lore = stack.method_58694(class_9334.field_49632);
        if (lore != null && !lore.comp_2400().isEmpty()) {
            info.append("List<Text> lore = List.of(\n");
            for (int i = 0; i < lore.comp_2400().size(); i++) {
                String line = lore.comp_2400().get(i).getString();
                if (line.trim().isEmpty()) continue;
                info.append("    Text.literal(\"").append(escapeString(line)).append("\")");
                if (i < lore.comp_2400().size() - 1) info.append(",");
                info.append("\n");
            }
            info.append(");\n");
        }

        if (stack.method_7909() == class_1802.field_8575) {
            generateHeadCode(stack, displayName, info);
        } else if (stack.method_7909() == class_1802.field_8288) {
            generateTalismanCode(displayName, info);
        } else if (stack.method_7909() == class_1802.field_8574 || stack.method_7909() == class_1802.field_8436 || stack.method_7909() == class_1802.field_8150) {
            generatePotionCode(stack, displayName, info);
        } else {
            generateGenericCode(stack, displayName, info);
        }
    }

    private void generateHeadCode(class_1799 stack, String displayName, StringBuilder info) {
        class_9296 profile = stack.method_58694(class_9334.field_49617);
        if (profile == null) {
            info.append("// НЕТ ПРОФИЛЯ\n");
            return;
        }

        var gameProfile = profile.method_73313();
        String uuid = gameProfile.id() != null ? gameProfile.id().toString() : "unknown";
        String texture = "";

        var textures = gameProfile.properties().get("textures");
        if (textures != null && !textures.isEmpty()) {
            for (var property : textures) {
                texture = property.value();
                break;
            }
        }

        String cleanName = displayName.replace("[★] ", "");
        info.append("spheres.add(createSphere(\"").append(displayName).append("\", \"")
                .append(uuid).append("\", \"").append(texture).append("\", ")
                .append("Defaultpricec.getPrice(\"").append(cleanName).append("\"), lore));\n");
    }

    private void generateTalismanCode(String displayName, StringBuilder info) {
        String cleanName = displayName.replace("[★] ", "");
        info.append("talismans.add(new CustomItem(\"").append(displayName)
                .append("\", null, Items.TOTEM_OF_UNDYING, Defaultpricec.getPrice(\"")
                .append(cleanName).append("\"), null, lore));\n");
    }

    private void generatePotionCode(class_1799 stack, String displayName, StringBuilder info) {
        String itemType;
        if (stack.method_7909() == class_1802.field_8436) {
            itemType = "SPLASH_POTION";
        } else if (stack.method_7909() == class_1802.field_8150) {
            itemType = "LINGERING_POTION";
        } else {
            itemType = "POTION";
        }

        class_1844 potionContents = stack.method_58694(class_9334.field_49651);

        if (potionContents != null) {
            List<class_1293> effects = new ArrayList<>();
            for (class_1293 effect : potionContents.method_57397()) {
                effects.add(effect);
            }

            int color = potionContents.method_8064();
            String colorHex = String.format("0x%06X", color & 0xFFFFFF);

            if (!effects.isEmpty()) {
                info.append("List<StatusEffectInstance> ").append(toVariableName(displayName)).append("Effects = List.of(\n");
                for (int i = 0; i < effects.size(); i++) {
                    class_1293 effect = effects.get(i);
                    String effectId = effect.method_5579().method_55840();
                    if (effectId != null) {
                        effectId = effectId.replace("minecraft:", "");
                    }
                    String statusEffect = EFFECT_TO_STATUSEFFECTS.getOrDefault(effectId, "StatusEffects." + effectId.toUpperCase());
                    int duration = effect.method_5584();
                    int amplifier = effect.method_5578();

                    info.append("        new StatusEffectInstance(").append(statusEffect)
                            .append(", ").append(duration)
                            .append(", ").append(amplifier).append(")");
                    if (i < effects.size() - 1) info.append(",");
                    info.append(" // ").append(effectId).append(" lvl:").append(amplifier + 1)
                            .append(" dur:").append(formatDuration(duration)).append("\n");
                }
                info.append(");\n");

                String cleanName = displayName.replace("[★] ", "").replace("[🍹] ", "").replace("[$] ", "");
                info.append("potions.add(new CustomItem(\"").append(displayName)
                        .append("\", null, Items.").append(itemType)
                        .append(", Defaultpricec.getPrice(\"").append(cleanName).append("\"),\n");
                info.append("        new PotionContentsComponent(Optional.empty(), Optional.of(")
                        .append(colorHex).append("), ").append(toVariableName(displayName))
                        .append("Effects, Optional.empty()), lore));\n");
            } else {
                info.append("// Зелье без эффектов, цвет: ").append(colorHex).append("\n");
                String cleanName = displayName.replace("[★] ", "").replace("[🍹] ", "").replace("[$] ", "");
                info.append("potions.add(new CustomItem(\"").append(displayName)
                        .append("\", null, Items.").append(itemType).append(", Defaultpricec.getPrice(\"")
                        .append(cleanName).append("\"), null, lore));\n");
            }
        } else {
            info.append("// Нет PotionContentsComponent\n");
            String cleanName = displayName.replace("[★] ", "").replace("[🍹] ", "").replace("[$] ", "");
            info.append("potions.add(new CustomItem(\"").append(displayName)
                    .append("\", null, Items.").append(itemType).append(", Defaultpricec.getPrice(\"")
                    .append(cleanName).append("\"), null, lore));\n");
        }
    }

    private void generateGenericCode(class_1799 stack, String displayName, StringBuilder info) {
        String itemConst = class_7923.field_41178.method_10221(stack.method_7909()).method_12832().toUpperCase();
        info.append("items.add(new CustomItem(\"").append(displayName)
                .append("\", null, Items.").append(itemConst).append(", price, null, lore));\n");
    }

    private String toVariableName(String displayName) {
        String clean = displayName
                .replace("[★] ", "")
                .replace("[🍹] ", "")
                .replace("[$] ", "")
                .replace(" ", "")
                .replace("-", "")
                .replace(".", "");

        StringBuilder sb = new StringBuilder();
        boolean nextUpper = false;
        for (int i = 0; i < clean.length(); i++) {
            char c = clean.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                if (i == 0) {
                    sb.append(Character.toLowerCase(c));
                } else if (nextUpper) {
                    sb.append(Character.toUpperCase(c));
                    nextUpper = false;
                } else {
                    sb.append(c);
                }
            } else {
                nextUpper = true;
            }
        }

        if (sb.length() == 0) return "potion";
        return sb.toString();
    }

    private String formatDuration(int ticks) {
        int seconds = ticks / 20;
        int minutes = seconds / 60;
        seconds = seconds % 60;
        return String.format("%d:%02d", minutes, seconds);
    }

    private String escapeString(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private void saveToFile(String content, int number) {
        try {
            class_310 mc = class_310.method_1551();
            File dir = new File(mc.field_1697, "item_parser");
            if (!dir.exists()) dir.mkdirs();

            File file = new File(dir, "parse_" + number + ".txt");
            try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
                writer.print(content);
            }
        } catch (IOException e) {
            ChatMessage.autobuymessageError("Ошибка: " + e.getMessage());
        }
    }
}