package moonshine.modules.impl.misc;

import antidaunleak.api.annotation.Native;
import lombok.Getter;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.*;
import moonshine.screens.clickgui.impl.autobuy.AutoBuyableItem;
import moonshine.screens.clickgui.impl.autobuy.AuctionUtils;
import moonshine.screens.clickgui.impl.autobuy.manager.AutoBuyManager;
import moonshine.util.modules.autobuy.BuyRequest;
import moonshine.util.modules.autobuy.NetworkManager;
import moonshine.util.modules.autobuy.ServerManager;
import moonshine.util.timer.TimerUtil;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_476;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import java.util.*;

@Getter
public class AutoBuy extends ModuleStructure {
    private static AutoBuy instance;

    private final SelectSetting mode = new SelectSetting("Режим", "Проверяющий").value("Проверяющий", "Покупающий");
    private final SelectSetting serverType = new SelectSetting("Сервера", "Выкл").value("Выкл", "1.16.5", "1.21.4");
    private final SliderSettings updateDelay = new SliderSettings("Задержка обновления", "").range(300, 1000).setValue(500);
    private final SliderSettings serverSwitchTime = new SliderSettings("Время смены сервера", "").range(30, 120).setValue(30);
    private final BooleanSetting notifications = new BooleanSetting("Уведомления", "").setValue(true);

    private final AutoBuyManager autoBuyManager = AutoBuyManager.getInstance();
    private final NetworkManager network = new NetworkManager();
    private final ServerManager serverManager = new ServerManager();

    private final TimerUtil updateTimer = TimerUtil.create();
    private final TimerUtil ahOpenTimer = TimerUtil.create();
    private final TimerUtil serverSwitchTimer = TimerUtil.create();

    private boolean inAuction = false;
    private boolean notifiedEnter = false;
    private Set<String> sentItems = new HashSet<>();
    private Set<String> boughtItems = new HashSet<>();
    private volatile boolean pendingUpdate = false;

    public AutoBuy() {
        super("Auto Buy", "Автоматическая покупка на аукционе", ModuleCategory.MISC);
        instance = this;

        serverType.setVisible(() -> mode.isSelected("Покупающий"));
        serverSwitchTime.setVisible(() -> mode.isSelected("Покупающий") && !serverType.isSelected("Выкл"));
        updateDelay.setVisible(() -> mode.isSelected("Покупающий"));

        settings(mode, serverType, updateDelay, serverSwitchTime, notifications);
    }

    public static AutoBuy getInstance() {
        return instance;
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void activate() {
        super.activate();
        autoBuyManager.setEnabled(true);
        reset();

        if (mode.isSelected("Покупающий")) {
            network.startAsServer();
            if (!serverType.isSelected("Выкл")) {
                mc.field_1690.field_1837 = false;
            }
        } else {
            network.startAsClient();
        }

        msg("§aМодуль включён. Режим: §b" + mode.getSelected());
        if (mode.isSelected("Покупающий") && !serverType.isSelected("Выкл")) {
            msg("§7Сервера: §b" + serverType.getSelected() + " §7| Смена каждые §b" + (int)serverSwitchTime.getValue() + "с");
        }
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void deactivate() {
        super.deactivate();
        autoBuyManager.setEnabled(false);
        network.stop();
        serverManager.reset();
        reset();
        msg("§cМодуль выключен");
    }

    private void reset() {
        inAuction = false;
        notifiedEnter = false;
        sentItems.clear();
        boughtItems.clear();
        pendingUpdate = false;
        updateTimer.resetCounter();
        ahOpenTimer.resetCounter();
        serverSwitchTimer.resetCounter();
        serverManager.resetTimers();
    }

    public void sendPauseSync(boolean paused) {
        network.sendPauseState(paused);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (!isState()) return;

        handlePauseSync();

        if (!autoBuyManager.isEnabled()) return;

        if (mode.isSelected("Проверяющий")) {
            handleServerSwitchCommand();
            handleUpdateCommand();
        }

        if (mode.isSelected("Покупающий") && !serverType.isSelected("Выкл")) {
            handleServerLogic();
        }

        if (!(mc.field_1755 instanceof class_476 screen)) {
            handleNotInScreen();
            return;
        }

        String title = screen.method_25440().getString().toLowerCase();
        int slots = screen.method_17577().field_7761.size();

        if (isSuspiciousPriceScreen(title, slots)) {
            confirmSuspiciousPrice(screen);
            return;
        }

        if (!title.contains("аукцион") && !title.contains("поиск")) {
            handleNotInAuction();
            return;
        }

        handleInAuction(screen);
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void handlePauseSync() {
        Boolean pauseState = network.pollPauseState();
        if (pauseState != null) {
            autoBuyManager.setEnabledSilent(!pauseState);
            if (pauseState) {
                msg("§e[СИНХРО] Пауза включена");
            } else {
                msg("§a[СИНХРО] Пауза выключена");
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void handleServerSwitchCommand() {
        String switchCmd = network.pollServerSwitch();
        if (switchCmd != null) {
            msg("§e[ПРОВЕРЯЮЩИЙ] Переключаюсь на сервер: " + switchCmd);
            mc.field_1724.field_3944.method_45730(switchCmd.substring(1));
            serverManager.setWaitingForServerLoad(true);
            inAuction = false;
            notifiedEnter = false;
            sentItems.clear();
        }
    }

    private void handleUpdateCommand() {
        if (network.pollUpdateCommand()) {
            pendingUpdate = true;
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleServerLogic() {
        serverManager.updateHubStatus(mc.field_1687);

        if (serverManager.shouldJoinAnarchy(serverType.getSelected())) {
            serverManager.joinAnarchyFromHub(mc.field_1724, serverType.getSelected());
            msg("§e[ПОКУПАТЕЛЬ] Захожу на анархию...");
        }

        if (serverManager.isWaitingForServerLoad()) {
            if (!serverManager.isInHub()) {
                serverManager.setWaitingForServerLoad(false);
                serverSwitchTimer.resetCounter();
                ahOpenTimer.resetCounter();
                msg("§a[ПОКУПАТЕЛЬ] Загрузился на сервер");
            }
        }

        long switchInterval = (long) (serverSwitchTime.getValue() * 1000);
        if (!serverManager.isInHub() && serverSwitchTimer.hasTimeElapsed(switchInterval)) {
            serverManager.switchToNextServer(mc.field_1724, network, serverType.getSelected());
            serverSwitchTimer.resetCounter();
            inAuction = false;
            sentItems.clear();
            boughtItems.clear();
        }
    }

    private void handleNotInScreen() {
        if (inAuction) {
            inAuction = false;
            sentItems.clear();
            boughtItems.clear();
            if (mode.isSelected("Проверяющий") && notifiedEnter) {
                network.sendLeaveAuction();
                notifiedEnter = false;
            }
        }

        if (ahOpenTimer.hasTimeElapsed(11000)) {
            mc.field_1724.field_3944.method_45730("ah");
            ahOpenTimer.resetCounter();
        }
    }

    private void handleNotInAuction() {
        if (inAuction) {
            inAuction = false;
            sentItems.clear();
            boughtItems.clear();
            if (mode.isSelected("Проверяющий") && notifiedEnter) {
                network.sendLeaveAuction();
                notifiedEnter = false;
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleInAuction(class_476 screen) {
        if (!inAuction) {
            inAuction = true;
            sentItems.clear();
            boughtItems.clear();
            msg("§aВ аукционе");

            if (mode.isSelected("Проверяющий") && !notifiedEnter) {
                network.sendEnterAuction();
                notifiedEnter = true;
            }
        }

        if (mode.isSelected("Покупающий")) {
            processBuyRequestsInstant(screen);

            if (updateTimer.hasTimeElapsed((long) updateDelay.getValue() - 200)) {
                int clientsInAuction = network.getClientsInAuctionCount();
                if (clientsInAuction > 0) {
                    network.sendUpdateCommand();
                }
                updateAuction(screen);
                updateTimer.resetCounter();
            }
        } else {
            if (pendingUpdate) {
                updateAuction(screen);
                pendingUpdate = false;
            }
            scanAndSendInstant(screen);
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean isSuspiciousPriceScreen(String title, int slots) {
        if (title.contains("подозрительн")) return true;
        if (title.contains("подтвер")) return true;
        if (title.contains("suspicious")) return true;
        if (title.contains("confirm")) return true;

        if (slots == 63 || slots == 36) {
            if (!title.contains("аукцион") && !title.contains("поиск") && !title.contains("инвентарь")) {
                return true;
            }
        }

        return false;
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void confirmSuspiciousPrice(class_476 screen) {
        int syncId = screen.method_17577().field_7763;
        mc.field_1761.method_2906(syncId, 1, 0, class_1713.field_7790, mc.field_1724);
        msg("§a✓ Подтвердил покупку");
    }

    private void updateAuction(class_476 screen) {
        int syncId = screen.method_17577().field_7763;
        mc.field_1761.method_2906(syncId, 49, 0, class_1713.field_7794, mc.field_1724);
    }

    private String generateLoreHash(class_1799 stack) {
        var lore = stack.method_58694(class_9334.field_49632);
        if (lore == null || lore.comp_2400().isEmpty()) {
            return "nolore";
        }
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (class_2561 line : lore.comp_2400()) {
            if (count >= 3) break;
            String text = line.getString();
            if (!text.contains("$") && !text.contains("Прoдaвeц") && !text.contains("Истeкaeт") && !text.contains("Нажмите")) {
                sb.append(text.hashCode());
                count++;
            }
        }
        return sb.toString();
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void scanAndSendInstant(class_476 screen) {
        if (!network.isConnected()) return;

        List<AutoBuyableItem> items = autoBuyManager.getEnabledItems();
        if (items.isEmpty()) return;

        for (int i = 0; i < 45 && i < screen.method_17577().field_7761.size(); i++) {
            class_1735 slot = screen.method_17577().field_7761.get(i);
            class_1799 stack = slot.method_7677();
            if (stack.method_7960()) continue;

            if (AuctionUtils.isArmorItem(stack) && AuctionUtils.hasThornsEnchantment(stack)) continue;

            int price = AuctionUtils.getPrice(stack);
            if (price <= 0) continue;

            String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
            String loreHash = generateLoreHash(stack);
            String key = itemId + "|" + price + "|" + stack.method_7947() + "|" + loreHash;

            if (sentItems.contains(key)) continue;

            processItemForSending(stack, items, key, itemId, price, loreHash);
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void processItemForSending(class_1799 stack, List<AutoBuyableItem> items, String key, String itemId, int price, String loreHash) {
        for (AutoBuyableItem item : items) {
            int maxPrice = item.getSettings().getBuyBelow();
            int minQuantity = item.getSettings().isCanHaveQuantity() ? item.getSettings().getMinQuantity() : 1;

            if (price > maxPrice) continue;

            if (item.getSettings().isCanHaveQuantity()) {
                if (stack.method_7947() < minQuantity) continue;
            }

            if (AuctionUtils.compareItem(stack, item.createItemStack())) {
                sentItems.add(key);
                String displayName = item.getDisplayName();
                network.sendBuyCommand(price, itemId, displayName, stack.method_7947(), loreHash, maxPrice, minQuantity);
                break;
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void processBuyRequestsInstant(class_476 screen) {
        int syncId = screen.method_17577().field_7763;

        BuyRequest request;
        while ((request = network.pollBuyRequest()) != null) {
            String buyKey = request.itemId + "|" + request.price + "|" + request.count + "|" + request.loreHash;
            if (boughtItems.contains(buyKey)) {
                continue;
            }

            boolean found = tryExactMatch(screen, syncId, request, buyKey);

            if (!found) {
                tryFallbackMatch(screen, syncId, request, buyKey);
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private boolean tryExactMatch(class_476 screen, int syncId, BuyRequest request, String buyKey) {
        for (int i = 0; i < 45 && i < screen.method_17577().field_7761.size(); i++) {
            class_1735 slot = screen.method_17577().field_7761.get(i);
            class_1799 stack = slot.method_7677();
            if (stack.method_7960()) continue;

            String stackItemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
            if (!stackItemId.equals(request.itemId)) continue;

            int stackPrice = AuctionUtils.getPrice(stack);
            if (stackPrice != request.price) continue;

            if (stack.method_7947() != request.count) continue;

            String stackLoreHash = generateLoreHash(stack);
            if (!stackLoreHash.equals(request.loreHash)) continue;

            if (AuctionUtils.isArmorItem(stack) && AuctionUtils.hasThornsEnchantment(stack)) continue;

            mc.field_1761.method_2906(syncId, slot.field_7874, 0, class_1713.field_7794, mc.field_1724);
            boughtItems.add(buyKey);
            msg("§a⚡ КУПИЛ: §f" + request.displayName + " §aза " + stackPrice + "$");
            return true;
        }
        return false;
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private boolean tryFallbackMatch(class_476 screen, int syncId, BuyRequest request, String buyKey) {
        for (int i = 0; i < 45 && i < screen.method_17577().field_7761.size(); i++) {
            class_1735 slot = screen.method_17577().field_7761.get(i);
            class_1799 stack = slot.method_7677();
            if (stack.method_7960()) continue;

            String stackItemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
            if (!stackItemId.equals(request.itemId)) continue;

            int stackPrice = AuctionUtils.getPrice(stack);
            if (stackPrice <= 0 || stackPrice > request.maxPrice) continue;

            if (stack.method_7947() < request.minQuantity) continue;

            if (AuctionUtils.isArmorItem(stack) && AuctionUtils.hasThornsEnchantment(stack)) continue;

            String fallbackKey = stackItemId + "|" + stackPrice + "|" + stack.method_7947() + "|" + generateLoreHash(stack);
            if (boughtItems.contains(fallbackKey)) continue;

            mc.field_1761.method_2906(syncId, slot.field_7874, 0, class_1713.field_7794, mc.field_1724);
            boughtItems.add(fallbackKey);
            boughtItems.add(buyKey);
            msg("§a⚡ КУПИЛ: §f" + request.displayName + " §aза " + stackPrice + "$");
            return true;
        }
        return false;
    }

    private void msg(String text) {
        if (notifications.isValue() && mc.field_1724 != null) {
        }
    }

    public NetworkManager getNetworkManager() {
        return network;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    public boolean isFullyEnabled() {
        return isState() && autoBuyManager.isEnabled();
    }
}