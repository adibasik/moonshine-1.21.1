package moonshine.modules.impl.misc;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.PacketEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.util.timer.TimerUtil;
import net.minecraft.class_2720;
import net.minecraft.class_2856;
import net.minecraft.class_634;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class ServerRPSpoofer extends ModuleStructure {
    private ResourcePackAction currentAction = ResourcePackAction.WAIT;
    private final TimerUtil counter = TimerUtil.create();

    public ServerRPSpoofer() {
        super("ServerRPSpoof", "Server RP Spoof", ModuleCategory.MISC);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void onPacket(PacketEvent e) {
        if (e.getPacket() instanceof class_2720) {
            currentAction = ResourcePackAction.ACCEPT;
            e.cancel();
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        class_634 networkHandler = mc.method_1562();
        if (networkHandler != null) {
            processResourcePackAction(networkHandler);
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void processResourcePackAction(class_634 networkHandler) {
        if (currentAction == ResourcePackAction.ACCEPT) {
            networkHandler.method_52787(new class_2856(mc.field_1724.method_5667(), class_2856.class_2857.field_13016));
            currentAction = ResourcePackAction.SEND;
            counter.resetCounter();
        } else if (currentAction == ResourcePackAction.SEND && counter.isReached(300L)) {
            networkHandler.method_52787(new class_2856(mc.field_1724.method_5667(), class_2856.class_2857.field_13017));
            currentAction = ResourcePackAction.WAIT;
        }
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void deactivate() {
        currentAction = ResourcePackAction.WAIT;
        super.deactivate();
    }

    public enum ResourcePackAction {
        ACCEPT, SEND, WAIT;
    }
}