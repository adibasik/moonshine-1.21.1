package moonshine.modules.impl.combat;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.NonFinal;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.PacketEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.util.Instance;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_6373;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class Velocity extends ModuleStructure {
    public static Velocity getInstance() {
        return Instance.get(Velocity.class);
    }

    SelectSetting mode = new SelectSetting("Режим", "Выберите режим уменьшения отдачи")
            .value("NewGrim", "OldGrim", "Matrix", "Normal")
            .selected("NewGrim");

    @NonFinal boolean flag;
    @NonFinal int grimTicks;
    @NonFinal int ccCooldown;
    @NonFinal class_243 pendingVelocity;

    public Velocity() {
        super("Velocity", ModuleCategory.COMBAT);
        settings(mode);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onPacket(PacketEvent e) {
        if (!state) return;
        if (e.getType() != PacketEvent.Type.RECEIVE) return;
        if (mc.field_1724 == null || mc.field_1724.method_5799() || mc.field_1724.method_5869() || mc.field_1724.method_5771()) return;
        if (ccCooldown > 0) {
            ccCooldown--;
            return;
        }

        if (e.getPacket() instanceof class_2743 pac && pac.method_11818() == mc.field_1724.method_5628()) {
            handleVelocityPacket(e, pac);
        }

        handleAdditionalPackets(e);
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleVelocityPacket(PacketEvent e, class_2743 pac) {
        class_243 velocity = pac.method_73085();

        switch (mode.getSelected()) {
            case "Matrix":
                if (!flag) {
                    e.setCancelled(true);
                    flag = true;
                } else {
                    flag = false;
                    e.setCancelled(true);
                    pendingVelocity = new class_243(
                            velocity.field_1352 * -0.1,
                            velocity.field_1351,
                            velocity.field_1350 * -0.1
                    );
                }
                break;
            case "Normal":
                e.setCancelled(true);
                break;
            case "OldGrim":
                e.setCancelled(true);
                grimTicks = 6;
                break;
            case "NewGrim":
                e.setCancelled(true);
                flag = true;
                break;
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void handleAdditionalPackets(PacketEvent e) {
        if (mode.isSelected("OldGrim") && e.getPacket() instanceof class_6373 && grimTicks > 0) {
            e.setCancelled(true);
            grimTicks--;
        }

        if (e.getPacket() instanceof class_2708 && mode.isSelected("NewGrim")) {
            ccCooldown = 5;
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (!state || mc.field_1724 == null || mc.field_1724.method_5799() || mc.field_1724.method_5869()) return;

        if (mode.isSelected("Matrix")) {
            handleMatrixTick();
        }

        if (mode.isSelected("NewGrim") && flag) {
            handleNewGrimTick();
        }

        if (grimTicks > 0) {
            grimTicks--;
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleMatrixTick() {
        if (pendingVelocity != null) {
            mc.field_1724.method_18799(pendingVelocity);
            pendingVelocity = null;
        }

        if (mc.field_1724.field_6235 > 0 && !mc.field_1724.method_24828()) {
            double yaw = mc.field_1724.method_36454() * 0.017453292F;
            double speed = Math.sqrt(mc.field_1724.method_18798().field_1352 * mc.field_1724.method_18798().field_1352 + mc.field_1724.method_18798().field_1350 * mc.field_1724.method_18798().field_1350);
            mc.field_1724.method_18800(-Math.sin(yaw) * speed, mc.field_1724.method_18798().field_1351, Math.cos(yaw) * speed);
            mc.field_1724.method_5728(mc.field_1724.field_6012 % 2 != 0);
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleNewGrimTick() {
        if (ccCooldown <= 0) {
            mc.field_1724.field_3944.method_52787(new class_2828.class_2830(
                    mc.field_1724.method_23317(),
                    mc.field_1724.method_23318(),
                    mc.field_1724.method_23321(),
                    mc.field_1724.method_36454(),
                    mc.field_1724.method_36455(),
                    mc.field_1724.method_24828(),
                    false
            ));
            mc.field_1724.field_3944.method_52787(new class_2846(
                    class_2846.class_2847.field_12973,
                    class_2338.method_49638(mc.field_1724.method_73189()),
                    class_2350.field_11033
            ));
        }
        flag = false;
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void activate() {
        super.activate();
        grimTicks = 0;
        flag = false;
        ccCooldown = 0;
        pendingVelocity = null;
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void deactivate() {
        super.deactivate();
        pendingVelocity = null;
    }
}