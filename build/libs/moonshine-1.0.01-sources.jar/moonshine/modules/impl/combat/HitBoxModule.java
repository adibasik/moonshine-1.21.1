package moonshine.modules.impl.combat;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.BoundingBoxControlEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.repository.friend.FriendUtils;
import net.minecraft.class_1309;
import net.minecraft.class_238;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class HitBoxModule extends ModuleStructure {
    SliderSettings xzExpandSetting = new SliderSettings("Расширение XZ", "Позволяет расширить хитбокс по осям XZ")
            .setValue(0.2F).range(0.0F, 3.0F);

    SliderSettings yExpandSetting = new SliderSettings("Расширение Y", "Позволяет расширить хитбокс по оси Y")
            .setValue(0.0F)
            .range(0.0F, 3.0F);

    public HitBoxModule() {
        super("HitBox", "Hit Box", ModuleCategory.COMBAT);
        settings(xzExpandSetting, yExpandSetting);
    }

    @EventHandler
    public void onBoundingBoxControl(BoundingBoxControlEvent event) {
        if (event.getEntity() instanceof class_1309 living) {
            class_238 box = event.getBox();

            float xzExpand = xzExpandSetting.getValue();
            float yExpand = yExpandSetting.getValue();
            class_238 changedBox = new class_238(box.field_1323 - xzExpand / 2.0f, box.field_1322 - yExpand / 2.0f,
                    box.field_1321 - xzExpand / 2.0f, box.field_1320 + xzExpand / 2.0f,
                    box.field_1325 + yExpand / 2.0f, box.field_1324 + xzExpand / 2.0f);

            if (living != mc.field_1724 && !FriendUtils.isFriend(living)) {
                event.setBox(changedBox);
            }
        }
    }
}
