package moonshine.modules.impl.combat;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AutoGApple extends ModuleStructure {

    final SliderSettings healthThreshold = new SliderSettings("Здоровье", "Порог здоровья для еды")
            .range(3.0f, 20.0f).setValue(16.0f);

    final BooleanSetting smartMode = new BooleanSetting("Умный", "Есть из хотбара, иначе только с левой руки")
            .setValue(true);

    final BooleanSetting goldenHearts = new BooleanSetting("Золотые сердца", "Учитывать absorption")
            .setValue(true);

    final BooleanSetting returnSlot = new BooleanSetting("Возвращать слот", "Возвращать предыдущий слот после еды")
            .setValue(true);

    boolean isEating = false;
    int previousSlot = -1;

    public AutoGApple() {
        super("AutoGApple", "Auto GApple", ModuleCategory.COMBAT);
        settings(healthThreshold, smartMode, goldenHearts, returnSlot);
    }

    @Override
    public void activate() {
        isEating = false;
        previousSlot = -1;
    }

    @Override
    public void deactivate() {
        stopEating();
    }

    @EventHandler
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        handleEating();
    }

    private void handleEating() {
        if (canEat()) {
            if (smartMode.isValue()) {
                if (!hasGappleInHand()) {
                    swapToGappleSlot();
                }
                startEating();
            } else {
                if (hasGappleInOffhand()) {
                    startEating();
                }
            }
        } else if (isEating && !shouldContinueEating()) {
            stopEating();
        }
    }

    private boolean hasGappleInHand() {
        class_1799 mainHand = mc.field_1724.method_6047();
        return mainHand.method_7909() == class_1802.field_8463;
    }

    private boolean canEat() {
        if (mc.field_1724.method_29504()) return false;
        if (mc.field_1724.method_7357().method_7904(class_1802.field_8463.method_7854())) return false;

        if (smartMode.isValue()) {
            if (!hasGapple()) return false;
        } else {
            if (!hasGappleInOffhand()) return false;
        }

        float health = getEffectiveHealth();
        return health <= healthThreshold.getValue();
    }

    private boolean shouldContinueEating() {
        if (mc.field_1724.method_29504()) return false;
        if (!mc.field_1724.method_6115()) return false;

        class_1799 usingItem = mc.field_1724.method_6030();
        return usingItem.method_7909() == class_1802.field_8463;
    }

    private float getEffectiveHealth() {
        float health = mc.field_1724.method_6032();
        if (goldenHearts.isValue()) {
            health += mc.field_1724.method_6067();
        }
        return health;
    }

    private boolean hasGappleInOffhand() {
        class_1799 offhandStack = mc.field_1724.method_6079();
        return offhandStack.method_7909() == class_1802.field_8463;
    }

    private boolean hasGappleInHotbar() {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() == class_1802.field_8463) {
                return true;
            }
        }
        return false;
    }

    private boolean hasGapple() {
        return hasGappleInOffhand() || hasGappleInHotbar();
    }

    private int findGappleInHotbar() {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() == class_1802.field_8463) {
                return i;
            }
        }
        return -1;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void swapToGappleSlot() {
        int gappleSlot = findGappleInHotbar();
        if (gappleSlot == -1) return;

        int currentSlot = mc.field_1724.method_31548().method_67532();

        if (currentSlot != gappleSlot) {
            if (previousSlot == -1 && returnSlot.isValue()) {
                previousSlot = currentSlot;
            }
            mc.field_1724.method_31548().method_61496(gappleSlot);
        }
    }

    private void startEating() {
        if (!isEating && !mc.field_1690.field_1904.method_1434()) {
            mc.field_1690.field_1904.method_23481(true);
            isEating = true;
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void stopEating() {
        if (isEating) {
            mc.field_1690.field_1904.method_23481(false);
            isEating = false;

            if (previousSlot != -1 && returnSlot.isValue()) {
                mc.field_1724.method_31548().method_61496(previousSlot);
                previousSlot = -1;
            }
        }
    }
}