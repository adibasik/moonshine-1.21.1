package moonshine.modules.impl.combat;

import antidaunleak.api.annotation.Native;
import com.mojang.authlib.GameProfile;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.PacketEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.util.Instance;
import net.minecraft.class_10192;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2703;
import net.minecraft.class_7828;
import net.minecraft.class_9334;
import java.util.*;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class AntiBot extends ModuleStructure {
    @Native(type = Native.Type.VMProtectBeginUltra)
    public static AntiBot getInstance() {
        return Instance.get(AntiBot.class);
    }

    Set<UUID> suspectSet = new HashSet<>();
    static Set<UUID> botSet = new HashSet<>();
    SelectSetting mode = new SelectSetting("Режим", "Выберите режим обнаружения ботов")
            .value("Matrix", "ReallyWorld")
            .selected("ReallyWorld");

    private static final class_1304[] ARMOR_SLOTS = {
            class_1304.field_6169,
            class_1304.field_6174,
            class_1304.field_6172,
            class_1304.field_6166
    };

    public AntiBot() {
        super("AntiBot", "Anti Bot", ModuleCategory.COMBAT);
        settings(mode);
    }

    @EventHandler
    public void onPacket(PacketEvent e) {
        switch (e.getPacket()) {
            case class_2703 list -> checkPlayerAfterSpawn(list);
            case class_7828 remove -> removePlayerBecauseLeftServer(remove);
            default -> {}
        }
    }

    @EventHandler
    public void onTick(TickEvent e) {
        if (!suspectSet.isEmpty()) {
            mc.field_1687.method_18456().stream()
                    .filter(p -> suspectSet.contains(p.method_5667()))
                    .forEach(this::evaluateSuspectPlayer);
        }
        if (mode.isSelected("Matrix")) {
            matrixMode();
        } else if (mode.isSelected("ReallyWorld")) {
            ReallyWorldMode();
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void checkPlayerAfterSpawn(class_2703 listS2CPacket) {
        listS2CPacket.method_46330().forEach(entry -> {
            GameProfile profile = entry.comp_1107();
            if (profile == null || isRealPlayer(entry, profile)) {
                return;
            }
            if (isDuplicateProfile(profile)) {
                botSet.add(profile.id());
            } else {
                suspectSet.add(profile.id());
            }
        });
    }

    private void removePlayerBecauseLeftServer(class_7828 removeS2CPacket) {
        removeS2CPacket.comp_1105().forEach(uuid -> {
            suspectSet.remove(uuid);
            botSet.remove(uuid);
        });
    }

    private boolean isRealPlayer(class_2703.class_2705 entry, GameProfile profile) {
        return entry.comp_1109() < 2 || (profile.properties() != null && !profile.properties().isEmpty());
    }

    private void evaluateSuspectPlayer(class_1657 player) {
        List<class_1799> armor = null;
        if (!isFullyEquipped(player)) {
            armor = getArmorItems(player);
        }
        if (isFullyEquipped(player) || hasArmorChanged(player, armor)) {
            botSet.add(player.method_5667());
        }
        suspectSet.remove(player.method_5667());
    }

    private List<class_1799> getArmorItems(class_1657 entity) {
        List<class_1799> armorItems = new ArrayList<>();
        for (class_1304 slot : ARMOR_SLOTS) {
            armorItems.add(entity.method_6118(slot));
        }
        return armorItems;
    }

    private class_1799 getArmorStack(class_1657 entity, int index) {
        if (index >= 0 && index < ARMOR_SLOTS.length) {
            return entity.method_6118(ARMOR_SLOTS[index]);
        }
        return class_1799.field_8037;
    }

    private boolean isArmorItem(class_1799 stack) {
        if (stack.method_7960()) return false;
        class_10192 equippable = stack.method_58694(class_9334.field_54196);
        if (equippable == null) return false;
        class_1304 slot = equippable.comp_3174();
        return slot == class_1304.field_6169 || slot == class_1304.field_6174 ||
                slot == class_1304.field_6172 || slot == class_1304.field_6166;
    }

    private void matrixMode() {
        Iterator<UUID> iterator = suspectSet.iterator();
        while (iterator.hasNext()) {
            UUID susPlayer = iterator.next();
            class_1657 entity = mc.field_1687.method_18470(susPlayer);
            if (entity != null) {
                String playerName = entity.method_5477().getString();
                boolean isNameBot = playerName.startsWith("CIT-") && !playerName.contains("NPC") && !playerName.contains("[ZNPC]");
                int armorCount = 0;
                for (class_1304 slot : ARMOR_SLOTS) {
                    class_1799 item = entity.method_6118(slot);
                    if (!item.method_7960()) armorCount++;
                }
                boolean isFullArmor = armorCount == 4;
                boolean isFakeUUID = !entity.method_5667().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + playerName).getBytes()));
                if (isFullArmor || isNameBot || isFakeUUID) {
                    botSet.add(susPlayer);
                }
            }
            iterator.remove();
        }
        if (mc.field_1724.field_6012 % 100 == 0) {
            botSet.removeIf(uuid -> mc.field_1687.method_18470(uuid) == null);
        }
    }

    private void ReallyWorldMode() {
        for (class_1657 entity : mc.field_1687.method_18456()) {
            if (!entity.method_5667().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + entity.method_5477().getString()).getBytes()))
                    && !botSet.contains(entity.method_5667())
                    && !entity.method_5477().getString().contains("NPC")
                    && !entity.method_5477().getString().startsWith("[ZNPC]")) {
                botSet.add(entity.method_5667());
            }
        }
    }

    private void newMatrixMode() {
        for (class_1657 entity : mc.field_1687.method_18456()) {
            if (entity != mc.field_1724) {
                List<class_1799> armorItems = getArmorItems(entity);
                boolean allArmorValid = true;
                for (class_1799 item : armorItems) {
                    if (item.method_7960() || !item.method_7923() || item.method_7919() > 0) {
                        allArmorValid = false;
                        break;
                    }
                }
                boolean hasSpecificArmor = false;
                for (class_1799 item : armorItems) {
                    if (item.method_7909() == class_1802.field_8370 || item.method_7909() == class_1802.field_8570
                            || item.method_7909() == class_1802.field_8577 || item.method_7909() == class_1802.field_8267
                            || item.method_7909() == class_1802.field_8660 || item.method_7909() == class_1802.field_8396
                            || item.method_7909() == class_1802.field_8523 || item.method_7909() == class_1802.field_8743) {
                        hasSpecificArmor = true;
                        break;
                    }
                }
                if (allArmorValid && hasSpecificArmor
                        && entity.method_5998(class_1268.field_5810).method_7909() == class_1802.field_8162
                        && entity.method_5998(class_1268.field_5808).method_7909() != class_1802.field_8162
                        && entity.method_7344().method_7586() == 20
                        && !entity.method_5477().getString().contains("NPC")
                        && !entity.method_5477().getString().startsWith("[ZNPC]")) {
                    botSet.add(entity.method_5667());
                } else {
                    botSet.remove(entity.method_5667());
                }
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    public boolean isDuplicateProfile(GameProfile profile) {
        return Objects.requireNonNull(mc.method_1562()).method_2880().stream()
                .filter(player -> player.method_2966().name().equals(profile.name()) && !player.method_2966().id().equals(profile.id()))
                .count() == 1;
    }

    public boolean isFullyEquipped(class_1657 entity) {
        for (class_1304 slot : ARMOR_SLOTS) {
            class_1799 stack = entity.method_6118(slot);
            if (!isArmorItem(stack) || stack.method_7942()) {
                return false;
            }
        }
        return true;
    }

    public boolean hasArmorChanged(class_1657 entity, List<class_1799> prevArmor) {
        if (prevArmor == null) {
            return true;
        }
        List<class_1799> currentArmorList = getArmorItems(entity);
        if (currentArmorList.size() != prevArmor.size()) {
            return true;
        }
        for (int i = 0; i < currentArmorList.size(); i++) {
            if (!class_1799.method_7973(currentArmorList.get(i), prevArmor.get(i))) {
                return true;
            }
        }
        return false;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    public boolean isBot(class_1657 entity) {
        String playerName = entity.method_5477().getString();
        boolean isNameBot = playerName.startsWith("CIT-") && !playerName.contains("NPC") && !playerName.startsWith("[ZNPC]");
        boolean isMarkedBot = botSet.contains(entity.method_5667());
        isBotU(entity);
        return isNameBot || isMarkedBot;
    }

    public boolean isBot(UUID uuid) {
        return botSet.contains(uuid);
    }

    public boolean isBotU(class_1297 entity) {
        return !entity.method_5667().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + entity.method_5477().getString()).getBytes()))
                && entity.method_5767()
                && !entity.method_5477().getString().contains("NPC")
                && !entity.method_5477().getString().startsWith("[ZNPC]");
    }

    public void reset() {
        suspectSet.clear();
        botSet.clear();
    }

    @Override
    public void deactivate() {
        reset();
        super.deactivate();
    }
}