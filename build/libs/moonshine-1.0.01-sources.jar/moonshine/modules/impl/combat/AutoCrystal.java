package moonshine.modules.impl.combat;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.EntitySpawnEvent;
import moonshine.events.impl.InputEvent;
import moonshine.events.impl.PacketEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.MultiSelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.inventory.InventoryUtils;
import moonshine.util.inventory.SwapExecutor;
import moonshine.util.inventory.SwapSettings;
import moonshine.util.repository.friend.FriendUtils;
import moonshine.util.string.PlayerInteractionHelper;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2885;
import net.minecraft.class_3965;
import java.util.List;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AutoCrystal extends ModuleStructure {

    private final MultiSelectSetting protections = new MultiSelectSetting("Защита", "Что не взрывать")
            .value("Себя", "Друзей", "Ресурсы")
            .selected("Себя", "Друзей", "Ресурсы");

    private final SliderSettings itemRange = new SliderSettings("Дистанция до ресурсов", "Минимальное расстояние до ресурсов")
            .range(1.0f, 12.0f)
            .setValue(6.0f);

    private final BooleanSetting legitMode = new BooleanSetting("Легит режим", "Останавливать движение перед свапом")
            .setValue(false);

    private final SliderSettings swapDelay = new SliderSettings("Задержка свапа", "Мс перед свапом кристалла")
            .range(0, 200)
            .setValue(50)
            .visible(() -> legitMode.isValue());

    private final SwapExecutor swapExecutor = new SwapExecutor();
    private class_2338 obsPosition;
    private boolean waitingForCrystal;

    public AutoCrystal() {
        super("AutoCrystal", "Auto Crystal", ModuleCategory.COMBAT);
        settings(protections, itemRange, legitMode, swapDelay);
    }

    @Override
    public void activate() {
        obsPosition = null;
        waitingForCrystal = false;
    }

    @Override
    public void deactivate() {
        swapExecutor.cancel();
        obsPosition = null;
        waitingForCrystal = false;
    }

    @EventHandler
    public void onPacket(PacketEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (swapExecutor.isRunning() || waitingForCrystal) return;

        if (e.getPacket() instanceof class_2885 interact && interact.method_42080() != 0) {
            class_2338 interactPos = interact.method_12543().method_17777();
            class_2338 spawnPos = interactPos.method_10093(interact.method_12543().method_17780());

            class_2338 blockPos = null;
            if (mc.field_1687.method_8320(spawnPos).method_26204().equals(class_2246.field_10540)) {
                blockPos = spawnPos;
            } else if (mc.field_1687.method_8320(interactPos).method_26204().equals(class_2246.field_10540)) {
                blockPos = interactPos;
            }

            if (blockPos == null) return;

            class_1735 crystalSlot = findCrystalSlot();
            if (crystalSlot == null) return;

            if (!isSafePosition(blockPos)) return;

            final class_2338 finalBlockPos = blockPos;
            obsPosition = blockPos;
            waitingForCrystal = true;

            SwapSettings settings = legitMode.isValue()
                    ? new SwapSettings()
                    .stopMovement(true)
                    .stopSprint(true)
                    .preSwapDelay(swapDelay.getInt(), swapDelay.getInt() + 30)
                    .postSwapDelay(20, 50)
                    : SwapSettings.instant();

            swapExecutor.execute(() -> {
                placeCrystal(crystalSlot, finalBlockPos);
            }, settings, () -> {
                scheduleReset();
            });
        }
    }

    private void placeCrystal(class_1735 crystalSlot, class_2338 blockPos) {
        if (crystalSlot == null || blockPos == null) return;

        int currentSlot = InventoryUtils.currentSlot();

        if (crystalSlot.field_7874 >= 36 && crystalSlot.field_7874 <= 44) {
            int hotbarSlot = crystalSlot.field_7874 - 36;
            InventoryUtils.selectSlot(hotbarSlot);

            PlayerInteractionHelper.sendSequencedPacket(i ->
                    new class_2885(
                            class_1268.field_5808,
                            new class_3965(blockPos.method_46558(), class_2350.field_11036, blockPos, false),
                            i
                    )
            );

            InventoryUtils.selectSlot(currentSlot);
        } else {
            InventoryUtils.swapHotbar(crystalSlot.field_7874, currentSlot);

            PlayerInteractionHelper.sendSequencedPacket(i ->
                    new class_2885(
                            class_1268.field_5808,
                            new class_3965(blockPos.method_46558(), class_2350.field_11036, blockPos, false),
                            i
                    )
            );

            InventoryUtils.swapHotbar(crystalSlot.field_7874, currentSlot);
            InventoryUtils.closeScreen();
        }
    }

    private void scheduleReset() {
        // Сбрасываем через 6 тиков если кристалл не появился
        resetTicks = 6;
    }

    private int resetTicks = 0;

    @EventHandler
    public void onEntitySpawnEvent(EntitySpawnEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (e.getEntity() instanceof class_1511 crystal) {
            if (obsPosition != null && obsPosition.equals(crystal.method_24515().method_10074())) {
                if (isSafeToDamage(crystal)) {
                    mc.field_1761.method_2918(mc.field_1724, crystal);
                }
                resetState();
            }
        }
    }

    @EventHandler
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        swapExecutor.tick();

        if (resetTicks > 0) {
            resetTicks--;
            if (resetTicks == 0) {
                resetState();
            }
        }
    }

    @EventHandler
    public void onInput(InputEvent e) {
        if (swapExecutor.isBlocking()) {
            e.setDirectionalLow(false, false, false, false);
            e.setJumping(false);
        }
    }

    private void resetState() {
        obsPosition = null;
        waitingForCrystal = false;
        resetTicks = 0;
    }

    private class_1735 findCrystalSlot() {
        return InventoryUtils.findSlot(class_1802.field_8301);
    }

    private boolean isSafePosition(class_2338 pos) {
        if (protections.isSelected("Себя")) {
            if (mc.field_1724.method_23318() > pos.method_10264()) {
                return false;
            }
        }

        if (protections.isSelected("Друзей")) {
            for (class_1657 player : mc.field_1687.method_18456()) {
                if (player == mc.field_1724) continue;
                if (FriendUtils.isFriend(player)) {
                    if (player.method_23318() > pos.method_10264()) {
                        return false;
                    }
                }
            }
        }

        if (protections.isSelected("Ресурсы")) {
            class_243 crystalPos = pos.method_10084().method_46558();
            double range = itemRange.getValue();
            class_238 box = new class_238(
                    crystalPos.field_1352 - range, crystalPos.field_1351 - range, crystalPos.field_1350 - range,
                    crystalPos.field_1352 + range, crystalPos.field_1351 + range, crystalPos.field_1350 + range
            );
            List<class_1297> entities = mc.field_1687.method_8335(mc.field_1724, box);

            for (class_1297 entity : entities) {
                if (entity instanceof class_1542) {
                    return false;
                }
            }
        }

        return true;
    }

    private boolean isSafeToDamage(class_1511 crystal) {
        class_2338 crystalBlock = crystal.method_24515().method_10074();

        if (protections.isSelected("Себя")) {
            if (mc.field_1724.method_23318() > crystalBlock.method_10264()) {
                return false;
            }
        }

        if (protections.isSelected("Друзей")) {
            for (class_1657 player : mc.field_1687.method_18456()) {
                if (player == mc.field_1724) continue;
                if (FriendUtils.isFriend(player)) {
                    if (player.method_23318() > crystalBlock.method_10264()) {
                        return false;
                    }
                }
            }
        }

        if (protections.isSelected("Ресурсы")) {
            class_243 crystalPos = crystal.method_73189();
            double range = itemRange.getValue();
            class_238 box = new class_238(
                    crystalPos.field_1352 - range, crystalPos.field_1351 - range, crystalPos.field_1350 - range,
                    crystalPos.field_1352 + range, crystalPos.field_1351 + range, crystalPos.field_1350 + range
            );
            List<class_1297> entities = mc.field_1687.method_8335(mc.field_1724, box);

            for (class_1297 entity : entities) {
                if (entity instanceof class_1542) {
                    return false;
                }
            }
        }

        return true;
    }
}