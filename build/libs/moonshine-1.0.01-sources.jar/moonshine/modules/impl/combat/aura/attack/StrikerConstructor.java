package moonshine.modules.impl.combat.aura.attack;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import moonshine.IMinecraft;
import moonshine.events.impl.PacketEvent;
import moonshine.events.impl.UsingItemEvent;
import moonshine.modules.impl.combat.TriggerBot;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.module.setting.implement.SelectSetting;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import java.util.List;

@Getter
public class StrikerConstructor implements IMinecraft {
    StrikeManager attackHandler = new StrikeManager();

    public void tick() {
        attackHandler.tick();
    }

    public void onPacket(PacketEvent e) {
        attackHandler.onPacket(e);
    }

    public void performAttack(AttackPerpetratorConfigurable configurable) {
        attackHandler.handleAttack(configurable);
    }

    public void performTriggerAttack(AttackPerpetratorConfigurable configurable, TriggerBot triggerBot) {
        attackHandler.handleTriggerAttack(configurable, triggerBot);
    }

    public void onUsingItem(UsingItemEvent e) {
        attackHandler.onUsingItem(e);
    }
    @Getter
    @FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
    public static class AttackPerpetratorConfigurable {
        class_1309 target;
        Angle angle;
        float maximumRange;
        boolean onlyCritical, shouldBreakShield, shouldUnPressShield, eatAndAttack, multiPoints, ignoreWalls;
        class_238 box;
        SelectSetting aimMode;

        public AttackPerpetratorConfigurable(class_1309 target, Angle angle, float maximumRange, List<String> options, SelectSetting aimMode, class_238 box) {
            this.target = target;
            this.angle = angle;
            this.maximumRange = maximumRange;
            this.onlyCritical = options.contains("Только криты") || options.contains("Only Critical") || options.contains("Crits with space");
            this.shouldBreakShield = options.contains("Break Shield");
            this.shouldUnPressShield = options.contains("UnPress Shield");
            this.multiPoints = options.contains("Multi Points");
            this.eatAndAttack = options.contains("No Attack When Eat");
            this.ignoreWalls = options.contains("Бить сквозь стены") || options.contains("Ignore The Walls");
            this.box = box;
            this.aimMode = aimMode;
        }
    }
}