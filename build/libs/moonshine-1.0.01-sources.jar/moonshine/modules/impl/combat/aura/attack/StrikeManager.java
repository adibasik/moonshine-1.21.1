package moonshine.modules.impl.combat.aura.attack;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import moonshine.IMinecraft;
import moonshine.events.api.types.EventType;
import moonshine.events.impl.PacketEvent;
import moonshine.events.impl.UsingItemEvent;
import moonshine.modules.impl.combat.Aura;
import moonshine.modules.impl.combat.TriggerBot;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.impl.combat.aura.target.RaycastAngle;
import moonshine.modules.impl.movement.ElytraTarget;
import moonshine.util.player.PlayerSimulation;
import moonshine.util.string.PlayerInteractionHelper;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1802;
import net.minecraft.class_1839;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_4050;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class StrikeManager implements IMinecraft {
    private final Pressing clickScheduler = new Pressing();
    private final StopWatch attackTimer = new StopWatch();
    private final StopWatch shieldWatch = new StopWatch();

    private int count = 0;
    private int ticksOnBlock = 0;

    void tick() {
        if (mc.field_1724 != null && mc.field_1724.method_24828()) {
            ticksOnBlock++;
        } else {
            ticksOnBlock = 0;
        }
    }

    void onUsingItem(UsingItemEvent e) {
        if (e.getType() == EventType.START && !shieldWatch.finished(50)) {
            e.cancel();
        }
    }

    void onPacket(PacketEvent e) {
        class_2596<?> packet = e.getPacket();
        if (packet instanceof class_2879 || packet instanceof class_2868) {
            clickScheduler.recalculate();
        }
    }

    public void resetPendingState() {
    }

    private boolean hasAnyMovementInput() {
        if (mc.field_1724 == null)
            return false;
        return mc.field_1724.field_3913.field_54155.comp_3159() ||
                mc.field_1724.field_3913.field_54155.comp_3160() ||
                mc.field_1724.field_3913.field_54155.comp_3161() ||
                mc.field_1724.field_3913.field_54155.comp_3162();
    }

    private boolean isHoldingMace() {
        return clickScheduler.isHoldingMace();
    }

    private boolean isPlayerEating() {
        if (mc.field_1724 == null)
            return false;
        if (!mc.field_1724.method_6115())
            return false;
        var activeItem = mc.field_1724.method_6030();
        if (activeItem.method_7960())
            return false;
        var useAction = activeItem.method_7976();
        return useAction == class_1839.field_8950 || useAction == class_1839.field_8946;
    }

    private boolean shouldWaitForEating() {
        Aura aura = Aura.getInstance();
        return aura.options.isSelected("Не бить если ешь") && isPlayerEating();
    }

    private boolean isInWater() {
        return mc.field_1724 != null
                && (mc.field_1724.method_5799() || mc.field_1724.method_5869() || mc.field_1724.method_5681());
    }

    private boolean hasLowCeiling() {
        if (mc.field_1724 == null || mc.field_1687 == null)
            return false;

        class_2338 playerPos = mc.field_1724.method_24515();
        class_2338 above1 = playerPos.method_10086(2);
        class_2338 above2 = playerPos.method_10086(3);

        class_2680 state1 = mc.field_1687.method_8320(above1);
        class_2680 state2 = mc.field_1687.method_8320(above2);

        boolean blocked1 = !state1.method_26215() && !state1.method_26220(mc.field_1687, above1).method_1110();
        boolean blocked2 = !state2.method_26215() && !state2.method_26220(mc.field_1687, above2).method_1110();

        return blocked1 || blocked2;
    }

    private boolean isPerfectCrit() {
        if (mc.field_1724 == null)
            return false;

        return mc.field_1724.field_6017 > 0.0F
                && !mc.field_1724.method_24828()
                && !mc.field_1724.method_6101()
                && !mc.field_1724.method_5799()
                && !mc.field_1724.method_6059(class_1294.field_5919)
                && !mc.field_1724.method_5765()
                && !mc.field_1724.method_31549().field_7479;
    }

    private boolean isAscending() {
        if (mc.field_1724 == null)
            return false;
        return !mc.field_1724.method_24828() && mc.field_1724.method_18798().field_1351 > 0.0;
    }

    private boolean isDescending() {
        if (mc.field_1724 == null)
            return false;
        return !mc.field_1724.method_24828() && mc.field_1724.method_18798().field_1351 <= 0.0;
    }

    private boolean willBeCritInTicks(int ticks) {
        if (ticks == 0) {
            return isPerfectCrit();
        }

        PlayerSimulation sim = PlayerSimulation.simulateLocalPlayer(ticks);

        return sim.fallDistance > 0.0F
                && !sim.onGround
                && sim.velocity.field_1351 <= 0.0
                && !sim.isClimbing()
                && !sim.player.method_5799()
                && !sim.hasStatusEffect(class_1294.field_5919)
                && !sim.player.method_5765()
                && !sim.player.method_31549().field_7479;
    }

    private boolean hasMovementRestrictions() {
        if (mc.field_1724 == null)
            return true;

        if (isInWater())
            return false;
        if (hasLowCeiling())
            return true;
        if (mc.field_1724.method_6059(class_1294.field_5919))
            return true;
        if (mc.field_1724.method_6059(class_1294.field_5902))
            return true;
        if (PlayerInteractionHelper.isBoxInBlock(mc.field_1724.method_5829().method_1014(-1e-3), class_2246.field_10343))
            return true;
        if (mc.field_1724.method_5771())
            return true;
        if (mc.field_1724.method_6101())
            return true;
        if (!PlayerInteractionHelper.canChangeIntoPose(class_4050.field_18076, mc.field_1724.method_73189()))
            return true;
        if (mc.field_1724.method_31549().field_7479)
            return true;

        return false;
    }

    private boolean shouldResetSprintForCrit() {
        if (mc.field_1724 == null)
            return false;

        if (isInWater())
            return false;
        if (mc.field_1724.method_6128())
            return false;

        return mc.field_1724.method_5624();
    }

    private boolean canCritNow() {
        Aura aura = Aura.getInstance();
        boolean checkCritEnabled = aura.getCheckCrit().isValue();
        boolean smartCritsEnabled = aura.getSmartCrits().isValue();

        if (isInWater() || hasLowCeiling() || hasMovementRestrictions()) {
            return true;
        }

        if (!checkCritEnabled) {
            return true;
        }

        if (isAscending()) {
            return false;
        }

        if (smartCritsEnabled) {
            if (mc.field_1724.method_24828()) {
                return true;
            }
            return isDescending() && mc.field_1724.field_6017 > 0.0F;
        }

        return isPerfectCrit();
    }

    void handleAttack(StrikerConstructor.AttackPerpetratorConfigurable config) {
        if (config.getTarget() == null || !config.getTarget().isAlive()) {
            return;
        }

        if (shouldWaitForEating()) {
            return;
        }

        if (isHoldingMace()) {
            handleMaceAttack(config);
            return;
        }

        boolean elytraMode = checkElytraMode(config);
        if (elytraMode && !checkElytraRaycast(config)) {
            return;
        }

        if (!RaycastAngle.rayTrace(config)) {
            return;
        }

        if (!isLookingAtTarget(config)) {
            return;
        }

        if (!clickScheduler.isCooldownComplete(0)) {
            return;
        }

        if (!canCritNow()) {
            return;
        }

        preAttackEntity(config);

        boolean wasSprinting = mc.field_1724.method_5624();
        boolean shouldReset = wasSprinting && shouldResetSprintForCrit();

        if (shouldReset) {
            if (Aura.getInstance().getResetSprintMode().isSelected("Пакетный")) {
                mc.method_1562()
                        .method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12985));
            } else {
                mc.field_1724.method_5728(false);
            }
        }

        executeAttack(config);

        if (shouldReset) {
            if (Aura.getInstance().getResetSprintMode().isSelected("Пакетный")) {
                mc.method_1562()
                        .method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12981));
            } else {
                mc.field_1724.method_5728(true);
            }
        }
    }

    private void preAttackEntity(StrikerConstructor.AttackPerpetratorConfigurable config) {
        if (config.isShouldUnPressShield() &&
                mc.field_1724.method_6115() &&
                mc.field_1724.method_6030().method_7909().equals(class_1802.field_8255)) {
            mc.field_1761.method_2897(mc.field_1724);
            shieldWatch.reset();
        }
    }

    private void handleMaceAttack(StrikerConstructor.AttackPerpetratorConfigurable config) {
        if (shouldWaitForEating())
            return;
        if (mc.field_1724.method_5739(config.getTarget()) > Aura.getInstance().getAttackrange().getValue())
            return;
        if (!RaycastAngle.rayTrace(config))
            return;
        if (!isLookingAtTarget(config))
            return;
        if (!clickScheduler.isMaceFastAttack())
            return;
        if (!attackTimer.finished(25))
            return;

        preAttackEntity(config);

        boolean wasSprinting = mc.field_1724.method_5624();
        boolean shouldReset = wasSprinting && shouldResetSprintForCrit();

        if (shouldReset) {
            if (Aura.getInstance().getResetSprintMode().isSelected("Пакетный")) {
                mc.method_1562()
                        .method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12985));
            } else {
                mc.field_1724.method_5728(false);
            }
        }

        executeAttack(config);

        if (shouldReset) {
            if (Aura.getInstance().getResetSprintMode().isSelected("Пакетный")) {
                mc.method_1562()
                        .method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12981));
            } else {
                mc.field_1724.method_5728(true);
            }
        }
    }

    private boolean checkElytraMode(StrikerConstructor.AttackPerpetratorConfigurable config) {
        return Aura.target != null &&
                Aura.target.method_6128() &&
                mc.field_1724.method_6128() &&
                ElytraTarget.getInstance() != null &&
                ElytraTarget.getInstance().isState();
    }

    private boolean checkElytraRaycast(StrikerConstructor.AttackPerpetratorConfigurable config) {
        class_243 targetVelocity = config.getTarget().getVelocity();
        float leadTicks = 0;
        if (ElytraTarget.shouldElytraTarget) {
            leadTicks = ElytraTarget.getInstance().elytraForward.getValue();
        }
        class_243 predictedPos = config.getTarget().getEntityPos().add(targetVelocity.method_1021(leadTicks));
        class_238 predictedBox = new class_238(
                predictedPos.field_1352 - config.getTarget().getWidth() / 2,
                predictedPos.field_1351,
                predictedPos.field_1350 - config.getTarget().getWidth() / 2,
                predictedPos.field_1352 + config.getTarget().getWidth() / 2,
                predictedPos.field_1351 + config.getTarget().getHeight(),
                predictedPos.field_1350 + config.getTarget().getWidth() / 2);
        class_243 eyePos = mc.field_1724.method_33571();
        class_243 lookVec = AngleConnection.INSTANCE.getRotation().toVector();
        return predictedBox.method_992(eyePos, eyePos.method_1019(lookVec.method_18806(config.getMaximumRange()))).isPresent();
    }

    private void executeAttack(StrikerConstructor.AttackPerpetratorConfigurable config) {
        mc.field_1761.method_2918(mc.field_1724, config.getTarget());
        mc.field_1724.method_6104(class_1268.field_5808);
        attackTimer.reset();
        count++;
    }

    void handleTriggerAttack(StrikerConstructor.AttackPerpetratorConfigurable config, TriggerBot triggerBot) {
        if (shouldWaitForEating())
            return;
        if (!RaycastAngle.rayTrace(config))
            return;
        if (!isLookingAtTarget(config))
            return;
        if (!clickScheduler.isCooldownComplete(0))
            return;
        if (!canAttackTrigger(config, triggerBot))
            return;

        preAttackEntity(config);

        boolean wasSprinting = mc.field_1724.method_5624();
        boolean shouldReset = wasSprinting && shouldResetSprintForCrit();

        if (shouldReset) {
            if (Aura.getInstance().getResetSprintMode().isSelected("Пакетный")) {
                mc.method_1562()
                        .method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12985));
            } else {
                mc.field_1724.method_5728(false);
            }
        }

        executeAttack(config);

        if (shouldReset) {
            if (Aura.getInstance().getResetSprintMode().isSelected("Пакетный")) {
                mc.method_1562()
                        .method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12981));
            } else {
                mc.field_1724.method_5728(true);
            }
        }
    }

    private boolean canAttackTrigger(StrikerConstructor.AttackPerpetratorConfigurable config, TriggerBot triggerBot) {
        if (shouldWaitForEating())
            return false;
        if (!clickScheduler.isCooldownComplete(0))
            return false;

        boolean checkCritEnabled = triggerBot.isOnlyCrits();
        boolean smartCritsEnabled = triggerBot.getSmartCrits().isValue();

        if (isInWater() || hasLowCeiling() || hasMovementRestrictions()) {
            return true;
        }

        if (!checkCritEnabled)
            return true;

        if (isAscending())
            return false;

        if (smartCritsEnabled) {
            if (mc.field_1724.method_24828()) {
                return true;
            }
            return isDescending() && mc.field_1724.field_6017 > 0.0F;
        }

        return isPerfectCrit();
    }

    public boolean shouldResetSprinting(StrikerConstructor.AttackPerpetratorConfigurable config) {
        if (Aura.target == null)
            return false;
        if (shouldWaitForEating())
            return false;
        if (isHoldingMace())
            return true;
        return shouldResetSprintForCrit();
    }

    public boolean shouldResetSprintingForTrigger(StrikerConstructor.AttackPerpetratorConfigurable config,
            TriggerBot triggerBot) {
        if (triggerBot.target == null)
            return false;
        if (shouldWaitForEating())
            return false;
        return shouldResetSprintForCrit();
    }

    public boolean canAttack(StrikerConstructor.AttackPerpetratorConfigurable config, int ticks) {
        if (shouldWaitForEating())
            return false;
        if (isHoldingMace()) {
            return attackTimer.finished(25) && clickScheduler.isMaceFastAttack();
        }

        if (!clickScheduler.isCooldownComplete(0)) {
            return false;
        }

        if (ticks > 0) {
            Aura aura = Aura.getInstance();
            boolean checkCritEnabled = aura.getCheckCrit().isValue();
            boolean smartCritsEnabled = aura.getSmartCrits().isValue();

            if (!checkCritEnabled)
                return true;
            if (isInWater() || hasLowCeiling() || hasMovementRestrictions())
                return true;

            for (int i = 0; i <= ticks; i++) {
                if (willBeCritInTicks(i))
                    return true;
                if (smartCritsEnabled) {
                    PlayerSimulation sim = PlayerSimulation.simulateLocalPlayer(i);
                    if (sim.onGround)
                        return true;
                }
            }
            return false;
        }

        return clickScheduler.isCooldownComplete(0) && canCritNow();
    }

    public boolean canCrit(StrikerConstructor.AttackPerpetratorConfigurable config, int ticks) {
        if (isHoldingMace())
            return true;

        if (mc.field_1724.method_6115()
                && !mc.field_1724.method_6030().method_7909().equals(class_1802.field_8255)
                && config.isEatAndAttack()) {
            return false;
        }

        if (isInWater() || hasLowCeiling() || hasMovementRestrictions()) {
            return true;
        }

        Aura aura = Aura.getInstance();
        boolean checkCritEnabled = aura.getCheckCrit().isValue();
        boolean smartCritsEnabled = aura.getSmartCrits().isValue();

        if (!checkCritEnabled)
            return true;

        if (ticks > 0) {
            for (int i = 0; i <= ticks; i++) {
                if (willBeCritInTicks(i))
                    return true;
                if (smartCritsEnabled) {
                    PlayerSimulation sim = PlayerSimulation.simulateLocalPlayer(i);
                    if (sim.onGround)
                        return true;
                }
            }
            return false;
        }

        return canCritNow();
    }

    private boolean isLookingAtTarget(StrikerConstructor.AttackPerpetratorConfigurable config) {
        class_243 eyePos = mc.field_1724.method_33571();
        class_243 lookVec = AngleConnection.INSTANCE.getRotation().toVector();
        class_243 endVec = eyePos.method_1019(lookVec.method_18806(config.getMaximumRange()));
        return config.getBox().raycast(eyePos, endVec).isPresent();
    }
}