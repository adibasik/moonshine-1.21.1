package moonshine.modules.impl.combat.aura;

import lombok.*;
import lombok.experimental.FieldDefaults;
import moonshine.util.math.MathUtils;
import net.minecraft.class_243;
import net.minecraft.class_3532;

import static net.minecraft.class_3532.method_15338;

@Getter
@Setter
@ToString
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Angle {
    public static Angle DEFAULT = new Angle(0, 0);
    float yaw, pitch;


    public static Angle fromTargetHead(class_243 playerPos, class_243 targetPos, double targetHeight) {
        double headY = targetPos.field_1351 + targetHeight * 0.9;

        double deltaX = targetPos.field_1352 - playerPos.field_1352;
        double deltaY = headY - (playerPos.field_1351 + 1.5);
        double deltaZ = targetPos.field_1350 - playerPos.field_1350;

        float yaw = (float) Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0f;
        yaw = method_15393(yaw);

        double horizontalDistance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        float pitch = (float) Math.toDegrees(-Math.atan2(deltaY, horizontalDistance));
        pitch = class_3532.method_15363(pitch, -90.0f, 90.0f);

        return new Angle(yaw, pitch);
    }

    public Angle adjustSensitivity() {
        double gcd = MathUtils.computeGcd();

        Angle previousAngle = AngleConnection.INSTANCE.getServerAngle();

        float adjustedYaw = adjustAxis(yaw, previousAngle.yaw, gcd);
        float adjustedPitch = adjustAxis(pitch, previousAngle.pitch, gcd);

        return new Angle(adjustedYaw, class_3532.method_15363(adjustedPitch, -90f, 90f));
    }

    public Angle random(float f) {
        return new Angle(yaw + MathUtils.getRandom(-f, f), pitch + MathUtils.getRandom(-f, f));
    }

    private float adjustAxis(float axisValue, float previousValue, double gcd) {
        float delta = axisValue - previousValue;
        return previousValue + Math.round(delta / gcd) * (float) gcd;
    }

    public final class_243 toVector() {
        float f = pitch * 0.017453292F;
        float g = -yaw * 0.017453292F;
        float h = class_3532.method_15362(g);
        float i = class_3532.method_15374(g);
        float j = class_3532.method_15362(f);
        float k = class_3532.method_15374(f);
        return new class_243(i * j, -k, h * j);
    }

    public Angle addYaw(float yaw) {
        return new Angle(this.yaw + yaw, this.pitch);
    }

    public Angle addPitch(float pitch) {
        this.pitch = class_3532.method_15363(this.pitch + pitch, -90, 90);
        return this;
    }

    public Angle of(Angle angle) {
        return new Angle(angle.getYaw(), angle.getPitch());
    }

    @ToString
    @Getter
    @RequiredArgsConstructor
    @FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
    public static class VecRotation {
        final Angle angle;
        final class_243 vec;
    }
}