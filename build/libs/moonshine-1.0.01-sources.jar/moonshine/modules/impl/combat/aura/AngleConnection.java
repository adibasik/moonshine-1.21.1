package moonshine.modules.impl.combat.aura;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import moonshine.IMinecraft;
import moonshine.Initialization;
import moonshine.events.api.EventHandler;
import moonshine.events.api.EventManager;
import moonshine.events.api.types.EventType;
import moonshine.events.impl.PacketEvent;
import moonshine.events.impl.PlayerVelocityStrafeEvent;
import moonshine.events.impl.RotationUpdateEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.util.math.TaskPriority;
import moonshine.util.math.TaskProcessor;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_2708;
import net.minecraft.class_2828;
import net.minecraft.class_3532;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AngleConnection implements IMinecraft {
    public static AngleConnection INSTANCE = new AngleConnection();

    AngleConstructor lastRotationPlan;
    final TaskProcessor<AngleConstructor> rotationPlanTaskProcessor = new TaskProcessor<>();
    public Angle currentAngle;
    Angle previousAngle;
    Angle serverAngle = Angle.DEFAULT;
    Angle fakeAngle;
    boolean returning = false;


    public AngleConnection() {
        Initialization.getInstance().getManager().getEventManager().register(this);
    }

    public void setRotation(Angle value) {
        if (value == null) {
            this.previousAngle = this.currentAngle != null ? this.currentAngle : MathAngle.cameraAngle();
        } else {
            this.previousAngle = this.currentAngle;
        }

        this.currentAngle = value;
    }

    public Angle getRotation() {
        return currentAngle != null ? currentAngle : MathAngle.cameraAngle();
    }

    public Angle getFakeRotation() {
        if (fakeAngle != null) {
            return fakeAngle;
        }

        return currentAngle != null ? currentAngle : previousAngle != null ? previousAngle : MathAngle.cameraAngle();
    }

    public void setFakeRotation(Angle angle) {
        this.fakeAngle = angle;
    }

    public Angle getPreviousRotation() {
        return currentAngle != null && previousAngle != null ? previousAngle : new Angle(mc.field_1724.field_5982, mc.field_1724.field_6004);
    }

    public Angle getMoveRotation() {
        AngleConstructor rotationPlan = getCurrentRotationPlan();
        return currentAngle != null && rotationPlan != null && rotationPlan.isMoveCorrection() ? currentAngle : MathAngle.cameraAngle();
    }

    public AngleConstructor getCurrentRotationPlan() {
        return rotationPlanTaskProcessor.fetchActiveTaskValue() != null ? rotationPlanTaskProcessor.fetchActiveTaskValue() : lastRotationPlan;
    }

    public void rotateTo(Angle.VecRotation vecRotation, class_1309 entity, int reset, AngleConfig configurable, TaskPriority taskPriority, ModuleStructure provider) {
        rotateTo(configurable.createRotationPlan(vecRotation.getAngle(), vecRotation.getVec(), entity, reset), taskPriority, provider);
    }

    public void rotateTo(Angle angle, int reset, AngleConfig configurable, TaskPriority taskPriority, ModuleStructure provider) {
        rotateTo(configurable.createRotationPlan(angle, angle.toVector(), null, reset), taskPriority, provider);
    }

    public void rotateTo(Angle angle, AngleConfig configurable, TaskPriority taskPriority, ModuleStructure provider) {
        rotateTo(configurable.createRotationPlan(angle, angle.toVector(), null, 1), taskPriority, provider);
    }

    public void rotateTo(AngleConstructor plan, TaskPriority taskPriority, ModuleStructure provider) {
        returning = false;
        rotationPlanTaskProcessor.addTask(new TaskProcessor.Task<>(1, taskPriority.getPriority(), provider, plan));
    }


    public void update() {
        AngleConstructor activePlan = getCurrentRotationPlan();

        if (activePlan == null) {
            if (currentAngle != null && returning) {
                Angle cameraAngle = MathAngle.cameraAngle();
                double diff = computeRotationDifference(currentAngle, cameraAngle);

                if (diff < 0.5) {
                    setRotation(null);
                    lastRotationPlan = null;
                    returning = false;
                } else {
                    float speed = 0.25f;
                    float distanceFactor = Math.min(1.0f, (float) diff / 30.0f);
                    speed = speed + (0.4f * distanceFactor);

                    float yawDiff = class_3532.method_15392(cameraAngle.getYaw() - currentAngle.getYaw());
                    float newYaw = currentAngle.getYaw() + yawDiff * speed;
                    float newPitch = class_3532.method_61342(speed, currentAngle.getPitch(), cameraAngle.getPitch());

                    setRotation(new Angle(newYaw, newPitch).adjustSensitivity());
                }
            }
            return;
        }

        returning = false;

        Angle clientAngle = MathAngle.cameraAngle();

        if (lastRotationPlan != null) {
            double differenceFromCurrentToPlayer = computeRotationDifference(serverAngle, clientAngle);
            if (activePlan.getTicksUntilReset() <= rotationPlanTaskProcessor.tickCounter && differenceFromCurrentToPlayer < activePlan.getResetThreshold()) {
                setRotation(null);
                lastRotationPlan = null;
                rotationPlanTaskProcessor.tickCounter = 0;
                return;
            }
        }

        Angle newAngle = activePlan.nextRotation(currentAngle != null ? currentAngle : clientAngle, rotationPlanTaskProcessor.fetchActiveTaskValue() == null).adjustSensitivity();

        setRotation(newAngle);

        lastRotationPlan = activePlan;
        rotationPlanTaskProcessor.tick(1);
    }


    public static double computeRotationDifference(Angle a, Angle b) {
        return Math.hypot(Math.abs(computeAngleDifference(a.getYaw(), b.getYaw())), Math.abs(a.getPitch() - b.getPitch()));
    }

    public static float computeAngleDifference(float a, float b) {
        return class_3532.method_15393(a - b);
    }


    private class_243 fixVelocity(class_243 currVelocity, class_243 movementInput, float speed) {
        if (currentAngle != null) {
            float yaw = currentAngle.getYaw();
            double d = movementInput.method_1027();

            if (d < 1.0E-7) {
                return class_243.field_1353;
            } else {
                class_243 vec3d = (d > 1.0 ? movementInput.method_1029() : movementInput).method_1021(speed);

                float f = class_3532.method_15374(yaw * 0.017453292f);
                float g = class_3532.method_15362(yaw * 0.017453292f);

                return new class_243(vec3d.method_10216() * g - vec3d.method_10215() * f, vec3d.method_10214(), vec3d.method_10215() * g + vec3d.method_10216() * f);
            }
        }
        return currVelocity;
    }

    public void clear() {
        rotationPlanTaskProcessor.activeTasks.clear();
    }

    public void startReturning() {
//        clear();
//        lastRotationPlan = null;
//        rotationPlanTaskProcessor.tickCounter = 0;
//        returning = true;
    }

    public void reset() {
//        clear();
        currentAngle = null;
        previousAngle = null;
        fakeAngle = null;
        lastRotationPlan = null;
        rotationPlanTaskProcessor.tickCounter = 0;
//        returning = false;
    }

    @EventHandler
    public void onPlayerVelocityStrafe(PlayerVelocityStrafeEvent e) {
        AngleConstructor currentRotationPlan = getCurrentRotationPlan();
        if (currentRotationPlan != null && currentRotationPlan.isMoveCorrection()) {
            e.setVelocity(fixVelocity(e.getVelocity(), e.getMovementInput(), e.getSpeed()));
        }
    }

    @EventHandler
    public void onTick(TickEvent e) {
        EventManager.callEvent(new RotationUpdateEvent(EventType.PRE));
        update();
        EventManager.callEvent(new RotationUpdateEvent(EventType.POST));
    }

    @EventHandler
    public void onPacket(PacketEvent event) {
        if (!event.isCancelled()) switch (event.getPacket()) {
            case class_2828 player when player.method_36172() ->
                    serverAngle = new Angle(player.method_12271(1), player.method_12270(1));
            case class_2708 player ->
                    serverAngle = new Angle(player.comp_3228().comp_3150(), player.comp_3228().comp_3151());
            default -> {
            }
        }
    }
}