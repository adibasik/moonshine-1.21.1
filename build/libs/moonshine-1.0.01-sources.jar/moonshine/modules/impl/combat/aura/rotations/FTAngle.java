package moonshine.modules.impl.combat.aura.rotations;

import moonshine.Initialization;
import moonshine.modules.impl.combat.Aura;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.MathAngle;
import moonshine.modules.impl.combat.aura.attack.StrikeManager;
import moonshine.modules.impl.combat.aura.impl.RotateConstructor;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import java.security.SecureRandom;

import static moonshine.IMinecraft.mc;

public class FTAngle extends RotateConstructor {

    private final SecureRandom random = new SecureRandom();

    private static int lastCount = -1;
    private static int hitsAfterMiss = 0;
    private static long missEndTime = 0;
    private static int swingsDone = 0;

    private float currentJitterYaw = 0;
    private float currentJitterPitch = 0;
    private float targetJitterYaw = 0;
    private float targetJitterPitch = 0;

    public FTAngle() {
        super("FunTime");
    }

    @Override
    public Angle limitAngleChange(Angle currentAngle, Angle targetAngle, class_243 vec3d, class_1297 entity) {
        StrikeManager attackHandler = Initialization.getInstance().getManager().getAttackPerpetrator().getAttackHandler();
        StopWatch attackTimer = attackHandler.getAttackTimer();
        int count = attackHandler.getCount();
        Aura aura = Aura.getInstance();

        long now = System.currentTimeMillis();

        if (count != lastCount) {
            hitsAfterMiss++;
            lastCount = count;
        }

        if (hitsAfterMiss >= 40 && missEndTime == 0) {
            missEndTime = now + 350;
            hitsAfterMiss = 0;
            swingsDone = 0;
        }

        if (missEndTime != 0) {
            if (now < missEndTime) {
                long elapsed = now - (missEndTime - 350);
                if (swingsDone == 0 && elapsed >= 50) {
                    mc.field_1724.method_6104(class_1268.field_5808);
                    swingsDone = 1;
                } else if (swingsDone == 1 && elapsed >= 180) {
                    mc.field_1724.method_6104(class_1268.field_5808);
                    swingsDone = 2;
                }
                return new Angle(currentAngle.getYaw() + random.nextFloat() * 6 - 3, -80);
            } else {
                missEndTime = 0;
            }
        }

        Angle angleDelta = MathAngle.calculateDelta(currentAngle, targetAngle);
        float yawDelta = angleDelta.getYaw();
        float pitchDelta = angleDelta.getPitch();
        float rotationDifference = (float) Math.hypot(Math.abs(yawDelta), Math.abs(pitchDelta));

        if (rotationDifference < 0.01f) rotationDifference = 1;

        int suck = count % 3;
        float timeRandom = attackTimer.elapsedTime() / 80F + (count % 6);

        Angle randomAngle = switch (suck) {
            case 0 -> new Angle((float) Math.cos(timeRandom), (float) Math.sin(timeRandom));
            case 1 -> new Angle((float) Math.sin(timeRandom), (float) Math.cos(timeRandom));
            case 2 -> new Angle((float) Math.sin(timeRandom), (float) -Math.cos(timeRandom));
            default -> new Angle((float) -Math.cos(timeRandom), (float) Math.sin(timeRandom));
        };

        targetJitterYaw = randomLerp(11, 20) * randomAngle.getYaw();
        targetJitterPitch = randomLerp(1, 6) * randomAngle.getPitch() + randomLerp(2, 1) * (float) Math.cos(System.currentTimeMillis() / 8000.0);

        float jitterSmoothSpeed = 1f;
        currentJitterYaw += (targetJitterYaw - currentJitterYaw) * jitterSmoothSpeed;
        currentJitterPitch += (targetJitterPitch - currentJitterPitch) * jitterSmoothSpeed;

        if (entity != null) {
            float speed = attackHandler.canAttack(aura.getConfig(), 0) ? 0.9f : random.nextBoolean() ? 0.1F : 0.2F;

            float lineYaw = (Math.abs(yawDelta / rotationDifference) * 180);
            float linePitch = (Math.abs(pitchDelta / rotationDifference) * 180);

            float moveYaw = class_3532.method_15363(yawDelta, -lineYaw, lineYaw);
            float movePitch = class_3532.method_15363(pitchDelta, -linePitch, linePitch);

            float lerpSpeed = randomLerp(speed, speed + 0.6F);

            float newYaw = class_3532.method_61342(lerpSpeed, currentAngle.getYaw(), currentAngle.getYaw() + moveYaw) + currentJitterYaw;
            float newPitch = class_3532.method_61342(lerpSpeed, currentAngle.getPitch(), currentAngle.getPitch() + movePitch) + currentJitterPitch;

            return new Angle(newYaw, class_3532.method_15363(newPitch, -90, 90));

        } else {
            float speed = attackTimer.finished(650) ? (random.nextBoolean() ? 0.85F : 0.2F) : -0.2F;

            float yawJitter = !attackTimer.finished(2000) ? currentJitterYaw : 0;
            float pitchJitter = !attackTimer.finished(2000) ? currentJitterPitch : 0;

            float lineYaw = (Math.abs(yawDelta / rotationDifference) * 180);
            float linePitch = (Math.abs(pitchDelta / rotationDifference) * 180);

            float moveYaw = class_3532.method_15363(yawDelta, -lineYaw, lineYaw);
            float movePitch = class_3532.method_15363(pitchDelta, -linePitch, linePitch);

            float lerpSpeed = Math.clamp(randomLerp(speed, speed + 0.2F), 0, 1);

            float newYaw = class_3532.method_61342(lerpSpeed, currentAngle.getYaw(), currentAngle.getYaw() + moveYaw) + yawJitter;
            float newPitch = class_3532.method_61342(lerpSpeed, currentAngle.getPitch(), currentAngle.getPitch() + movePitch) + pitchJitter;

            return new Angle(newYaw, class_3532.method_15363(newPitch, -90, 90));
        }
    }

    private float randomLerp(float min, float max) {
        return class_3532.method_16439(random.nextFloat(), min, max);
    }

    @Override
    public class_243 randomValue() {
        return class_243.field_1353;
    }
}