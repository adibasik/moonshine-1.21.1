package moonshine.modules.impl.combat.aura.impl;

import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.MathAngle;
import net.minecraft.class_1297;
import net.minecraft.class_243;


public class LinearConstructor extends RotateConstructor {
    public LinearConstructor() {
        super("Linear");
    }
    public static final LinearConstructor INSTANCE = new LinearConstructor();

    @Override
    public Angle limitAngleChange(Angle currentAngle, Angle targetAngle, class_243 vec3d, class_1297 entity) {
        Angle angleDelta = MathAngle.calculateDelta(currentAngle, targetAngle);
        float yawDelta = angleDelta.getYaw();
        float pitchDelta = angleDelta.getPitch();

        float rotationDifference = (float) Math.hypot(yawDelta, pitchDelta);

        float straightLineYaw = Math.abs(yawDelta / rotationDifference) * 360.0F;
        float straightLinePitch = Math.abs(pitchDelta / rotationDifference) * 360.0F;

        float newYaw = currentAngle.getYaw() + Math.min(Math.max(yawDelta, -straightLineYaw), straightLineYaw);
        float newPitch = currentAngle.getPitch() + Math.min(Math.max(pitchDelta, -straightLinePitch), straightLinePitch);

        return new Angle(newYaw, newPitch);
    }

    @Override
    public class_243 randomValue() {
        return new class_243(0, 0, 0);
    }
}
