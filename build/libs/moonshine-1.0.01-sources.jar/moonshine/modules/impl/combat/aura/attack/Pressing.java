package moonshine.modules.impl.combat.aura.attack;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.IMinecraft;
import net.minecraft.class_1799;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class Pressing implements IMinecraft {

    long lastClickTime = System.currentTimeMillis();

    public boolean isCooldownComplete(int ticks) {
        if (mc.field_1724 == null)
            return false;

        if (isHoldingMace()) {
            return lastClickPassed() >= 50;
        }

        float cooldownProgress = mc.field_1724.method_7261(ticks);
        return cooldownProgress >= 0.95F;
    }

    public boolean isMaceFastAttack() {
        return isHoldingMace() && lastClickPassed() >= 50;
    }

    public long lastClickPassed() {
        return System.currentTimeMillis() - lastClickTime;
    }

    public void recalculate() {
        lastClickTime = System.currentTimeMillis();
    }

    public boolean isHoldingMace() {
        if (mc.field_1724 == null)
            return false;
        class_1799 mainHand = mc.field_1724.method_6047();
        return mainHand.method_7909().method_7876().toLowerCase().contains("mace");
    }

    public boolean isWeapon() {
        if (mc.field_1724 == null)
            return false;
        class_1799 mainHand = mc.field_1724.method_6047();
        if (mainHand.method_7960())
            return false;
        String itemName = mainHand.method_7909().method_7876().toLowerCase();
        return itemName.contains("sword") || itemName.contains("axe") || itemName.contains("trident");
    }
}