package moonshine.modules.impl.combat.aura.rotations;

import moonshine.Initialization;
import moonshine.modules.impl.combat.Aura;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.impl.combat.aura.MathAngle;
import moonshine.modules.impl.combat.aura.attack.StrikeManager;
import moonshine.modules.impl.combat.aura.impl.RotateConstructor;
import moonshine.modules.impl.combat.aura.target.RaycastAngle;
import moonshine.modules.impl.combat.aura.target.Vector;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import java.security.SecureRandom;

public class SnapAngle extends RotateConstructor {

    private final SecureRandom random = new SecureRandom();
    private static long lastSnapTime = 0;
    private static Angle snappedAngle = null;
    private static boolean holdingSnap = false;

    public SnapAngle() {
        super("Snap");
    }

    @Override
    public Angle limitAngleChange(Angle currentAngle, Angle targetAngle, class_243 vec3d, class_1297 entity) {
        StrikeManager attackHandler = Initialization.getInstance().getManager().getAttackPerpetrator().getAttackHandler();
        Aura aura = Aura.getInstance();

        Angle angleDelta = MathAngle.calculateDelta(currentAngle, targetAngle);
        float yawDelta = angleDelta.getYaw(), pitchDelta = angleDelta.getPitch();
        float rotationDifference = (float) Math.hypot(Math.abs(yawDelta), Math.abs(pitchDelta));
        boolean canAttack = entity != null && attackHandler.canAttack(aura.getConfig(), 0);

        float preAttackSpeed = 1F;
        float postAttackSpeed = 1F;
        float speed = canAttack ? preAttackSpeed : postAttackSpeed;
        float lineYaw = (Math.abs(yawDelta / rotationDifference) * 180);
        float linePitch = (Math.abs(pitchDelta / rotationDifference) * 180);

        float moveYaw = class_3532.method_15363(yawDelta, -lineYaw, lineYaw);
        float movePitch = class_3532.method_15363(pitchDelta, -linePitch, linePitch);
        Angle moveAngle = new Angle(currentAngle.getYaw(), currentAngle.getPitch());
        moveAngle.setYaw(class_3532.method_61342(speed, currentAngle.getYaw(), currentAngle.getYaw() + moveYaw));
        moveAngle.setPitch(class_3532.method_61342(speed, currentAngle.getPitch(), currentAngle.getPitch() + movePitch));

        return moveAngle;
    }

    private float randomLerp(float min, float max) {
        return class_3532.method_16439(random.nextFloat(), min, max);
    }

    @Override
    public class_243 randomValue() {
        return class_243.field_1353;
    }
}