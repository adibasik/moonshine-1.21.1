package moonshine.modules.impl.combat;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_1268;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class TapeMouse extends ModuleStructure {

    final SelectSetting modeClick = new SelectSetting("Тип", "Тип клика")
            .value("Левая кнопка", "Правая кнопка")
            .selected("Левая кнопка");

    final SliderSettings delayForClick = new SliderSettings("Задержка", "Задержка между кликами")
            .range(1.0f, 15.0f).setValue(1.0f);

    final StopWatch delay = new StopWatch();

    public TapeMouse() {
        super("TapeMouse", "Tape Mouse", ModuleCategory.COMBAT);
        settings(modeClick, delayForClick);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1755 != null) return;

        long delayMs = (long) (delayForClick.getValue() * 300.0f);

        if (!delay.finished(delayMs)) return;

        performClick();
        delay.reset();
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void performClick() {
        if (modeClick.isSelected("Левая кнопка")) {
            leftClick();
        } else {
            rightClick();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void leftClick() {
        if (mc.field_1761 == null) return;

        if (mc.field_1692 != null) {
            mc.field_1761.method_2918(mc.field_1724, mc.field_1692);
            mc.field_1724.method_6104(class_1268.field_5808);
        } else if (mc.field_1765 != null) {
            mc.method_1536();
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void rightClick() {
        if (mc.field_1761 == null) return;
        mc.method_1583();
    }
}