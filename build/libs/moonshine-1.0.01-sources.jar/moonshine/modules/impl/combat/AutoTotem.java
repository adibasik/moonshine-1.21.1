package moonshine.modules.impl.combat;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.InputEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.MultiSelectSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.inventory.SwapExecutor;
import moonshine.util.inventory.SwapSettings;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1541;
import net.minecraft.class_1657;
import net.minecraft.class_1701;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_408;
import java.util.HashMap;
import java.util.Map;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AutoTotem extends ModuleStructure {

    final SelectSetting swapMode = new SelectSetting("Режим свапа", "Способ свапа тотема")
            .value("Instant", "Legit")
            .selected("Legit");

    final SliderSettings healthThreshold = new SliderSettings("Порог здоровья", "Минимальное здоровье для взятия тотема")
            .range(1, 20).setValue(6);

    final MultiSelectSetting triggers = new MultiSelectSetting("Триггеры", "Условия для взятия тотема")
            .value("Кристалл", "Падение", "Анти ваншот", "Динамит", "Вагонетка", "Элитра")
            .selected("Кристалл", "Падение", "Анти ваншот");

    final MultiSelectSetting options = new MultiSelectSetting("Опции", "Дополнительные настройки")
            .value("Не брать если шар", "Возврат предмета", "Сохранять талисманы")
            .selected("Не брать если шар", "Возврат предмета", "Сохранять талисманы");

    final SliderSettings crystalDistance = new SliderSettings("Дистанция кристалла", "Максимальное расстояние до кристалла")
            .range(1, 12).setValue(6)
            .visible(() -> triggers.isSelected("Кристалл"));

    final SliderSettings fallHeight = new SliderSettings("Высота падения", "Минимальная высота падения")
            .range(5, 50).setValue(15)
            .visible(() -> triggers.isSelected("Падение"));

    final SliderSettings tntDistance = new SliderSettings("Дистанция динамита", "Максимальное расстояние до динамита")
            .range(3, 25).setValue(6)
            .visible(() -> triggers.isSelected("Динамит"));

    final SliderSettings tntMinecartDistance = new SliderSettings("Дистанция вагонетки", "Максимальное расстояние до вагонетки")
            .range(3, 15).setValue(6)
            .visible(() -> triggers.isSelected("Вагонетка"));

    final SliderSettings elytraHealth = new SliderSettings("Здоровье элитры", "Порог здоровья при полёте на элитре")
            .range(1, 20).setValue(10)
            .visible(() -> triggers.isSelected("Элитра"));

    final SwapExecutor executor = new SwapExecutor();
    final Map<Integer, Double> playerLastY = new HashMap<>();
    final Map<Integer, Double> playerFallStartY = new HashMap<>();

    int savedSlotId = -1;
    float fallStartY = 0;
    boolean wasFalling = false;

    class_1657 dangerousFallingPlayer = null;
    class_1657 dangerousElytraPlayer = null;

    public AutoTotem() {
        super("AutoTotem", "Auto Totem", ModuleCategory.COMBAT);
        settings(swapMode, healthThreshold, triggers, options, crystalDistance, fallHeight, tntDistance, tntMinecartDistance, elytraHealth);
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void activate() {
        savedSlotId = -1;
        fallStartY = 0;
        wasFalling = false;
        playerLastY.clear();
        playerFallStartY.clear();
        dangerousFallingPlayer = null;
        dangerousElytraPlayer = null;
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void deactivate() {
        executor.cancel();
        savedSlotId = -1;
        playerLastY.clear();
        playerFallStartY.clear();
        dangerousFallingPlayer = null;
        dangerousElytraPlayer = null;
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        executor.tick();

        if (executor.isRunning()) return;

        updateFallTracking();
        updatePlayerFallTracking();

        boolean needTotem = shouldEquipTotem();
        boolean hasTotemInOffhand = mc.field_1724.method_6079().method_7909() == class_1802.field_8288;
        boolean hasEnchantedTotemInOffhand = hasTotemInOffhand && mc.field_1724.method_6079().method_7942();

        float currentHealth = mc.field_1724.method_6032();
        float threshold = healthThreshold.getValue();

        if (needTotem) {
            if (!hasTotemInOffhand) {
                equipTotem();
            } else if (options.isSelected("Сохранять талисманы") && hasEnchantedTotemInOffhand) {
                class_1735 regularTotemSlot = findRegularTotemSlot();
                if (regularTotemSlot != null) {
                    swapToRegularTotem(regularTotemSlot);
                }
            }
        } else {
            dangerousFallingPlayer = null;
            dangerousElytraPlayer = null;

            if (savedSlotId != -1 && hasTotemInOffhand && options.isSelected("Возврат предмета") && currentHealth > threshold) {
                returnSavedItem();
            } else if (!hasTotemInOffhand) {
                savedSlotId = -1;
            }
        }
    }

    @EventHandler
    public void onInput(InputEvent e) {
        if (mc.field_1724 == null) return;
        if (executor.isBlocking()) {
            e.setDirectionalLow(false, false, false, false);
            e.setJumping(false);
            mc.field_1724.method_5728(false);
        }
    }

    private void updateFallTracking() {
        boolean isFalling = mc.field_1724.method_18798().field_1351 < -0.1
                && !mc.field_1724.method_24828()
                && !mc.field_1724.method_6101()
                && !mc.field_1724.method_5799()
                && !mc.field_1724.method_6128();

        if (isFalling && !wasFalling) {
            fallStartY = (float) mc.field_1724.method_23318();
        }

        if (mc.field_1724.method_24828() || mc.field_1724.method_5799() || mc.field_1724.method_6101()) {
            fallStartY = (float) mc.field_1724.method_23318();
        }

        wasFalling = isFalling;
    }

    private void updatePlayerFallTracking() {
        if (mc.field_1687 == null) return;

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724) continue;

            int id = player.method_5628();
            double currentY = player.method_23318();
            Double lastY = playerLastY.get(id);

            boolean isGoingDown = lastY != null && currentY < lastY - 0.01;
            boolean isOnGroundOrWater = player.method_24828() || player.method_5799() || player.method_6101();

            if (isGoingDown && !isOnGroundOrWater && !player.method_6128()) {
                if (!playerFallStartY.containsKey(id)) {
                    playerFallStartY.put(id, lastY);
                }
            } else if (isOnGroundOrWater) {
                playerFallStartY.remove(id);
            }

            playerLastY.put(id, currentY);
        }

        playerLastY.entrySet().removeIf(entry -> {
            for (class_1657 player : mc.field_1687.method_18456()) {
                if (player.method_5628() == entry.getKey()) return false;
            }
            return true;
        });

        playerFallStartY.entrySet().removeIf(entry -> {
            for (class_1657 player : mc.field_1687.method_18456()) {
                if (player.method_5628() == entry.getKey()) return false;
            }
            return true;
        });
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private boolean shouldEquipTotem() {
        float health = mc.field_1724.method_6032();
        float threshold = healthThreshold.getValue();

        if (health <= threshold) {
            return true;
        }

        if (triggers.isSelected("Элитра") && mc.field_1724.method_6128()) {
            if (health <= elytraHealth.getValue()) {
                return true;
            }
        }

        if (triggers.isSelected("Падение")) {
            float fallDistance = fallStartY - (float) mc.field_1724.method_23318();
            if (fallDistance >= fallHeight.getValue() && mc.field_1724.method_18798().field_1351 < -0.1) {
                return true;
            }
        }

        if (triggers.isSelected("Анти ваншот") && checkOneshotDanger()) {
            return true;
        }

        if (triggers.isSelected("Кристалл") && checkCrystalDanger()) {
            return true;
        }

        if (triggers.isSelected("Динамит") && checkTntDanger()) {
            return true;
        }

        if (triggers.isSelected("Вагонетка") && checkTntMinecartDanger()) {
            return true;
        }

        return false;
    }

    private boolean hasHeadInOffhand() {
        return mc.field_1724.method_6079().method_7909() == class_1802.field_8575;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean checkCrystalDanger() {
        if (options.isSelected("Не брать если шар") && hasHeadInOffhand()) {
            float health = mc.field_1724.method_6032();
            if (health > healthThreshold.getValue()) {
                return false;
            }
        }

        double distance = crystalDistance.getValue();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity instanceof class_1511) {
                if (mc.field_1724.method_5739(entity) <= distance) {
                    return true;
                }
            }
        }
        return false;
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private boolean checkOneshotDanger() {
        dangerousFallingPlayer = null;
        dangerousElytraPlayer = null;

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724) continue;

            if (isFallingPlayerDangerous(player)) {
                dangerousFallingPlayer = player;
                return true;
            }

            if (checkElytraPlayer(player)) {
                dangerousElytraPlayer = player;
                return true;
            }
        }
        return false;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean isFallingPlayerDangerous(class_1657 player) {
        if (player == mc.field_1724) return false;
        if (player.method_6128()) return false;

        class_243 playerPos = mc.field_1724.method_73189();
        double radius = 7;
        double height = 50;

        class_238 checkZone = new class_238(
                playerPos.field_1352 - radius, playerPos.field_1351, playerPos.field_1350 - radius,
                playerPos.field_1352 + radius, playerPos.field_1351 + height, playerPos.field_1350 + radius
        );

        if (!checkZone.method_994(player.method_5829())) {
            return false;
        }

        if (player.method_23318() < mc.field_1724.method_23318()) {
            return false;
        }

        int id = player.method_5628();
        Double fallStart = playerFallStartY.get(id);

        if (fallStart == null) {
            return false;
        }

        double fallDistance = fallStart - player.method_23318();

        return fallDistance >= 3;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean checkElytraPlayer(class_1657 player) {
        if (!player.method_6128()) return false;

        double distance = mc.field_1724.method_5739(player);
        if (distance > 20) return false;

        class_243 velocity = player.method_18798();
        double speed = velocity.method_1033();

        if (speed < 0.8) return false;

        class_243 toMe = new class_243(
                mc.field_1724.method_23317() - player.method_23317(),
                mc.field_1724.method_23318() - player.method_23318(),
                mc.field_1724.method_23321() - player.method_23321()
        ).method_1029();

        class_243 velocityNorm = velocity.method_1029();
        double dot = velocityNorm.field_1352 * toMe.field_1352 + velocityNorm.field_1351 * toMe.field_1351 + velocityNorm.field_1350 * toMe.field_1350;

        if (dot > 0.25) {
            double timeToReach = distance / speed;

            if (timeToReach < 2.5) {
                return true;
            }

            double predictedX = player.method_23317() + velocity.field_1352 * timeToReach;
            double predictedY = player.method_23318() + velocity.field_1351 * timeToReach;
            double predictedZ = player.method_23321() + velocity.field_1350 * timeToReach;

            double predictedDist = Math.sqrt(
                    Math.pow(predictedX - mc.field_1724.method_23317(), 2) +
                            Math.pow(predictedY - mc.field_1724.method_23318(), 2) +
                            Math.pow(predictedZ - mc.field_1724.method_23321(), 2)
            );

            return predictedDist < 6;
        }
        return false;
    }

    private boolean checkTntDanger() {
        double distance = tntDistance.getValue();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity instanceof class_1541) {
                if (mc.field_1724.method_5739(entity) <= distance) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean checkTntMinecartDanger() {
        double distance = tntMinecartDistance.getValue();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity instanceof class_1701) {
                if (mc.field_1724.method_5739(entity) <= distance) {
                    return true;
                }
            }
        }
        return false;
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void swapSlots(int slot) {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        int syncId = mc.field_1724.field_7498.field_7763;
        mc.field_1761.method_2906(syncId, slot, 40, class_1713.field_7791, mc.field_1724);
    }

    private boolean isScreenOpen() {
        return mc.field_1755 != null && !(mc.field_1755 instanceof class_408);
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void equipTotem() {
        class_1735 totemSlot = findTotemSlot();
        if (totemSlot == null) return;

        boolean hasItemInOffhand = !mc.field_1724.method_6079().method_7960()
                && mc.field_1724.method_6079().method_7909() != class_1802.field_8288;

        if (hasItemInOffhand && savedSlotId == -1) {
            savedSlotId = totemSlot.field_7874;
        }

        final int slotId = totemSlot.field_7874;

        if (isScreenOpen()) {
            swapSlots(slotId);
        } else if (swapMode.isSelected("Instant")) {
            executor.execute(() -> swapSlots(slotId), SwapSettings.instantWithStop());
        } else {
            executor.execute(() -> swapSlots(slotId), SwapSettings.legit());
        }
    }

    private void swapToRegularTotem(class_1735 regularTotemSlot) {
        if (regularTotemSlot == null) return;

        final int slotId = regularTotemSlot.field_7874;

        if (isScreenOpen()) {
            swapSlots(slotId);
        } else if (swapMode.isSelected("Instant")) {
            executor.execute(() -> swapSlots(slotId), SwapSettings.instantWithStop());
        } else {
            executor.execute(() -> swapSlots(slotId), SwapSettings.legit());
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void returnSavedItem() {
        if (savedSlotId == -1) return;

        final int slotId = savedSlotId;

        if (isScreenOpen()) {
            swapSlots(slotId);
            savedSlotId = -1;
        } else if (swapMode.isSelected("Instant")) {
            executor.execute(() -> {
                swapSlots(slotId);
                savedSlotId = -1;
            }, SwapSettings.instantWithStop());
        } else {
            executor.execute(() -> {
                swapSlots(slotId);
                savedSlotId = -1;
            }, SwapSettings.legit());
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private class_1735 findTotemSlot() {
        if (mc.field_1724 == null) return null;

        class_1735 regularTotem = findRegularTotemSlot();
        if (regularTotem != null) {
            return regularTotem;
        }

        return findAnyTotemSlot();
    }

    private class_1735 findRegularTotemSlot() {
        if (mc.field_1724 == null) return null;

        for (int i = 36; i <= 44; i++) {
            class_1735 slot = mc.field_1724.field_7498.method_7611(i);
            if (slot != null && isRegularTotem(slot.method_7677())) {
                return slot;
            }
        }

        for (int i = 9; i <= 35; i++) {
            class_1735 slot = mc.field_1724.field_7498.method_7611(i);
            if (slot != null && isRegularTotem(slot.method_7677())) {
                return slot;
            }
        }

        return null;
    }

    private class_1735 findAnyTotemSlot() {
        if (mc.field_1724 == null) return null;

        for (int i = 36; i <= 44; i++) {
            class_1735 slot = mc.field_1724.field_7498.method_7611(i);
            if (slot != null && isTotem(slot.method_7677())) {
                return slot;
            }
        }

        for (int i = 9; i <= 35; i++) {
            class_1735 slot = mc.field_1724.field_7498.method_7611(i);
            if (slot != null && isTotem(slot.method_7677())) {
                return slot;
            }
        }

        return null;
    }

    private boolean isTotem(class_1799 stack) {
        return !stack.method_7960() && stack.method_7909() == class_1802.field_8288;
    }

    private boolean isRegularTotem(class_1799 stack) {
        if (!isTotem(stack)) return false;
        if (options.isSelected("Сохранять талисманы")) {
            return !stack.method_7942();
        }
        return true;
    }
}