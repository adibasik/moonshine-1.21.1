package moonshine.modules.impl.combat;

import antidaunleak.api.annotation.Native;
import lombok.Getter;
import lombok.experimental.NonFinal;
import moonshine.Initialization;
import moonshine.events.api.EventHandler;
import moonshine.events.api.types.EventType;
import moonshine.events.impl.InputEvent;
import moonshine.events.impl.RotationUpdateEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.AngleConfig;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.impl.combat.aura.MathAngle;
import moonshine.modules.impl.combat.aura.attack.StrikeManager;
import moonshine.modules.impl.combat.aura.attack.StrikerConstructor;
import moonshine.modules.impl.combat.aura.impl.*;
import moonshine.modules.impl.combat.aura.rotations.*;
import moonshine.modules.impl.combat.aura.target.MultiPoint;
import moonshine.modules.impl.combat.aura.target.TargetFinder;
import moonshine.modules.impl.movement.ElytraTarget;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.*;
import moonshine.util.Instance;
import moonshine.util.math.TaskPriority;
import net.minecraft.class_10185;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3545;
import java.util.Objects;

public class Aura extends ModuleStructure {

    @Native(type = Native.Type.VMProtectBeginUltra)
    public static Aura getInstance() {
        return Instance.get(Aura.class);
    }

    private final SelectSetting mode = new SelectSetting("Режим наводки", "Select aim mode")
            .value("Matrix", "FunTime Snap", "Snap", "SpookyTime")
            .selected("Matrix");

    private final SelectSetting moveFix = new SelectSetting("Коррекция движения", "Select move fix mode")
            .value("Сфокусированная", "Свободная", "Преследование", "Таргет", "Отключена")
            .selected("Focus");

    @Getter
    public final SliderSettings attackrange = new SliderSettings("Дистанция удара", "Set range value")
            .range(2.0f, 6.0f)
            .setValue(3.0f);

    private final SliderSettings lookrange = new SliderSettings("Дистанция поиска", "Set look range value")
            .range(0.0f, 10.0f)
            .setValue(1.5f);

    public final MultiSelectSetting options = new MultiSelectSetting("Настройки", "Select settings")
            .value("Бить сквозь стены", "Рандомизация крита", "Не бить если ешь")
            .selected("Бить сквозь стены", "Рандомизация крита", "Не бить если ешь");

    private final MultiSelectSetting targetType = new MultiSelectSetting("Настройка целей", "Select target settings")
            .value("Игроки", "Мобы", "Животные", "Друзья", "Стойки для брони")
            .selected("Игроки", "Мобы", "Животные");

    @Getter
    private final SelectSetting resetSprintMode = new SelectSetting("Сброс спринта", "Reset sprint mode")
            .value("Легитный", "Пакетный")
            .selected("Легитный");

    @Getter
    private final BooleanSetting checkCrit = new BooleanSetting("Только криты", "Only critical hits")
            .setValue(true);

    @Getter
    private final BooleanSetting smartCrits = new BooleanSetting("Умные криты",
            "Smart crits - attack on ground when possible")
            .setValue(true)
            .visible(() -> checkCrit.isValue());

    public Aura() {
        super("Aura", ModuleCategory.COMBAT);
        settings(mode, attackrange, lookrange, options, targetType, moveFix, resetSprintMode, checkCrit, smartCrits);
    }

    @NonFinal
    public static class_1309 target;

    @NonFinal
    public class_1309 lastTarget;

    TargetFinder targetSelector = new TargetFinder();
    MultiPoint pointFinder = new MultiPoint();

    @Override
    public void deactivate() {
        AngleConnection.INSTANCE.startReturning();
        Initialization.getInstance().getManager()
                .getAttackPerpetrator()
                .getAttackHandler()
                .resetPendingState();
        target = null;
        lastTarget = null;
    }

    @EventHandler
    private void tick(TickEvent event) {
    }

    @EventHandler
    public void onRotationUpdate(RotationUpdateEvent e) {
        switch (e.getType()) {
            case EventType.PRE -> {
                class_1309 previousTarget = target;
                target = updateTarget();

                if (previousTarget != null && target == null) {
                    Initialization.getInstance().getManager()
                            .getAttackPerpetrator()
                            .getAttackHandler()
                            .resetPendingState();
                }

                boolean passed = false;
                if (mode.isSelected("FunTime Snap") || mode.isSelected("HolyWorld")) {
                    passed = true;
                }
                if (target != null && passed && target.method_5739(mc.field_1724) <= attackrange.getValue() + 0.25F) {
                    rotateToTarget(getConfig());
                    lastTarget = target;
                }
                if (target != null && !passed) {
                    rotateToTarget(getConfig());
                    lastTarget = target;
                }
            }
            case EventType.POST -> {
                if (target != null) {
                    Initialization.getInstance().getManager().getAttackPerpetrator().performAttack(getConfig());
                }
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    public StrikerConstructor.AttackPerpetratorConfigurable getConfig() {
        float baseRange = attackrange.getValue();

        class_3545<class_243, class_238> pointData = pointFinder.computeVector(
                target,
                baseRange,
                AngleConnection.INSTANCE.getRotation(),
                getSmoothMode().randomValue(),
                options.isSelected("Бить сквозь стены"));

        class_243 computedPoint = pointData.method_15442();
        class_238 hitbox = pointData.method_15441();

        if (mc.field_1724.method_6128() && target.method_6128()) {
            class_243 targetVelocity = target.method_18798();
            double targetSpeed = targetVelocity.method_37267();

            float leadTicks = 0;
            if (ElytraTarget.shouldElytraTarget && ElytraTarget.getInstance() != null
                    && ElytraTarget.getInstance().isState()) {
                leadTicks = ElytraTarget.getInstance().elytraForward.getValue();
            }

            if (targetSpeed > 0.35) {
                class_243 predictedPos = target.method_73189().method_1019(targetVelocity.method_1021(leadTicks));
                computedPoint = predictedPos.method_1031(0, target.method_17682() / 2, 0);

                hitbox = new class_238(
                        predictedPos.field_1352 - target.method_17681() / 2,
                        predictedPos.field_1351,
                        predictedPos.field_1350 - target.method_17681() / 2,
                        predictedPos.field_1352 + target.method_17681() / 2,
                        predictedPos.field_1351 + target.method_17682(),
                        predictedPos.field_1350 + target.method_17681() / 2);
            }
        }

        Angle angle = MathAngle.fromVec3d(computedPoint.method_1020(Objects.requireNonNull(mc.field_1724).method_33571()));
        return new StrikerConstructor.AttackPerpetratorConfigurable(
                target,
                angle,
                baseRange,
                options.getSelected(),
                mode,
                hitbox);
    }

    public AngleConfig getRotationConfig() {
        boolean visibleCorrection = !moveFix.isSelected("Отключена");
        boolean freeCorrection = moveFix.isSelected("Свободная");
        return new AngleConfig(getSmoothMode(), visibleCorrection, freeCorrection);
    }

    private void rotateToTarget(StrikerConstructor.AttackPerpetratorConfigurable config) {
        StrikeManager attackHandler = Initialization.getInstance().getManager().getAttackPerpetrator()
                .getAttackHandler();
        AngleConnection controller = AngleConnection.INSTANCE;
        Angle.VecRotation rotation = new Angle.VecRotation(config.getAngle(), config.getAngle().toVector());
        AngleConfig rotationConfig = getRotationConfig();

        boolean elytraMode = mc.field_1724.method_6128() && ElytraTarget.getInstance() != null
                && ElytraTarget.getInstance().isState();

        switch (mode.getSelected()) {

            case "FunTime Snap" -> {
                if (attackHandler.canAttack(config, 5)) {
                    controller.clear();
                    controller.rotateTo(rotation, target, 60, rotationConfig, TaskPriority.HIGH_IMPORTANCE_1, this);
                }
            }

            case "Snap" -> {
                if (attackHandler.canAttack(config, 0)) {
                    controller.rotateTo(rotation, target, 0, rotationConfig, TaskPriority.HIGH_IMPORTANCE_1, this);
                }
            }

            case "Matrix", "SpookyTime" -> {
                controller.rotateTo(rotation, target, 1, rotationConfig, TaskPriority.HIGH_IMPORTANCE_1, this);
            }

        }

        if (elytraMode) {
            controller.rotateTo(rotation, target, 1, rotationConfig, TaskPriority.HIGH_IMPORTANCE_1, this);
        }
    }

    @EventHandler
    public void onInput(InputEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null)
            return;

        class_10185 input = event.getInput();
        if (input == null)
            return;

        if (!isState())
            return;

        if (target == null || !target.method_5805())
            return;

        boolean w = mc.field_1690.field_1894.method_1434();
        boolean s = mc.field_1690.field_1881.method_1434();
        boolean a = mc.field_1690.field_1913.method_1434();
        boolean d = mc.field_1690.field_1849.method_1434();

        if (moveFix.isSelected("Таргет")) {
            class_243 playerPos = mc.field_1724.method_73189();
            class_243 targetPos = target.method_73189();

            class_243 moveTarget = new class_243(targetPos.field_1352, playerPos.field_1351, targetPos.field_1350);
            class_243 dir = moveTarget.method_1020(playerPos).method_1029();

            float yaw = AngleConnection.INSTANCE.getRotation().getYaw();
            float moveAngle = (float) Math.toDegrees(Math.atan2(dir.field_1350, dir.field_1352)) - 90F;
            float angleDiff = class_3532.method_15393(moveAngle - yaw);

            boolean forward = false, back = false, left = false, right = false;

            if (angleDiff >= -22.5 && angleDiff < 22.5) {
                forward = true;
            } else if (angleDiff >= 22.5 && angleDiff < 67.5) {
                forward = true;
                right = true;
            } else if (angleDiff >= 67.5 && angleDiff < 112.5) {
                right = true;
            } else if (angleDiff >= 112.5 && angleDiff < 157.5) {
                back = true;
                right = true;
            } else if (angleDiff >= -67.5 && angleDiff < -22.5) {
                forward = true;
                left = true;
            } else if (angleDiff >= -112.5 && angleDiff < -67.5) {
                left = true;
            } else if (angleDiff >= -157.5 && angleDiff < -112.5) {
                back = true;
                left = true;
            } else {
                back = true;
            }

            event.setDirectionalLow(forward, back, left, right);
            return;
        }

        if (moveFix.isSelected("Преследование")) {
            if (!w && !s && !a && !d)
                return;

            class_243 playerPos = mc.field_1724.method_73189();
            class_238 targetBox = target.method_5829();
            class_243 center = targetBox.method_1005();

            float targetYaw = target.method_36454();
            double rad = Math.toRadians(targetYaw);

            class_243 forwardDir = new class_243(-Math.sin(rad), 0, Math.cos(rad)).method_1029();
            class_243 rightDir = new class_243(-forwardDir.field_1350, 0, forwardDir.field_1352).method_1029();
            class_243 leftDir = rightDir.method_1021(-1);

            double halfWidth = target.method_17681() / 2.0;
            double offset = halfWidth + 0.1;

            class_243 moveTargetVec = center;
            class_243 offsetVec = class_243.field_1353;

            if (w)
                offsetVec = offsetVec.method_1019(forwardDir);
            if (s)
                offsetVec = offsetVec.method_1019(forwardDir.method_1021(-1.0));
            if (a)
                offsetVec = offsetVec.method_1019(leftDir);
            if (d)
                offsetVec = offsetVec.method_1019(rightDir);

            if (offsetVec.method_1027() > 0) {
                offsetVec = offsetVec.method_1029().method_1021(offset);
                moveTargetVec = center.method_1019(offsetVec);
            }

            moveTargetVec = new class_243(moveTargetVec.field_1352, playerPos.field_1351, moveTargetVec.field_1350);
            class_243 dir = moveTargetVec.method_1020(playerPos).method_1029();

            float yaw = AngleConnection.INSTANCE.getRotation().getYaw();
            float moveAngle = (float) Math.toDegrees(Math.atan2(dir.field_1350, dir.field_1352)) - 90F;
            float angleDiff = class_3532.method_15393(moveAngle - yaw);

            boolean forward = false, back = false, left = false, right = false;

            if (angleDiff >= -22.5 && angleDiff < 22.5) {
                forward = true;
            } else if (angleDiff >= 22.5 && angleDiff < 67.5) {
                forward = true;
                right = true;
            } else if (angleDiff >= 67.5 && angleDiff < 112.5) {
                right = true;
            } else if (angleDiff >= 112.5 && angleDiff < 157.5) {
                back = true;
                right = true;
            } else if (angleDiff >= -67.5 && angleDiff < -22.5) {
                forward = true;
                left = true;
            } else if (angleDiff >= -112.5 && angleDiff < -67.5) {
                left = true;
            } else if (angleDiff >= -157.5 && angleDiff < -112.5) {
                back = true;
                left = true;
            } else {
                back = true;
            }

            event.setDirectionalLow(forward, back, left, right);
        }
    }

    private class_1309 updateTarget() {
        TargetFinder.EntityFilter filter = new TargetFinder.EntityFilter(targetType.getSelected());
        float range = attackrange.getValue() + 0.25F
                + (mc.field_1724.method_6128() && ElytraTarget.getInstance() != null && ElytraTarget.getInstance().isState()
                        ? ElytraTarget.getInstance().elytraFindRange.getValue()
                        : lookrange.getValue());

        float dynamicFov = 360;

        targetSelector.searchTargets(mc.field_1687.method_18112(), range, dynamicFov,
                options.isSelected("Бить сквозь стены"));
        targetSelector.validateTarget(filter::isValid);
        return targetSelector.getCurrentTarget();
    }

    public RotateConstructor getSmoothMode() {
        if (mc.field_1724.method_6128() && ElytraTarget.getInstance() != null && ElytraTarget.getInstance().isState()) {
            return new LinearConstructor();
        }
        return switch (mode.getSelected()) {
            case "FunTime Snap" -> new FTAngle();
            case "SpookyTime" -> new SPAngle();
            case "Snap" -> new SnapAngle();
            case "Matrix" -> new MatrixAngle();
            default -> new LinearConstructor();
        };
    }
}