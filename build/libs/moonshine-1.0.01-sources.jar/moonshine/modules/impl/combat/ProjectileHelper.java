package moonshine.modules.impl.combat;

import antidaunleak.api.annotation.Native;
import moonshine.events.api.EventHandler;
import moonshine.events.api.types.EventType;
import moonshine.events.impl.RotationUpdateEvent;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.AngleConfig;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.impl.combat.aura.target.TargetFinder;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.MultiSelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.math.MathUtils;
import moonshine.util.math.TaskPriority;
import moonshine.util.repository.friend.FriendUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1835;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class ProjectileHelper extends ModuleStructure {

    private final SliderSettings searchDistance = new SliderSettings("Дистанция поиска", "Радиус поиска цели вокруг игрока")
            .setValue(16).range(5F, 64F);

    private final MultiSelectSetting targetType = new MultiSelectSetting("Тип таргета", "Фильтрует цели по типу")
            .value("Players", "Mobs", "Animals", "Armor Stand")
            .selected("Players", "Mobs", "Animals");

    private final TargetFinder targetFinder = new TargetFinder();
    private class_1309 currentTarget;

    public ProjectileHelper() {
        super("ProjectileHelper", "Projectile Helper", ModuleCategory.COMBAT);
        settings(searchDistance, targetType);
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    public class_1309 getTarget(class_1937 world, Iterable<class_1297> entities) {
        List<class_1297> entityList = StreamSupport.stream(entities.spliterator(), false).collect(Collectors.toList());

        List<class_1309> validTargets = entityList.stream()
                .filter(e -> e instanceof class_1309)
                .map(e -> (class_1309) e)
                .filter(this::isValidTarget)
                .collect(Collectors.toList());

        class_1309 nearestTarget = null;
        double nearestDistance = Double.MAX_VALUE;
        class_243 playerPos = mc.field_1724.method_73189();

        for (class_1309 target : validTargets) {
            double distance = target.method_73189().method_1022(playerPos);
            if (distance < nearestDistance && distance <= searchDistance.getValue()) {
                nearestDistance = distance;
                nearestTarget = target;
            }
        }

        currentTarget = nearestTarget;
        return currentTarget;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean isValidTarget(class_1309 entity) {
        if (entity == null) return false;
        if (entity == mc.field_1724) return false;
        if (!entity.method_5805()) return false;

        if (!targetType.isSelected("Players") && entity instanceof class_1657) return false;
        if (!targetType.isSelected("Mobs") && entity instanceof class_1308) return false;
        if (!targetType.isSelected("Animals") && entity instanceof class_1429) return false;
        if (!targetType.isSelected("Armor Stand") && entity instanceof class_1531) return false;
        return true;
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    public class_243 getPredictedPosition(class_1309 target, class_243 shooterPos, float projectileSpeed, float gravity) {
        class_243 targetPos = target.method_73189().method_1031(0, target.method_17682() * 0.5, 0);
        class_243 targetVelocity = target.method_18798();
        class_243 delta = targetPos.method_1020(shooterPos);

        double a = projectileSpeed * projectileSpeed - targetVelocity.method_1027();
        double b = -2 * delta.method_1026(targetVelocity);
        double c = -delta.method_1027();

        double t;
        double discriminant = b * b - 4 * a * c;
        if (discriminant > 0) {
            double t1 = (-b + Math.sqrt(discriminant)) / (2 * a);
            double t2 = (-b - Math.sqrt(discriminant)) / (2 * a);
            t = Math.max(t1, t2);
        } else {
            t = delta.method_1033() / projectileSpeed;
        }

        class_243 predicted = targetPos.method_1019(targetVelocity.method_1021(t));
        predicted = predicted.method_1031(0, 0.5 * gravity * t * t, 0);

        return predicted;
    }

    private boolean isHoldingProjectile() {
        class_1799 main = mc.field_1724.method_6047();
        return main.method_7909() instanceof class_1753 || main.method_7909() instanceof class_1764 || main.method_7909() instanceof class_1835;
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onRotationUpdate(RotationUpdateEvent e) {
        if (e.getType() != EventType.PRE) return;

        class_1799 stack = mc.field_1724.method_6047();

        if (!isValidWeaponState(stack)) {
            currentTarget = null;
            return;
        }

        updateTarget();

        if (currentTarget != null) {
            performAim();
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean isValidWeaponState(class_1799 stack) {
        boolean holdingBow = stack.method_7909() instanceof class_1753;
        boolean holdingCrossbow = stack.method_7909() instanceof class_1764 && ((class_1764) stack.method_7909()).method_7781(stack);
        boolean holdingTrident = stack.method_7909() instanceof class_1835;

        if (!holdingBow && !holdingCrossbow && !holdingTrident) {
            return false;
        }

        if (holdingBow && mc.field_1724.method_6030() != stack) {
            return false;
        }

        return true;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void updateTarget() {
        if (currentTarget != null && !currentTarget.method_5805()) {
            currentTarget = null;
        }

        if (currentTarget == null) {
            currentTarget = getTarget(mc.field_1687, mc.field_1687.method_18112());
            if (currentTarget == mc.field_1724) currentTarget = null;
        }

        if (FriendUtils.isFriend(currentTarget)) currentTarget = null;
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void performAim() {
        class_243 shooterPos = mc.field_1724.method_73189()
                .method_1031(0, mc.field_1724.method_18381(mc.field_1724.method_18376()), 0)
                .method_1019(mc.field_1724.method_18798());

        float projectileSpeed = 6.0f;
        float gravity = 0.02f;

        class_243 predictedPos = getPredictedPosition(currentTarget, shooterPos, projectileSpeed, gravity);

        double dx = predictedPos.field_1352 - shooterPos.field_1352;
        double dy = predictedPos.field_1351 - shooterPos.field_1351;
        double dz = predictedPos.field_1350 - shooterPos.field_1350;
        double distanceXZ = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f + MathUtils.getRandom(-1, 1);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, distanceXZ)) + MathUtils.getRandom(-1, 1);

        AngleConnection.INSTANCE.rotateTo(
                new Angle(yaw, pitch),
                AngleConfig.DEFAULT,
                TaskPriority.HIGH_IMPORTANCE_1,
                this
        );
    }
}