package moonshine.modules.impl.combat;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.api.types.EventType;
import moonshine.events.impl.InputEvent;
import moonshine.events.impl.RotationUpdateEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.AngleConfig;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.impl.combat.aura.impl.LinearConstructor;
import moonshine.modules.impl.combat.aura.target.TargetFinder;
import moonshine.modules.impl.combat.macetarget.armor.ArmorSwapHandler;
import moonshine.modules.impl.combat.macetarget.armor.FireworkHandler;
import moonshine.modules.impl.combat.macetarget.attack.AttackHandler;
import moonshine.modules.impl.combat.macetarget.flight.FlightController;
import moonshine.modules.impl.combat.macetarget.prediction.TargetPredictor;
import moonshine.modules.impl.combat.macetarget.stage.StageHandler;
import moonshine.modules.impl.combat.macetarget.state.MaceState.Stage;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.MultiSelectSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.Instance;
import moonshine.util.inventory.InventoryUtils;
import moonshine.util.inventory.SwapSettings;
import moonshine.util.math.TaskPriority;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_1309;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class MaceTarget extends ModuleStructure {

    public static MaceTarget getInstance() {
        return Instance.get(MaceTarget.class);
    }

    final SelectSetting serverMode = new SelectSetting("Сервер", "Режим работы под сервер")
            .value("Default", "ReallyWorld")
            .selected("Default");

    final SelectSetting modeSetting = new SelectSetting("Режим", "Способ свапа")
            .value("Silent", "Legit")
            .selected("Silent");

    final SliderSettings height = new SliderSettings("Высота", "Высота полёта над целью")
            .range(20.0f, 60.0f)
            .setValue(30.0f);

    final MultiSelectSetting targetType = new MultiSelectSetting("Цели", "Типы целей")
            .value("Игроки", "Мобы", "Животные")
            .selected("Игроки");

    final BooleanSetting autoEquipChest = new BooleanSetting("Авто-нагрудник", "Одевать нагрудник при выключении")
            .setValue(true);

    final BooleanSetting predictMovement = new BooleanSetting("Предугадывание", "Предугадывать позицию убегающей цели")
            .setValue(true);

    final TargetPredictor predictor = new TargetPredictor();
    final FlightController flightController;
    final ArmorSwapHandler armorSwapHandler;
    final FireworkHandler fireworkHandler;
    final AttackHandler attackHandler = new AttackHandler();
    final StageHandler stageHandler;
    final TargetFinder targetFinder = new TargetFinder();
    final StopWatch fireworkTimer = new StopWatch();

    class_1309 target;

    public MaceTarget() {
        super("MaceTarget", "Mace Target", ModuleCategory.COMBAT);
        settings(serverMode, modeSetting, height, targetType, autoEquipChest, predictMovement);

        flightController = new FlightController(predictor);
        armorSwapHandler = new ArmorSwapHandler(this::buildSettings);
        fireworkHandler = new FireworkHandler(this::buildSettings);
        stageHandler = new StageHandler(armorSwapHandler, fireworkHandler, attackHandler, fireworkTimer);
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean isSilentMode() {
        return modeSetting.getSelected().equals("Silent");
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean isReallyWorldMode() {
        return serverMode.getSelected().equals("ReallyWorld");
    }

    private SwapSettings buildSettings() {
        return isSilentMode() ? SwapSettings.instant() : SwapSettings.legit();
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void updateHandlers() {
        stageHandler.setSilentMode(isSilentMode());
        stageHandler.setReallyWorldMode(isReallyWorldMode());
        stageHandler.setHeight(height.getValue());
        flightController.setPredictionEnabled(predictMovement.isValue());
        flightController.setHeight(height.getValue());
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void activate() {
        stageHandler.reset();
        target = null;
        attackHandler.reset();
        armorSwapHandler.reset();
        fireworkHandler.reset();
        predictor.reset();
        fireworkTimer.reset();
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void deactivate() {
        if (autoEquipChest.isValue() && mc.field_1724 != null) {
            equipChestplateOnDisable();
        }

        armorSwapHandler.forceRestore();
        fireworkHandler.forceRestore();
        target = null;
        targetFinder.releaseTarget();
        armorSwapHandler.reset();
        fireworkHandler.reset();
        predictor.reset();
        AngleConnection.INSTANCE.startReturning();
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void equipChestplateOnDisable() {
        if (InventoryUtils.hasElytra()) {
            int slot = InventoryUtils.findChestArmorSlot();
            if (slot != -1) {
                int wrappedSlot = InventoryUtils.wrapSlot(slot);
                InventoryUtils.swap(wrappedSlot, 6);
                InventoryUtils.closeScreen();
            }
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onRotationUpdate(RotationUpdateEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (event.getType() == EventType.PRE) {
            updateHandlers();

            if (target == null || !target.method_5805()) {
                findTarget();
            }

            if (target == null) return;

            predictor.update(target);

            Stage currentStage = stageHandler.getStage();

            switch (currentStage) {
                case FLYING_UP -> {
                    if (InventoryUtils.hasElytra() && mc.field_1724.method_6128()) {
                        Angle targetAngle = flightController.calculateAngle(target, currentStage);
                        rotateTo(targetAngle);
                    }
                }
                case TARGETTING, ATTACKING -> {
                    Angle targetAngle = flightController.calculateAngle(target, currentStage);
                    rotateTo(targetAngle);
                }
            }
        }

        if (event.getType() == EventType.POST) {
            handlePostRotation();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handlePostRotation() {
        if (attackHandler.isPendingAttack()) {
            attackHandler.performAttack(target);
            attackHandler.setPendingAttack(false);

            if (attackHandler.isShouldDisableAfterAttack()) {
                attackHandler.setShouldDisableAfterAttack(false);
                setState(false);
            }
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            resetAllStates();
            return;
        }

        if (!isSilentMode()) {
            armorSwapHandler.processLoop();
            fireworkHandler.processLoop();
        }

        if (armorSwapHandler.isActive() || fireworkHandler.isActive()) {
            return;
        }

        if (target == null || !target.method_5805()) {
            return;
        }

        processStage();
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void processStage() {
        boolean hasElytra = InventoryUtils.hasElytra();
        Stage currentStage = stageHandler.getStage();

        switch (currentStage) {
            case PREPARE -> stageHandler.handlePrepare(hasElytra);
            case FLYING_UP -> stageHandler.handleFlyingUp(target, hasElytra);
            case TARGETTING -> stageHandler.handleTargetting(target);
            case ATTACKING -> stageHandler.handleAttacking(target, hasElytra);
        }
    }

    @EventHandler
    public void onInput(InputEvent event) {
        if (mc.field_1724 == null) return;

        if (armorSwapHandler.getMovement().isBlocked() || fireworkHandler.getMovement().isBlocked()) {
            event.setDirectionalLow(false, false, false, false);
            event.setJumping(false);
        }

        if (target != null && InventoryUtils.hasElytra() && stageHandler.getStage() == Stage.FLYING_UP) {
            if (mc.field_1724.method_24828()) {
                event.setJumping(true);
            } else if (!mc.field_1724.method_6128() && !mc.field_1724.method_31549().field_7479) {
                event.setJumping(mc.field_1724.field_6012 % 2 == 0);
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void findTarget() {
        TargetFinder.EntityFilter filter = new TargetFinder.EntityFilter(targetType.getSelected());
        targetFinder.searchTargets(mc.field_1687.method_18112(), 128.0f, 360, true);
        targetFinder.validateTarget(filter::isValid);
        target = targetFinder.getCurrentTarget();
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void rotateTo(Angle angle) {
        AngleConfig config = new AngleConfig(new LinearConstructor(), true, false);
        Angle.VecRotation rotation = new Angle.VecRotation(angle, angle.toVector());
        AngleConnection.INSTANCE.rotateTo(rotation, target, 1, config, TaskPriority.HIGH_IMPORTANCE_1, this);
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void resetAllStates() {
        armorSwapHandler.reset();
        fireworkHandler.reset();
        attackHandler.reset();
        predictor.reset();
        target = null;
        stageHandler.reset();
    }
}