package moonshine.modules.impl.combat;

import antidaunleak.api.annotation.Native;
import lombok.Getter;
import moonshine.Initialization;
import moonshine.events.api.EventHandler;
import moonshine.events.api.types.EventType;
import moonshine.events.impl.PacketEvent;
import moonshine.events.impl.RotationUpdateEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.impl.combat.aura.MathAngle;
import moonshine.modules.impl.combat.aura.attack.StrikerConstructor;
import moonshine.modules.impl.combat.aura.impl.LinearConstructor;
import moonshine.modules.impl.combat.aura.impl.RotateConstructor;
import moonshine.modules.impl.combat.aura.target.MultiPoint;
import moonshine.modules.impl.combat.aura.target.TargetFinder;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.MultiSelectSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.Instance;
import moonshine.util.string.PlayerInteractionHelper;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3545;
import java.util.Objects;

public class TriggerBot extends ModuleStructure {
    private static final float RANGE_MARGIN = 0.253F;
    private final TargetFinder targetSelector = new TargetFinder();
    private final MultiPoint pointFinder = new MultiPoint();
    public class_1309 target;

    public SliderSettings attackRange = new SliderSettings("Дистанция удара", "Дальность атаки до цели")
            .setValue(3).range(1F, 6F);

    MultiSelectSetting targetType = new MultiSelectSetting("Тип таргета", "Фильтрует список целей по типу")
            .value("Игроки", "Мобы", "Животные", "Стойки для брони")
            .selected("Игроки", "Мобы", "Животные");

    public MultiSelectSetting attackSetting = new MultiSelectSetting("Настройки", "Параметры атаки")
            .value("Только криты", "Рандомизация крита", "Бить сквозь стены")
            .selected("Только криты");

    @Getter
    public SelectSetting sprintReset = new SelectSetting("Сброс спринта", "Выбор сброса спринта перед ударом")
            .value("Легитный", "Интенсивный")
            .selected("Легитный");

    @Getter
    public BooleanSetting smartCrits = new BooleanSetting("Умные криты", "Атака на земле когда кулдаун готов")
            .setValue(true)
            .visible(() -> attackSetting.isSelected("Только криты"));

    public TriggerBot() {
        super("TriggerBot", "Trigger Bot", ModuleCategory.COMBAT);
        settings(attackRange, targetType, attackSetting, sprintReset, smartCrits);
    }

    public static TriggerBot getInstance() {
        return Instance.get(TriggerBot.class);
    }

    @Override
    public void deactivate() {
        target = null;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private class_1309 updateTarget() {
        TargetFinder.EntityFilter filter = new TargetFinder.EntityFilter(targetType.getSelected());
        float range = attackRange.getValue() + RANGE_MARGIN;
        targetSelector.searchTargets(mc.field_1687.method_18112(), range, 360, attackSetting.isSelected("Бить сквозь стены"));
        targetSelector.validateTarget(filter::isValid);
        return targetSelector.getCurrentTarget();
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onRotationUpdate(RotationUpdateEvent e) {
        if (PlayerInteractionHelper.nullCheck()) return;

        switch (e.getType()) {
            case EventType.PRE -> target = updateTarget();
            case EventType.POST -> {
                if (target != null) {
                    Initialization.getInstance().getManager().getAttackPerpetrator().performTriggerAttack(getConfig(), this);
                }
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    public StrikerConstructor.AttackPerpetratorConfigurable getConfig() {
        float baseRange = attackRange.getValue() + RANGE_MARGIN;

        class_3545<class_243, class_238> pointData = pointFinder.computeVector(
                target,
                baseRange,
                AngleConnection.INSTANCE.getRotation(),
                getSmoothMode().randomValue(),
                attackSetting.isSelected("Бить сквозь стены")
        );

        class_243 computedPoint = pointData.method_15442();
        class_238 hitbox = pointData.method_15441();

        Angle angle = MathAngle.fromVec3d(computedPoint.method_1020(Objects.requireNonNull(mc.field_1724).method_33571()));

        return new StrikerConstructor.AttackPerpetratorConfigurable(
                target,
                angle,
                baseRange,
                attackSetting.getSelected(),
                null,
                hitbox
        );
    }

    public RotateConstructor getSmoothMode() {
        return new LinearConstructor();
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    public boolean isResetSprintLegit() {
        return sprintReset.isSelected("Легитный");
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    public boolean isResetSprintPacket() {
        return sprintReset.isSelected("Интенсивный");
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    public boolean isOnlyCrits() {
        return attackSetting.isSelected("Только криты");
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    public boolean isRandomizeCrit() {
        return attackSetting.isSelected("Рандомизация крита");
    }

    @EventHandler
    public void tick(TickEvent e) {}

    @EventHandler
    public void onPacket(PacketEvent e) {}
}