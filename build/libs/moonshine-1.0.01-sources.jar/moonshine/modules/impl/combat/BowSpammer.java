package moonshine.modules.impl.combat;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.SliderSettings;
import net.minecraft.class_1268;
import net.minecraft.class_1753;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_2886;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class BowSpammer extends ModuleStructure {

    final SliderSettings delay = new SliderSettings("Задержка", "Задержка между выстрелами")
            .range(2.2f, 5.0f).setValue(2.5f);

    public BowSpammer() {
        super("BowSpammer", "Bow Spammer", ModuleCategory.COMBAT);
        settings(delay);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.method_1562() == null) return;

        if (!canShoot()) return;

        sendShootPackets();
        mc.field_1724.method_6075();
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean canShoot() {
        if (!(mc.field_1724.method_6047().method_7909() instanceof class_1753)) return false;
        if (!mc.field_1724.method_6115()) return false;
        return mc.field_1724.method_6048() >= delay.getValue();
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void sendShootPackets() {
        mc.method_1562().method_52787(new class_2846(
                class_2846.class_2847.field_12974,
                class_2338.field_10980,
                class_2350.field_11033
        ));

        mc.method_1562().method_52787(new class_2886(
                class_1268.field_5808,
                0,
                mc.field_1724.method_36454(),
                mc.field_1724.method_36455()
        ));
    }
}