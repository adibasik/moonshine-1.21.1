package moonshine.modules.impl.combat.macetarget.stage;

import lombok.Getter;
import lombok.Setter;
import moonshine.modules.impl.combat.macetarget.armor.ArmorSwapHandler;
import moonshine.modules.impl.combat.macetarget.armor.FireworkHandler;
import moonshine.modules.impl.combat.macetarget.attack.AttackHandler;
import moonshine.modules.impl.combat.macetarget.state.MaceState.Stage;
import moonshine.util.inventory.InventoryUtils;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_1309;
import net.minecraft.class_310;

@Getter
public class StageHandler {

    private static final class_310 mc = class_310.method_1551();

    private final ArmorSwapHandler armorSwapHandler;
    private final FireworkHandler fireworkHandler;
    private final AttackHandler attackHandler;
    private final StopWatch fireworkTimer;

    @Setter
    private Stage stage = Stage.PREPARE;
    @Setter
    private boolean silentMode = true;
    @Setter
    private boolean reallyWorldMode = false;
    @Setter
    private float height = 30.0f;

    public StageHandler(ArmorSwapHandler armorSwapHandler, FireworkHandler fireworkHandler, 
                        AttackHandler attackHandler, StopWatch fireworkTimer) {
        this.armorSwapHandler = armorSwapHandler;
        this.fireworkHandler = fireworkHandler;
        this.attackHandler = attackHandler;
        this.fireworkTimer = fireworkTimer;
    }

    public void handlePrepare(boolean hasElytra) {
        if (!hasElytra) {
            int slot = InventoryUtils.findElytraSlot();
            if (slot != -1) {
                armorSwapHandler.startSwap(slot, silentMode);
            }
            return;
        }
        stage = Stage.FLYING_UP;
        fireworkTimer.reset();
    }

    public void handleFlyingUp(class_1309 target, boolean hasElytra) {
        if (!hasElytra) {
            stage = Stage.PREPARE;
            return;
        }

        if (mc.field_1724.method_6128() && fireworkTimer.finished(300)) {
            fireworkHandler.useFirework(silentMode);
            fireworkTimer.reset();
        }

        if (mc.field_1724.method_23318() - target.method_23318() >= height) {
            stage = Stage.TARGETTING;
        }
    }

    public void handleTargetting(class_1309 target) {
        float swapDistance = 12.0f;

        if (InventoryUtils.hasElytra() && mc.field_1724.method_5739(target) < swapDistance
                && !armorSwapHandler.isActive()) {
            int slot = InventoryUtils.findChestArmorSlot();
            if (slot != -1) {
                armorSwapHandler.startSwap(slot, silentMode);
            }
        }

        if (mc.field_1724.method_5739(target) < 16.0f) {
            stage = Stage.ATTACKING;
        }
    }

    public void handleAttacking(class_1309 target, boolean hasElytra) {
        if (hasElytra && !armorSwapHandler.isActive()) {
            int slot = InventoryUtils.findChestArmorSlot();
            if (slot != -1) {
                armorSwapHandler.startSwap(slot, silentMode);
            }
            return;
        }

        if (!hasElytra && !armorSwapHandler.isActive() && mc.field_1724.method_5739(target) < 5) {
            attackHandler.setPendingAttack(true);

            if (reallyWorldMode) {
                attackHandler.setShouldDisableAfterAttack(true);
            } else {
                stage = Stage.FLYING_UP;
                fireworkTimer.reset();
            }
        }
    }

    public void reset() {
        stage = Stage.PREPARE;
    }
}