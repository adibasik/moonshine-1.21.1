package moonshine.modules.impl.combat.macetarget.attack;

import lombok.Getter;
import lombok.Setter;
import moonshine.util.inventory.InventoryUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_2868;
import net.minecraft.class_310;

@Getter
@Setter
public class AttackHandler {

    private static final class_310 mc = class_310.method_1551();

    private boolean pendingAttack = false;
    private boolean shouldDisableAfterAttack = false;

    public void performAttack(class_1309 target) {
        if (mc.field_1724 == null || target == null) return;

        int maceSlot = InventoryUtils.findHotbarItem(class_1802.field_49814);
        int prevSlot = mc.field_1724.method_31548().method_67532();

        if (maceSlot != -1 && maceSlot != prevSlot) {
            mc.method_1562().method_52787(new class_2868(maceSlot));
        }

        mc.field_1761.method_2918(mc.field_1724, target);
        mc.field_1724.method_6104(class_1268.field_5808);

        if (maceSlot != -1 && maceSlot != prevSlot) {
            mc.method_1562().method_52787(new class_2868(prevSlot));
        }
    }

    public void reset() {
        pendingAttack = false;
        shouldDisableAfterAttack = false;
    }
}