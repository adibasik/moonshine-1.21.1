package moonshine.modules.impl.combat.macetarget.flight;

import lombok.Getter;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.MathAngle;
import moonshine.modules.impl.combat.macetarget.prediction.TargetPredictor;
import moonshine.modules.impl.combat.macetarget.state.MaceState.Stage;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;

@Getter
public class FlightController {

    private static final class_310 mc = class_310.method_1551();

    private final TargetPredictor predictor;
    private boolean predictionEnabled = false;
    private float height = 30.0f;

    public FlightController(TargetPredictor predictor) {
        this.predictor = predictor;
    }

    public void setPredictionEnabled(boolean enabled) {
        this.predictionEnabled = enabled;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public class_243 getTargetPosition(class_1309 target, Stage stage) {
        if (target == null) {
            return class_243.field_1353;
        }

        if (predictionEnabled && predictor.isMoving()) {
            return predictor.getPredictedPosition(target, stage);
        }

        return target.method_33571();
    }

    public Angle calculateAngle(class_1309 target, Stage stage) {
        if (target == null || mc.field_1724 == null) {
            return MathAngle.cameraAngle();
        }

        class_243 targetPos = getTargetPosition(target, stage);

        switch (stage) {
            case FLYING_UP -> {
                class_243 flyTarget = targetPos.method_1031(0, height, 0);
                return MathAngle.fromVec3d(flyTarget.method_1020(mc.field_1724.method_33571()));
            }
            case TARGETTING, ATTACKING -> {
                return MathAngle.fromVec3d(targetPos.method_1020(mc.field_1724.method_33571()));
            }
            default -> {
                return MathAngle.cameraAngle();
            }
        }
    }
}