package moonshine.modules.impl.combat.macetarget.prediction;

import lombok.Getter;
import moonshine.modules.impl.combat.macetarget.state.MaceState.Stage;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;

@Getter
public class TargetPredictor {

    private static final class_310 mc = class_310.method_1551();

    private class_243 lastPosition = null;
    private class_243 velocity = class_243.field_1353;
    private class_243 smoothedVelocity = class_243.field_1353;
    private long lastUpdateTime = 0;
    private int sampleCount = 0;

    private static final int MIN_SAMPLES = 2;
    private static final double SMOOTHING = 0.6;

    public void update(class_1309 target) {
        if (target == null) {
            reset();
            return;
        }

        class_243 currentPos = target.method_73189();
        long currentTime = System.currentTimeMillis();

        if (lastPosition != null && lastUpdateTime > 0) {
            long deltaTime = currentTime - lastUpdateTime;
            if (deltaTime > 0 && deltaTime < 500) {
                velocity = currentPos.method_1020(lastPosition);
                smoothedVelocity = smoothedVelocity.method_1021(SMOOTHING).method_1019(velocity.method_1021(1 - SMOOTHING));
                sampleCount++;
            }
        }

        lastPosition = currentPos;
        lastUpdateTime = currentTime;
    }

    public class_243 getPredictedPosition(class_1309 target, Stage stage) {
        if (target == null || mc.field_1724 == null) {
            return class_243.field_1353;
        }

        class_243 currentPos = target.method_73189();

        if (sampleCount < MIN_SAMPLES || smoothedVelocity.method_37268() < 0.0001) {
            return currentPos;
        }

        double distance = mc.field_1724.method_5739(target);
        double playerSpeed = mc.field_1724.method_18798().method_1033();
        double targetSpeed = smoothedVelocity.method_37267();

        double ticksToReach;

        switch (stage) {
            case FLYING_UP -> {
                double heightDiff = Math.abs(mc.field_1724.method_23318() - target.method_23318());
                ticksToReach = (heightDiff + distance) / Math.max(playerSpeed * 20, 1.0) * 1.2;
            }
            case TARGETTING -> {
                ticksToReach = distance / Math.max(playerSpeed * 20, 0.8);
            }
            case ATTACKING -> {
                ticksToReach = distance / Math.max(playerSpeed * 20, 1.5) * 0.8;
            }
            default -> {
                ticksToReach = distance / 2.0;
            }
        }

        ticksToReach = Math.min(ticksToReach, 40);

        double leadMultiplier = 1.0;
        if (targetSpeed > 0.2) {
            leadMultiplier = 1.3;
        }
        if (targetSpeed > 0.4) {
            leadMultiplier = 1.5;
        }

        class_243 prediction = smoothedVelocity.method_1021(ticksToReach * leadMultiplier);

        return currentPos.method_1019(prediction);
    }

    public boolean isMoving() {
        return smoothedVelocity.method_37268() > 0.001;
    }

    public void reset() {
        lastPosition = null;
        velocity = class_243.field_1353;
        smoothedVelocity = class_243.field_1353;
        lastUpdateTime = 0;
        sampleCount = 0;
    }
}