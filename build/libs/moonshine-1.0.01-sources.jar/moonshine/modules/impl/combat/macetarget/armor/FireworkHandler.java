package moonshine.modules.impl.combat.macetarget.armor;

import lombok.Getter;
import lombok.Setter;
import moonshine.mixin.ClientWorldAccessor;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.impl.combat.aura.MathAngle;
import moonshine.modules.impl.combat.macetarget.state.MaceState.FireworkPhase;
import moonshine.util.inventory.InventoryUtils;
import moonshine.util.inventory.MovementController;
import moonshine.util.inventory.SwapSettings;
import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2596;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_310;
import net.minecraft.class_7202;
import java.util.function.IntFunction;

@Getter
public class FireworkHandler {

    private static final class_310 mc = class_310.method_1551();

    private final MovementController movement = new MovementController();

    @Setter
    private FireworkPhase phase = FireworkPhase.IDLE;
    private int slot = -1;
    private int savedSlot = -1;
    private boolean fromInventory = false;
    private long phaseStartTime = 0;
    private int currentDelay = 0;

    private final SwapSettingsProvider settingsProvider;

    @FunctionalInterface
    public interface SwapSettingsProvider {
        SwapSettings get();
    }

    public FireworkHandler(SwapSettingsProvider settingsProvider) {
        this.settingsProvider = settingsProvider;
    }

    public boolean isActive() {
        return phase != FireworkPhase.IDLE;
    }

    public void useFirework(boolean isSilent) {
        if (isSilent) {
            useSilent();
        } else {
            startLegit();
        }
    }

    private void useSilent() {
        if (mc.field_1724 == null) return;

        int hotbarSlot = InventoryUtils.findHotbarItem(class_1802.field_8639);
        if (hotbarSlot != -1) {
            int currentSlot = mc.field_1724.method_31548().method_67532();

            if (hotbarSlot != currentSlot) {
                mc.method_1562().method_52787(new class_2868(hotbarSlot));
            }

            Angle rotation = getRotation();
            sendSequencedPacket(sequence -> new class_2886(
                    class_1268.field_5808,
                    sequence,
                    rotation.getYaw(),
                    rotation.getPitch()
            ));

            if (hotbarSlot != currentSlot) {
                mc.method_1562().method_52787(new class_2868(currentSlot));
            }
            return;
        }

        int invSlot = InventoryUtils.findItemInInventory(class_1802.field_8639);
        if (invSlot != -1) {
            int currentHotbarSlot = mc.field_1724.method_31548().method_67532();
            int wrappedSlot = InventoryUtils.wrapSlot(invSlot);

            InventoryUtils.click(wrappedSlot, currentHotbarSlot, class_1713.field_7791);

            Angle rotation = getRotation();
            sendSequencedPacket(sequence -> new class_2886(
                    class_1268.field_5808,
                    sequence,
                    rotation.getYaw(),
                    rotation.getPitch()
            ));

            InventoryUtils.click(wrappedSlot, currentHotbarSlot, class_1713.field_7791);
            InventoryUtils.closeScreen();
        }
    }

    private void startLegit() {
        if (mc.field_1724 == null) return;

        savedSlot = mc.field_1724.method_31548().method_67532();

        int hotbarSlot = InventoryUtils.findHotbarItem(class_1802.field_8639);
        if (hotbarSlot != -1) {
            slot = hotbarSlot;
            fromInventory = false;
            InventoryUtils.selectSlot(slot);
            startPhase(FireworkPhase.AWAIT_ITEM, 0);
            return;
        }

        int invSlot = InventoryUtils.findItemInInventory(class_1802.field_8639);
        if (invSlot != -1) {
            slot = invSlot;
            fromInventory = true;

            SwapSettings settings = settingsProvider.get();
            if (settings.shouldStopMovement()) {
                startPhase(FireworkPhase.PRE_STOP, settings.randomPreStopDelay());
            } else {
                startPhase(FireworkPhase.SWAP_TO_HAND, 0);
            }
        }
    }

    public void processLoop() {
        if (phase == FireworkPhase.IDLE) return;

        boolean continueProcessing = true;
        int iterations = 0;

        while (continueProcessing && iterations < 10) {
            iterations++;
            continueProcessing = processTick();
        }
    }

    private boolean processTick() {
        if (mc.field_1724 == null) {
            reset();
            return false;
        }

        long elapsed = System.currentTimeMillis() - phaseStartTime;
        SwapSettings settings = settingsProvider.get();

        switch (phase) {
            case PRE_STOP -> {
                if (elapsed >= currentDelay) {
                    movement.saveState();
                    movement.block();
                    if (settings.shouldStopSprint()) {
                        movement.stopSprint();
                    }
                    startPhase(FireworkPhase.STOPPING, 0);
                    return true;
                }
            }
            case STOPPING -> {
                movement.block();
                if (settings.shouldStopSprint()) {
                    movement.stopSprint();
                }
                startPhase(FireworkPhase.WAIT_STOP, settings.randomWaitStopDelay());
                return currentDelay == 0;
            }
            case WAIT_STOP -> {
                movement.block();
                boolean stopped = movement.isPlayerStopped(settings.getVelocityThreshold());
                boolean timeout = elapsed >= currentDelay;

                if (stopped || timeout) {
                    startPhase(FireworkPhase.PRE_SWAP, settings.randomPreSwapDelay());
                    return currentDelay == 0;
                }
            }
            case PRE_SWAP -> {
                movement.block();
                if (elapsed >= currentDelay) {
                    startPhase(FireworkPhase.SWAP_TO_HAND, 0);
                    return true;
                }
            }
            case SWAP_TO_HAND -> {
                int hotbarSlot = mc.field_1724.method_31548().method_67532();
                InventoryUtils.click(slot, hotbarSlot, class_1713.field_7791);
                startPhase(FireworkPhase.AWAIT_ITEM, 0);
                return true;
            }
            case AWAIT_ITEM -> {
                if (mc.field_1724.method_6047().method_7909() == class_1802.field_8639) {
                    startPhase(FireworkPhase.USE, 0);
                    return true;
                }
            }
            case USE -> {
                Angle rotation = getRotation();
                sendSequencedPacket(sequence -> new class_2886(
                        class_1268.field_5808,
                        sequence,
                        rotation.getYaw(),
                        rotation.getPitch()
                ));

                mc.field_1724.method_6104(class_1268.field_5808);
                startPhase(FireworkPhase.POST_USE, settings.randomPostSwapDelay());
                return currentDelay == 0;
            }
            case POST_USE -> {
                if (elapsed >= currentDelay) {
                    if (fromInventory) {
                        startPhase(FireworkPhase.SWAP_BACK, 0);
                        return true;
                    } else {
                        InventoryUtils.selectSlot(savedSlot);
                        startPhase(FireworkPhase.RESUMING, settings.randomResumeDelay());
                        return currentDelay == 0;
                    }
                }
            }
            case SWAP_BACK -> {
                int hotbarSlot = mc.field_1724.method_31548().method_67532();
                InventoryUtils.click(slot, hotbarSlot, class_1713.field_7791);
                InventoryUtils.selectSlot(savedSlot);
                if (settings.shouldCloseInventory()) {
                    InventoryUtils.closeScreen();
                }
                startPhase(FireworkPhase.RESUMING, settings.randomResumeDelay());
                return currentDelay == 0;
            }
            case RESUMING -> {
                if (elapsed >= currentDelay) {
                    movement.restoreFromCurrent();
                    reset();
                    return false;
                }
            }
        }
        return false;
    }

    private Angle getRotation() {
        Angle rotation = AngleConnection.INSTANCE.getRotation();
        return rotation != null ? rotation : MathAngle.cameraAngle();
    }

    private void sendSequencedPacket(IntFunction<class_2596<?>> packetCreator) {
        if (mc.field_1724 == null || mc.method_1562() == null || mc.field_1687 == null) return;

        try {
            ClientWorldAccessor worldAccessor = (ClientWorldAccessor) mc.field_1687;
            class_7202 pendingUpdateManager = worldAccessor.getPendingUpdateManager().method_41937();

            int sequence = pendingUpdateManager.method_41942();
            mc.method_1562().method_52787(packetCreator.apply(sequence));

            pendingUpdateManager.close();
        } catch (Exception e) {
            mc.method_1562().method_52787(packetCreator.apply(0));
        }
    }

    private void startPhase(FireworkPhase phase, int delay) {
        this.phase = phase;
        this.phaseStartTime = System.currentTimeMillis();
        this.currentDelay = delay;
    }

    public void reset() {
        movement.reset();
        phase = FireworkPhase.IDLE;
        slot = -1;
        savedSlot = -1;
        fromInventory = false;
        phaseStartTime = 0;
        currentDelay = 0;
    }

    public void forceRestore() {
        if (movement.isBlocked()) {
            movement.restoreFromCurrent();
        }
    }
}