package moonshine.modules.impl.combat;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.InputEvent;
import moonshine.events.impl.KeyEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BindSetting;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.inventory.InventoryUtils;
import moonshine.util.inventory.SwapExecutor;
import moonshine.util.inventory.SwapSettings;
import moonshine.util.string.chat.ChatMessage;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import java.util.Comparator;
import java.util.function.Predicate;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AutoSwap extends ModuleStructure {

    final SelectSetting modeSetting = new SelectSetting("Режим", "Способ свапа")
            .value("Instant", "Legit", "Custom")
            .selected("Legit");

    final BindSetting swapBind = new BindSetting("Кнопка свапа", "Кнопка для обмена предметов");

    final SelectSetting firstItem = new SelectSetting("Основной предмет", "Первый предмет")
            .value("Totem of Undying", "Player Head", "Golden Apple", "Shield");

    final SelectSetting secondItem = new SelectSetting("Вторичный предмет", "Второй предмет")
            .value("Totem of Undying", "Player Head", "Golden Apple", "Shield");

    final BooleanSetting stopMovement = new BooleanSetting("Стоп движение", "Остановить WASD")
            .setValue(true)
            .visible(() -> modeSetting.getSelected().equals("Custom"));

    final BooleanSetting stopSprint = new BooleanSetting("Стоп спринт", "Остановить спринт")
            .setValue(true)
            .visible(() -> modeSetting.getSelected().equals("Custom"));

    final BooleanSetting closeInventory = new BooleanSetting("Закрыть инвентарь", "Отправить пакет закрытия")
            .setValue(true)
            .visible(() -> modeSetting.getSelected().equals("Custom"));

    final SliderSettings preStopDelayMin = new SliderSettings("До стопа (мин)", "Мс до остановки")
            .range(0, 300).setValue(0)
            .visible(() -> modeSetting.getSelected().equals("Custom"));

    final SliderSettings preStopDelayMax = new SliderSettings("До стопа (макс)", "Мс до остановки")
            .range(0, 300).setValue(50)
            .visible(() -> modeSetting.getSelected().equals("Custom"));

    final SliderSettings waitStopDelayMin = new SliderSettings("Ожидание стопа (мин)", "Мс ожидания остановки")
            .range(0, 500).setValue(50)
            .visible(() -> modeSetting.getSelected().equals("Custom"));

    final SliderSettings waitStopDelayMax = new SliderSettings("Ожидание стопа (макс)", "Мс ожидания остановки")
            .range(0, 500).setValue(150)
            .visible(() -> modeSetting.getSelected().equals("Custom"));

    final SliderSettings preSwapDelayMin = new SliderSettings("До свапа (мин)", "Мс перед свапом")
            .range(0, 300).setValue(20)
            .visible(() -> modeSetting.getSelected().equals("Custom"));

    final SliderSettings preSwapDelayMax = new SliderSettings("До свапа (макс)", "Мс перед свапом")
            .range(0, 300).setValue(100)
            .visible(() -> modeSetting.getSelected().equals("Custom"));

    final SliderSettings postSwapDelayMin = new SliderSettings("После свапа (мин)", "Мс после свапа")
            .range(0, 300).setValue(20)
            .visible(() -> modeSetting.getSelected().equals("Custom"));

    final SliderSettings postSwapDelayMax = new SliderSettings("После свапа (макс)", "Мс после свапа")
            .range(0, 300).setValue(80)
            .visible(() -> modeSetting.getSelected().equals("Custom"));

    final SliderSettings resumeDelayMin = new SliderSettings("Восстановление (мин)", "Мс до восстановления")
            .range(0, 300).setValue(50)
            .visible(() -> modeSetting.getSelected().equals("Custom"));

    final SliderSettings resumeDelayMax = new SliderSettings("Восстановление (макс)", "Мс до восстановления")
            .range(0, 300).setValue(150)
            .visible(() -> modeSetting.getSelected().equals("Custom"));

    final SliderSettings velocityThreshold = new SliderSettings("Порог скорости", "Порог для определения остановки")
            .range(0.0001f, 0.05f).setValue(0.001f)
            .visible(() -> modeSetting.getSelected().equals("Custom"));

    final SwapExecutor executor = new SwapExecutor();

    public AutoSwap() {
        super("AutoSwap", "Auto Swap", ModuleCategory.COMBAT);
        settings(
                modeSetting, swapBind, firstItem, secondItem,
                stopMovement, stopSprint, closeInventory,
                preStopDelayMin, preStopDelayMax,
                waitStopDelayMin, waitStopDelayMax,
                preSwapDelayMin, preSwapDelayMax,
                postSwapDelayMin, postSwapDelayMax,
                resumeDelayMin, resumeDelayMax,
                velocityThreshold
        );
    }

    @EventHandler
    public void onKey(KeyEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1755 != null) return;
        if (!e.isKeyDown(swapBind.getKey())) return;
        if (executor.isRunning()) return;

        class_1735 hotbarSlot = findValidSlot(s -> s.field_7874 >= 36 && s.field_7874 <= 44);
        class_1735 targetSlot = hotbarSlot != null ? hotbarSlot : findValidSlot(s -> s.field_7874 >= 9 && s.field_7874 <= 35);

        if (targetSlot == null) {
            ChatMessage.brandmessage("Предмет не найден в инвентаре");
            return;
        }

        SwapSettings settings = buildSettings();
        final int slotId = targetSlot.field_7874;

        executor.execute(() -> {
            InventoryUtils.swap(slotId, 45);
        }, settings);
    }

    @EventHandler
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        executor.tick();
    }

    @EventHandler
    public void onInput(InputEvent e) {
        if (mc.field_1724 == null) return;
        if (executor.isBlocking()) {
            e.setDirectionalLow(false, false, false, false);
            e.setJumping(false);
        }
    }

    private SwapSettings buildSettings() {
        String mode = modeSetting.getSelected();

        return switch (mode) {
            case "Instant" -> SwapSettings.instant();
            case "Legit" -> SwapSettings.legit();
            default -> new SwapSettings()
                    .stopMovement(stopMovement.isValue())
                    .stopSprint(stopSprint.isValue())
                    .closeInventory(closeInventory.isValue())
                    .preStopDelay(preStopDelayMin.getInt(), preStopDelayMax.getInt())
                    .waitStopDelay(waitStopDelayMin.getInt(), waitStopDelayMax.getInt())
                    .preSwapDelay(preSwapDelayMin.getInt(), preSwapDelayMax.getInt())
                    .postSwapDelay(postSwapDelayMin.getInt(), postSwapDelayMax.getInt())
                    .resumeDelay(resumeDelayMin.getInt(), resumeDelayMax.getInt())
                    .velocityThreshold(velocityThreshold.getValue());
        };
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private class_1735 findValidSlot(Predicate<class_1735> slotPredicate) {
        Predicate<class_1735> combinedPredicate = s -> s.field_7874 != 45 && !s.method_7677().method_7960() && slotPredicate.test(s);

        class_1792 firstType = getItemByType(firstItem.getSelected());
        class_1792 secondType = getItemByType(secondItem.getSelected());
        class_1792 offHandItem = mc.field_1724.method_6079().method_7909();
        String offHandItemName = mc.field_1724.method_6079().method_7964().getString();

        if (offHandItem == firstType) {
            class_1735 second = InventoryUtils.findSlot(
                    secondType,
                    combinedPredicate.and(s -> !s.method_7677().method_7964().getString().equals(offHandItemName)),
                    Comparator.comparing(s -> s.method_7677().method_7942())
            );
            if (second != null) return second;
        }

        if (offHandItem == secondType) {
            class_1735 first = InventoryUtils.findSlot(
                    firstType,
                    combinedPredicate.and(s -> !s.method_7677().method_7964().getString().equals(offHandItemName)),
                    Comparator.comparing(s -> s.method_7677().method_7942())
            );
            if (first != null) return first;
        }

        if (offHandItem != firstType && offHandItem != secondType) {
            class_1735 first = InventoryUtils.findSlot(
                    firstType,
                    combinedPredicate.and(s -> !s.method_7677().method_7964().getString().equals(offHandItemName)),
                    Comparator.comparing(s -> s.method_7677().method_7942())
            );
            if (first != null) return first;

            class_1735 second = InventoryUtils.findSlot(
                    secondType,
                    combinedPredicate.and(s -> !s.method_7677().method_7964().getString().equals(offHandItemName)),
                    Comparator.comparing(s -> s.method_7677().method_7942())
            );
            if (second != null) return second;
        }

        return null;
    }

    private class_1792 getItemByType(String itemType) {
        return switch (itemType) {
            case "Totem of Undying" -> class_1802.field_8288;
            case "Player Head" -> class_1802.field_8575;
            case "Golden Apple" -> class_1802.field_8463;
            case "Shield" -> class_1802.field_8255;
            default -> class_1802.field_8162;
        };
    }

    @Override
    public void deactivate() {
        executor.cancel();
    }
}