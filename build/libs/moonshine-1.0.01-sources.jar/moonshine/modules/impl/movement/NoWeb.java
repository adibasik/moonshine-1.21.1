package moonshine.modules.impl.movement;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.util.Instance;
import moonshine.util.move.MoveUtil;
import moonshine.util.string.PlayerInteractionHelper;
import net.minecraft.class_2246;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class NoWeb extends ModuleStructure {
    public static NoWeb getInstance() {
        return Instance.get(NoWeb.class);
    }

    public final SelectSetting webMode = new SelectSetting("Режим", "Выберите режим обхода").value("Grim");

    public NoWeb() {
        super("NoWeb", "No Web", ModuleCategory.MOVEMENT);
        settings(webMode);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (PlayerInteractionHelper.isPlayerInBlock(class_2246.field_10343)) {
            double[] speed = MoveUtil.calculateDirection(0.35);
            mc.field_1724.method_5762(speed[0], 0, speed[1]);
            mc.field_1724.method_18800(speed[0], mc.field_1690.field_1903.method_1434() ? 0.65f : mc.field_1690.field_1832.method_1434() ? -0.65f : 0, speed[1]);
        }
    }
}