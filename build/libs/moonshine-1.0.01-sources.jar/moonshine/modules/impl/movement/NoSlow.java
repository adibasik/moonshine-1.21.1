package moonshine.modules.impl.movement;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.api.types.EventType;
import moonshine.events.impl.TickEvent;
import moonshine.events.impl.UsingItemEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.util.Instance;
import moonshine.util.inventory.script.Script;
import moonshine.util.string.PlayerInteractionHelper;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_1268;
import net.minecraft.class_1764;
import net.minecraft.class_1839;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class NoSlow extends ModuleStructure {
    public static NoSlow getInstance() {
        return Instance.get(NoSlow.class);
    }

    private final StopWatch notifWatch = new StopWatch();
    private final Script script = new Script();
    private boolean finish;

    public final SelectSetting itemMode = new SelectSetting("Режим предмета", "Выберите режим обхода").value("Grim Old", "ReallyWorld", "SpookyTime", "Funtime");

    public NoSlow() {
        super("NoSlow", "No Slow", ModuleCategory.MOVEMENT);
        settings(itemMode);
    }

    private int ticks = 0;
    private int cycleCounter = 0;

    private boolean isOnSnowOrCarpet() {
        if (mc.field_1724 == null || mc.field_1687 == null) return false;
        class_2338 playerPos = mc.field_1724.method_24515();
        var block = mc.field_1687.method_8320(playerPos).method_26204();
        return block == class_2246.field_10477 ||
                block == class_2246.field_10466 ||
                block == class_2246.field_9977 ||
                block == class_2246.field_10482 ||
                block == class_2246.field_10290 ||
                block == class_2246.field_10512 ||
                block == class_2246.field_10040 ||
                block == class_2246.field_10393 ||
                block == class_2246.field_10591 ||
                block == class_2246.field_10209 ||
                block == class_2246.field_10433 ||
                block == class_2246.field_10510 ||
                block == class_2246.field_10043 ||
                block == class_2246.field_10473 ||
                block == class_2246.field_10338 ||
                block == class_2246.field_10536 ||
                block == class_2246.field_10106;
    }

    @EventHandler
    public void onUpdate(TickEvent event) {
        if (mc.field_1724 == null) return;

        if (itemMode.isSelected("ReallyWorld") || itemMode.isSelected("SpookyTime")) {
            if (!mc.field_1724.method_6123()) {
                if (mc.field_1724.method_6115()) {
                    ticks++;
                } else {
                    ticks = 0;
                    cycleCounter = 0;
                }
            }
        } else {
            if (mc.field_1724.method_6058() == class_1268.field_5808 || mc.field_1724.method_6058() == class_1268.field_5810) {
                ticks++;
            } else {
                ticks = 0;
            }
        }
    }

    @EventHandler
    public void onUsingItem(UsingItemEvent e) {
        if (mc.field_1724 == null) return;

        class_1268 first = mc.field_1724.method_6058();
        class_1268 second = first.equals(class_1268.field_5808) ? class_1268.field_5810 : class_1268.field_5808;

        switch (e.getType()) {
            case EventType.ON -> {
                handleItemUse(e, first, second);
            }
            case EventType.POST -> {
                while (!script.isFinished()) script.update();
            }
        }
    }

    private void handleItemUse(UsingItemEvent e, class_1268 first, class_1268 second) {
        switch (itemMode.getSelected()) {
            case "Grim Old" -> {
                if (mc.field_1724.method_6079().method_7976().equals(class_1839.field_8952) || mc.field_1724.method_6047().method_7976().equals(class_1839.field_8952)) {
                    PlayerInteractionHelper.interactItem(first);
                    PlayerInteractionHelper.interactItem(second);
                    e.cancel();
                }
            }
            case "ReallyWorld" -> {
                int[] thresholds;

                if (mc.field_1724.method_70673()) {
                    thresholds = new int[]{2, 2, 2};
                } else {
                    thresholds = new int[]{2, 3, 3};
                }

                int threshold = thresholds[cycleCounter % thresholds.length];

                if (ticks >= threshold) {
                    e.cancel();
                    ticks = 0;
                    cycleCounter++;
                }
            }
            case "SpookyTime" -> {
                int[] thresholds = new int[]{2, 2, 2};
                int threshold = thresholds[cycleCounter % 2];
                if (ticks >= threshold) {
                    e.cancel();
                    ticks = 0;
                    cycleCounter++;
                }
            }
            case "Funtime" -> {
                if (ticks > 0F && mc.field_1724.method_6048() > 1F) {
                    boolean mainHandCrossbow = mc.field_1724.method_6047().method_7909() instanceof class_1764;
                    boolean offHandCrossbow = mc.field_1724.method_6079().method_7909() instanceof class_1764;

                    if (mainHandCrossbow || offHandCrossbow) {
                        if (ticks > 0F && mc.field_1724.method_6048() > 1) {
                            e.cancel();
                            ticks = 0;
                        }
                    } else if (mc.field_1724.method_24828() && isOnSnowOrCarpet()) {
                        mc.field_1724.field_3944.method_52787(new class_2846(
                                class_2846.class_2847.field_12971,
                                mc.field_1724.method_24515().method_10084(),
                                class_2350.field_11033
                        ));
                        mc.field_1724.method_18800(
                                mc.field_1724.method_18798().field_1352,
                                mc.field_1724.method_18798().field_1351,
                                mc.field_1724.method_18798().field_1350
                        );
                        e.cancel();
                        ticks = 0;
                    }
                }
            }
        }
    }
}