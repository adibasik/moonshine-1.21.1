package moonshine.modules.impl.movement;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.ClickSlotEvent;
import moonshine.events.impl.CloseScreenEvent;
import moonshine.events.impl.InputEvent;
import moonshine.events.impl.PacketEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.util.inventory.MovementController;
import moonshine.util.move.MoveUtil;
import moonshine.util.string.PlayerInteractionHelper;
import net.minecraft.class_10185;
import net.minecraft.class_1713;
import net.minecraft.class_2596;
import net.minecraft.class_2645;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import net.minecraft.class_463;
import net.minecraft.class_471;
import net.minecraft.class_497;
import net.minecraft.class_498;
import java.util.ArrayList;
import java.util.List;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class InventoryMove extends ModuleStructure {

    private final List<class_2596<?>> packets = new ArrayList<>();

    private final SelectSetting mode = new SelectSetting("Режим", "Выберите режим передвижения в инвентаре")
            .value("Normal", "Legit")
            .selected("Legit");

    private final BooleanSetting grimBypass = new BooleanSetting("Grim Bypass", "Остановка движения при закрытии инвентаря")
            .setValue(true);

    enum MovePhase {
        READY,
        ALLOW_MOVEMENT,
        STOPPING,
        WAIT_STOP,
        SLOWING_DOWN,
        SEND_PACKETS,
        SPEEDING_UP,
        RESUMING,
        CLOSE_INVENTORY,
        FINISHED
    }

    final MovementController movement = new MovementController();

    MovePhase movePhase = MovePhase.READY;
    long actionStartTime = 0L;
    int currentDelay = 0;
    boolean wasForwardPressed, wasBackPressed, wasLeftPressed, wasRightPressed, wasJumpPressed;
    boolean keysOverridden = false;
    boolean inventoryOpened = false;
    boolean packetsHeld = false;
    boolean pendingClose = false;
    int closeScreenSyncId = -1;

    public InventoryMove() {
        super("InventoryMove", "Inventory Move", ModuleCategory.MOVEMENT);
        settings(mode, grimBypass);
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void deactivate() {
        resetState();
    }

    @EventHandler
    public void onInput(InputEvent e) {
        if (mc.field_1724 == null) return;
        if (movement.isBlocked()) {
            e.setDirectionalLow(false, false, false, false);
            e.setJumping(false);
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onPacket(PacketEvent e) {
        if (mode.isSelected("Legit")) {
            handleLegitPackets(e);
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleLegitPackets(PacketEvent e) {
        if (e.getPacket() instanceof class_2813 slot) {
            if ((packetsHeld || MoveUtil.hasPlayerMovement()) && shouldSkipExecution()) {
                packets.add(slot);
                e.cancel();
                packetsHeld = true;
            }
        } else if (e.getPacket() instanceof class_2645 screen) {
            if (screen.method_36148() == 0) {
                e.cancel();
            }
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null) return;

        if (mode.isSelected("Legit")) {
            processLegitMovement();
        } else {
            if (!isServerScreen() && shouldSkipExecution()) {
                updateMoveKeys();
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void processLegitMovement() {
        boolean hasOpenScreen = mc.field_1755 != null;

        if (hasOpenScreen && !inventoryOpened && movePhase == MovePhase.READY) {
            startLegitMovement();
            inventoryOpened = true;
        }

        if (pendingClose) {
            handlePendingClose();
            return;
        }

        if (!hasOpenScreen && inventoryOpened && movePhase != MovePhase.READY) {
            inventoryOpened = false;
            if (movePhase == MovePhase.ALLOW_MOVEMENT) {
                resetState();
            }
            return;
        }

        if (movePhase != MovePhase.READY) {
            handleMovementStates();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handlePendingClose() {
        long elapsed = System.currentTimeMillis() - actionStartTime;

        switch (movePhase) {
            case STOPPING -> {
                movement.block();
                movement.stopSprint();
                movePhase = MovePhase.WAIT_STOP;
                actionStartTime = System.currentTimeMillis();
            }
            case WAIT_STOP -> {
                movement.block();
                boolean stopped = isPlayerStopped();
                if (stopped || elapsed >= 100) {
                    if (packetsHeld) {
                        movePhase = MovePhase.SEND_PACKETS;
                    } else {
                        movePhase = MovePhase.CLOSE_INVENTORY;
                    }
                    actionStartTime = System.currentTimeMillis();
                }
            }
            case SLOWING_DOWN -> {
                blockMovementInput();
                if (elapsed > 1) {
                    movePhase = MovePhase.SEND_PACKETS;
                    actionStartTime = System.currentTimeMillis();
                }
            }
            case SEND_PACKETS -> {
                sendHeldPackets();
                movePhase = MovePhase.CLOSE_INVENTORY;
                actionStartTime = System.currentTimeMillis();
            }
            case CLOSE_INVENTORY -> {
                closeInventoryNow();
                movePhase = MovePhase.RESUMING;
                currentDelay = 20 + (int)(Math.random() * 30);
                actionStartTime = System.currentTimeMillis();
            }
            case RESUMING -> {
                if (elapsed >= currentDelay) {
                    if (movement.isBlocked()) {
                        movement.restoreFromCurrent();
                    }
                    if (keysOverridden) {
                        restoreKeyStates();
                    }
                    movePhase = MovePhase.FINISHED;
                }
            }
            case FINISHED -> resetState();
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean isPlayerStopped() {
        if (mc.field_1724 == null) return true;
        double vx = Math.abs(mc.field_1724.method_18798().field_1352);
        double vz = Math.abs(mc.field_1724.method_18798().field_1350);
        return vx < 0.03 && vz < 0.03;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void blockMovementInput() {
        if (mc.field_1724 != null && mc.field_1724.field_3913 != null) {
            mc.field_1724.field_3913.field_54155 = new class_10185(false, false, false, false,
                    mc.field_1724.field_3913.field_54155.comp_3163(), mc.field_1724.field_3913.field_54155.comp_3164(), mc.field_1724.field_3913.field_54155.comp_3165());
        }
        if (!keysOverridden) {
            mc.field_1690.field_1894.method_23481(false);
            mc.field_1690.field_1881.method_23481(false);
            mc.field_1690.field_1913.method_23481(false);
            mc.field_1690.field_1849.method_23481(false);
            mc.field_1690.field_1903.method_23481(false);
            keysOverridden = true;
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void sendHeldPackets() {
        if (!packets.isEmpty()) {
            packets.forEach(PlayerInteractionHelper::sendPacketWithOutEvent);
            packets.clear();
            updateSlots();
        }
        packetsHeld = false;
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void closeInventoryNow() {
        if (mc.field_1724 == null || mc.method_1562() == null) return;

        if (closeScreenSyncId != -1) {
            mc.method_1562().method_52787(new class_2815(closeScreenSyncId));
        }

        if (mc.field_1755 != null) {
            mc.field_1755.method_25419();
        }

        pendingClose = false;
        inventoryOpened = false;
        closeScreenSyncId = -1;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void startLegitMovement() {
        wasForwardPressed = isKeyPressed(mc.field_1690.field_1894.method_1429().method_1444());
        wasBackPressed = isKeyPressed(mc.field_1690.field_1881.method_1429().method_1444());
        wasLeftPressed = isKeyPressed(mc.field_1690.field_1913.method_1429().method_1444());
        wasRightPressed = isKeyPressed(mc.field_1690.field_1849.method_1429().method_1444());
        wasJumpPressed = isKeyPressed(mc.field_1690.field_1903.method_1429().method_1444());
        movePhase = MovePhase.ALLOW_MOVEMENT;
        keysOverridden = false;
        packetsHeld = false;
        pendingClose = false;
        closeScreenSyncId = -1;
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleMovementStates() {
        long elapsed = System.currentTimeMillis() - actionStartTime;

        switch (movePhase) {
            case ALLOW_MOVEMENT -> {
                if (!isServerScreen() && shouldSkipExecution()) updateMoveKeys();
            }
            case SPEEDING_UP -> {
                if (keysOverridden) restoreKeyStates();
                if (mc.field_1724 != null && elapsed > 1 && isKeyPressed(mc.field_1690.field_1894.method_1429().method_1444()) && !mc.field_1724.method_5624()) {
                    mc.field_1724.method_5728(true);
                }
                if (elapsed > 1) movePhase = MovePhase.FINISHED;
            }
            case RESUMING -> {
                if (elapsed >= currentDelay) {
                    movement.restoreFromCurrent();
                    movePhase = MovePhase.FINISHED;
                }
            }
            case FINISHED -> resetState();
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void restoreKeyStates() {
        mc.field_1690.field_1894.method_23481(wasForwardPressed && isKeyPressed(mc.field_1690.field_1894.method_1429().method_1444()));
        mc.field_1690.field_1881.method_23481(wasBackPressed && isKeyPressed(mc.field_1690.field_1881.method_1429().method_1444()));
        mc.field_1690.field_1913.method_23481(wasLeftPressed && isKeyPressed(mc.field_1690.field_1913.method_1429().method_1444()));
        mc.field_1690.field_1849.method_23481(wasRightPressed && isKeyPressed(mc.field_1690.field_1849.method_1429().method_1444()));
        mc.field_1690.field_1903.method_23481(wasJumpPressed && isKeyPressed(mc.field_1690.field_1903.method_1429().method_1444()));
        keysOverridden = false;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void resetState() {
        if (movement.isBlocked()) movement.restoreFromCurrent();
        if (keysOverridden) restoreKeyStates();
        movePhase = MovePhase.READY;
        inventoryOpened = false;
        packetsHeld = false;
        pendingClose = false;
        closeScreenSyncId = -1;
        packets.clear();
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void onClickSlot(ClickSlotEvent e) {
        if (mode.isSelected("Legit")) {
            class_1713 actionType = e.getActionType();
            if ((packetsHeld || MoveUtil.hasPlayerMovement()) &&
                    ((e.getButton() == 1 && !actionType.equals(class_1713.field_7791) && !actionType.equals(class_1713.field_7795))
                            || actionType.equals(class_1713.field_7793))) {
                e.cancel();
            }
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onCloseScreen(CloseScreenEvent e) {
        if (!mode.isSelected("Legit")) return;
        if (movePhase != MovePhase.ALLOW_MOVEMENT) return;
        if (!shouldSkipExecution()) return;

        boolean needsStop = grimBypass.isValue() && MoveUtil.hasPlayerMovement();
        boolean hasPackets = packetsHeld;

        if (needsStop || hasPackets) {
            e.cancel();

            pendingClose = true;
            closeScreenSyncId = mc.field_1724 != null ? mc.field_1724.field_7512.field_7763 : 0;

            if (needsStop) {
                movePhase = MovePhase.STOPPING;
            } else {
                movePhase = MovePhase.SLOWING_DOWN;
            }
            actionStartTime = System.currentTimeMillis();
        }
    }

    private boolean isKeyPressed(int keyCode) {
        return class_3675.method_15987(mc.method_22683(), keyCode);
    }

    private void updateMoveKeys() {
        mc.field_1690.field_1894.method_23481(isKeyPressed(mc.field_1690.field_1894.method_1429().method_1444()));
        mc.field_1690.field_1881.method_23481(isKeyPressed(mc.field_1690.field_1881.method_1429().method_1444()));
        mc.field_1690.field_1913.method_23481(isKeyPressed(mc.field_1690.field_1913.method_1429().method_1444()));
        mc.field_1690.field_1849.method_23481(isKeyPressed(mc.field_1690.field_1849.method_1429().method_1444()));
        mc.field_1690.field_1903.method_23481(isKeyPressed(mc.field_1690.field_1903.method_1429().method_1444()));
    }

    private boolean shouldSkipExecution() {
        return mc.field_1755 != null && !(mc.field_1755 instanceof class_408) && !(mc.field_1755 instanceof class_498)
                && !(mc.field_1755 instanceof class_471) && !(mc.field_1755 instanceof class_463) && !(mc.field_1755 instanceof class_497);
    }

    private boolean isServerScreen() {
        return mc.field_1724 != null && mc.field_1724.field_7512.field_7761.size() != 46;
    }

    private void updateSlots() {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, 0, 0, class_1713.field_7793, mc.field_1724);
    }
}