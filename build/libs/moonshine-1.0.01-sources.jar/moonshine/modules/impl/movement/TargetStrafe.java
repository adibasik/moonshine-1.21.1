package moonshine.modules.impl.movement;

import antidaunleak.api.annotation.Native;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.InputEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.impl.combat.Aura;
import moonshine.modules.impl.combat.AutoTotem;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.*;
import moonshine.util.Instance;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class TargetStrafe extends ModuleStructure {

    private static final class_310 mc = class_310.method_1551();

    public SelectSetting mode = new SelectSetting("Режим", "Тип стрейфа")
            .value("Matrix", "Grim")
            .selected("Matrix");

    SelectSetting type = new SelectSetting("Точка ходьбы", "Выбирете точку куда будет идти стрейф")
            .value("Cube", "Center", "Circle")
            .selected("Cube").visible(() -> mode.isSelected("Grim"));

    SelectSetting typeMatrix = new SelectSetting("Точка для обхода", "Выберите точку обхода в режиме Matrix")
            .value("Cube", "Circle")
            .selected("Circle")
            .visible(() -> mode.isSelected("Matrix"));

    SliderSettings grimRadius = new SliderSettings("Радиус обхода", "Радиус обхода вокруг цели")
            .setValue(0.87F).range(0.1F, 1.5F).visible(() -> mode.isSelected("Grim") && (type.isSelected("Cube") || type.isSelected("Circle")));

    MultiSelectSetting setting = new MultiSelectSetting("Настройки", "Позволяет настроить работу стрейфов")
            .value("Auto Jump", "Only Key Pressed", "In front of the target", "Direction Mode")
            .selected("Auto Jump");

    SelectSetting directionMode = new SelectSetting("Направление", "Выберите направление обхода")
            .value("Clockwise", "Counterclockwise", "Random")
            .selected("Clockwise")
            .visible(() -> setting.isSelected("Direction Mode"));

    SliderSettings radius = new SliderSettings("Радиус", "Радиус обхода вокруг цели")
            .setValue(2.5F).range(0.1F, 7F).visible(() -> mode.isSelected("Matrix"));
    SliderSettings speed = new SliderSettings("Скорость", "Скорость стрейфа")
            .setValue(0.3F).range(0.1F, 1F).visible(() -> mode.isSelected("Matrix"));

    private int grimPointIndex = 0;

    public TargetStrafe() {
        super("TargetStrafe", "Target Strafe", ModuleCategory.MOVEMENT);
        settings(mode, type, typeMatrix, grimRadius, radius, speed, setting, directionMode);
    }

    public static TargetStrafe getInstance() {
        return Instance.get(TargetStrafe.class);
    }

    private boolean isAutoTotemBlocking() {
        AutoTotem autoTotem = Instance.get(AutoTotem.class);
        if (autoTotem == null) return false;
        if (!autoTotem.isState()) return false;
        return autoTotem.getExecutor().isBlocking() || autoTotem.getExecutor().isRunning();
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onInput(InputEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (isAutoTotemBlocking()) return;

        class_1309 target = Aura.target;
        if (target == null || !target.method_5805()) return;

        if (!mode.isSelected("Grim")) return;

        if (setting.isSelected("Only Key Pressed")) {
            if (!mc.field_1690.field_1894.method_1434() &&
                    !mc.field_1690.field_1881.method_1434() &&
                    !mc.field_1690.field_1913.method_1434() &&
                    !mc.field_1690.field_1849.method_1434()) {
                return;
            }
        }

        class_243 nextPoint = calculateGrimNextPoint(target);
        applyGrimMovement(event, nextPoint);
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private class_243 calculateGrimNextPoint(class_1309 target) {
        class_243 playerPos = mc.field_1724.method_73189();
        class_243 targetPos = target.method_73189();
        double r = grimRadius.getValue();

        int directionMultiplier = getDirectionMultiplier();

        if (setting.isSelected("In front of the target")) {
            return calculateFrontPoint(target, targetPos, r, directionMultiplier);
        } else {
            return calculateNormalPoint(playerPos, targetPos, r, directionMultiplier);
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private class_243 calculateFrontPoint(class_1309 target, class_243 targetPos, double r, int directionMultiplier) {
        float targetYaw = target.method_36454();

        if (type.isSelected("Center")) {
            return targetPos.method_1031(
                    -Math.sin(Math.toRadians(targetYaw)) * r * directionMultiplier,
                    0,
                    Math.cos(Math.toRadians(targetYaw)) * r * directionMultiplier);
        } else {
            double offset = Math.cos(System.currentTimeMillis() / 500.0) * r * directionMultiplier;
            return targetPos.method_1031(
                    -Math.sin(Math.toRadians(targetYaw)) * r + Math.cos(Math.toRadians(targetYaw)) * offset,
                    0,
                    Math.cos(Math.toRadians(targetYaw)) * r + Math.sin(Math.toRadians(targetYaw)) * offset
            );
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private class_243 calculateNormalPoint(class_243 playerPos, class_243 targetPos, double r, int directionMultiplier) {
        if (type.isSelected("Cube")) {
            class_243[] points = new class_243[]{
                    new class_243(targetPos.field_1352 - r, playerPos.field_1351, targetPos.field_1350 - r),
                    new class_243(targetPos.field_1352 - r, playerPos.field_1351, targetPos.field_1350 + r),
                    new class_243(targetPos.field_1352 + r, playerPos.field_1351, targetPos.field_1350 + r),
                    new class_243(targetPos.field_1352 + r, playerPos.field_1351, targetPos.field_1350 - r)
            };

            if (playerPos.method_1022(points[grimPointIndex]) < 0.5) {
                grimPointIndex = (grimPointIndex + directionMultiplier + points.length) % points.length;
            }

            return points[grimPointIndex];
        } else if (type.isSelected("Circle")) {
            double baseAngle = (System.currentTimeMillis() % 3600L) / 3600.0 * 4 * Math.PI;
            double angle = directionMultiplier > 0 ? baseAngle : (2 * Math.PI - baseAngle);

            return new class_243(
                    targetPos.field_1352 + Math.cos(angle) * r,
                    playerPos.field_1351,
                    targetPos.field_1350 + Math.sin(angle) * r
            );
        } else {
            return new class_243(targetPos.field_1352, playerPos.field_1351, targetPos.field_1350);
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void applyGrimMovement(InputEvent event, class_243 nextPoint) {
        class_243 playerPos = mc.field_1724.method_73189();
        class_243 direction = nextPoint.method_1020(playerPos).method_1029();

        float yaw = AngleConnection.INSTANCE.getRotation().getYaw();
        float movementAngle = (float) Math.toDegrees(Math.atan2(direction.field_1350, direction.field_1352)) - 90F;
        float angleDiff = class_3532.method_15393(movementAngle - yaw);

        boolean forward = false, back = false, left = false, right = false;

        if (angleDiff >= -22.5 && angleDiff < 22.5) {
            forward = true;
        } else if (angleDiff >= 22.5 && angleDiff < 67.5) {
            forward = true; right = true;
        } else if (angleDiff >= 67.5 && angleDiff < 112.5) {
            right = true;
        } else if (angleDiff >= 112.5 && angleDiff < 157.5) {
            back = true; right = true;
        } else if (angleDiff >= -67.5 && angleDiff < -22.5) {
            forward = true; left = true;
        } else if (angleDiff >= -112.5 && angleDiff < -67.5) {
            left = true;
        } else if (angleDiff >= -157.5 && angleDiff < -112.5) {
            back = true; left = true;
        } else {
            back = true;
        }

        event.setDirectionalLow(forward, back, left, right);

        if (setting.isSelected("Auto Jump") && mc.field_1724.method_24828()) {
            event.setJumping(true);
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (isAutoTotemBlocking()) return;

        class_1309 target = Aura.target;
        if (target == null || !target.method_5805()) return;

        if (!mode.isSelected("Matrix")) return;

        if (setting.isSelected("Only Key Pressed")) {
            if (!mc.field_1690.field_1894.method_1434() &&
                    !mc.field_1690.field_1881.method_1434() &&
                    !mc.field_1690.field_1913.method_1434() &&
                    !mc.field_1690.field_1849.method_1434()) {
                return;
            }
        }

        if (setting.isSelected("Auto Jump") && mc.field_1724.method_24828()) {
            mc.field_1724.method_6043();
        }

        processMatrixStrafe(target);
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void processMatrixStrafe(class_1309 target) {
        class_243 playerPos = mc.field_1724.method_73189();
        class_243 targetPos = target.method_73189();
        double r = radius.getValue();

        int directionMultiplier = getDirectionMultiplier();

        if (setting.isSelected("In front of the target")) {
            processMatrixFrontStrafe(target, playerPos, targetPos, r, directionMultiplier);
            return;
        }

        if (typeMatrix.isSelected("Cube")) {
            processMatrixCubeStrafe(playerPos, targetPos, r, directionMultiplier);
        } else if (typeMatrix.isSelected("Circle")) {
            processMatrixCircleStrafe(playerPos, targetPos, r, directionMultiplier);
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private int getDirectionMultiplier() {
        int directionMultiplier = 1;
        if (setting.isSelected("Direction Mode")) {
            if (directionMode.isSelected("Counterclockwise")) {
                directionMultiplier = -1;
            } else if (directionMode.isSelected("Random")) {
                long time = System.currentTimeMillis() / 3000;
                directionMultiplier = (time % 2 == 0) ? 1 : -1;
            }
        }
        return directionMultiplier;
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void processMatrixFrontStrafe(class_1309 target, class_243 playerPos, class_243 targetPos, double r, int directionMultiplier) {
        float targetYaw = target.method_36454();
        double x = targetPos.field_1352 - Math.sin(Math.toRadians(targetYaw)) * r * directionMultiplier;
        double z = targetPos.field_1350 + Math.cos(Math.toRadians(targetYaw)) * r * directionMultiplier;

        float yaw = (float) Math.toDegrees(Math.atan2(z - playerPos.field_1350, x - playerPos.field_1352)) - 90F;
        double motionSpeed = speed.getValue();
        mc.field_1724.method_18800(-Math.sin(Math.toRadians(yaw)) * motionSpeed,
                mc.field_1724.method_18798().field_1351,
                Math.cos(Math.toRadians(yaw)) * motionSpeed);
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void processMatrixCubeStrafe(class_243 playerPos, class_243 targetPos, double r, int directionMultiplier) {
        class_243[] points = new class_243[]{
                new class_243(targetPos.field_1352 - r, playerPos.field_1351, targetPos.field_1350 - r),
                new class_243(targetPos.field_1352 - r, playerPos.field_1351, targetPos.field_1350 + r),
                new class_243(targetPos.field_1352 + r, playerPos.field_1351, targetPos.field_1350 + r),
                new class_243(targetPos.field_1352 + r, playerPos.field_1351, targetPos.field_1350 - r)
        };

        if (playerPos.method_1022(points[grimPointIndex]) < 0.5) {
            grimPointIndex = (grimPointIndex + directionMultiplier + points.length) % points.length;
        }

        class_243 nextPoint = points[grimPointIndex];
        class_243 dirVec = nextPoint.method_1020(playerPos).method_1029();

        float yaw = (float) Math.toDegrees(Math.atan2(dirVec.field_1350, dirVec.field_1352)) - 90F;
        double motionSpeed = speed.getValue();

        mc.field_1724.method_18800(-Math.sin(Math.toRadians(yaw)) * motionSpeed,
                mc.field_1724.method_18798().field_1351,
                Math.cos(Math.toRadians(yaw)) * motionSpeed);
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void processMatrixCircleStrafe(class_243 playerPos, class_243 targetPos, double r, int directionMultiplier) {
        double angle = Math.atan2(playerPos.field_1350 - targetPos.field_1350, playerPos.field_1352 - targetPos.field_1352);
        angle += directionMultiplier * speed.getValue() / Math.max(playerPos.method_1022(targetPos), r);

        double x = targetPos.field_1352 + r * Math.cos(angle);
        double z = targetPos.field_1350 + r * Math.sin(angle);

        float yaw = (float) Math.toDegrees(Math.atan2(z - playerPos.field_1350, x - playerPos.field_1352)) - 90F;
        double motionSpeed = speed.getValue();

        mc.field_1724.method_18800(-Math.sin(Math.toRadians(yaw)) * motionSpeed,
                mc.field_1724.method_18798().field_1351,
                Math.cos(Math.toRadians(yaw)) * motionSpeed);
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void activate() {
        super.activate();
        grimPointIndex = 0;
    }
}