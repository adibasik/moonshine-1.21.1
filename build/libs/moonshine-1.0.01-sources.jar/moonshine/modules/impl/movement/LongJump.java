package moonshine.modules.impl.movement;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.NonFinal;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_2338;
import net.minecraft.class_2480;
import net.minecraft.class_2490;
import net.minecraft.class_495;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class LongJump extends ModuleStructure {
    SelectSetting modeSetting = new SelectSetting("Режим", "Режим прыжка").value("Boat", "Shulker Screen", "Slime Boost", "FunTime Soul Sand").selected("Always");

    @NonFinal
    private boolean wasInShulkerScreen = false;

    @NonFinal
    private boolean wasOnSlimeBlock = false;

    private StopWatch timer = new StopWatch();

    public LongJump() {
        super("LongJump", "Long Jump", ModuleCategory.MOVEMENT);
        settings(modeSetting);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    private void tickEvent(TickEvent event) {
        if (modeSetting.isSelected("Shulker Screen")) {
            handleShulkerScreen();
        }

        if (modeSetting.isSelected("FunTime Soul Sand") && mc.field_1724.method_5799() && !mc.field_1724.method_5869()) {
            mc.field_1724.method_5762(0, 0.56, 0);
        }

        if (modeSetting.isSelected("Boat")) {
            handleBoatMode();
        }

        if (modeSetting.isSelected("Slime Boost")) {
            handleSlimeBoost();
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void handleShulkerScreen() {
        if (mc.field_1755 instanceof class_495) {
            StopWatch speedTimer = new StopWatch();
            float speed = 0.9F;
            mc.field_1724.method_5762(0, speed, 0);
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleBoatMode() {
        if (mc.field_1755 instanceof class_495) {
            float yaw = (float) Math.toRadians(mc.field_1724.method_36454());
            double x = -Math.sin(yaw) * 1.0;
            double z = Math.cos(yaw) * 1.0;
            mc.field_1724.method_5762(0, 1, 0);
            mc.field_1724.method_23327(mc.field_1724.method_23317(), mc.field_1724.method_23318() + 0.24, mc.field_1724.method_23321());
        }
        if (mc.field_1755 instanceof class_495) {
            wasInShulkerScreen = true;
        } else if (wasInShulkerScreen && mc.field_1755 == null && isNearShulkerBox()) {
            wasInShulkerScreen = false;
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void handleSlimeBoost() {
        if (mc.field_1724.method_24828() && isOnSlimeBlock()) {
            wasOnSlimeBlock = true;
        } else if (wasOnSlimeBlock && !mc.field_1724.method_24828() && mc.field_1724.method_18798().method_10214() > 0) {
            mc.field_1724.method_5762(0, 1.35, 0);
            wasOnSlimeBlock = false;
        } else if (!isOnSlimeBlock()) {
            wasOnSlimeBlock = false;
        }
    }

    private boolean isNearShulkerBox() {
        class_2338 playerPos = mc.field_1724.method_24515();
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                for (int z = -1; z <= 1; z++) {
                    class_2338 pos = playerPos.method_10069(x, y, z);
                    if (mc.field_1687.method_8320(pos).method_26204() instanceof class_2480) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean isOnSlimeBlock() {
        class_2338 playerPos = mc.field_1724.method_24515();
        class_2338 belowPos = playerPos.method_10074();
        return mc.field_1687.method_8320(belowPos).method_26204() instanceof class_2490;
    }
}