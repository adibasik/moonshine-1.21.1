package moonshine.modules.impl.movement;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.NonFinal;
import moonshine.events.api.EventHandler;
import moonshine.events.api.types.EventType;
import moonshine.events.impl.RotationUpdateEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.AngleConfig;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.impl.combat.aura.MathAngle;
import moonshine.modules.impl.combat.aura.rotations.SnapAngle;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.util.inventory.InventoryUtils;
import moonshine.util.math.TaskPriority;
import moonshine.util.player.PlayerSimulation;
import moonshine.util.string.PlayerInteractionHelper;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2879;
import net.minecraft.class_2886;
import net.minecraft.class_3965;
import java.util.stream.Stream;

@Setter
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@SuppressWarnings("deprecation")
public class Spider extends ModuleStructure {
    StopWatch stopWatch = new StopWatch();

    SelectSetting mode = new SelectSetting("Режим", "Выбирает режим")
            .value("SpookyTime", "FunTime", "Slime Block", "Water Bucket")
            .selected("Slime Block");

    @NonFinal
    int cooldown;

    @NonFinal
    boolean startSetPitch = false;

    public Spider() {
        super("Spider", ModuleCategory.MOVEMENT);
        settings(mode);
    }

    private class_2248 getBlockState(class_2338 blockPos) {
        return mc.field_1687.method_8320(blockPos).method_26204();
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void deactivate() {
        if (mode.isSelected("Slime Block")) {
            mc.field_1690.field_1903.method_23481(false);
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (mode.isSelected("FunTime")) {
            handleFunTimeMode();
        }

        if (mode.isSelected("Water Bucket")) {
            handleWaterBucketMode();
        }

        if (mode.isSelected("SpookyTime") && stopWatch.finished(310)) {
            handleSpookyTimeMode();
        }

        if (mode.isSelected("Slime Block")) {
            handleSlimeBlock();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleFunTimeMode() {
        if (mc.field_1690.field_1903.method_1434()) return;
        class_238 playerBox = mc.field_1724.method_5829().method_1014(-1e-3);
        class_238 box = new class_238(playerBox.field_1323, playerBox.field_1322, playerBox.field_1321, playerBox.field_1320, playerBox.field_1322 + 0.5, playerBox.field_1324);
        if (stopWatch.finished(400) && PlayerInteractionHelper.isBox(box, this::hasCollision)) {
            box = new class_238(playerBox.field_1323 - 0.3, playerBox.field_1322 + 1, playerBox.field_1321 - 0.3, playerBox.field_1320, playerBox.field_1325, playerBox.field_1324);
            if (PlayerInteractionHelper.isBox(box, this::hasCollision)) {
                mc.field_1724.method_24830(true);
                mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.6, mc.field_1724.method_18798().field_1350);
            } else {
                mc.field_1724.method_24830(true);
                mc.field_1724.method_6043();
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void handleWaterBucketMode() {
        if (mc.field_1724.method_6047().method_7909() == class_1802.field_8705 && mc.field_1724.field_5976) {
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            mc.field_1724.method_6104(class_1268.field_5808);
            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.3, mc.field_1724.method_18798().field_1350);
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleSpookyTimeMode() {
        if (mc.field_1724.method_6047().method_7909() == class_1802.field_8705 && mc.field_1724.field_5976) {
            mc.field_1724.field_3944.method_52787(new class_2886(class_1268.field_5808, 0, mc.field_1724.method_36454(), mc.field_1724.method_36455()));
            mc.field_1724.field_3944.method_52787(new class_2879(class_1268.field_5808));
            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.35, mc.field_1724.method_18798().field_1350);
        }
        stopWatch.reset();
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleSlimeBlock() {
        class_2338 playerPos = mc.field_1724.method_24515();
        class_2338[] adjacentBlocks = {
                playerPos.method_10078(),
                playerPos.method_10067(),
                playerPos.method_10095(),
                playerPos.method_10072()
        };

        boolean hasAdjacentSlime = false;
        for (class_2338 pos : adjacentBlocks) {
            if (getBlockState(pos) == class_2246.field_10030) {
                hasAdjacentSlime = true;
                break;
            }
        }

        if (!hasAdjacentSlime || !mc.field_1724.field_5976 || mc.field_1724.method_18798().field_1351 <= -1) {
            return;
        }

        class_239 crosshair = mc.field_1765;
        if (crosshair instanceof class_3965 blockHit) {
            class_2350 face = blockHit.method_17780();
            class_2338 targetPos = blockHit.method_17777();

            if (getBlockState(targetPos) == class_2246.field_10124) {
                return;
            }

            int slimeSlot = findHotbarSlot(class_1802.field_8828);

            if (slimeSlot != -1) {
                InventoryUtils.selectSlot(slimeSlot);
                startSetPitch = true;
                mc.field_1724.method_36457(54);

                class_3965 interaction = new class_3965(
                        blockHit.method_17784(),
                        face,
                        targetPos,
                        false
                );

                mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, interaction);
                mc.field_1724.method_6104(class_1268.field_5808);

                if (cooldown >= 0.5) {
                    mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.63, mc.field_1724.method_18798().field_1350);
                    cooldown = 0;
                } else {
                    cooldown++;
                }
            }
        }
    }

    @EventHandler
    public void onRotationUpdate(RotationUpdateEvent e) {
        if (e.getType() != EventType.PRE) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (!mode.isSelected("Slime Block")) return;

        boolean offHand = mc.field_1724.method_6079().method_7909() instanceof class_1747;
        int slotId = findHotbarBlockSlot();
        class_2338 blockPos = findPos();

        if ((offHand || slotId != -1) && !blockPos.equals(class_2338.field_10980)) {
            class_1799 stack = offHand ? mc.field_1724.method_6079() : mc.field_1724.method_31548().method_5438(slotId);
            class_1268 hand = offHand ? class_1268.field_5810 : class_1268.field_5808;
            class_243 vec = blockPos.method_46558();
            class_2350 direction = class_2350.method_10142(vec.field_1352 - mc.field_1724.method_23317(), vec.field_1351 - mc.field_1724.method_23318(), vec.field_1350 - mc.field_1724.method_23321());
            Angle angle = MathAngle.calculateAngle(vec.method_1020(new class_243(direction.method_62675()).method_1021(0.1F)));
            Angle.VecRotation vecRotation = new Angle.VecRotation(angle, angle.toVector());
            AngleConnection.INSTANCE.rotateTo(vecRotation, mc.field_1724, 1, new AngleConfig(new SnapAngle(), true, true), TaskPriority.HIGH_IMPORTANCE_1, this);

            if (canPlace(stack)) {
                int prev = mc.field_1724.method_31548().method_67532();
                if (!offHand) InventoryUtils.selectSlot(slotId);
                mc.field_1761.method_2896(mc.field_1724, hand, new class_3965(vec, direction.method_10153(), blockPos, false));
                mc.field_1724.field_3944.method_52787(new class_2879(hand));
                if (!offHand) InventoryUtils.selectSlot(prev);
            }
        }
    }

    private int findHotbarSlot(net.minecraft.class_1792 item) {
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() == item) {
                return i;
            }
        }
        return -1;
    }

    private int findHotbarBlockSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() instanceof class_1747) {
                return i;
            }
        }
        return -1;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean canPlace(class_1799 stack) {
        class_2338 blockPos = getBlockPos();
        if (blockPos.method_10264() >= mc.field_1724.method_31478()) return false;
        class_1747 blockItem = (class_1747) stack.method_7909();
        class_265 shape = blockItem.method_7711().method_9564().method_26220(mc.field_1687, blockPos);
        if (shape.method_1110()) return false;
        class_238 box = shape.method_1107().method_996(blockPos);
        return !box.method_994(mc.field_1724.method_5829()) && box.method_994(PlayerSimulation.simulateLocalPlayer(4).boundingBox);
    }

    private class_2338 findPos() {
        class_2338 blockPos = getBlockPos();
        if (mc.field_1687.method_8320(blockPos).method_51367()) return class_2338.field_10980;
        return Stream.of(blockPos.method_10067(), blockPos.method_10078(), blockPos.method_10072(), blockPos.method_10095())
                .filter(pos -> mc.field_1687.method_8320(pos).method_51367())
                .findFirst()
                .orElse(class_2338.field_10980);
    }

    private class_2338 getBlockPos() {
        return class_2338.method_49638(PlayerSimulation.simulateLocalPlayer(1).pos.method_1031(0, -1e-3, 0));
    }

    private boolean hasCollision(class_2338 blockPos) {
        return !mc.field_1687.method_8320(blockPos).method_26220(mc.field_1687, blockPos).method_1110();
    }
}