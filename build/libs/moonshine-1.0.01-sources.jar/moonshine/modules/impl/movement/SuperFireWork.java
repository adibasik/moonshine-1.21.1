package moonshine.modules.impl.movement;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.FireworkEvent;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import net.minecraft.class_1657;
import net.minecraft.class_243;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class SuperFireWork extends ModuleStructure {
    SelectSetting modeSetting = new SelectSetting("Режим", "Выберите тип режима")
            .value("BravoHvH", "ReallyWorld", "PulseHVH", "Custom");

    SliderSettings customSpeedSetting = new SliderSettings("Скорость", "Скорость для Custom режима")
            .range(1.5f, 3f)
            .setValue(1.963f)
            .visible(() -> modeSetting.isSelected("Custom"));

    BooleanSetting nearBoostSetting = new BooleanSetting("", "");

    public SuperFireWork() {
        super("SuperFireWork", "Super FireWork", ModuleCategory.MOVEMENT);
        settings(modeSetting, customSpeedSetting);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onFirework(FireworkEvent e) {
        if (mc.field_1724 == null || !mc.field_1724.method_6128()) return;

        float yaw = AngleConnection.INSTANCE.getRotation().getYaw() % 360f;
        if (yaw < 0) yaw += 360f;

        if (modeSetting.isSelected("ReallyWorld")) {
            handleReallyWorldMode(e, yaw);
        } else if (modeSetting.isSelected("BravoHvH")) {
            handleBravoHvHMode(e, yaw);
        } else if (modeSetting.isSelected("PulseHVH")) {
            handlePulseHVHMode(e, yaw);
        } else if (modeSetting.isSelected("Custom")) {
            handleCustomMode(e, yaw);
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleReallyWorldMode(FireworkEvent e, float yaw) {
        float[] diagonals = {45f, 135f, 225f, 315f};
        float closestDiff = 180f;

        for (float d : diagonals) {
            float diff = Math.abs(yaw - d);
            diff = Math.min(diff, 360f - diff);
            if (diff < closestDiff) closestDiff = diff;
        }

        double speedXZ = 1.5;
        double speedY = 1.5;

        if (closestDiff <= 4) {
            speedXZ = 2.2;
        } else if (closestDiff <= 8) {
            speedXZ = 2.06;
        } else if (closestDiff <= 12) {
            speedXZ = 1.98;
        } else if (closestDiff <= 16) {
            speedXZ = 1.87;
        } else if (closestDiff <= 20) {
            speedXZ = 1.8;
        } else if (closestDiff <= 24) {
            speedXZ = 1.74;
        } else if (closestDiff <= 28) {
            speedXZ = 1.7;
        } else if (closestDiff <= 32) {
            speedXZ = 1.65;
        } else if (closestDiff <= 36) {
            speedXZ = 1.63;
        } else {
            speedXZ = 1.61;
            speedY = 1.61;
        }

        applyFireworkVelocity(e, speedXZ, speedY);
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleBravoHvHMode(FireworkEvent e, float yaw) {
        boolean isDiagonal = checkDiagonal(yaw, 16f);
        boolean nearPlayer = checkNearPlayer(4f);

        double speedXZ;
        double speedY = 1.66;

        if (isDiagonal) {
            speedXZ = 1.963;
        } else if (nearBoostSetting.isValue() && nearPlayer) {
            speedXZ = 1.82;
            speedY = 1.67;
        } else {
            speedXZ = 1.675;
        }

        applyFireworkVelocity(e, speedXZ, speedY);
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handlePulseHVHMode(FireworkEvent e, float yaw) {
        boolean isDiagonal = checkDiagonal(yaw, 16f);
        boolean nearPlayer = checkNearPlayer(5f);

        double speedXZ;
        double speedY = 1.66;

        if (isDiagonal) {
            speedXZ = 1.963;
        } else if (nearBoostSetting.isValue() && nearPlayer) {
            speedXZ = 1.82;
            speedY = 1.67;
        } else {
            speedXZ = 1.675;
        }

        applyFireworkVelocity(e, speedXZ, speedY);
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleCustomMode(FireworkEvent e, float yaw) {
        boolean isDiagonal = checkDiagonal(yaw, 16f);
        boolean nearPlayer = checkNearPlayer(5f);

        double speedXZ;
        double speedY = 1.66;

        if (isDiagonal) {
            speedXZ = customSpeedSetting.getValue();
        } else if (nearBoostSetting.isValue() && nearPlayer) {
            speedXZ = customSpeedSetting.getValue() - 0.1f;
            speedY = 1.67;
        } else {
            speedXZ = 1.675;
        }

        applyFireworkVelocity(e, speedXZ, speedY);
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean checkDiagonal(float yaw, float threshold) {
        for (float d : new float[]{45f, 135f, 225f, 315f}) {
            float diff = Math.abs(yaw - d);
            diff = Math.min(diff, 360f - diff);
            if (diff <= threshold) {
                return true;
            }
        }
        return false;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean checkNearPlayer(float distance) {
        if (!nearBoostSetting.isValue() || mc.field_1687 == null) return false;

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724) continue;
            if (player.method_5739(mc.field_1724) <= distance) {
                return true;
            }
        }
        return false;
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void applyFireworkVelocity(FireworkEvent e, double speedXZ, double speedY) {
        class_243 rotationVector = AngleConnection.INSTANCE.getMoveRotation().toVector();
        class_243 currentVelocity = e.getVector();

        e.setVector(currentVelocity.method_1031(
                rotationVector.field_1352 * 0.1 + (rotationVector.field_1352 * speedXZ - currentVelocity.field_1352) * 0.5,
                rotationVector.field_1351 * 0.1 + (rotationVector.field_1351 * speedY - currentVelocity.field_1351) * 0.5,
                rotationVector.field_1350 * 0.1 + (rotationVector.field_1350 * speedXZ - currentVelocity.field_1350) * 0.5
        ));
    }
}