package moonshine.modules.impl.movement;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.SwimmingEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3532;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class WaterSpeed extends ModuleStructure {

    SelectSetting modeSetting = new SelectSetting("Режим", "Выберите режим обхода")
            .value("FunTime")
            .selected("FunTime");

    BooleanSetting iceBoost = new BooleanSetting("Ускорение под льдом", "Ускоряет когда упираешься головой в лёд")
            .setValue(true);

    SliderSettings iceBoostSpeed = new SliderSettings("Скорость под льдом", "Множитель скорости под льдом")
            .range(1.0f, 3.0f)
            .setValue(1.5f)
            .visible(() -> iceBoost.isValue());

    public WaterSpeed() {
        super("WaterSpeed", "Water Speed", ModuleCategory.MOVEMENT);
        settings(modeSetting, iceBoost, iceBoostSpeed);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (modeSetting.isSelected("FunTime") && mc.field_1724.method_5681() && mc.field_1724.method_24828()) {
            mc.field_1724.method_6043();
            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.1, mc.field_1724.method_18798().field_1350);
        }

        if (iceBoost.isValue() && mc.field_1724.method_5681() && isHeadUnderIce()) {
            applyIceBoost();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void applyIceBoost() {
        float speedMultiplier = iceBoostSpeed.getValue();

        double yaw = Math.toRadians(mc.field_1724.method_36454());
        double pitch = Math.toRadians(mc.field_1724.method_36455());

        double baseSpeed = 0.04 * speedMultiplier;

        double horizontalSpeed = Math.cos(pitch) * baseSpeed;
        double motionX = -Math.sin(yaw) * horizontalSpeed;
        double motionZ = Math.cos(yaw) * horizontalSpeed;

        mc.field_1724.method_18800(
                mc.field_1724.method_18798().field_1352 + motionX,
                mc.field_1724.method_18798().field_1351,
                mc.field_1724.method_18798().field_1350 + motionZ
        );
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onSwimming(SwimmingEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (modeSetting.isSelected("FunTime")) {
            processSwimmingBoost(e);
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void processSwimmingBoost(SwimmingEvent e) {
        if (mc.field_1690.field_1903.method_1434()) {
            float pitch = AngleConnection.INSTANCE.getRotation().getPitch();
            float boost = pitch >= 0 ? class_3532.method_15363(pitch / 45, 1, 2) : 0.5F;
            e.getVector().y = 0.1 * boost;
        }

        if (iceBoost.isValue() && isHeadUnderIce()) {
            float speedMultiplier = iceBoostSpeed.getValue();
            e.getVector().x *= speedMultiplier;
            e.getVector().z *= speedMultiplier;
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean isHeadUnderIce() {
        if (mc.field_1724 == null || mc.field_1687 == null) return false;

        class_2338 headPos = mc.field_1724.method_24515().method_10086(1);
        class_2338 aboveHeadPos = mc.field_1724.method_24515().method_10086(2);

        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                class_2338 checkPos = headPos.method_10069(dx, 0, dz);
                class_2338 checkPosAbove = aboveHeadPos.method_10069(dx, 0, dz);

                if (isIceBlock(checkPos) || isIceBlock(checkPosAbove)) {
                    return true;
                }
            }
        }

        return false;
    }

    private boolean isIceBlock(class_2338 pos) {
        var block = mc.field_1687.method_8320(pos).method_26204();
        return block == class_2246.field_10295 ||
                block == class_2246.field_10225 ||
                block == class_2246.field_10384 ||
                block == class_2246.field_10110;
    }
}