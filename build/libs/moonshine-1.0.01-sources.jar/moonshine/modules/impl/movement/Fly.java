package moonshine.modules.impl.movement;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.NonFinal;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.Instance;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_243;
import net.minecraft.class_3532;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class Fly extends ModuleStructure {
    public static Fly getInstance() {
        return Instance.get(Fly.class);
    }

    SelectSetting mode = new SelectSetting("Режим", "Выберите режим полета")
            .value("Normal", "Dragon Fly")
            .selected("Normal");

    SliderSettings speedXZ = new SliderSettings("Скорость XZ", "Горизонтальная скорость")
            .setValue(1.5F).range(1.0F, 10.0F)
            .visible(() -> !mode.isSelected("FunTime Up"));
    SliderSettings speedY = new SliderSettings("Скорость Y", "Вертикальная скорость")
            .setValue(1.5F).range(0.0F, 10.0F)
            .visible(() -> !mode.isSelected("FunTime Up"));

    @NonFinal
    StopWatch timer = new StopWatch();

    public Fly() {
        super("Fly", ModuleCategory.MOVEMENT);
        settings(mode, speedXZ, speedY);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (!state || mc.field_1724 == null || mc.field_1687 == null) return;

        if (mode.isSelected("Normal")) {
            handleNormalMode();
        } else if (mode.isSelected("Dragon Fly")) {
            handleDragonFlyMode();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleNormalMode() {
        double motionY = getMotionY();
        setMotion(speedXZ.getValue());
        class_243 v = mc.field_1724.method_18798();
        mc.field_1724.method_18800(v.field_1352, motionY, v.field_1350);
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleDragonFlyMode() {
        if (mc.field_1724.method_31549().field_7479) {
            setMotion(speedXZ.getValue());
            double motionY = 0.0;
            if (mc.field_1690.field_1903.method_1434()) {
                motionY = speedY.getValue();
            }
            if (mc.field_1690.field_1832.method_1434()) {
                motionY = -speedY.getValue();
            }
            class_243 v = mc.field_1724.method_18798();
            mc.field_1724.method_18800(v.field_1352, motionY, v.field_1350);
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private double getMotionY() {
        if (mc.field_1690.field_1832.method_1434()) {
            return -speedY.getValue();
        } else if (mc.field_1690.field_1903.method_1434()) {
            return speedY.getValue();
        }
        return 0.0;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void setMotion(float speed) {
        float yaw = mc.field_1724.method_36454();
        float f = mc.field_1724.field_6250;
        float s = mc.field_1724.field_6212;
        float speedScale = speed / 3.0F;
        double x = 0.0;
        double z = 0.0;
        if (f != 0.0F || s != 0.0F) {
            float yawRad = yaw * ((float)Math.PI / 180.0F);
            x = -class_3532.method_15374(yawRad) * speedScale * f + class_3532.method_15362(yawRad) * speedScale * s;
            z = class_3532.method_15362(yawRad) * speedScale * f + class_3532.method_15374(yawRad) * speedScale * s;
        }
        mc.field_1724.method_18800(x, mc.field_1724.method_18798().field_1351, z);
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void deactivate() {
        super.deactivate();
        timer.reset();
    }
}