package moonshine.modules.impl.movement;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.PlayerTravelEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.move.MoveUtil;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1690;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class Speed extends ModuleStructure {

    SelectSetting mode = new SelectSetting("Режим", "Выберите режим скорости")
            .value("Vanilla", "Grim", "FunTime", "HolyWorld")
            .selected("Grim");

    SliderSettings speed = new SliderSettings("Скорость", "Настройка скорости передвижения")
            .range(1.0f, 5.0f)
            .setValue(1.5f)
            .visible(() -> mode.isSelected("Vanilla"));

    public Speed() {
        super("Speed", "Speed", ModuleCategory.MOVEMENT);
        settings(mode, speed);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void onTick(TickEvent e) {
        if (mode.isSelected("Vanilla")) {
            MoveUtil.setVelocity(speed.getValue() / 3);
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onMotion(PlayerTravelEvent e) {
        if (mode.isSelected("FunTime")) {
            handleFunTimeMode();
        }
        if (mode.isSelected("Grim") && e.isPre() && MoveUtil.hasPlayerMovement()) {
            handleGrimMode();
        }

        if (mode.isSelected("HolyWorld") && e.isPre() && MoveUtil.hasPlayerMovement()) {
            handleHolyWorldMode();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleFunTimeMode() {
        if (!mc.field_1724.method_5681() && !mc.field_1724.method_6128() && !mc.field_1724.method_5715()) {
            if (mc.field_1724.method_5829().field_1325 - mc.field_1724.method_5829().field_1322 < 1.5f) {
                float motion = mc.field_1724.method_6059(class_1294.field_5904) ? 0.32f : 0.28f;
                MoveUtil.setVelocity(motion);
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleGrimMode() {
        int collisions = 0;

        for (class_1297 ent : mc.field_1687.method_18112())
            if (ent != mc.field_1724 && (!(ent instanceof class_1531)) && (ent instanceof class_1309 || ent instanceof class_1690) && mc.field_1724.method_5829().method_1014(0.5f).method_994(ent.method_5829()))
                collisions++;
        double[] motion = MoveUtil.forward(0.07 * collisions);
        mc.field_1724.method_5762(motion[0], 0, motion[1]);
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleHolyWorldMode() {
        int collisions = 0;

        for (class_1297 ent : mc.field_1687.method_18112())
            if (ent != mc.field_1724 && (!(ent instanceof class_1531)) && (ent instanceof class_1309 || ent instanceof class_1690) && mc.field_1724.method_5829().method_1014(0.35f).method_994(ent.method_5829()))
                collisions++;
        double[] motion = MoveUtil.forward(0.0205 * collisions);
        mc.field_1724.method_5762(motion[0], 0, motion[1]);
    }

    private boolean hasSprintingTarget() {
        return false;
    }
}