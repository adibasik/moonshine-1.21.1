package moonshine.modules.impl.movement;

import antidaunleak.api.annotation.Native;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.TickEvent;
import moonshine.modules.impl.combat.Aura;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.AngleConfig;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.Instance;
import moonshine.util.math.TaskPriority;
import moonshine.util.move.MoveUtil;
import net.minecraft.class_310;

public class Strafe extends ModuleStructure {

    private static final class_310 mc = class_310.method_1551();
    public SelectSetting mode = new SelectSetting("Режим", "Выберите тип стрейфов")
            .value("Matrix", "Grim")
            .selected("Matrix");
    SliderSettings speed = new SliderSettings("Скорость", "Выберите скорость для стрейфа")
            .setValue(0.42F).range(0F, 1F).visible(() -> mode.isSelected("Matrix"));

    private float lastYaw, lastPitch;
    private final Angle rot = new Angle(0, 0);

    public Strafe() {
        super("Strafe", "Strafe", ModuleCategory.MOVEMENT);
        settings(mode, speed);
    }

    public static Strafe getInstance() {
        return Instance.get(Strafe.class);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        boolean moving = MoveUtil.hasPlayerMovement();

        float yaw = mc.field_1724.method_36454();

        if (mode.isSelected("Matrix")) {
            handleMatrixMode(moving, yaw);
        } else if (mode.isSelected("Grim")) {
            handleGrimMode(moving, yaw);
        }

        lastYaw = yaw;
        lastPitch = 0;
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleMatrixMode(boolean moving, float yaw) {
        if (moving) {
            yaw = MoveUtil.moveYaw(mc.field_1724.method_36454());
            double motion = speed.getValue() * 1.5f;
            MoveUtil.setVelocity(motion);
        } else {
            MoveUtil.setVelocity(0);
        }
        mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, mc.field_1724.method_18798().field_1351, mc.field_1724.method_18798().field_1350);
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleGrimMode(boolean moving, float yaw) {
        if (moving) {
            AngleConfig.freeCorrection = true;
            yaw = MoveUtil.moveYaw(mc.field_1724.method_36454());
            rot.setYaw(yaw);
            rot.setPitch(mc.field_1724.method_36455());
            if (Aura.getInstance().target == null) {
                AngleConnection.INSTANCE.rotateTo(rot, AngleConfig.DEFAULT, TaskPriority.HIGH_IMPORTANCE_1, this);
            }
        }
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void activate() {
        super.activate();
        lastYaw = mc.field_1724 != null ? mc.field_1724.method_36454() : 0;
        lastPitch = mc.field_1724 != null ? mc.field_1724.method_36455() : 0;
    }
}