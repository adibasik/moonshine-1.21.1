package moonshine.modules.impl.movement;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.NonFinal;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.move.MoveUtil;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class Jesus extends ModuleStructure {

    SelectSetting mode = new SelectSetting("Режим", "Выберите режим передвижения по воде")
            .value("Matrix", "MetaHVH", "FunTime New")
            .selected("Matrix");

    SliderSettings funtimeSpeed = new SliderSettings("Скорость FT", "Скорость передвижения по воде")
            .range(0.01f, 0.2f)
            .setValue(0.08f)
            .visible(() -> mode.isSelected("FunTime New"));

    StopWatch timer = new StopWatch();

    @NonFinal
    boolean isMoving;

    @NonFinal
    int tickCounter = 0;

    float melonBallSpeed = 0.44F;

    public Jesus() {
        super("Jesus", ModuleCategory.MOVEMENT);
        settings(mode, funtimeSpeed);
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void deactivate() {
        tickCounter = 0;
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void tick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (mode.isSelected("Matrix")) {
            handleMatrixMode();
        } else if (mode.isSelected("MetaHVH")) {
            handleMetaHVHMode();
        } else if (mode.isSelected("FunTime New")) {
            handleFunTimeNewMode();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleMatrixMode() {
        if (mc.field_1724.method_5799() || mc.field_1724.method_5771()) {
            class_1293 speedEffect = mc.field_1724.method_6112(class_1294.field_5904);
            class_1293 slowEffect = mc.field_1724.method_6112(class_1294.field_5909);
            class_1799 offHandItem = mc.field_1724.method_6079();

            String itemName = offHandItem.method_7964().getString();
            float appliedSpeed = 0F;

            if (itemName.contains("Ломтик Дыни") && speedEffect != null && speedEffect.method_5578() == 2) {
                appliedSpeed = 0.4283F * 1.15F;
            } else {
                if (speedEffect != null) {
                    if (speedEffect.method_5578() == 2) {
                        appliedSpeed = melonBallSpeed * 1.15F;
                    } else if (speedEffect.method_5578() == 1) {
                        appliedSpeed = melonBallSpeed;
                    }
                } else {
                    appliedSpeed = melonBallSpeed * 0.68F;
                }
            }

            if (slowEffect != null) {
                appliedSpeed *= 0.85f;
            }

            MoveUtil.setVelocity(appliedSpeed);

            isMoving = mc.field_1690.field_1894.method_1434()
                    || mc.field_1690.field_1881.method_1434()
                    || mc.field_1690.field_1913.method_1434()
                    || mc.field_1690.field_1849.method_1434();

            if (!isMoving) {
                mc.field_1724.method_18800(0.0, mc.field_1724.method_18798().field_1351, 0.0);
            }

            double yMotion = mc.field_1690.field_1903.method_1434() ? 0.019 : 0.003;
            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, yMotion, mc.field_1724.method_18798().field_1350);
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleMetaHVHMode() {
        if (mc.field_1724.method_5799() || mc.field_1724.method_5771()) {
            class_1293 speedEffect = mc.field_1724.method_6112(class_1294.field_5904);
            class_1293 slowEffect = mc.field_1724.method_6112(class_1294.field_5909);

            float appliedSpeed = 0.47F;

            if (speedEffect != null) {
                if (speedEffect.method_5578() == 2) {
                    appliedSpeed = 0.47F * 1.2F;
                } else if (speedEffect.method_5578() == 1) {
                    appliedSpeed = 0.47F * 1.05F;
                }
            } else {
                appliedSpeed = 0.47F * 0.7F;
            }

            if (slowEffect != null) {
                appliedSpeed *= 0.8f;
            }

            MoveUtil.setVelocity(appliedSpeed);

            isMoving = mc.field_1690.field_1894.method_1434()
                    || mc.field_1690.field_1881.method_1434()
                    || mc.field_1690.field_1913.method_1434()
                    || mc.field_1690.field_1849.method_1434();

            if (!isMoving) {
                mc.field_1724.method_18800(0.0, mc.field_1724.method_18798().field_1351, 0.0);
            }

            double yMotion = mc.field_1690.field_1903.method_1434() ? 0.025 : 0.005;
            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, yMotion, mc.field_1724.method_18798().field_1350);
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleFunTimeNewMode() {
        if (mc.field_1724.method_52535() || mc.field_1724.method_5799()) {
            tickCounter++;
            if (tickCounter > 2) tickCounter = 0;

            if (MoveUtil.hasPlayerMovement()) {
                double speed = funtimeSpeed.getValue();

                double yaw = Math.toRadians(mc.field_1724.method_36454());
                double motionX = -Math.sin(yaw) * speed;
                double motionZ = Math.cos(yaw) * speed;

                double motionY;
                if (tickCounter == 0) {
                    motionY = 0.05;
                } else if (tickCounter == 2) {
                    motionY = -0.05;
                } else {
                    motionY = 0;
                }

                mc.field_1724.method_18800(motionX, motionY, motionZ);
            } else {
                mc.field_1724.method_18800(0, 0, 0);
            }
        } else {
            tickCounter = 0;
        }
    }
}