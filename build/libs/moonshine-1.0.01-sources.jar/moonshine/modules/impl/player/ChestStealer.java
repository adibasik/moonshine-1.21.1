package moonshine.modules.impl.player;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.MultiSelectSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.inventory.InventoryUtils;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_476;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ChestStealer extends ModuleStructure {
    StopWatch stopWatch = new StopWatch();

    SelectSetting modeSetting = new SelectSetting("Тип", "Выбирает тип стила")
            .value("FunTime", "WhiteList", "Default").selected("FunTime");

    SliderSettings delaySetting = new SliderSettings("Задержка", "Задержка между кликами по слоту")
            .setValue(100).range(0, 1000)
            .visible(() -> modeSetting.isSelected("WhiteList") || modeSetting.isSelected("Default"));

    MultiSelectSetting itemSettings = new MultiSelectSetting("Предметы", "Выберите предметы, которые вор будет подбирать")
            .value("Player Head", "Totem Of Undying", "Elytra", "Netherite Sword",
                    "Netherite Helmet", "Netherite ChestPlate", "Netherite Leggings",
                    "Netherite Boots", "Netherite Ingot", "Netherite Scrap")
            .visible(() -> modeSetting.isSelected("WhiteList"));

    public ChestStealer() {
        super("ChestStealer", "Chest Stealer", ModuleCategory.PLAYER);
        settings(modeSetting, delaySetting, itemSettings);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null) return;

        switch (modeSetting.getSelected()) {
            case "FunTime" -> handleFunTimeMode();
            case "WhiteList", "Default" -> handleDefaultMode();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleFunTimeMode() {
        if (mc.field_1755 instanceof class_476 sh
                && sh.method_25440().getString().toLowerCase().contains("мистический")
                && !mc.field_1724.method_7357().method_7904(class_1802.field_8054.method_7854())) {

            sh.method_17577().field_7761.stream()
                    .filter(s -> s.method_7681()
                            && !s.field_7871.equals(mc.field_1724.method_31548())
                            && stopWatch.every(150))
                    .forEach(s -> InventoryUtils.click(s.field_7874, 0, class_1713.field_7794));
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void handleDefaultMode() {
        if (mc.field_1724.field_7512 instanceof class_1707 sh) {
            sh.field_7761.forEach(s -> {
                if (s.method_7681()
                        && !s.field_7871.equals(mc.field_1724.method_31548())
                        && (modeSetting.isSelected("Default") || whiteList(s.method_7677().method_7909()))
                        && stopWatch.every(delaySetting.getValue())) {
                    InventoryUtils.click(s.field_7874, 0, class_1713.field_7794);
                }
            });
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean whiteList(class_1792 item) {
        return itemSettings.getSelected().toString().toLowerCase()
                .contains(item.toString().toLowerCase().replace("_", ""));
    }
}