package moonshine.modules.impl.player;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.ClickSlotEvent;
import moonshine.events.impl.HandledScreenEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.inventory.InventoryUtils;
import moonshine.util.string.PlayerInteractionHelper;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import java.util.stream.Stream;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ItemScroller extends ModuleStructure {
    StopWatch stopWatch = new StopWatch();

    SliderSettings scrollerSetting = new SliderSettings("Задержка прокрутки предметов", "Выберите задержку прокрутки предметов")
            .setValue(50).range(0, 200);

    public ItemScroller() {
        super("ItemScroller", "Item Scroller", ModuleCategory.PLAYER);
        settings(scrollerSetting);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onHandledScreen(HandledScreenEvent e) {
        if (mc.field_1724 == null) return;

        class_1735 hoverSlot = e.getSlotHover();
        class_1713 actionType = getActionType();

        if (PlayerInteractionHelper.isKey(mc.field_1690.field_1832)
                && !PlayerInteractionHelper.isKey(mc.field_1690.field_1867)
                && hoverSlot != null
                && hoverSlot.method_7681()
                && actionType != null
                && stopWatch.every(scrollerSetting.getValue())) {

            InventoryUtils.click(
                    hoverSlot.field_7874,
                    actionType.equals(class_1713.field_7795) ? 1 : 0,
                    actionType
            );
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private class_1713 getActionType() {
        return PlayerInteractionHelper.isKey(mc.field_1690.field_1869)
                ? class_1713.field_7795
                : PlayerInteractionHelper.isKey(mc.field_1690.field_1886)
                ? class_1713.field_7794
                : null;
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onClickSlot(ClickSlotEvent e) {
        if (mc.field_1724 == null) return;

        int slotId = e.getSlotId();
        if (slotId < 0 || slotId >= mc.field_1724.field_7512.field_7761.size()) return;

        class_1735 slot = mc.field_1724.field_7512.method_7611(slotId);
        class_1792 item = slot.method_7677().method_7909();

        if (item != null
                && PlayerInteractionHelper.isKey(mc.field_1690.field_1832)
                && PlayerInteractionHelper.isKey(mc.field_1690.field_1867)
                && stopWatch.every(50)) {

            processSlotClick(slot, item, e);
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void processSlotClick(class_1735 slot, class_1792 item, ClickSlotEvent e) {
        getSlots()
                .filter(s -> s.method_7677().method_7909().equals(item) && s.field_7871.equals(slot.field_7871))
                .forEach(s -> InventoryUtils.click(s.field_7874, 1, e.getActionType()));
    }

    private Stream<class_1735> getSlots() {
        return mc.field_1724.field_7512.field_7761.stream();
    }
}