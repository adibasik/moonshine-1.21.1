package moonshine.modules.impl.player;

import antidaunleak.api.annotation.Native;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.TickEvent;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.AngleConfig;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.util.Instance;
import moonshine.util.math.TaskPriority;
import net.minecraft.class_1542;
import net.minecraft.class_1802;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class AutoPilot extends ModuleStructure {

    private static final class_310 mc = class_310.method_1551();

    public class_1542 target;

    private float lastYaw, lastPitch;

    private float targetYaw, targetPitch;

    Angle rot = new Angle(0, 0);

    public AutoPilot() {
        super("AutoPilot", "Auto Pilot", ModuleCategory.MISC);
    }

    public static AutoPilot getInstance() {
        return Instance.get(AutoPilot.class);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null) {
            target = null;
            return;
        }

        target = findTarget();

        if (target != null) {
            processRotation();
        } else {
            lastYaw = mc.field_1724.method_36454();
            lastPitch = mc.field_1724.method_36455();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void processRotation() {
        double dx = target.method_73189().method_10216() - mc.field_1724.method_73189().method_10216();
        double dy = (target.method_73189().method_10214()) - (mc.field_1724.method_73189().method_10214() + mc.field_1724.method_18381(mc.field_1724.method_18376()));
        double dz = target.method_73189().method_10215() - mc.field_1724.method_73189().method_10215();

        targetYaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI - 90.0);
        targetPitch = (float) (-Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);

        float maxRotation = 1024;

        float yawDiff = class_3532.method_15393(targetYaw - lastYaw);
        float yawStep = class_3532.method_15363(yawDiff, -maxRotation, maxRotation);
        lastYaw += yawStep;

        float pitchDiff = class_3532.method_15393(targetPitch - lastPitch);
        float pitchStep = class_3532.method_15363(pitchDiff, -maxRotation, maxRotation);
        lastPitch += pitchStep;
        mc.field_1724.method_36456(lastYaw);
        mc.field_1724.method_36457(lastPitch);
        rot.setYaw(lastYaw);
        rot.setPitch(lastPitch);
        AngleConnection.INSTANCE.rotateTo(rot, AngleConfig.DEFAULT, TaskPriority.HIGH_IMPORTANCE_1, this);
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private class_1542 findTarget() {
        List<class_1542> items = mc.field_1687.method_8390(class_1542.class,
                        mc.field_1724.method_5829().method_1014(50.0),
                        e -> e.method_5805() && isValidItem(e))
                .stream()
                .sorted(Comparator.comparingDouble(e -> mc.field_1724.method_5858(e)))
                .collect(Collectors.toList());
        return items.isEmpty() ? null : items.get(0);
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean isValidItem(class_1542 item) {
        var stack = item.method_6983();
        return stack.method_7909() == class_1802.field_8849 ||
                stack.method_7909() == class_1802.field_8575 ||
                stack.method_7909() == class_1802.field_8367 ||
                stack.method_7909().toString().contains("_spawn_egg");
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void deactivate() {
        target = null;
        if (mc.field_1724 != null) {
            mc.method_1562().method_52787(new class_2828.class_2830(
                    mc.field_1724.method_73189().method_10216(),
                    mc.field_1724.method_73189().method_10214(),
                    mc.field_1724.method_73189().method_10215(),
                    mc.field_1724.method_36454(),
                    mc.field_1724.method_36455(),
                    mc.field_1724.method_24828(),
                    false
            ));
        }
    }
}