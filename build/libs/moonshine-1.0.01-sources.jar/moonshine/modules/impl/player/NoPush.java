package moonshine.modules.impl.player;

import antidaunleak.api.annotation.Native;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.PlayerCollisionEvent;
import moonshine.events.impl.PushEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.MultiSelectSetting;
import net.minecraft.class_2246;
import net.minecraft.class_2248;

public class NoPush extends ModuleStructure {

    MultiSelectSetting ignoreSetting = new MultiSelectSetting("Игнорировать", "")
            .value("Вода", "Блоки", "Коллизию сущностей", "Рыхлый снег", "Ягоды");

    public NoPush() {
        super("AntiPush", "Anti Push", ModuleCategory.PLAYER);
        settings(ignoreSetting);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onPush(PushEvent e) {
        switch (e.getType()) {
            case PushEvent.Type.COLLISION -> e.setCancelled(ignoreSetting.isSelected("Коллизию сущностей"));
            case PushEvent.Type.WATER -> e.setCancelled(ignoreSetting.isSelected("Вода"));
            case PushEvent.Type.BLOCK -> e.setCancelled(ignoreSetting.isSelected("Блоки"));
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onPlayerCollision(PlayerCollisionEvent e) {
        class_2248 block = e.getBlock();
        if (block.equals(class_2246.field_27879)) e.setCancelled(ignoreSetting.isSelected("Рыхлый снег"));
        else if (block.equals(class_2246.field_16999)) e.setCancelled(ignoreSetting.isSelected("Ягоды"));
    }
}