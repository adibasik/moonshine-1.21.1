package moonshine.modules.impl.player;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.RotationUpdateEvent;
import moonshine.events.impl.TickEvent;
import moonshine.events.api.types.EventType;
import moonshine.mixin.ClientWorldAccessor;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.impl.combat.aura.AngleConfig;
import moonshine.modules.impl.combat.aura.impl.LinearConstructor;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.MultiSelectSetting;
import moonshine.util.math.TaskPriority;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2246;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_6880;
import net.minecraft.class_7202;
import net.minecraft.class_7204;
import net.minecraft.class_9334;

@SuppressWarnings("all")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AutoPotion extends ModuleStructure {

    final BooleanSetting autoOff = new BooleanSetting("Авто отключение", "Автоматически выключать модуль после использования")
            .setValue(false);

    final MultiSelectSetting potions = new MultiSelectSetting("Бросать", "Выберите зелья для автоброса")
            .value("Силу", "Скорость", "Огнестойкость")
            .selected("Силу", "Скорость");

    final StopWatch timer = new StopWatch();

    boolean spoofed = false;
    boolean isActivePotion = false;
    int rotationTicks = 0;
    int selectedSlot = -1;
    final float THROW_PITCH = 90f;
    final int ROTATION_WAIT_TICKS = 2;

    public AutoPotion() {
        super("AutoPotion", ModuleCategory.PLAYER);
        settings(potions, autoOff);
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void deactivate() {
        isActivePotion = false;
        spoofed = false;
        rotationTicks = 0;
        selectedSlot = -1;
        AngleConnection.INSTANCE.startReturning();
    }

    private enum PotionType {
        STRENGTH(class_1294.field_5910, "Силу"),
        SPEED(class_1294.field_5904, "Скорость"),
        FIRE_RESISTANCE(class_1294.field_5918, "Огнестойкость");

        final class_6880<class_1291> effect;
        final String settingName;

        PotionType(class_6880<class_1291> effect, String settingName) {
            this.effect = effect;
            this.settingName = settingName;
        }

        public boolean isEnabled(AutoPotion module) {
            return module.potions.isSelected(this.settingName);
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private int findPotionSlot(PotionType type) {
        if (mc.field_1724 == null) return -1;

        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);

            if (stack.method_31574(class_1802.field_8436)) {
                class_1844 potionComponent = stack.method_58694(class_9334.field_49651);
                if (potionComponent != null) {
                    for (class_1293 effect : potionComponent.method_57397()) {
                        if (effect.method_5579() == type.effect) {
                            return i;
                        }
                    }
                }
            }
        }
        return -1;
    }

    private boolean hasEffect(class_6880<class_1291> effect) {
        return mc.field_1724 != null && mc.field_1724.method_6059(effect);
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean canBuff(PotionType type) {
        if (hasEffect(type.effect)) return false;
        return type.isEnabled(this) && findPotionSlot(type) != -1;
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean canBuff() {
        if (mc.field_1724 == null || mc.field_1687 == null) return false;

        return (canBuff(PotionType.STRENGTH) || canBuff(PotionType.SPEED) || canBuff(PotionType.FIRE_RESISTANCE))
                && mc.field_1724.method_24828()
                && timer.finished(500);
    }

    private boolean isActive() {
        return isActivePotion || canBuff(PotionType.STRENGTH) || canBuff(PotionType.SPEED) || canBuff(PotionType.FIRE_RESISTANCE);
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private boolean shouldThrow() {
        if (mc.field_1724 == null || mc.field_1687 == null) return false;

        return isActive()
                && canBuff()
                && mc.field_1687.method_8320(mc.field_1724.method_24515().method_10074()).method_26204() != class_2246.field_10124;
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onRotationUpdate(RotationUpdateEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (event.getType() == EventType.PRE) {
            if (shouldThrow() || spoofed) {
                performRotation();
            }
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void performRotation() {
        Angle throwAngle = new Angle(mc.field_1724.method_36454(), THROW_PITCH);
        AngleConfig config = new AngleConfig(new LinearConstructor(), true, true);

        AngleConnection.INSTANCE.rotateTo(
                throwAngle,
                3,
                config,
                TaskPriority.HIGH_IMPORTANCE_1,
                this
        );

        if (!spoofed) {
            spoofed = true;
            isActivePotion = true;
            rotationTicks = 0;
            selectedSlot = mc.field_1724.method_31548().method_67532();
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onTick(TickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (isActivePotion && !shouldThrow() && !spoofed) {
            isActivePotion = false;
            if (autoOff.isValue()) {
                setState(false);
            }
        }

        if (spoofed) {
            processThrow();
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void processThrow() {
        rotationTicks++;

        Angle currentRotation = AngleConnection.INSTANCE.getRotation();
        boolean rotationReady = currentRotation != null && currentRotation.getPitch() >= 80f;
        boolean waitedEnough = rotationTicks >= ROTATION_WAIT_TICKS;

        if (rotationReady && waitedEnough) {
            boolean threwAny = false;

            if (canBuff(PotionType.STRENGTH)) {
                throwPotion(PotionType.STRENGTH);
                threwAny = true;
            }
            if (canBuff(PotionType.SPEED)) {
                throwPotion(PotionType.SPEED);
                threwAny = true;
            }
            if (canBuff(PotionType.FIRE_RESISTANCE)) {
                throwPotion(PotionType.FIRE_RESISTANCE);
                threwAny = true;
            }

            if (selectedSlot != -1) {
                mc.field_1724.field_3944.method_52787(new class_2868(selectedSlot));
            }

            timer.reset();
            spoofed = false;
            rotationTicks = 0;
            isActivePotion = false;

            if (autoOff.isValue() || !threwAny) {
                setState(false);
            }
        }

        if (rotationTicks > 10) {
            resetThrowState();
        }
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private void resetThrowState() {
        spoofed = false;
        rotationTicks = 0;
        isActivePotion = false;
        if (selectedSlot != -1) {
            mc.field_1724.field_3944.method_52787(new class_2868(selectedSlot));
        }
    }

    @Native(type = Native.Type.VMProtectBeginUltra)
    private void throwPotion(PotionType type) {
        if (!type.isEnabled(this) || hasEffect(type.effect)) return;
        if (mc.field_1724 == null || mc.field_1724.field_3944 == null) return;

        int slot = findPotionSlot(type);
        if (slot == -1) return;

        mc.field_1724.field_3944.method_52787(new class_2868(slot));

        sendSequencedPacket(id -> new class_2886(class_1268.field_5808, id, mc.field_1724.method_36454(), THROW_PITCH));
    }

    private void sendSequencedPacket(class_7204 packetCreator) {
        if (mc.field_1724 == null || mc.field_1724.field_3944 == null || mc.field_1687 == null) return;

        try {
            ClientWorldAccessor worldAccessor = (ClientWorldAccessor) mc.field_1687;
            class_7202 pendingUpdateManager = worldAccessor.getPendingUpdateManager().method_41937();

            int sequence = pendingUpdateManager.method_41942();
            mc.field_1724.field_3944.method_52787(packetCreator.predict(sequence));

            pendingUpdateManager.close();
        } catch (Exception e) {
            mc.field_1724.field_3944.method_52787(packetCreator.predict(0));
        }
    }
}