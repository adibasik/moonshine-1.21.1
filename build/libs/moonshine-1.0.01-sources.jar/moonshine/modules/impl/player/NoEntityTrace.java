package moonshine.modules.impl.player;

import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.util.Instance;
import net.minecraft.class_1799;

public class NoEntityTrace extends ModuleStructure {

    private final BooleanSetting noSword = new BooleanSetting("Выключать с мечом", "d").setValue(true);

    public NoEntityTrace() {
        super("NoEntityTrace", "No Entity Trace", ModuleCategory.PLAYER);
        settings(noSword);
    }

    public static NoEntityTrace getInstance() {
        return Instance.get(NoEntityTrace.class);
    }

    public boolean shouldIgnoreEntityTrace() {
        if (!isState() || mc.field_1724 == null) return false;
        if (!noSword.isValue()) return true;

        class_1799 stack = mc.field_1724.method_6047();
        String key = stack.method_7909().method_7876().toLowerCase();
        return !key.contains("sword");
    }

}