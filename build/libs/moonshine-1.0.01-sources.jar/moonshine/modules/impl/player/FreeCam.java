package moonshine.modules.impl.player;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.*;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.ColorSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.ColorUtil;
import moonshine.util.Instance;
import moonshine.util.math.MathUtils;
import moonshine.util.move.MoveUtil;
import net.minecraft.class_243;
import net.minecraft.class_2678;
import net.minecraft.class_2724;
import net.minecraft.class_2828;
import net.minecraft.class_5498;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class FreeCam extends ModuleStructure {
    public static FreeCam getInstance() {
        return Instance.get(FreeCam.class);
    }

    private final SliderSettings speedSetting = new SliderSettings("Скорость", "Выберите скорость камеры отладки").setValue(2.0F).range(0.5F, 5.0F);
    private final BooleanSetting freezeSetting = new BooleanSetting("Заморозка", "Вы замораживаетесь на месте").setValue(false);
    private final BooleanSetting reloadChunksSetting = new BooleanSetting("Reload Chunks", "Отключает cave culling").setValue(true);
    private final BooleanSetting toggleOnLogSetting = new BooleanSetting("Toggle On Log", "Выключает при дисконнекте").setValue(true);

    public final ColorSetting fakeplayer = new ColorSetting("Color 1", "First gradient color")
            .value(ColorUtil.getColor(255, 50, 100, 255));

    public class_243 pos, prevPos;

    public FreeCam() {
        super("FreeCam", "Free Cam", ModuleCategory.PLAYER);
        settings(speedSetting, freezeSetting, reloadChunksSetting, toggleOnLogSetting);
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void activate() {
        prevPos = pos = mc.method_1561().field_4686.method_71156();

        if (reloadChunksSetting.isValue()) {
            mc.field_1769.method_3279();
        }

        super.activate();
    }

    @Override
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void deactivate() {
        if (reloadChunksSetting.isValue()) {
            mc.execute(mc.field_1769::method_3279);
        }

        super.deactivate();
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onPacket(PacketEvent e) {
        switch (e.getPacket()) {
            case class_2828 move when freezeSetting.isValue() -> e.cancel();
            case class_2724 respawn -> setState(false);
            case class_2678 join -> setState(false);
            default -> {}
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void onMove(MoveEvent e) {
        if (freezeSetting.isValue()) {
            e.setMovement(class_243.field_1353);
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginUltra)
    public void onInput(InputEvent e) {
        float speed = speedSetting.getValue();
        double[] motion = MoveUtil.calculateDirection(e.forward(), e.sideways(), speed);

        prevPos = pos;
        pos = pos.method_1031(motion[0], e.getInput().jump() ? speed : e.getInput().sneak() ? -speed : 0, motion[1]);

        e.inputNone();
    }

    @EventHandler
    public void onCameraPosition(CameraPositionEvent e) {
        e.setPos(MathUtils.interpolate(prevPos, pos));
        mc.field_1690.method_31043(class_5498.field_26664);
    }

    @EventHandler
    public void onChunkOcclusion(ChunkOcclusionEvent event) {
        event.setCancelled(true);
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void onGameLeft(GameLeftEvent event) {
        if (toggleOnLogSetting.isValue()) {
            setState(false);
        }
    }
}