package moonshine.modules.impl.player;

import antidaunleak.api.annotation.Native;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.*;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import java.util.Comparator;
import java.util.Objects;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AutoTool extends ModuleStructure {

    final BooleanSetting silentSwap = new BooleanSetting("Визуально", "Скрывать смену инструмента визуально")
            .setValue(true);

    long lastSwapTime = 0;
    long lastBreakTime = 0;

    class_1799 originalStack = null;
    class_1799 toolStack = null;
    int originalSlotIndex = -1;
    int toolSlotIndex = -1;
    class_2338 lastBreakPos = null;

    boolean isActive = false;
    class_1735 swapBackSlot = null;

    public AutoTool() {
        super("AutoTool", "Auto Tool", ModuleCategory.PLAYER);
        settings(silentSwap);
    }

    @Override
    public void activate() {
        resetState();
    }

    @Override
    public void deactivate() {
        resetState();
    }

    private void resetState() {
        lastSwapTime = 0;
        lastBreakTime = 0;
        originalStack = null;
        toolStack = null;
        originalSlotIndex = -1;
        toolSlotIndex = -1;
        lastBreakPos = null;
        isActive = false;
        swapBackSlot = null;
    }

    private void clearRenderState() {
        originalStack = null;
        toolStack = null;
        originalSlotIndex = -1;
        toolSlotIndex = -1;
    }

    @EventHandler
    public void onHeldItemUpdate(HeldItemUpdateEvent e) {
        if (!silentSwap.isValue()) return;
        if (!isActive) return;
        if (originalStack == null || mc.field_1724 == null) return;

        if (mc.field_1724.method_31548().method_67532() != originalSlotIndex) {
            clearRenderState();
            return;
        }

        e.setMainHand(originalStack);
    }

    @EventHandler
    public void onItemRenderer(ItemRendererEvent e) {
        if (!silentSwap.isValue()) return;
        if (!isActive) return;
        if (originalStack == null) return;
        if (e.getHand() != class_1268.field_5808) return;
        if (!Objects.equals(mc.field_1724, e.getPlayer())) return;

        if (mc.field_1724.method_31548().method_67532() != originalSlotIndex) {
            clearRenderState();
            return;
        }

        e.setStack(originalStack);
    }

    @EventHandler
    public void onHotbarItemRender(HotbarItemRenderEvent e) {
        if (!silentSwap.isValue()) return;
        if (!isActive) return;
        if (originalStack == null || mc.field_1724 == null) return;

        int currentSelectedSlot = mc.field_1724.method_31548().method_67532();

        if (currentSelectedSlot != originalSlotIndex) {
            clearRenderState();
            return;
        }

        if (e.getHotbarIndex() == originalSlotIndex) {
            e.setStack(originalStack);
        }

        if (toolSlotIndex != -1 && toolSlotIndex != originalSlotIndex && e.getHotbarIndex() == toolSlotIndex) {
            e.setStack(toolStack);
        }
    }

    @EventHandler
    public void onHotBarUpdate(HotBarUpdateEvent e) {
        if (isActive) {
            e.cancel();
        }
    }

    @EventHandler
    public void onHotBarScroll(HotBarScrollEvent e) {
        if (isActive) {
            e.cancel();
        }
    }

    @EventHandler
    @Native(type = Native.Type.VMProtectBeginMutation)
    public void onBlockBreaking(BlockBreakingEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        lastBreakTime = System.currentTimeMillis();
        lastBreakPos = e.blockPos();

        if (mc.field_1724.method_68878()) return;
        if (isActive) return;
        if (!hasSwapCooldownPassed()) return;

        class_1735 bestSlot = findBestTool(lastBreakPos);
        class_1735 mainHandSlot = getMainHandSlot();

        if (bestSlot == null || mainHandSlot == null) return;
        if (bestSlot.field_7874 == mainHandSlot.field_7874) return;

        int selectedSlot = mc.field_1724.method_31548().method_67532();
        int bestToolHotbarIndex = bestSlot.field_7874 - 36;

        if (silentSwap.isValue()) {
            originalStack = mc.field_1724.method_31548().method_5438(selectedSlot).method_7972();
            toolStack = mc.field_1724.method_31548().method_5438(bestToolHotbarIndex).method_7972();
            originalSlotIndex = selectedSlot;
            toolSlotIndex = bestToolHotbarIndex;
        }

        swapBackSlot = bestSlot;

        swapToHand(bestSlot);

        isActive = true;
        lastSwapTime = System.currentTimeMillis();
    }

    @EventHandler
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (!isActive) {
            if (originalStack != null) {
                clearRenderState();
            }
            return;
        }

        if (silentSwap.isValue()) {
            int currentSlot = mc.field_1724.method_31548().method_67532();
            if (originalSlotIndex != -1 && currentSlot != originalSlotIndex) {
                forceReset();
                return;
            }
        }

        if (!hasSwapCooldownPassed()) return;

        boolean breakingStopped = hasBreakingCooldownPassed();

        if (breakingStopped) {
            if (swapBackSlot != null) {
                swapToHand(swapBackSlot);
            }

            clearRenderState();
            isActive = false;
            swapBackSlot = null;
            lastSwapTime = System.currentTimeMillis();
        }
    }

    private void forceReset() {
        clearRenderState();
        isActive = false;
        swapBackSlot = null;
    }

    private boolean hasSwapCooldownPassed() {
        return System.currentTimeMillis() - lastSwapTime >= 350;
    }

    private boolean hasBreakingCooldownPassed() {
        return System.currentTimeMillis() - lastBreakTime >= 100;
    }

    private class_1735 getMainHandSlot() {
        if (mc.field_1724 == null) return null;
        int selectedSlot = mc.field_1724.method_31548().method_67532();
        return mc.field_1724.field_7498.method_7611(36 + selectedSlot);
    }

    private void swapToHand(class_1735 slot) {
        if (mc.field_1724 == null || mc.field_1761 == null || slot == null) return;
        int hotbarSlot = mc.field_1724.method_31548().method_67532();
        mc.field_1761.method_2906(
                mc.field_1724.field_7498.field_7763,
                slot.field_7874,
                hotbarSlot,
                class_1713.field_7791,
                mc.field_1724
        );
    }

    @Native(type = Native.Type.VMProtectBeginMutation)
    private class_1735 findBestTool(class_2338 blockPos) {
        if (mc.field_1724 == null || mc.field_1687 == null || blockPos == null) return getMainHandSlot();

        class_2680 state = mc.field_1687.method_8320(blockPos);
        if (state.method_26215()) return getMainHandSlot();

        class_1735 mainHandSlot = getMainHandSlot();
        float currentSpeed = mainHandSlot != null ? mainHandSlot.method_7677().method_7924(state) : 1.0f;

        class_1735 bestSlot = mc.field_1724.field_7498.field_7761.stream()
                .filter(slot -> slot.field_7874 >= 36 && slot.field_7874 <= 44)
                .filter(slot -> !slot.method_7677().method_7960())
                .filter(slot -> slot.method_7677().method_7924(state) > 1.0f)
                .max(Comparator.comparingDouble(slot -> slot.method_7677().method_7924(state)))
                .orElse(null);

        if (bestSlot != null && bestSlot.method_7677().method_7924(state) > currentSpeed) {
            return bestSlot;
        }

        return mainHandSlot;
    }
}