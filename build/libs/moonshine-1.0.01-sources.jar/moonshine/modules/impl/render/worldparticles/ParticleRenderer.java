package moonshine.modules.impl.render.worldparticles;

import org.joml.Matrix4f;
import moonshine.util.render.сliemtpipeline.ClientPipelines;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4588;

public class ParticleRenderer {

    private static final class_2960 GLOW_TEXTURE = class_2960.method_60655("moonshine", "textures/world/dashbloom.png");
    private static final class_2960 GLOW_TEXTURE_SECONDARY = class_2960.method_60655("moonshine", "textures/world/dashbloomsample.png");

    public static class_1921 getQuadsLayer() {
        return ClientPipelines.WORLD_PARTICLES_QUADS;
    }

    public static class_1921 getLinesLayer() {
        return ClientPipelines.WORLD_PARTICLES_LINES;
    }

    public static class_1921 getGlowLayer() {
        return ClientPipelines.WORLD_PARTICLES_GLOW.apply(GLOW_TEXTURE);
    }

    public static class_1921 getGlowLayerSecondary() {
        return ClientPipelines.WORLD_PARTICLES_GLOW.apply(GLOW_TEXTURE_SECONDARY);
    }

    public static void drawCube(class_4588 b, Matrix4f m, int color, float s) {
        float h = s / 2.0F;
        int r = color >> 16 & 0xFF;
        int g = color >> 8 & 0xFF;
        int bl = color & 0xFF;
        int a = color >> 24 & 0xFF;

        b.method_22918(m, -h, h, -h).method_1336(r, g, bl, a);
        b.method_22918(m, -h, h, h).method_1336(r, g, bl, a);
        b.method_22918(m, h, h, h).method_1336(r, g, bl, a);
        b.method_22918(m, h, h, -h).method_1336(r, g, bl, a);

        b.method_22918(m, -h, -h, -h).method_1336(r, g, bl, a);
        b.method_22918(m, h, -h, -h).method_1336(r, g, bl, a);
        b.method_22918(m, h, -h, h).method_1336(r, g, bl, a);
        b.method_22918(m, -h, -h, h).method_1336(r, g, bl, a);

        b.method_22918(m, -h, h, h).method_1336(r, g, bl, a);
        b.method_22918(m, -h, -h, h).method_1336(r, g, bl, a);
        b.method_22918(m, h, -h, h).method_1336(r, g, bl, a);
        b.method_22918(m, h, h, h).method_1336(r, g, bl, a);

        b.method_22918(m, -h, h, -h).method_1336(r, g, bl, a);
        b.method_22918(m, h, h, -h).method_1336(r, g, bl, a);
        b.method_22918(m, h, -h, -h).method_1336(r, g, bl, a);
        b.method_22918(m, -h, -h, -h).method_1336(r, g, bl, a);

        b.method_22918(m, -h, h, -h).method_1336(r, g, bl, a);
        b.method_22918(m, -h, -h, -h).method_1336(r, g, bl, a);
        b.method_22918(m, -h, -h, h).method_1336(r, g, bl, a);
        b.method_22918(m, -h, h, h).method_1336(r, g, bl, a);

        b.method_22918(m, h, h, -h).method_1336(r, g, bl, a);
        b.method_22918(m, h, h, h).method_1336(r, g, bl, a);
        b.method_22918(m, h, -h, h).method_1336(r, g, bl, a);
        b.method_22918(m, h, -h, -h).method_1336(r, g, bl, a);
    }

    public static void drawLines(class_4588 b, Matrix4f m, int c, float s) {
        float h = s / 2.0F;
        int r = c >> 16 & 0xFF;
        int g = c >> 8 & 0xFF;
        int bl = c & 0xFF;
        int a = c >> 24 & 0xFF;

        line(b, m, -h, -h, -h, h, -h, -h, r, g, bl, a);
        line(b, m, h, -h, -h, h, -h, h, r, g, bl, a);
        line(b, m, h, -h, h, -h, -h, h, r, g, bl, a);
        line(b, m, -h, -h, h, -h, -h, -h, r, g, bl, a);
        line(b, m, -h, h, -h, h, h, -h, r, g, bl, a);
        line(b, m, h, h, -h, h, h, h, r, g, bl, a);
        line(b, m, h, h, h, -h, h, h, r, g, bl, a);
        line(b, m, -h, h, h, -h, h, -h, r, g, bl, a);
        line(b, m, -h, -h, -h, -h, h, -h, r, g, bl, a);
        line(b, m, h, -h, -h, h, h, -h, r, g, bl, a);
        line(b, m, h, -h, h, h, h, h, r, g, bl, a);
        line(b, m, -h, -h, h, -h, h, h, r, g, bl, a);
    }

    private static void line(class_4588 b, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2, int r, int g, int bl, int a) {
        b.method_22918(m, x1, y1, z1).method_1336(r, g, bl, a);
        b.method_22918(m, x2, y2, z2).method_1336(r, g, bl, a);
    }

    public static void drawGlow(class_4588 buffer, Matrix4f matrix, int color, int alpha, float size) {
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        float half = size / 2.0f;
        buffer.method_22918(matrix, -half, -half, 0).method_22913(0, 0).method_1336(r, g, b, alpha);
        buffer.method_22918(matrix, -half, half, 0).method_22913(0, 1).method_1336(r, g, b, alpha);
        buffer.method_22918(matrix, half, half, 0).method_22913(1, 1).method_1336(r, g, b, alpha);
        buffer.method_22918(matrix, half, -half, 0).method_22913(1, 0).method_1336(r, g, b, alpha);
    }
}