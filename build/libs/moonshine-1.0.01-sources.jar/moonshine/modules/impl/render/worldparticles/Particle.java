package moonshine.modules.impl.render.worldparticles;

import org.joml.Matrix4f;
import moonshine.IMinecraft;
import moonshine.util.ColorUtil;
import moonshine.util.animations.Animation;
import moonshine.util.animations.Direction;
import moonshine.util.animations.EaseInOutQuad;
import moonshine.util.render.сliemtpipeline.ClientPipelines;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import java.util.concurrent.ThreadLocalRandom;

public class Particle implements IMinecraft {

    public enum ParticleType {
        CUBE_3D,
        CROWN,
        CUBE_BLAST,
        DOLLAR,
        HEART,
        LIGHTNING,
        LINE,
        RHOMBUS,
        SNOWFLAKE,
        STAR,
        STAR_ALT,
        TRIANGLE,
        GLOW,
        RANDOM
    }

    private static final ParticleType[] RANDOM_TYPES = {
            ParticleType.CROWN,
            ParticleType.CUBE_BLAST,
            ParticleType.DOLLAR,
            ParticleType.HEART,
            ParticleType.LIGHTNING,
            ParticleType.LINE,
            ParticleType.RHOMBUS,
            ParticleType.SNOWFLAKE,
            ParticleType.STAR,
            ParticleType.STAR_ALT,
            ParticleType.TRIANGLE,
            ParticleType.GLOW
    };

    private static final class_2960 TEXTURE_CROWN = class_2960.method_60655("moonshine", "textures/world/crown.png");
    private static final class_2960 TEXTURE_CUBE_BLAST = class_2960.method_60655("moonshine", "textures/world/cubeblast1.png");
    private static final class_2960 TEXTURE_DOLLAR = class_2960.method_60655("moonshine", "textures/world/dollar.png");
    private static final class_2960 TEXTURE_HEART = class_2960.method_60655("moonshine", "textures/world/heart.png");
    private static final class_2960 TEXTURE_LIGHTNING = class_2960.method_60655("moonshine", "textures/world/lightning.png");
    private static final class_2960 TEXTURE_LINE = class_2960.method_60655("moonshine", "textures/world/line.png");
    private static final class_2960 TEXTURE_RHOMBUS = class_2960.method_60655("moonshine", "textures/world/rhombus.png");
    private static final class_2960 TEXTURE_SNOWFLAKE = class_2960.method_60655("moonshine", "textures/world/snowflake.png");
    private static final class_2960 TEXTURE_STAR = class_2960.method_60655("moonshine", "textures/world/star.png");
    private static final class_2960 TEXTURE_STAR_ALT = class_2960.method_60655("moonshine", "textures/world/star1.png");
    private static final class_2960 TEXTURE_TRIANGLE = class_2960.method_60655("moonshine", "textures/world/triangle.png");
    private static final class_2960 TEXTURE_GLOW = class_2960.method_60655("moonshine", "textures/world/dashbloom.png");

    private static final class_2960 GLOW_BLOOM = class_2960.method_60655("moonshine", "textures/world/dashbloom.png");
    private static final class_2960 GLOW_BLOOM_SAMPLE = class_2960.method_60655("moonshine", "textures/world/dashbloomsample.png");

    double x, y, z;
    double prevX, prevY, prevZ;
    double mX, mY, mZ;
    long start;
    float phase;
    Animation fadeInAnimation;
    Animation fadeOutAnimation;
    float cachedAlpha = 0.0F;
    long lastAlphaUpdate = 0L;
    boolean fadingOut = false;
    long lifeTimeMs;
    boolean forceFadeOut = false;

    private ParticleType type;
    private ParticleType actualType;
    private class_2960 texture;
    private float rotation;
    private float rotationSpeed;
    private int randomColor;
    private long spawnTime;
    private boolean physicsEnabled = true;
    private float size = 0.5f;

    public Particle(double x, double y, double z, long lifeTimeMs) {
        this.start = System.currentTimeMillis();
        this.spawnTime = System.currentTimeMillis();
        this.phase = (float) (Math.random() * 100.0);
        this.x = x;
        this.y = y;
        this.z = z;
        this.prevX = x;
        this.prevY = y;
        this.prevZ = z;
        this.mX = (Math.random() - 0.5) * 0.04;
        this.mY = (Math.random() - 0.5) * 0.04;
        this.mZ = (Math.random() - 0.5) * 0.04;
        this.fadeInAnimation = new EaseInOutQuad().setMs(600).setValue(1.0);
        this.fadeInAnimation.setDirection(Direction.FORWARDS);
        this.fadeOutAnimation = new EaseInOutQuad().setMs(400).setValue(1.0);
        this.fadeOutAnimation.setDirection(Direction.FORWARDS);
        this.lifeTimeMs = lifeTimeMs;
        this.rotation = (float) (Math.random() * 360.0);
        this.rotationSpeed = (float) (Math.random() * 1.5 + 0.5);
        this.randomColor = generateRandomColor();
        this.type = ParticleType.CUBE_3D;
        this.actualType = ParticleType.CUBE_3D;
    }

    public Particle(double x, double y, double z, double mx, double my, double mz, long lifeTimeMs) {
        this(x, y, z, lifeTimeMs);
        this.mX = mx;
        this.mY = my;
        this.mZ = mz;
    }

    private int generateRandomColor() {
        int[] colors = {
                0xFFFF0000, 0xFFFF7F00, 0xFFFFFF00, 0xFF00FF00,
                0xFF00FFFF, 0xFF0000FF, 0xFF8B00FF, 0xFFFF00FF,
                0xFFFF1493, 0xFFFFFFFF, 0xFF00FF7F, 0xFFFF6347
        };
        return colors[ThreadLocalRandom.current().nextInt(colors.length)];
    }

    public Particle setType(ParticleType type) {
        this.type = type;
        if (type == ParticleType.RANDOM) {
            this.actualType = RANDOM_TYPES[ThreadLocalRandom.current().nextInt(RANDOM_TYPES.length)];
        } else {
            this.actualType = type;
        }
        this.texture = getTextureForType(this.actualType);
        return this;
    }

    public Particle setPhysics(boolean enabled) {
        this.physicsEnabled = enabled;
        return this;
    }

    public Particle setSize(float size) {
        this.size = size;
        return this;
    }

    private class_2960 getTextureForType(ParticleType type) {
        return switch (type) {
            case CROWN -> TEXTURE_CROWN;
            case CUBE_BLAST -> TEXTURE_CUBE_BLAST;
            case DOLLAR -> TEXTURE_DOLLAR;
            case HEART -> TEXTURE_HEART;
            case LIGHTNING -> TEXTURE_LIGHTNING;
            case LINE -> TEXTURE_LINE;
            case RHOMBUS -> TEXTURE_RHOMBUS;
            case SNOWFLAKE -> TEXTURE_SNOWFLAKE;
            case STAR -> TEXTURE_STAR;
            case STAR_ALT -> TEXTURE_STAR_ALT;
            case TRIANGLE -> TEXTURE_TRIANGLE;
            case GLOW -> TEXTURE_GLOW;
            default -> null;
        };
    }

    public double getDistanceSquaredTo(class_243 pos) {
        double dx = this.x - pos.field_1352;
        double dy = this.y - pos.field_1351;
        double dz = this.z - pos.field_1350;
        return dx * dx + dy * dy + dz * dz;
    }

    public double getHorizontalDistanceSquaredTo(class_243 pos) {
        double dx = this.x - pos.field_1352;
        double dz = this.z - pos.field_1350;
        return dx * dx + dz * dz;
    }

    public void startFadeOut() {
        if (!fadingOut) {
            fadingOut = true;
            forceFadeOut = true;
            this.fadeOutAnimation.setDirection(Direction.BACKWARDS);
        }
    }

    public void update(long now) {
        if (mc.field_1687 == null) return;

        this.prevX = this.x;
        this.prevY = this.y;
        this.prevZ = this.z;

        double velMagSq = this.mX * this.mX + this.mY * this.mY + this.mZ * this.mZ;
        if (velMagSq > 1.0E-4) {
            if (this.isHit(this.x + this.mX, this.y, this.z)) {
                this.mX *= -0.8;
            } else {
                this.x = this.x + this.mX;
            }
            if (this.isHit(this.x, this.y + this.mY, this.z)) {
                this.mY *= -0.8;
            } else {
                this.y = this.y + this.mY;
            }
            if (this.isHit(this.x, this.y, this.z + this.mZ)) {
                this.mZ *= -0.8;
            } else {
                this.z = this.z + this.mZ;
            }
        } else {
            this.x = this.x + this.mX;
            this.y = this.y + this.mY;
            this.z = this.z + this.mZ;
        }

        this.mX *= 0.99;
        this.mY *= 0.99;
        this.mZ *= 0.99;

        if (physicsEnabled) {
            this.mY -= 0.0002;
        }

        this.rotation += this.rotationSpeed;

        if (!fadingOut && now - this.start > lifeTimeMs) {
            fadingOut = true;
            this.fadeOutAnimation.setDirection(Direction.BACKWARDS);
        }

        if (now - this.lastAlphaUpdate > 16L) {
            if (fadingOut) {
                this.cachedAlpha = this.fadeOutAnimation.getOutput().floatValue();
            } else {
                this.cachedAlpha = this.fadeInAnimation.getOutput().floatValue();
            }
            this.lastAlphaUpdate = now;
        }
    }

    public float getAlpha() {
        return this.cachedAlpha;
    }

    private boolean isHit(double px, double py, double pz) {
        if (mc.field_1687 == null) return false;
        class_2338 pos = class_2338.method_49637(px, py, pz);
        return mc.field_1687.method_8320(pos).method_26234(mc.field_1687, pos);
    }

    public boolean shouldRemove() {
        return fadingOut && this.cachedAlpha <= 0.0F;
    }

    public boolean isFadingOut() {
        return fadingOut;
    }

    public int getColor(int baseColor, boolean useRandomColor, boolean whiteOnSpawn) {
        if (useRandomColor) {
            return ColorUtil.multAlpha(randomColor, cachedAlpha);
        }

        if (whiteOnSpawn) {
            long currentTime = System.currentTimeMillis();
            long transitionDuration = 7000;
            long timeSinceSpawn = currentTime - spawnTime;

            if (timeSinceSpawn < transitionDuration) {
                float progress = (float) timeSinceSpawn / transitionDuration;

                int targetR = (baseColor >> 16) & 0xFF;
                int targetG = (baseColor >> 8) & 0xFF;
                int targetB = baseColor & 0xFF;
                int targetA = (baseColor >> 24) & 0xFF;

                int r = (int) (255 + ((targetR - 255) * progress));
                int g = (int) (255 + ((targetG - 255) * progress));
                int b = (int) (255 + ((targetB - 255) * progress));

                int color = (targetA << 24) | (r << 16) | (g << 8) | b;
                return ColorUtil.multAlpha(color, cachedAlpha);
            }
        }

        return ColorUtil.multAlpha(baseColor, cachedAlpha);
    }

    public void render(class_4587 matrices, class_4597 immediate, class_243 cameraPos,
                       int baseColor, float globalRotation, float cameraYaw, float cameraPitch,
                       float glowSize, boolean useRandomColor, boolean whiteOnSpawn, boolean whiteCenter) {

        float alpha = this.getAlpha();
        if (alpha <= 0.0F) return;

        float partialTicks = mc.method_61966().method_60637(true);
        double interpX = prevX + (x - prevX) * partialTicks;
        double interpY = prevY + (y - prevY) * partialTicks;
        double interpZ = prevZ + (z - prevZ) * partialTicks;

        float relX = (float) (interpX - cameraPos.field_1352);
        float relY = (float) (interpY - cameraPos.field_1351);
        float relZ = (float) (interpZ - cameraPos.field_1350);

        int color = getColor(baseColor, useRandomColor, whiteOnSpawn);

        if (actualType == ParticleType.CUBE_3D) {
            renderCube3D(matrices, immediate, relX, relY, relZ, alpha, color, globalRotation, cameraYaw, cameraPitch, glowSize);
        } else {
            renderTextured(matrices, immediate, relX, relY, relZ, alpha, color, cameraYaw, cameraPitch, glowSize, whiteCenter);
        }
    }

    private void renderCube3D(class_4587 matrices, class_4597 immediate,
                              float relX, float relY, float relZ, float alpha, int color,
                              float globalRotation, float cameraYaw, float cameraPitch, float glowSize) {

        float alpha02 = alpha * 0.2F;
        float alpha04 = alpha * 0.4F;
        int glowCol = color;
        float cubeSize = size * 0.5f;
        float cubeGlow1 = cubeSize * glowSize;
        float cubeGlow2 = cubeSize * (glowSize / 3.0f);

        float rotY = globalRotation + this.phase;
        float rotX = globalRotation * 0.5F;

        matrices.method_22903();
        matrices.method_46416(relX, relY, relZ);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(rotY));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(rotX));
        Matrix4f mat = matrices.method_23760().method_23761();
        ParticleRenderer.drawCube(immediate.method_73477(ParticleRenderer.getQuadsLayer()), mat, ColorUtil.multAlpha(color, alpha02), cubeSize);
        ParticleRenderer.drawLines(immediate.method_73477(ParticleRenderer.getLinesLayer()), mat, ColorUtil.multAlpha(color, alpha04), cubeSize);
        matrices.method_22909();

        matrices.method_22903();
        matrices.method_46416(relX, relY, relZ);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-cameraYaw));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(cameraPitch));
        Matrix4f gMat = matrices.method_23760().method_23761();
        ParticleRenderer.drawGlow(immediate.method_73477(ParticleRenderer.getGlowLayer()), gMat, glowCol, (int) (80.0F * alpha), cubeGlow1);
        ParticleRenderer.drawGlow(immediate.method_73477(ParticleRenderer.getGlowLayerSecondary()), gMat, glowCol, (int) (140.0F * alpha), cubeGlow2);
        matrices.method_22909();
    }

    private void renderTextured(class_4587 matrices, class_4597 immediate,
                                float relX, float relY, float relZ, float alpha, int color,
                                float cameraYaw, float cameraPitch, float glowSize, boolean whiteCenter) {

        if (texture == null) return;

        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        int a = (int) (255 * alpha);

        float textureSize = size * 0.5f;

        matrices.method_22903();
        matrices.method_46416(relX, relY, relZ);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-cameraYaw));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(cameraPitch));
        matrices.method_22907(class_7833.field_40718.rotationDegrees(rotation));

        Matrix4f mat = matrices.method_23760().method_23761();

        class_1921 layer = ClientPipelines.WORLD_PARTICLES_GLOW.apply(texture);
        class_4588 buffer = immediate.method_73477(layer);

        float half = textureSize / 2.0f;
        buffer.method_22918(mat, -half, -half, 0).method_22913(0, 0).method_1336(r, g, b, a);
        buffer.method_22918(mat, -half, half, 0).method_22913(0, 1).method_1336(r, g, b, a);
        buffer.method_22918(mat, half, half, 0).method_22913(1, 1).method_1336(r, g, b, a);
        buffer.method_22918(mat, half, -half, 0).method_22913(1, 0).method_1336(r, g, b, a);

        if (whiteCenter) {
            float centerSize = half * 0.5f;
            int whiteA = (int) (200 * alpha);
            buffer.method_22918(mat, -centerSize, -centerSize, 0.001f).method_22913(0, 0).method_1336(255, 255, 255, whiteA);
            buffer.method_22918(mat, -centerSize, centerSize, 0.001f).method_22913(0, 1).method_1336(255, 255, 255, whiteA);
            buffer.method_22918(mat, centerSize, centerSize, 0.001f).method_22913(1, 1).method_1336(255, 255, 255, whiteA);
            buffer.method_22918(mat, centerSize, -centerSize, 0.001f).method_22913(1, 0).method_1336(255, 255, 255, whiteA);
        }

        matrices.method_22909();

        matrices.method_22903();
        matrices.method_46416(relX, relY, relZ);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-cameraYaw));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(cameraPitch));
        Matrix4f gMat = matrices.method_23760().method_23761();

        float glowSizePrimary = textureSize * glowSize * 0.5f;
        float glowSizeSecondary = textureSize * glowSize * 0.2f;

        class_1921 layerBloom = ClientPipelines.WORLD_PARTICLES_GLOW.apply(GLOW_BLOOM);
        class_1921 layerSample = ClientPipelines.WORLD_PARTICLES_GLOW.apply(GLOW_BLOOM_SAMPLE);
        ParticleRenderer.drawGlow(immediate.method_73477(layerBloom), gMat, color, (int) (80.0F * alpha), glowSizePrimary);
        ParticleRenderer.drawGlow(immediate.method_73477(layerSample), gMat, color, (int) (140.0F * alpha), glowSizeSecondary);

        matrices.method_22909();
    }
}