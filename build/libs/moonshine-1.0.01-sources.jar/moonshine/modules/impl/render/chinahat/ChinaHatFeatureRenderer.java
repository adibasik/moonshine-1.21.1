package moonshine.modules.impl.render.chinahat;

import org.joml.Matrix4f;
import moonshine.modules.impl.render.ChinaHat;
import moonshine.util.ColorUtil;
import moonshine.util.render.сliemtpipeline.ClientPipelines;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_591;
import net.minecraft.class_7833;

public class ChinaHatFeatureRenderer extends class_3887<class_10055, class_591> {

    private static final float PI2 = (float) (Math.PI * 2);
    private static final int CIRCLE_SEGMENTS = 720;
    private static final int OUTLINE_SEGMENTS = 360;

    public ChinaHatFeatureRenderer(class_3883<class_10055, class_591> context) {
        super(context);
    }

    @Override
    public void render(class_4587 matrixStack, class_11659 queue, int light, class_10055 state, float limbAngle, float limbDistance) {
        class_310 mc = class_310.method_1551();

        ChinaHat chinaHat = ChinaHat.getInstance();
        if (chinaHat == null || !chinaHat.isState()) return;

        if (mc.field_1724 == null) return;

        if (mc.field_1690.method_31044().method_31034()) {
            return;
        }

        if (!isLocalPlayer(state, mc)) {
            return;
        }

        matrixStack.method_22903();

        this.method_17165().field_3398.method_22703(matrixStack);

        matrixStack.method_22907(class_7833.field_40718.rotationDegrees(180f));
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(90f));
        matrixStack.method_46416(0, 0.42f, 0);
        class_4597.class_4598 immediate = mc.method_22940().method_23000();
        renderFlatHat(matrixStack, immediate, chinaHat);
        renderOutline(matrixStack, immediate, chinaHat);
        immediate.method_22993();

        matrixStack.method_22909();
    }

    private boolean isLocalPlayer(class_10055 state, class_310 mc) {
        try {
            if (state.field_53528 == mc.field_1724.method_5628()) {
                return true;
            }
        } catch (Exception ignored) {}

        try {
            if (state.field_53525 != null && mc.field_1724.method_5477() != null) {
                return state.field_53525.getString().equals(mc.field_1724.method_5477().getString());
            }
        } catch (Exception ignored) {}

        return false;
    }

    private void renderFlatHat(class_4587 stack, class_4597 provider, ChinaHat chinaHat) {
        class_4588 consumer = provider.method_73477(ClientPipelines.CHINA_HAT);

        Matrix4f matrix = stack.method_23760().method_23761();

        float width = 0.55f;
        float coneHeight = 0.31f;
        int alpha = 185;
        float animSpeed = 5;

        int centerColor = getGradientColor(0, CIRCLE_SEGMENTS, chinaHat, animSpeed);
        centerColor = ColorUtil.replAlpha(centerColor, alpha);

        consumer.method_22918(matrix, 0, coneHeight, 0).method_39415(centerColor);

        for (int i = 0; i <= CIRCLE_SEGMENTS; i++) {
            int color = getGradientColor(i, CIRCLE_SEGMENTS, chinaHat, animSpeed);
            color = ColorUtil.replAlpha(color, alpha);

            float angle = i * PI2 / CIRCLE_SEGMENTS;
            float x = -class_3532.method_15374(angle) * width;
            float z = class_3532.method_15362(angle) * width;

            consumer.method_22918(matrix, x, 0, z).method_39415(color);
        }

        for (int i = CIRCLE_SEGMENTS; i >= 0; i--) {
            int color = getGradientColor(i, CIRCLE_SEGMENTS, chinaHat, animSpeed);
            color = ColorUtil.replAlpha(color, alpha);

            float angle = i * PI2 / CIRCLE_SEGMENTS;
            float x = -class_3532.method_15374(angle) * width;
            float z = class_3532.method_15362(angle) * width;

            consumer.method_22918(matrix, x, 0, z).method_39415(color);
        }

        consumer.method_22918(matrix, 0, coneHeight, 0).method_39415(centerColor);
    }

    private void renderOutline(class_4587 stack, class_4597 provider, ChinaHat chinaHat) {
        class_4588 consumer = provider.method_73477(ClientPipelines.CHINA_HAT_OUTLINE);

        Matrix4f matrix = stack.method_23760().method_23761();

        float width = 0.55f;
        float animSpeed = 5;
        int outlineAlpha = 255;

        for (int i = 0; i <= OUTLINE_SEGMENTS; i++) {
            int color = getGradientColor(i * 2, OUTLINE_SEGMENTS * 2, chinaHat, animSpeed);
            color = ColorUtil.replAlpha(color, outlineAlpha);

            float angle = i * PI2 / OUTLINE_SEGMENTS;
            float x = -class_3532.method_15374(angle) * width;
            float z = class_3532.method_15362(angle) * width;

            consumer.method_22918(matrix, x, 0, z).method_39415(color);
        }
    }

    private int getGradientColor(int index, int size, ChinaHat chinaHat, float animSpeed) {
        long time = System.currentTimeMillis();
        float timeOffset = (time / (1000f / animSpeed)) % size;

        int adjustedIndex = (int) ((index + timeOffset) % size);

        int color1 = chinaHat.color1.getColor();
        int color2 = chinaHat.color2.getColor();

        float progress = (float) adjustedIndex / size;

        if (progress < 0.5f) {
            return ColorUtil.interpolateColor(color1, color2, progress * 2f);
        } else {
            return ColorUtil.interpolateColor(color2, color1, (progress - 0.5f) * 2f);
        }
    }
}