package moonshine.modules.impl.render.particles;

import lombok.Getter;
import net.minecraft.class_1297;

@Getter
public class TotemEmitter {

    private final class_1297 entity;
    private final int maxAge;
    private int age;

    public TotemEmitter(class_1297 entity, int maxAge) {
        this.entity = entity;
        this.maxAge = maxAge;
        this.age = 0;
    }

    public void tick() {
        age++;
    }

    public boolean isAlive() {
        return age < maxAge && entity != null && !entity.method_31481();
    }

    public float getProgress() {
        return (float) age / maxAge;
    }
}