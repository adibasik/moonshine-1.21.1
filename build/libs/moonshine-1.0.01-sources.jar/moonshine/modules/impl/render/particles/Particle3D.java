package moonshine.modules.impl.render.particles;

import org.joml.Matrix4f;
import moonshine.IMinecraft;
import moonshine.modules.impl.render.worldparticles.ParticleRenderer;
import moonshine.util.ColorUtil;
import moonshine.util.animations.Animation;
import moonshine.util.animations.Direction;
import moonshine.util.animations.EaseInOutQuad;
import moonshine.util.render.сliemtpipeline.ClientPipelines;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import java.util.concurrent.ThreadLocalRandom;

public class Particle3D implements IMinecraft {

    public enum ParticleMode {
        CUBES,
        CROWN,
        CUBE_BLAST,
        DOLLAR,
        HEART,
        LIGHTNING,
        LINE,
        RHOMBUS,
        SNOWFLAKE,
        STAR,
        STAR_ALT,
        TRIANGLE,
        RANDOM
    }

    public enum GlowMode {
        BLOOM,
        BLOOM_SAMPLE,
        BOTH
    }

    private static final ParticleMode[] RANDOM_MODES = {
            ParticleMode.CUBES,
            ParticleMode.CROWN,
            ParticleMode.CUBE_BLAST,
            ParticleMode.DOLLAR,
            ParticleMode.HEART,
            ParticleMode.LIGHTNING,
            ParticleMode.LINE,
            ParticleMode.RHOMBUS,
            ParticleMode.SNOWFLAKE,
            ParticleMode.STAR,
            ParticleMode.STAR_ALT,
            ParticleMode.TRIANGLE
    };

    private static final class_2960 TEXTURE_CROWN = class_2960.method_60655("moonshine", "textures/world/crown.png");
    private static final class_2960 TEXTURE_CUBE_BLAST = class_2960.method_60655("moonshine", "textures/world/cubeblast1.png");
    private static final class_2960 TEXTURE_DOLLAR = class_2960.method_60655("moonshine", "textures/world/dollar.png");
    private static final class_2960 TEXTURE_HEART = class_2960.method_60655("moonshine", "textures/world/heart.png");
    private static final class_2960 TEXTURE_LIGHTNING = class_2960.method_60655("moonshine", "textures/world/lightning.png");
    private static final class_2960 TEXTURE_LINE = class_2960.method_60655("moonshine", "textures/world/line.png");
    private static final class_2960 TEXTURE_RHOMBUS = class_2960.method_60655("moonshine", "textures/world/rhombus.png");
    private static final class_2960 TEXTURE_SNOWFLAKE = class_2960.method_60655("moonshine", "textures/world/snowflake.png");
    private static final class_2960 TEXTURE_STAR = class_2960.method_60655("moonshine", "textures/world/star.png");
    private static final class_2960 TEXTURE_STAR_ALT = class_2960.method_60655("moonshine", "textures/world/star1.png");
    private static final class_2960 TEXTURE_TRIANGLE = class_2960.method_60655("moonshine", "textures/world/triangle.png");

    private static final class_2960 GLOW_BLOOM = class_2960.method_60655("moonshine", "textures/world/dashbloom.png");
    private static final class_2960 GLOW_BLOOM_SAMPLE = class_2960.method_60655("moonshine", "textures/world/dashbloomsample.png");

    private double x, y, z;
    private double lastX, lastY, lastZ;
    private double velocityX, velocityY, velocityZ;
    private long start;
    private float phase;
    private int color;
    private float scale;
    private long lifeTimeMs;
    private float rotation;

    private Animation fadeInAnimation;
    private Animation fadeOutAnimation;
    private float cachedAlpha = 0.0F;
    private long lastAlphaUpdate = 0L;
    private boolean fadingOut = false;

    private float gravityStrength = 0.04f;
    private float velocityMultiplier = 0.98f;
    private boolean collidesWithWorld = true;

    private ParticleMode mode = ParticleMode.CUBES;
    private ParticleMode actualMode = ParticleMode.CUBES;
    private GlowMode glowMode = GlowMode.BOTH;
    private boolean spinning = true;

    public Particle3D(class_243 pos, class_243 velocity, int color, float scale, float maxAgeSeconds) {
        this.start = System.currentTimeMillis();
        this.phase = (float) (Math.random() * 100.0);
        this.rotation = (float) (Math.random() * 360.0);
        this.x = pos.field_1352;
        this.y = pos.field_1351;
        this.z = pos.field_1350;
        this.lastX = pos.field_1352;
        this.lastY = pos.field_1351;
        this.lastZ = pos.field_1350;
        this.velocityX = velocity.field_1352;
        this.velocityY = velocity.field_1351;
        this.velocityZ = velocity.field_1350;
        this.color = color;
        this.scale = scale;
        this.lifeTimeMs = (long) (maxAgeSeconds * 1000);

        this.fadeInAnimation = new EaseInOutQuad().setMs(150).setValue(1.0);
        this.fadeInAnimation.setDirection(Direction.FORWARDS);
        this.fadeOutAnimation = new EaseInOutQuad().setMs(250).setValue(1.0);
        this.fadeOutAnimation.setDirection(Direction.FORWARDS);
    }

    public Particle3D setGravity(float gravity) {
        this.gravityStrength = gravity;
        return this;
    }

    public Particle3D setVelocityMultiplier(float mult) {
        this.velocityMultiplier = mult;
        return this;
    }

    public Particle3D setCollision(boolean collision) {
        this.collidesWithWorld = collision;
        return this;
    }

    public Particle3D setMode(ParticleMode mode) {
        this.mode = mode;
        if (mode == ParticleMode.RANDOM) {
            this.actualMode = RANDOM_MODES[ThreadLocalRandom.current().nextInt(RANDOM_MODES.length)];
        } else {
            this.actualMode = mode;
        }
        return this;
    }

    public Particle3D setGlowMode(GlowMode glowMode) {
        this.glowMode = glowMode;
        return this;
    }

    public Particle3D setSpinning(boolean spinning) {
        this.spinning = spinning;
        return this;
    }

    public void update() {
        long now = System.currentTimeMillis();

        this.lastX = this.x;
        this.lastY = this.y;
        this.lastZ = this.z;

        this.velocityY -= gravityStrength;

        if (collidesWithWorld && mc.field_1687 != null) {
            if (this.isHit(this.x + this.velocityX, this.y, this.z)) {
                this.velocityX *= -0.8;
            } else {
                this.x += this.velocityX;
            }
            if (this.isHit(this.x, this.y + this.velocityY, this.z)) {
                this.velocityX *= 0.999;
                this.velocityZ *= 0.999;
                this.velocityY *= -0.7;
            } else {
                this.y += this.velocityY;
            }
            if (this.isHit(this.x, this.y, this.z + this.velocityZ)) {
                this.velocityZ *= -0.8;
            } else {
                this.z += this.velocityZ;
            }
        } else {
            this.x += this.velocityX;
            this.y += this.velocityY;
            this.z += this.velocityZ;
        }

        this.velocityX /= 0.999999;
        this.velocityZ /= 0.999999;

        if (spinning) {
            this.rotation += 2.0f;
        }

        if (!fadingOut && now - this.start > lifeTimeMs) {
            fadingOut = true;
            this.fadeOutAnimation.setDirection(Direction.BACKWARDS);
        }

        if (now - this.lastAlphaUpdate > 16L) {
            if (fadingOut) {
                this.cachedAlpha = this.fadeOutAnimation.getOutput().floatValue();
            } else {
                this.cachedAlpha = this.fadeInAnimation.getOutput().floatValue();
            }
            this.lastAlphaUpdate = now;
        }
    }

    private boolean isHit(double px, double py, double pz) {
        if (mc.field_1687 == null) return false;
        class_2338 pos = class_2338.method_49637(px, py, pz);
        return mc.field_1687.method_8320(pos).method_26234(mc.field_1687, pos);
    }

    public boolean isDead() {
        return fadingOut && this.cachedAlpha <= 0.0F;
    }

    public float getAlpha() {
        return this.cachedAlpha;
    }

    private class_2960 getTexture() {
        return switch (actualMode) {
            case CROWN -> TEXTURE_CROWN;
            case CUBE_BLAST -> TEXTURE_CUBE_BLAST;
            case DOLLAR -> TEXTURE_DOLLAR;
            case HEART -> TEXTURE_HEART;
            case LIGHTNING -> TEXTURE_LIGHTNING;
            case LINE -> TEXTURE_LINE;
            case RHOMBUS -> TEXTURE_RHOMBUS;
            case SNOWFLAKE -> TEXTURE_SNOWFLAKE;
            case STAR -> TEXTURE_STAR;
            case STAR_ALT -> TEXTURE_STAR_ALT;
            case TRIANGLE -> TEXTURE_TRIANGLE;
            default -> null;
        };
    }

    public void render(class_4587 matrices, class_4597 immediate, float glowSize, float partialTicks) {
        float alpha = this.getAlpha();
        if (alpha <= 0.0F) return;

        class_243 cameraPos = mc.field_1773.method_19418().method_71156();
        float cameraYaw = mc.field_1773.method_19418().method_19330();
        float cameraPitch = mc.field_1773.method_19418().method_19329();

        double interpX = class_3532.method_16436(partialTicks, this.lastX, this.x);
        double interpY = class_3532.method_16436(partialTicks, this.lastY, this.y);
        double interpZ = class_3532.method_16436(partialTicks, this.lastZ, this.z);

        float relX = (float) (interpX - cameraPos.field_1352);
        float relY = (float) (interpY - cameraPos.field_1351);
        float relZ = (float) (interpZ - cameraPos.field_1350);

        if (actualMode == ParticleMode.CUBES) {
            renderCube(matrices, immediate, relX, relY, relZ, alpha, glowSize, cameraYaw, cameraPitch);
        } else {
            renderTextured(matrices, immediate, relX, relY, relZ, alpha, glowSize, cameraYaw, cameraPitch);
        }
    }

    private void renderCube(class_4587 matrices, class_4597 immediate,
                            float relX, float relY, float relZ, float alpha, float glowSize,
                            float cameraYaw, float cameraPitch) {
        long now = System.currentTimeMillis();
        float rotationAnim = (float) (now % 9000L) / 9000.0F * 360.0F;

        float alpha02 = alpha * 0.2F;
        float alpha04 = alpha * 0.4F;
        int glowCol = ColorUtil.multAlpha(color, alpha);
        float size = scale * 0.25f;
        float cubeGlow1 = size * glowSize;
        float cubeGlow2 = size * (glowSize / 3.0f);

        float rotY = rotationAnim + this.phase;
        float rotX = rotationAnim * 0.5F;

        matrices.method_22903();
        matrices.method_46416(relX, relY, relZ);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(rotY));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(rotX));
        Matrix4f mat = matrices.method_23760().method_23761();
        ParticleRenderer.drawCube(immediate.method_73477(ParticleRenderer.getQuadsLayer()), mat, ColorUtil.multAlpha(color, alpha02), size);
        ParticleRenderer.drawLines(immediate.method_73477(ParticleRenderer.getLinesLayer()), mat, ColorUtil.multAlpha(color, alpha04), size);
        matrices.method_22909();

        matrices.method_22903();
        matrices.method_46416(relX, relY, relZ);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-cameraYaw));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(cameraPitch));
        Matrix4f gMat = matrices.method_23760().method_23761();

        renderGlowEffect(immediate, gMat, glowCol, alpha, cubeGlow1, cubeGlow2);

        matrices.method_22909();
    }

    private void renderTextured(class_4587 matrices, class_4597 immediate,
                                float relX, float relY, float relZ, float alpha, float glowSize,
                                float cameraYaw, float cameraPitch) {
        class_2960 texture = getTexture();
        if (texture == null) return;

        int glowCol = ColorUtil.multAlpha(color, alpha);
        float size = scale * 0.5f;

        int r = (glowCol >> 16) & 0xFF;
        int g = (glowCol >> 8) & 0xFF;
        int b = glowCol & 0xFF;
        int a = (int) (255 * alpha);

        matrices.method_22903();
        matrices.method_46416(relX, relY, relZ);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-cameraYaw));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(cameraPitch));

        if (spinning) {
            matrices.method_22907(class_7833.field_40718.rotationDegrees(rotation));
        }

        Matrix4f mat = matrices.method_23760().method_23761();

        class_1921 layer = ClientPipelines.WORLD_PARTICLES_GLOW.apply(texture);
        class_4588 buffer = immediate.method_73477(layer);

        float half = size / 2.0f;
        buffer.method_22918(mat, -half, -half, 0).method_22913(0, 0).method_1336(r, g, b, a);
        buffer.method_22918(mat, -half, half, 0).method_22913(0, 1).method_1336(r, g, b, a);
        buffer.method_22918(mat, half, half, 0).method_22913(1, 1).method_1336(r, g, b, a);
        buffer.method_22918(mat, half, -half, 0).method_22913(1, 0).method_1336(r, g, b, a);

        matrices.method_22909();

        matrices.method_22903();
        matrices.method_46416(relX, relY, relZ);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-cameraYaw));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(cameraPitch));
        Matrix4f gMat = matrices.method_23760().method_23761();

        float glowSizePrimary = size * glowSize * 0.5f;
        float glowSizeSecondary = size * glowSize * 0.2f;
        renderGlowEffect(immediate, gMat, glowCol, alpha, glowSizePrimary, glowSizeSecondary);

        matrices.method_22909();
    }

    private void renderGlowEffect(class_4597 immediate, Matrix4f matrix, int color, float alpha, float sizePrimary, float sizeSecondary) {
        switch (glowMode) {
            case BLOOM -> {
                class_1921 layerBloom = ClientPipelines.WORLD_PARTICLES_GLOW.apply(GLOW_BLOOM);
                ParticleRenderer.drawGlow(immediate.method_73477(layerBloom), matrix, color, (int) (80.0F * alpha), sizePrimary);
            }
            case BLOOM_SAMPLE -> {
                class_1921 layerSample = ClientPipelines.WORLD_PARTICLES_GLOW.apply(GLOW_BLOOM_SAMPLE);
                ParticleRenderer.drawGlow(immediate.method_73477(layerSample), matrix, color, (int) (140.0F * alpha), sizeSecondary);
            }
            case BOTH -> {
                class_1921 layerBloom = ClientPipelines.WORLD_PARTICLES_GLOW.apply(GLOW_BLOOM);
                class_1921 layerSample = ClientPipelines.WORLD_PARTICLES_GLOW.apply(GLOW_BLOOM_SAMPLE);
                ParticleRenderer.drawGlow(immediate.method_73477(layerBloom), matrix, color, (int) (80.0F * alpha), sizePrimary);
                ParticleRenderer.drawGlow(immediate.method_73477(layerSample), matrix, color, (int) (140.0F * alpha), sizeSecondary);
            }
        }
    }
}