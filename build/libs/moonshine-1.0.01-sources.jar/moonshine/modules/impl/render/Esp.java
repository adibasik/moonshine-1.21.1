package moonshine.modules.impl.render;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import org.joml.Vector4d;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.DrawEvent;
import moonshine.events.impl.TickEvent;
import moonshine.events.impl.WorldLoadEvent;
import moonshine.events.impl.WorldRenderEvent;
import moonshine.modules.impl.combat.AntiBot;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.ColorSetting;
import moonshine.modules.module.setting.implement.MultiSelectSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.ColorUtil;
import moonshine.util.Instance;
import moonshine.util.math.Projection;
import moonshine.util.modules.esp.RwPrefix;
import moonshine.util.network.Network;
import moonshine.util.render.Render2D;
import moonshine.util.render.font.Fonts;
import moonshine.util.render.item.ItemRender;
import moonshine.util.render.Render3D;
import moonshine.util.repository.friend.FriendUtils;
import moonshine.util.string.PlayerInteractionHelper;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class Esp extends ModuleStructure {

    public static Esp getInstance() {
        return Instance.get(Esp.class);
    }

    class_2960 TEXTURE = class_2960.method_60655("moonshine", "textures/features/esp/container.png");

    List<class_1657> players = new ArrayList<>();

    public MultiSelectSetting entityType = new MultiSelectSetting("Тип сущности", "Сущности, которые будут отображаться")
            .value("Player", "Item").selected("Player", "Item");

    MultiSelectSetting playerSetting = new MultiSelectSetting("Настройки игрока", "Настройки для игроков")
            .value("Box", "Armor", "NameTags", "Hand Items").selected("Box", "Armor", "NameTags", "Hand Items")
            .visible(() -> entityType.isSelected("Player"));

    public SelectSetting boxType = new SelectSetting("Тип", "Тип")
            .value("Corner", "3D Box").selected("Corner")
            .visible(() -> playerSetting.isSelected("Box"));

    public ColorSetting boxColor = new ColorSetting("Цвет бокса", "Цвет для отображения бокса")
            .value(0xFFFFAA00)
            .visible(() -> playerSetting.isSelected("Box"));

    public ColorSetting friendColor = new ColorSetting("Цвет друга", "Цвет для отображения друзей")
            .value(0xFF00FF00)
            .visible(() -> playerSetting.isSelected("Box"));

    public BooleanSetting flatBoxOutline = new BooleanSetting("Контур", "Контур для плоских боксов")
            .visible(() -> playerSetting.isSelected("Box") && boxType.isSelected("Corner"));

    public SliderSettings boxAlpha = new SliderSettings("Прозрачность", "Прозрачность бокса")
            .setValue(1.0F).range(0.1F, 1.0F).visible(() -> boxType.isSelected("3D Box"));

    private static final float DISTANCE = 128.0f;
    private static final int GRAY_COLOR = 0xFF888888;
    private static final int WHITE_COLOR = 0xFFFFFFFF;

    public Esp() {
        super("Esp", "Esp", ModuleCategory.RENDER);
        settings(entityType, playerSetting, boxType, boxColor, friendColor, flatBoxOutline, boxAlpha);
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent e) {
        players.clear();
    }

    @EventHandler
    public void onTick(TickEvent e) {
        players.clear();
        if (mc.field_1687 != null) {
            mc.field_1687.method_18456().stream()
                    .filter(player -> player != mc.field_1724)
                    .filter(player -> player.method_5797() == null || !player.method_5797().getString().startsWith("Ghost_"))
                    .forEach(players::add);
        }
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        if (!entityType.isSelected("Player")) return;
        float tickDelta = e.getPartialTicks();

        for (class_1657 player : players) {
            if (player == null || player == mc.field_1724) continue;
            if (player.method_5797() != null && player.method_5797().getString().startsWith("Ghost_")) continue;

            double interpX = class_3532.method_16436(tickDelta, player.field_6014, player.method_23317());
            double interpY = class_3532.method_16436(tickDelta, player.field_6036, player.method_23318());
            double interpZ = class_3532.method_16436(tickDelta, player.field_5969, player.method_23321());
            class_243 interpCenter = new class_243(interpX, interpY, interpZ);

            float distance = (float) mc.field_1773.method_19418().method_71156().method_1022(interpCenter);
            if (distance < 1) continue;

            boolean friend = FriendUtils.isFriend(player);
            int baseColor = friend ? getFriendColor() : getClientColor();
            int alpha = (int) (boxAlpha.getValue() * 255);
            int fillColor = (baseColor & 0x00FFFFFF) | (alpha << 24);
            int outlineColor = baseColor | 0xFF000000;

            if (boxType.isSelected("3D Box") && playerSetting.isSelected("Box")) {
                class_238 interpBox = player.method_18377(player.method_18376()).method_30231(interpX, interpY, interpZ);
                Render3D.drawBox(interpBox, fillColor, 2, true, true, false);
                Render3D.drawBox(interpBox, outlineColor, 2, true, false, false);
            }
        }
    }

    @EventHandler
    public void onDraw(DrawEvent e) {
        class_332 context = e.getDrawContext();
        float tickDelta = e.getPartialTicks();
        float size = 5.5f;

        if (entityType.isSelected("Player")) {
            for (class_1657 player : players) {
                if (player == null || player == mc.field_1724) continue;
                if (player.method_5797() != null && player.method_5797().getString().startsWith("Ghost_")) continue;

                Vector4d vec4d = Projection.getVector4D(player, tickDelta);
                float distance = (float) mc.field_1773.method_19418().method_71156().method_1022(player.method_5829().method_1005());
                boolean friend = FriendUtils.isFriend(player);

                if (distance < 1) continue;
                if (Projection.cantSee(vec4d)) continue;

                if (playerSetting.isSelected("Box") && !boxType.isSelected("3D Box")) {
                    drawBox(friend, vec4d, player);
                }
                if (playerSetting.isSelected("Armor")) {
                    drawArmor(context, player, vec4d);
                }
                if (playerSetting.isSelected("Hand Items")) {
                    drawHands(context, player, vec4d, size);
                }

                drawPlayerName(context, player, friend, Projection.centerX(vec4d), vec4d.y - 2, size);
            }
        }

        List<class_1297> entities = PlayerInteractionHelper.streamEntities()
                .sorted(Comparator.comparing(ent -> ent instanceof class_1542 item && item.method_6983().method_7964().method_10851().toString().equals("empty")))
                .toList();

        for (class_1297 entity : entities) {
            if (entity instanceof class_1542 item && entityType.isSelected("Item")) {
                Vector4d vec4d = Projection.getVector4D(entity, tickDelta);
                class_1799 stack = item.method_6983();
                class_9288 compoundTag = stack.method_58694(class_9334.field_49622);
                List<class_1799> list = compoundTag != null ? compoundTag.method_57489().toList() : List.of();

                if (Projection.cantSee(vec4d)) continue;

                String text = item.method_6983().method_7964().getString();

                if (!list.isEmpty()) {
                    drawShulkerBox(context, stack, list, vec4d);
                } else {
                    drawText(context, text, Projection.centerX(vec4d), vec4d.y, size);
                }
            }
        }
    }

    private void drawPlayerName(class_332 context, class_1657 player, boolean friend, double centerX, double startY, float size) {
        StringBuilder extraInfo = new StringBuilder();
        if (friend) extraInfo.append("[Friend] ");
        if (AntiBot.getInstance() != null && AntiBot.getInstance().isState() && AntiBot.getInstance().isBot(player)) {
            extraInfo.append("[BOT] ");
        }

        String displayName;
        if (playerSetting.isSelected("NameTags")) {
            displayName = player.method_5476().getString();
        } else {
            displayName = player.method_5477().getString();
        }

        RwPrefix.ParsedName parsed = RwPrefix.parseDisplayName(displayName);

        String sphere = "";
        class_1799 offHand = player.method_5998(class_1268.field_5810);
        if (offHand.method_7909().equals(class_1802.field_8575) || offHand.method_7909().equals(class_1802.field_8288)) {
            sphere = getSphere(offHand);
        }

        String prefixPart = "";
        if (!parsed.prefix.isEmpty()) {
            prefixPart = parsed.prefix + " ";
        }
        String namePart = parsed.name;
        String clanPart = !parsed.clan.isEmpty() ? " " + parsed.clan : "";
        String spherePart = sphere;
        String extraPart = extraInfo.toString();

        float extraWidth = extraPart.isEmpty() ? 0 : Fonts.TEST.getWidth(extraPart, size);
        float prefixWidth = prefixPart.isEmpty() ? 0 : Fonts.TEST.getWidth(prefixPart, size);
        float nameWidth = Fonts.TEST.getWidth(namePart, size);
        float clanWidth = clanPart.isEmpty() ? 0 : Fonts.TEST.getWidth(clanPart, size);
        float sphereWidth = spherePart.isEmpty() ? 0 : Fonts.TEST.getWidth(spherePart, size);

        float totalWidth = extraWidth + prefixWidth + nameWidth + clanWidth + sphereWidth;
        float height = Fonts.TEST.getHeight(size);

        float posX = (float) centerX - totalWidth / 2;
        float posY = (float) startY - height;

        Render2D.rect(posX - 4, posY - 1.25f, totalWidth + 8, height + 2, 0x80000000, 2f);

        float drawX = posX;

        if (!extraPart.isEmpty()) {
            Fonts.TEST.draw(extraPart, drawX, posY, size, friend ? getFriendColor() : 0xFFFF5555);
            drawX += extraWidth;
        }

        if (!prefixPart.isEmpty()) {
            Fonts.TEST.draw(prefixPart, drawX, posY, size, GRAY_COLOR);
            drawX += prefixWidth;
        }

        Fonts.TEST.draw(namePart, drawX, posY, size, WHITE_COLOR);
        drawX += nameWidth;

        if (!clanPart.isEmpty()) {
            Fonts.TEST.draw(clanPart, drawX, posY, size, GRAY_COLOR);
            drawX += clanWidth;
        }

        if (!spherePart.isEmpty()) {
            Fonts.TEST.draw(spherePart, drawX, posY, size, GRAY_COLOR);
        }
    }

    private void drawBox(boolean friend, Vector4d vec, class_1657 player) {
        int client = friend ? getFriendColor() : getClientColor();
        int black = 0x80000000;

        float posX = (float) vec.x;
        float posY = (float) vec.y;
        float endPosX = (float) vec.z;
        float endPosY = (float) vec.w;
        float size = (endPosX - posX) / 3;

        if (boxType.isSelected("Corner")) {
            Render2D.rect(posX - 0.5F, posY - 0.5F, size, 0.5F, client);
            Render2D.rect(posX - 0.5F, posY, 0.5F, size + 0.5F, client);
            Render2D.rect(posX - 0.5F, endPosY - size - 0.5F, 0.5F, size, client);
            Render2D.rect(posX - 0.5F, endPosY - 0.5F, size, 0.5F, client);
            Render2D.rect(endPosX - size + 1, posY - 0.5F, size, 0.5F, client);
            Render2D.rect(endPosX + 0.5F, posY, 0.5F, size + 0.5F, client);
            Render2D.rect(endPosX + 0.5F, endPosY - size - 0.5F, 0.5F, size, client);
            Render2D.rect(endPosX - size + 1, endPosY - 0.5F, size, 0.5F, client);

            if (flatBoxOutline.isValue()) {
                Render2D.rect(posX - 1F, posY - 1, size + 1, 1.5F, black);
                Render2D.rect(posX - 1F, posY + 0.5F, 1.5F, size + 0.5F, black);
                Render2D.rect(posX - 1F, endPosY - size - 1, 1.5F, size, black);
                Render2D.rect(posX - 1F, endPosY - 1, size + 1, 1.5F, black);
                Render2D.rect(endPosX - size + 0.5F, posY - 1, size + 1, 1.5F, black);
                Render2D.rect(endPosX, posY + 0.5F, 1.5F, size + 0.5F, black);
                Render2D.rect(endPosX, endPosY - size - 1, 1.5F, size, black);
                Render2D.rect(endPosX - size + 0.5F, endPosY - 1, size + 1, 1.5F, black);
            }
        }
    }

    private void drawArmor(class_332 context, class_1657 player, Vector4d vec) {
        List<class_1799> items = new ArrayList<>();
        for (class_1304 slot : class_1304.field_54086) {
            class_1799 stack = player.method_6118(slot);
            if (!stack.method_7960()) {
                items.add(stack);
            }
        }

        float posX = (float) (Projection.centerX(vec) - items.size() * 4.5f);
        float posY = (float) (vec.y - 20);
        float offset = 0;

        for (class_1799 stack : items) {
            ItemRender.drawItemWithContext(context, stack, posX + offset, posY, 0.5F, 1.0F);
            offset += 11;
        }
    }

    private void drawHands(class_332 context, class_1657 player, Vector4d vec, float size) {
        double posY = vec.w;

        class_1799 mainHand = player.method_5998(class_1268.field_5808);
        class_1799 offHand = player.method_5998(class_1268.field_5810);

        for (class_1799 stack : new class_1799[]{mainHand, offHand}) {
            if (stack.method_7960()) continue;
            String text = stack.method_7964().getString();
            posY += Fonts.TEST.getHeight(size) / 2.0 + 6;
            drawText(context, text, Projection.centerX(vec), posY, size);
        }
    }

    private void drawShulkerBox(class_332 context, class_1799 itemStack, List<class_1799> stacks, Vector4d vec) {
        int width = 176;
        int height = 67;
        int color = ((class_1747) itemStack.method_7909()).method_7711().method_26403().field_16011 | 0xFF000000;

        float scale = 0.5F;
        float scaledWidth = width * scale;
        float scaledHeight = height * scale;

        float drawX = (float) Projection.centerX(vec) - scaledWidth / 2;
        float drawY = (float) vec.y - scaledHeight - 2;

        Render2D.texture(TEXTURE, drawX, drawY, scaledWidth, scaledHeight, color);
        Render2D.blur(drawX, drawY, 1, 1, 0f, 0, ColorUtil.rgba(0, 0, 0, 0));

        float itemScale = scale;
        float itemStartX = drawX + 7 * scale;
        float itemStartY = drawY + 6 * scale;
        float itemSize = 18 * scale;

        int col = 0;
        int row = 0;
        for (class_1799 stack : stacks) {
            float itemX = itemStartX + col * itemSize;
            float itemY = itemStartY + row * itemSize;
            ItemRender.drawItemWithContext(context, stack, itemX, itemY, itemScale, 1F);
            col++;
            if (col >= 9) {
                row++;
                col = 0;
            }
        }
    }

    private void drawText(class_332 context, String text, double startX, double startY, float size) {
        String cleanText = RwPrefix.stripFormatting(text);
        float width = Fonts.TEST.getWidth(cleanText, size);
        float height = Fonts.TEST.getHeight(size);
        float posX = (float) (startX - width / 2);
        float posY = (float) startY - height;

        Render2D.rect(posX - 4, posY - 1, width + 8, height + 2, 0x80000000, 2f);
        Fonts.TEST.draw(cleanText, posX, posY, size, 0xFFFFFFFF);
    }

    private String getSphere(class_1799 stack) {
        var component = stack.method_58694(class_9334.field_49628);
        if (Network.isFunTime() && component != null) {
            class_2487 compound = component.method_57461();
            int tslevel = compound.method_10550("tslevel").orElse(0);
            if (tslevel != 0) {
                String donItem = compound.method_10558("don-item").orElse("");
                return " [" + donItem.replace("sphere-", "").toUpperCase() + "]";
            }
        }
        return "";
    }

    private float getHealth(class_1657 player) {
        return player.method_6032() + player.method_6067();
    }

    private String getHealthString(float hp) {
        return String.format("%.1f", hp).replace(",", ".").replace(".0", "");
    }

    private int getFriendColor() {
        return friendColor.getColorNoAlpha();
    }

    private int getClientColor() {
        return boxColor.getColorNoAlpha();
    }
}