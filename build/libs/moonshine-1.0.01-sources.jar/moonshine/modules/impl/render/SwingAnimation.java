package moonshine.modules.impl.render;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.experimental.NonFinal;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.HandAnimationEvent;
import moonshine.events.impl.SwingDurationEvent;
import moonshine.modules.impl.combat.Aura;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class SwingAnimation extends ModuleStructure {
    SelectSetting swingType = new SelectSetting("Тип взмаха", "Выберите тип взмаха")
            .value("Chop", "Swipe", "Down", "Smooth", "Smooth 2", "Power", "Feast", "Twist", "Default");
    SliderSettings hitStrengthSetting = new SliderSettings("Сила взмаха", "Сила анимации взмаха")
            .range(0.5F, 3.0F).setValue(1.0F);
    SliderSettings swingSpeedSetting = new SliderSettings("Длительность взмаха", "Длительность анимации удара")
            .range(0.5F, 4.0F).setValue(1.0F);

    BooleanSetting onlySwing = new BooleanSetting("Только при взмахе", "Показывает анимацию только при взмахе")
            .setValue(false);

    BooleanSetting onlyAura = new BooleanSetting("Только при включенной КиллАуре", "Показывает анимацию только при включенной киллауре")
            .setValue(false);

    public SwingAnimation() {
        super("SwingAnimation", "Swing Animation", ModuleCategory.RENDER);
        settings(swingType, hitStrengthSetting, swingSpeedSetting, onlySwing, onlyAura);
    }

    @EventHandler
    public void onSwingDuration(SwingDurationEvent e) {
        if (onlyAura.isValue() ? Aura.getInstance().isState() && Aura.getInstance().target != null : true) {
            e.setAnimation(swingSpeedSetting.getValue());
            e.cancel();
        }
    }

    @NonFinal
    private float spinAngle = 0.0F;
    @NonFinal
    private float spinBackTimer = 0.0F;
    @NonFinal
    private boolean wasSwinging = false;

    @EventHandler
    public void onHandAnimation(HandAnimationEvent e) {
        boolean isMainHand = e.getHand().equals(class_1268.field_5808);
        if (isMainHand) {
            class_4587 matrix = e.getMatrices();
            float swingProgress = e.getSwingProgress();
            int i = mc.field_1724.method_6068().equals(class_1306.field_6183) ? 1 : -1;
            float sin1 = class_3532.method_15374(swingProgress * swingProgress * (float) Math.PI);
            float sin2 = class_3532.method_15374(class_3532.method_15355(swingProgress) * (float) Math.PI);
            float sinSmooth = (float) (Math.sin(swingProgress * Math.PI) * 0.5F);
            float strength = hitStrengthSetting.getValue();

            if (onlyAura.isValue() ? Aura.getInstance().isState() && Aura.getInstance().target != null : true) {
                if (onlySwing.isValue() ? mc.field_1724.field_6279 != 0 : true) {
                    switch (swingType.getSelected()) {
                        case "Chop" -> {
                            matrix.method_46416(0.56F * i, -0.44F, -0.72F);
                            matrix.method_46416(0.0F, 0.33F * -0.6F, 0.0F);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(45.0F * i));
                            float f = class_3532.method_15374(swingProgress * swingProgress * (float) Math.PI);
                            float f2 = class_3532.method_15374(class_3532.method_15355(swingProgress) * (float) Math.PI);
                            matrix.method_22907(class_7833.field_40718.rotationDegrees(f2 * -20.0F * i * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(f2 * -80.0F * strength));
                            matrix.method_46416(0.4F, 0.2F, 0.2F);
                            matrix.method_46416(-0.5F, 0.08F, 0.0F);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(20.0F));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-80.0F));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(20.0F));
                        }
                        case "Twist" -> {
                            matrix.method_46416(i * 0.56F, -0.36F, -0.72F);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(80 * i));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -90 * strength));
                            matrix.method_22907(class_7833.field_40718.rotationDegrees((sin1 - sin2) * 60 * i * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-30));
                            matrix.method_46416(0, -0.1F, 0.05F);
                        }
                        case "Swipe" -> {
                            matrix.method_46416(0.56F * i, -0.32F, -0.72F);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(70 * i));
                            matrix.method_22907(class_7833.field_40718.rotationDegrees(-20 * i));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((sin2 * sin1) * -5 * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees((sin2 * sin1) * -120 * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-70));
                        }
                        case "Default" -> {
                            matrix.method_46416(i * 0.56F, -0.52F - (sin2 * 0.5F * strength), -0.72F);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(45 * i));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(-45 * i));
                        }
                        case "Down" -> {
                            matrix.method_46416(i * 0.56F, -0.32F, -0.72F);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(76 * i));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(sin2 * -5 * strength));
                            matrix.method_22907(class_7833.field_40713.rotationDegrees(sin2 * -100 * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -155 * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-100));
                        }
                        case "Smooth" -> {
                            matrix.method_46416(i * 0.56F, -0.42F, -0.72F);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((float) i * (45.0F + sin1 * -20.0F * strength)));
                            matrix.method_22907(class_7833.field_40718.rotationDegrees((float) i * sin2 * -20.0F * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -80.0F * strength));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((float) i * -45.0F));
                            matrix.method_22904(0, -0.1, 0);
                        }
                        case "Smooth 2" -> {
                            matrix.method_46416(i * 0.56F, -0.42F, -0.72F);
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -80.0F * strength));
                            matrix.method_22904(0, -0.1, 0);
                        }
                        case "Power" -> {
                            matrix.method_46416(i * 0.56F, -0.32F, -0.72F);
                            matrix.method_46416((-sinSmooth * sinSmooth * sin1) * i * strength, 0, 0);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(61 * i));
                            matrix.method_22907(class_7833.field_40718.rotationDegrees(sin2 * strength));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees((sin2 * sin1) * -5 * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees((sin2 * sin1) * -30 * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-60));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sinSmooth * -60 * strength));
                        }
                        case "Feast" -> {
                            matrix.method_46416(i * 0.56F, -0.32F, -0.72F);
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(30 * i));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(sin2 * 75 * i * strength));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -45 * strength));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(30 * i));
                            matrix.method_22907(class_7833.field_40714.rotationDegrees(-80));
                            matrix.method_22907(class_7833.field_40716.rotationDegrees(35 * i));
                        }
                    }
                } else {
                    matrix.method_46416(i * 0.56F, -0.52F, -0.72F);
                }
            } else {
                return;
            }
            e.cancel();
        }
    }
}