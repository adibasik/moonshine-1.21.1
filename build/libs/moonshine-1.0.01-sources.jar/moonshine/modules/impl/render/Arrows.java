package moonshine.modules.impl.render;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.DrawEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.ColorSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.Instance;
import moonshine.util.animations.Animation;
import moonshine.util.animations.Direction;
import moonshine.util.animations.EaseInOutQuad;
import moonshine.util.animations.Easings;
import moonshine.util.animations.SmoothAnimation;
import net.minecraft.class_10799;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_490;
import net.minecraft.class_5498;
import net.minecraft.class_742;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class Arrows extends ModuleStructure {

    public static Arrows getInstance() {
        return Instance.get(Arrows.class);
    }

    private static final class_2960 ARROW_TEXTURE = class_2960.method_60655("moonshine", "textures/world/arrow.png");

    public SliderSettings arrowsDistance = new SliderSettings("Дистанция", "Дистанция от прицела")
            .range(1.0f, 20.0f)
            .setValue(25.0f);

    public ColorSetting arrowColor = new ColorSetting("Цвет", "Цвет стрелок")
            .value(0xFF896148);

    private final SmoothAnimation animationStep = new SmoothAnimation();
    private final SmoothAnimation animatedYaw = new SmoothAnimation();
    private final SmoothAnimation animatedPitch = new SmoothAnimation();
    private final SmoothAnimation animatedCameraYaw = new SmoothAnimation();

    private final List<Arrow> playerList = new ArrayList<>();

    public Arrows() {
        super("Arrows", "Показывает стрелки в сторону игроков", ModuleCategory.RENDER);
        settings(arrowsDistance, arrowColor);
    }

    @Override
    public void deactivate() {
        playerList.clear();
    }

    @EventHandler
    public void onDraw(DrawEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1690.method_31044() != class_5498.field_26664) return;

        class_332 context = event.getDrawContext();
        float partialTicks = event.getPartialTicks();

        animationStep.update();
        animatedYaw.update();
        animatedPitch.update();
        animatedCameraYaw.update();

        float size = 45 + arrowsDistance.getValue();

        if (mc.field_1755 instanceof class_490) {
            size += 80;
        }

        if (mc.field_1724.method_5715()) {
            size -= 20;
        }

        if (isMoving()) {
            size += 10;
        }

        float strafeInput = mc.field_1724.field_3913.method_3128().field_1343;
        float forwardInput = mc.field_1724.field_3913.method_3128().field_1342;

        animatedYaw.run(strafeInput * 5, 0.75, Easings.EXPO_OUT);
        animatedPitch.run(forwardInput * 5, 0.75, Easings.EXPO_OUT);
        animatedCameraYaw.run(mc.field_1773.method_19418().method_19330(), 0.75, Easings.EXPO_OUT, true);
        animationStep.run(size, 1.0, Easings.EXPO_OUT, false);

        List<Arrow> players = new ArrayList<>();

        for (class_742 player : mc.field_1687.method_18456()) {
            Optional<Arrow> arrowConsumer = playerList.stream()
                    .filter(a -> a.player == player)
                    .findFirst();

            if (arrowConsumer.isPresent() && !isValidPlayer(player)) {
                continue;
            }

            Arrow arrow = new Arrow(
                    player,
                    arrowConsumer.map(a -> a.fadeAnimation).orElse(createFadeAnimation())
            );
            players.add(arrow);
        }

        List<Arrow> arrows = new ArrayList<>(playerList);
        arrows.removeIf(p -> players.stream().anyMatch(p2 -> p.player == p2.player));

        for (Arrow arrow : arrows) {
            arrow.fadeAnimation.setDirection(Direction.BACKWARDS);
            if (!arrow.isDead()) {
                players.add(arrow);
            }
        }

        playerList.clear();
        playerList.addAll(players);

        int screenWidth = mc.method_22683().method_4486();
        int screenHeight = mc.method_22683().method_4502();
        float centerX = screenWidth / 2f;
        float centerY = screenHeight / 2f;

        for (Arrow arrow : playerList) {
            class_1657 player = arrow.player;

            arrow.updateAlpha();

            float animValue = arrow.getAlpha();
            if (animValue <= 0.001f) continue;

            if (!isValidPlayer(player) && arrow.fadeAnimation.isDirection(Direction.FORWARDS)) {
                continue;
            }

            double playerX = player.field_6038 + (player.method_23317() - player.field_6038) * partialTicks
                    - mc.field_1773.method_19418().method_71156().field_1352;
            double playerZ = player.field_5989 + (player.method_23321() - player.field_5989) * partialTicks
                    - mc.field_1773.method_19418().method_71156().field_1350;

            double cameraYaw = animatedCameraYaw.getValue();
            double cos = class_3532.method_15362((float) (cameraYaw * (Math.PI * 2 / 360)));
            double sin = class_3532.method_15374((float) (cameraYaw * (Math.PI * 2 / 360)));

            double rotY = -(playerZ * cos - playerX * sin);
            double rotX = -(playerX * cos + playerZ * sin);

            float angle = (float) (Math.atan2(rotY, rotX) * 180 / Math.PI);

            double x2 = animationStep.getValue() * animValue * class_3532.method_15362((float) Math.toRadians(angle)) + centerX;
            double y2 = animationStep.getValue() * animValue * class_3532.method_15374((float) Math.toRadians(angle)) + centerY;

            x2 += animatedYaw.getValue();
            y2 += animatedPitch.getValue();

            int color = applyAlpha(arrowColor.getColor(), animValue);

            drawArrow(context, (float) x2, (float) y2, angle, color, 1);
        }
    }

    private Animation createFadeAnimation() {
        Animation anim = new EaseInOutQuad().setMs(200).setValue(1.0);
        anim.setDirection(Direction.FORWARDS);
        return anim;
    }

    private void drawArrow(class_332 context, float x, float y, float angle, int color, float scale) {
        float size = 17 * scale;
        float halfSize = size / 2.0f;

        context.method_51448().pushMatrix();
        context.method_51448().translate(x, y);
        context.method_51448().rotate((float) Math.toRadians(angle));
        context.method_51448().rotate((float) Math.toRadians(90));

        int intSize = (int) size;

        context.method_25291(
                class_10799.field_56883,
                ARROW_TEXTURE,
                (int) (1 - halfSize),
                (int) (-5.5f),
                0, 0,
                intSize, intSize,
                intSize, intSize,
                color
        );

        context.method_51448().popMatrix();
    }

    private int applyAlpha(int color, float alpha) {
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        int a = (int) (alpha * 255);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private boolean isValidPlayer(class_1657 player) {
        return player != mc.field_1724 && !player.method_31481();
    }

    private boolean isMoving() {
        return mc.field_1724.field_3913.method_3128().field_1342 != 0 || mc.field_1724.field_3913.method_3128().field_1343 != 0;
    }

    private static class Arrow {
        final class_1657 player;
        final Animation fadeAnimation;
        float cachedAlpha = 0.0f;
        long lastAlphaUpdate = 0L;

        Arrow(class_1657 player, Animation fadeAnimation) {
            this.player = player;
            this.fadeAnimation = fadeAnimation;
        }

        void updateAlpha() {
            long now = System.currentTimeMillis();
            if (now - lastAlphaUpdate > 16L) {
                cachedAlpha = fadeAnimation.getOutput().floatValue();
                lastAlphaUpdate = now;
            }
        }

        float getAlpha() {
            return cachedAlpha;
        }

        boolean isDead() {
            return fadeAnimation.isDirection(Direction.BACKWARDS) && fadeAnimation.isDone() && cachedAlpha <= 0.0f;
        }
    }
}