package moonshine.modules.impl.render;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import moonshine.IMinecraft;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.WorldRenderEvent;
import moonshine.modules.impl.combat.Aura;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.ColorSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.animations.Animation;
import moonshine.util.animations.Direction;
import moonshine.util.animations.OutBack;
import moonshine.util.render.сliemtpipeline.ClientPipelines;
import moonshine.util.render.Render3D;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class TargetESP extends ModuleStructure implements IMinecraft {

    private static TargetESP instance;

    public static TargetESP getInstance() {
        return instance;
    }

    Animation espAnim = new OutBack().setMs(300).setValue(1);
    StopWatch stopWatch = new StopWatch();

    SelectSetting mode = new SelectSetting("Режим", "Тип TargetESP")
            .value("Rhomb", "Ghost", "Chain", "Crystals", "Circle")
            .selected("Rhomb");

    SliderSettings crystalRotationSpeed = new SliderSettings("Скорость вращения кристаллов",
            "Скорость вращения кристаллов")
            .range(0.1f, 2.0f)
            .visible(() -> mode.isSelected("Crystals"));

    ColorSetting color1 = new ColorSetting("Цвет 1", "Первый цвет градиента")
            .setColor(new Color(255, 101, 57, 255).getRGB());

    ColorSetting color2 = new ColorSetting("Цвет 2", "Второй цвет градиента")
            .setColor(new Color(255, 50, 150, 255).getRGB());

    ColorSetting color3 = new ColorSetting("Цвет 3", "Третий цвет для Ghost")
            .setColor(new Color(150, 50, 255, 255).getRGB())
            .visible(() -> mode.isSelected("Ghost"));

    private class_243 smoothedPos = null;
    private class_1309 lastTarget = null;
    private float movingValue = 0;
    private float hurtProgress = 0;

    private class_1297 lastRenderedTarget = null;
    private final List<Crystal> crystalList = new ArrayList<>();
    private float rotationAngle = 0;

    private long lastFrameTime = System.currentTimeMillis();
    private static final float TARGET_FPS = 60f;
    private static final float TARGET_FRAME_TIME = 1000f / TARGET_FPS;

    public TargetESP() {
        super("TargetEsp", "Target Esp", ModuleCategory.RENDER);
        instance = this;

        crystalRotationSpeed.setValue(0.5f);

        settings(mode, crystalRotationSpeed, color1, color2, color3);
    }

    private float getDeltaTime() {
        long currentTime = System.currentTimeMillis();
        float deltaMs = currentTime - lastFrameTime;
        lastFrameTime = currentTime;
        deltaMs = Math.max(1f, Math.min(deltaMs, 100f));
        return deltaMs / TARGET_FRAME_TIME;
    }

    @EventHandler
    public void onRender3D(WorldRenderEvent e) {
        float deltaTime = getDeltaTime();

        class_1309 target = null;

        if (Aura.getInstance() != null && Aura.getInstance().isState()) {
            target = Aura.target;
        }

        if (target == null) {
            smoothedPos = null;
            lastTarget = null;
            espAnim.setDirection(Direction.BACKWARDS);
            Render3D.resetCircleSmoothing();
            return;
        }

        espAnim.setDirection(Direction.FORWARDS);
        float alpha = espAnim.getOutput().floatValue();
        if (alpha <= 0.01f)
            return;

        movingValue += 2f * deltaTime;
        if (movingValue > 360000)
            movingValue = 0;

        float hurtDecay = 0.1f * deltaTime;
        hurtProgress = target.field_6235 > 0 ? (float) target.field_6235 / 10f : Math.max(0, hurtProgress - hurtDecay);

        Render3D.updateTargetEsp(deltaTime);

        if (mode.isSelected("Circle")) {
            renderCircle(e.getStack(), target, alpha);
            return;
        }

        class_4587 stack = e.getStack();
        class_4597.class_4598 provider = mc.method_22940().method_23000();

        class_243 camPos = mc.field_1773.method_19418().method_71156();
        float partialTicks = e.getPartialTicks();
        class_243 targetPos = target.method_30950(partialTicks);

        if (lastTarget != target || smoothedPos == null) {
            smoothedPos = targetPos;
            lastTarget = target;
        } else {
            float smoothingFactor = Math.min(1.0f, partialTicks * 1.5f);
            double dx = targetPos.field_1352 - smoothedPos.field_1352;
            double dy = targetPos.field_1351 - smoothedPos.field_1351;
            double dz = targetPos.field_1350 - smoothedPos.field_1350;
            smoothedPos = new class_243(
                    smoothedPos.field_1352 + dx * smoothingFactor,
                    smoothedPos.field_1351 + dy * smoothingFactor,
                    smoothedPos.field_1350 + dz * smoothingFactor);
        }

        stack.method_22903();
        stack.method_22904(
                smoothedPos.field_1352 - camPos.field_1352,
                smoothedPos.field_1351 - camPos.field_1351,
                smoothedPos.field_1350 - camPos.field_1350);

        if (mode.isSelected("Rhomb")) {
            renderRhomb(stack, provider, target, alpha);
        } else if (mode.isSelected("Ghost")) {
            renderGhost(stack, provider, target, alpha);
        } else if (mode.isSelected("Chain")) {
            renderChain(stack, provider, target, alpha, deltaTime);
        } else if (mode.isSelected("Crystals")) {
            if (crystalList.isEmpty() || lastRenderedTarget != target) {
                createCrystals(target);
                lastRenderedTarget = target;
            }
            renderCrystals(stack, provider, target, alpha, deltaTime);
        }

        provider.method_22993();

        stack.method_22909();
    }

    private void renderCircle(class_4587 stack, class_1309 target, float alpha) {
        int baseColor1 = color1.getColor();
        int baseColor2 = color2.getColor();

        if (hurtProgress > 0) {
            baseColor1 = lerpColor(baseColor1, 0xFFFF0000, hurtProgress);
            baseColor2 = lerpColor(baseColor2, 0xFFFF0000, hurtProgress);
        }

        Render3D.drawCircle(stack, target, alpha, hurtProgress, baseColor1, baseColor2);
    }

    private void renderChain(class_4587 stack, class_4597 provider, class_1309 target, float alpha,
            float deltaTime) {
        class_4588 consumer = provider
                .method_73477(ClientPipelines.CHAIN_ESP.apply(class_2960.method_60655("moonshine", "images/world/chain.png")));

        float animValue = (System.currentTimeMillis() % 360000) / 1000f * 60f;

        float gradusX = (float) (20 * Math.min(1 + Math.sin(Math.toRadians(animValue)), 1));
        float gradusZ = (float) (20 * (Math.min(1 + Math.sin(Math.toRadians(animValue)), 2) - 1));
        float width = target.method_17681() * 3;

        int linksStep = 18;
        int totalAngle = 360 * 2;
        float chainSizeVal = 8;
        float down = 1.5f;
        float chainScale = 0.5f;

        int alphaVal = class_3532.method_15340((int) (alpha * 128), 0, 128);

        int baseColor1 = color1.getColor();
        int baseColor2 = color2.getColor();

        if (hurtProgress > 0) {
            baseColor1 = lerpColor(baseColor1, 0xFFFF0000, hurtProgress);
            baseColor2 = lerpColor(baseColor2, 0xFFFF0000, hurtProgress);
        }

        int c1 = withAlpha(baseColor1, alphaVal);
        int c2 = withAlpha(baseColor2, alphaVal);

        float rotationValue = (System.currentTimeMillis() % 720000) / 1000f * 30f;

        for (int chain = 0; chain < 2; chain++) {
            float val = 1.2f - 0.5f * (chain == 0 ? 1.0f : 0.9f);

            stack.method_22903();
            stack.method_46416(0, target.method_17682() / 2.0f, 0);
            stack.method_22905(chainScale, chainScale, chainScale);

            stack.method_22907(class_7833.field_40718.rotationDegrees(chain == 0 ? gradusX : -gradusX));
            stack.method_22907(class_7833.field_40714.rotationDegrees(chain == 0 ? gradusZ : -gradusZ));

            float x = 0, y = -0.5f, z = 0;
            Matrix4f matrix = stack.method_23760().method_23761();

            int modif = linksStep / 2;
            for (int i = 0; i < totalAngle; i += modif) {
                float offsetX = (chain == 0 ? gradusX : -gradusX) / 100F;
                float offsetZ = (chain == 0 ? -gradusZ : gradusZ) / 100F;

                float prevSin = (float) (x + offsetX
                        + Math.sin(Math.toRadians(i - modif + rotationValue)) * width * val);
                float prevCos = (float) (z + offsetZ
                        + Math.cos(Math.toRadians(i - modif + rotationValue)) * width * val);

                float sin = (float) (x + offsetX + Math.sin(Math.toRadians(i + rotationValue)) * width * val);
                float cos = (float) (z + offsetZ + Math.cos(Math.toRadians(i + rotationValue)) * width * val);

                float u0 = 1f / 360f * (float) (i - modif) * chainSizeVal;
                float u1 = 1f / 360f * (float) i * chainSizeVal;

                consumer.method_22918(matrix, prevSin, y, prevCos).method_22913(u0, 0).method_39415(c1);
                consumer.method_22918(matrix, sin, y, cos).method_22913(u1, 0).method_39415(c1);
                consumer.method_22918(matrix, sin, y + down, cos).method_22913(u1, 0.99f).method_39415(c2);
                consumer.method_22918(matrix, prevSin, y + down, prevCos).method_22913(u0, 0.99f).method_39415(c2);
            }

            stack.method_22909();
        }
    }

    private void renderRhomb(class_4587 stack, class_4597 provider, class_1309 target, float alpha) {
        class_4588 consumer = provider
                .method_73477(ClientPipelines.ROMB_ESP.apply(class_2960.method_60655("moonshine", "images/world/cube.png")));

        Quaternionf camRot = mc.field_1773.method_19418().method_23767();

        stack.method_46416(0, target.method_17682() / 2f, 0);
        stack.method_22907(camRot);

        float timeRotation = (System.currentTimeMillis() % 6283) / 1000f;
        stack.method_22907(class_7833.field_40718.rotationDegrees((float) Math.sin(timeRotation) * 360));

        float size = 0.5f;
        stack.method_22905(size, size, 1);

        int c1 = withAlpha(color1.getColor(), (int) (255 * alpha));
        int c2 = withAlpha(color2.getColor(), (int) (255 * alpha));

        Vector3f[] quad = {
                new Vector3f(-1, -1, 0),
                new Vector3f(-1, 1, 0),
                new Vector3f(1, 1, 0),
                new Vector3f(1, -1, 0)
        };

        var m = stack.method_23760();
        consumer.method_56824(m, quad[0].x, quad[0].y, 0).method_22913(0, 0).method_39415(c2);
        consumer.method_56824(m, quad[1].x, quad[1].y, 0).method_22913(0, 1).method_39415(c1);
        consumer.method_56824(m, quad[2].x, quad[2].y, 0).method_22913(1, 1).method_39415(c2);
        consumer.method_56824(m, quad[3].x, quad[3].y, 0).method_22913(1, 0).method_39415(c1);
    }

    private void renderGhost(class_4587 stack, class_4597 consumers, class_1309 target, float alpha) {
        class_4588 consumer = consumers
                .method_73477(ClientPipelines.GHOSTS_ESP.apply(class_2960.method_60655("moonshine", "images/particle/ghost-glow.png")));

        stack.method_46416(0, target.method_17682() * 0.5f, 0);

        particle(stack, consumer, (sin, cos) -> new class_243(sin, cos, -cos), alpha, 0);
        particle(stack, consumer, (sin, cos) -> new class_243(-sin, sin, -cos), alpha, 1);
        particle(stack, consumer, (sin, cos) -> new class_243(-sin, -sin, cos), alpha, 2);
    }

    private void particle(class_4587 stack, class_4588 consumer, Transformation transformation, float alpha,
            int colorIndex) {
        double radius = 0.7f;
        double distance = 11;

        float particleSize = 0.5f;
        int alphaFactor = 15;

        long elapsed = System.currentTimeMillis();

        int baseColor;
        switch (colorIndex) {
            case 0 -> baseColor = color1.getColor();
            case 1 -> baseColor = color2.getColor();
            default -> baseColor = color3.getColor();
        }

        for (int i = 0; i < 40 * alpha; i++) {
            stack.method_22903();

            double angle = 0.15 * ((elapsed * 0.5) - (i * distance)) / 30.0;

            double sin = Math.sin(angle) * radius;
            double cos = Math.cos(angle) * radius;

            class_243 trans = transformation.make(sin, cos);
            stack.method_22904(trans.field_1352, trans.field_1351, trans.field_1350);

            stack.method_22907(mc.field_1773.method_19418().method_23767());

            float spinRotation = (elapsed * 0.1f) - (i * 10f);
            stack.method_22907(class_7833.field_40718.rotationDegrees(spinRotation));

            stack.method_46416(particleSize / 2f, particleSize / 2f, 0);

            float x = (float) i / (float) 40;
            int lerpedColor = lerpColor(baseColor, getNextColor(colorIndex), x);

            int c1 = withAlpha(lerpedColor, (int) ((255 - i * alphaFactor) * alpha));
            int c2 = withAlpha(lerpedColor, (int) ((255 - i * alphaFactor) * alpha));

            var m = stack.method_23760();
            consumer.method_56824(m, 0, -particleSize, 0).method_22913(0, 0).method_39415(c2);
            consumer.method_56824(m, -particleSize, -particleSize, 0).method_22913(0, 1).method_39415(c1);
            consumer.method_56824(m, -particleSize, 0, 0).method_22913(1, 1).method_39415(c2);
            consumer.method_56824(m, 0, 0, 0).method_22913(1, 0).method_39415(c1);

            stack.method_22909();
        }
    }

    private void createCrystals(class_1297 target) {
        crystalList.clear();
        crystalList.add(new Crystal(new class_243(0, 0.85, 0.8), new class_243(-49, 0, 40)));
        crystalList.add(new Crystal(new class_243(0.2, 0.85, -0.675), new class_243(35, 0, -30)));
        crystalList.add(new Crystal(new class_243(0.6, 1.35, 0.6), new class_243(-30, 0, 35)));
        crystalList.add(new Crystal(new class_243(-0.74, 1.05, 0.4), new class_243(-25, 0, -30)));
        crystalList.add(new Crystal(new class_243(0.74, 0.95, -0.4), new class_243(0, 0, 0)));
        crystalList.add(new Crystal(new class_243(-0.475, 0.85, -0.375), new class_243(30, 0, -25)));
        crystalList.add(new Crystal(new class_243(0, 1.35, -0.6), new class_243(45, 0, 0)));
        crystalList.add(new Crystal(new class_243(0.85, 0.7, 0.1), new class_243(-30, 0, 30)));
        crystalList.add(new Crystal(new class_243(-0.7, 1.35, -0.3), new class_243(0, 0, 0)));
        crystalList.add(new Crystal(new class_243(-0.3, 1.35, 0.55), new class_243(0, 0, 0)));
        crystalList.add(new Crystal(new class_243(-0.5, 0.7, 0.7), new class_243(0, 0, 0)));
        crystalList.add(new Crystal(new class_243(0.5, 0.7, 0.7), new class_243(0, 0, 0)));
        crystalList.add(new Crystal(new class_243(-0.7, 0.75, 0), new class_243(0, 0, 0)));
        crystalList.add(new Crystal(new class_243(-0.2, 0.65, -0.7), new class_243(0, 0, 0)));
    }

    private void renderCrystals(class_4587 stack, class_4597 provider, class_1309 target, float alpha,
            float deltaTime) {
        if (target == null || crystalList.isEmpty()) {
            return;
        }

        rotationAngle += crystalRotationSpeed.getValue() * deltaTime;
        rotationAngle = rotationAngle % 360;

        stack.method_22903();
        stack.method_22907(class_7833.field_40716.rotationDegrees(rotationAngle));

        int baseColor = color1.getColor();
        if (hurtProgress > 0) {
            baseColor = lerpColor(baseColor, 0xFFFF0000, hurtProgress);
        }

        for (Crystal crystal : crystalList) {
            crystal.render(stack, provider, alpha, baseColor);
        }

        stack.method_22909();
    }

    private class Crystal {
        private final class_243 position;
        private final class_243 rotation;
        private final float rotationSpeed;

        public Crystal(class_243 position, class_243 rotation) {
            this.position = position;
            this.rotation = rotation;
            this.rotationSpeed = 0.5f + (float) (Math.random() * 1.5f);
        }

        public void render(class_4587 stack, class_4597 provider, float alpha, int baseColor) {
            stack.method_22903();
            stack.method_22904(position.field_1352, position.field_1351, position.field_1350);

            float timeSeconds = (System.currentTimeMillis() % 31416) / 1000f;
            float pulsation = 1.0f + (float) (Math.sin(timeSeconds * 2f) * 0.1f);
            stack.method_22905(pulsation, pulsation, pulsation);

            float selfRotation = (System.currentTimeMillis() % 36000) / 100.0f * rotationSpeed;
            stack.method_22907(class_7833.field_40714.rotationDegrees((float) rotation.field_1352));
            stack.method_22907(class_7833.field_40716.rotationDegrees((float) rotation.field_1351 + selfRotation));
            stack.method_22907(class_7833.field_40718.rotationDegrees((float) rotation.field_1350));

            float userAlpha = 0.3f;

            class_4588 filledConsumer = provider.method_73477(ClientPipelines.CRYSTAL_FILLED);
            drawFilledCrystal(stack, filledConsumer, baseColor, userAlpha * 0.85f, alpha);

            class_4588 glowConsumer = provider.method_73477(ClientPipelines.CRYSTAL_GLOW);
            stack.method_22903();
            stack.method_22905(1.15f, 1.15f, 1.15f);
            drawFilledCrystal(stack, glowConsumer, baseColor, userAlpha * 0.25f, alpha);
            stack.method_22909();

            stack.method_22903();
            stack.method_22905(1.3f, 1.3f, 1.3f);
            drawFilledCrystal(stack, glowConsumer, baseColor, userAlpha * 0.1f, alpha);
            stack.method_22909();

            drawBloomEffect(stack, provider, baseColor, alpha);

            stack.method_22909();
        }

        private void drawFilledCrystal(class_4587 stack, class_4588 consumer, int baseColor, float alphaMultiplier,
                float anim) {
            float s = 0.05f;
            float h_prism = s * 1.0f;
            float h_pyramid = s * 1.5f;
            int numSides = 8;

            List<Vector3f> topVertices = new ArrayList<>();
            List<Vector3f> bottomVertices = new ArrayList<>();

            for (int i = 0; i < numSides; i++) {
                float angle = (float) (2 * Math.PI * i / numSides);
                float x = (float) (s * Math.cos(angle));
                float z = (float) (s * Math.sin(angle));
                topVertices.add(new Vector3f(x, h_prism / 2, z));
                bottomVertices.add(new Vector3f(x, -h_prism / 2, z));
            }

            Vector3f vTop = new Vector3f(0, h_prism / 2 + h_pyramid, 0);
            Vector3f vBottom = new Vector3f(0, -h_prism / 2 - h_pyramid, 0);

            int finalAlpha = (int) (alphaMultiplier * 255 * anim);
            int finalColor = withAlpha(baseColor, finalAlpha);
            int darkerColor = withAlpha(darkenColor(baseColor, 0.7f), finalAlpha);
            int lighterColor = withAlpha(lightenColor(baseColor, 1.2f), finalAlpha);

            Matrix4f matrix = stack.method_23760().method_23761();

            for (int i = 0; i < numSides; i++) {
                Vector3f v1 = bottomVertices.get(i);
                Vector3f v2 = bottomVertices.get((i + 1) % numSides);
                Vector3f v3 = topVertices.get((i + 1) % numSides);
                Vector3f v4 = topVertices.get(i);

                int sideColor = (i % 2 == 0) ? finalColor : darkerColor;
                drawQuadFilled(matrix, consumer, v1, v2, v3, v4, sideColor);
            }

            for (int i = 0; i < numSides; i++) {
                Vector3f v1 = topVertices.get(i);
                Vector3f v2 = topVertices.get((i + 1) % numSides);

                int pyramidColor = (i % 2 == 0) ? lighterColor : finalColor;
                drawTriangleFilled(matrix, consumer, vTop, v2, v1, pyramidColor);
            }

            for (int i = 0; i < numSides; i++) {
                Vector3f v1 = bottomVertices.get(i);
                Vector3f v2 = bottomVertices.get((i + 1) % numSides);

                int pyramidColor = (i % 2 == 0) ? darkerColor : finalColor;
                drawTriangleFilled(matrix, consumer, vBottom, v1, v2, pyramidColor);
            }
        }

        private void drawTriangleFilled(Matrix4f matrix, class_4588 consumer, Vector3f v1, Vector3f v2, Vector3f v3,
                int color) {
            consumer.method_22918(matrix, v1.x, v1.y, v1.z).method_39415(color);
            consumer.method_22918(matrix, v2.x, v2.y, v2.z).method_39415(color);
            consumer.method_22918(matrix, v3.x, v3.y, v3.z).method_39415(color);
            consumer.method_22918(matrix, v3.x, v3.y, v3.z).method_39415(color);
        }

        private void drawQuadFilled(Matrix4f matrix, class_4588 consumer, Vector3f v1, Vector3f v2, Vector3f v3,
                Vector3f v4, int color) {
            consumer.method_22918(matrix, v1.x, v1.y, v1.z).method_39415(color);
            consumer.method_22918(matrix, v2.x, v2.y, v2.z).method_39415(color);
            consumer.method_22918(matrix, v3.x, v3.y, v3.z).method_39415(color);
            consumer.method_22918(matrix, v4.x, v4.y, v4.z).method_39415(color);
        }

        private void drawBloomEffect(class_4587 stack, class_4597 provider, int baseColor, float anim) {
            class_4588 bloomConsumer = provider
                    .method_73477(ClientPipelines.BLOOM_ESP.apply(class_2960.method_60655("moonshine", "images/particle/glow.png")));

            int bloomAlpha = (int) (0.3f * 60 * anim);
            int bloomColor = withAlpha(baseColor, bloomAlpha);
            float bloomSize = 0.05f * 15.0f;

            Quaternionf camRot = mc.field_1773.method_19418().method_23767();
            int segments = 6;

            for (int i = 0; i < segments; i++) {
                stack.method_22903();
                float angle = (360.0f / segments) * i;
                stack.method_22907(class_7833.field_40716.rotationDegrees(angle));
                stack.method_22907(camRot);

                Matrix4f matrix = stack.method_23760().method_23761();

                bloomConsumer.method_22918(matrix, -bloomSize / 2, -bloomSize / 2, 0).method_22913(0, 1).method_39415(bloomColor);
                bloomConsumer.method_22918(matrix, bloomSize / 2, -bloomSize / 2, 0).method_22913(1, 1).method_39415(bloomColor);
                bloomConsumer.method_22918(matrix, bloomSize / 2, bloomSize / 2, 0).method_22913(1, 0).method_39415(bloomColor);
                bloomConsumer.method_22918(matrix, -bloomSize / 2, bloomSize / 2, 0).method_22913(0, 0).method_39415(bloomColor);

                stack.method_22909();
            }

            for (int i = 0; i < segments; i++) {
                stack.method_22903();
                float angle = (360.0f / segments) * i;
                stack.method_22907(class_7833.field_40714.rotationDegrees(90));
                stack.method_22907(class_7833.field_40716.rotationDegrees(angle));
                stack.method_22907(camRot);

                Matrix4f matrix = stack.method_23760().method_23761();

                bloomConsumer.method_22918(matrix, -bloomSize / 2, -bloomSize / 2, 0).method_22913(0, 1).method_39415(bloomColor);
                bloomConsumer.method_22918(matrix, bloomSize / 2, -bloomSize / 2, 0).method_22913(1, 1).method_39415(bloomColor);
                bloomConsumer.method_22918(matrix, bloomSize / 2, bloomSize / 2, 0).method_22913(1, 0).method_39415(bloomColor);
                bloomConsumer.method_22918(matrix, -bloomSize / 2, bloomSize / 2, 0).method_22913(0, 0).method_39415(bloomColor);

                stack.method_22909();
            }
        }
    }

    private int darkenColor(int color, float factor) {
        int a = (color >> 24) & 0xFF;
        int r = (int) (((color >> 16) & 0xFF) * factor);
        int g = (int) (((color >> 8) & 0xFF) * factor);
        int b = (int) ((color & 0xFF) * factor);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private int lightenColor(int color, float factor) {
        int a = (color >> 24) & 0xFF;
        int r = Math.min(255, (int) (((color >> 16) & 0xFF) * factor));
        int g = Math.min(255, (int) (((color >> 8) & 0xFF) * factor));
        int b = Math.min(255, (int) ((color & 0xFF) * factor));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private int getNextColor(int colorIndex) {
        return switch (colorIndex) {
            case 0 -> color2.getColor();
            case 1 -> color3.getColor();
            default -> color1.getColor();
        };
    }

    private int lerpColor(int c1, int c2, float t) {
        int a1 = (c1 >> 24) & 0xFF;
        int r1 = (c1 >> 16) & 0xFF;
        int g1 = (c1 >> 8) & 0xFF;
        int b1 = c1 & 0xFF;

        int a2 = (c2 >> 24) & 0xFF;
        int r2 = (c2 >> 16) & 0xFF;
        int g2 = (c2 >> 8) & 0xFF;
        int b2 = c2 & 0xFF;

        int a = (int) (a1 + (a2 - a1) * t);
        int r = (int) (r1 + (r2 - r1) * t);
        int g = (int) (g1 + (g2 - g1) * t);
        int b = (int) (b1 + (b2 - b1) * t);

        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private int withAlpha(int color, int alpha) {
        alpha = Math.max(0, Math.min(255, alpha));
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    @FunctionalInterface
    private interface Transformation {
        class_243 make(double sin, double cos);
    }
}