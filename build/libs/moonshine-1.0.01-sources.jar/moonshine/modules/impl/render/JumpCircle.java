package moonshine.modules.impl.render;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import moonshine.IMinecraft;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.JumpEvent;
import moonshine.events.impl.WorldRenderEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.ColorSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.ColorUtil;
import moonshine.util.render.сliemtpipeline.ClientPipelines;
import moonshine.util.timer.StopWatch;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class JumpCircle extends ModuleStructure implements IMinecraft {

    private final List<Circle> circles = new ArrayList<>();

    final class_2960 circleTexture = class_2960.method_60655("moonshine", "images/circle/circle.png");
    final class_2960 glowTexture = class_2960.method_60655("moonshine", "images/particle/glow.png");

    final SliderSettings maxSize = new SliderSettings("Max Size", "Максимальный размер круга")
            .setValue(2f)
            .range(1.0f, 2.0f);

    final SliderSettings speed = new SliderSettings("Speed", "Скорость анимации")
            .setValue(2000f)
            .range(1000f, 2000f);

    final BooleanSetting glow = new BooleanSetting("Glow", "Эффект свечения")
            .setValue(true);

    final ColorSetting color1 = new ColorSetting("Цвет 1", "Первый цвет")
            .value(ColorUtil.getColor(137, 97, 72, 255));

    final ColorSetting color2 = new ColorSetting("Цвет 2", "Второй цвет")
            .value(ColorUtil.getColor(255, 255, 255, 255));

    private static final int SEGMENTS = 64;

    public JumpCircle() {
        super("JumpCircle", "Jump Circle", ModuleCategory.RENDER);
        settings(maxSize, speed, glow, color1, color2);
    }

    @EventHandler
    public void onJump(JumpEvent event) {
        if (mc.field_1724 == null || event.getPlayer() != mc.field_1724) return;

        class_243 pos = new class_243(
                mc.field_1724.method_23317(),
                Math.floor(mc.field_1724.method_23318()) + 0.001,
                mc.field_1724.method_23321()
        );
        circles.add(new Circle(pos, new StopWatch()));
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        long maxTime = (long) speed.getValue();

        Iterator<Circle> iterator = circles.iterator();
        while (iterator.hasNext()) {
            Circle circle = iterator.next();
            if (circle.timer.elapsedTime() > maxTime) {
                iterator.remove();
            }
        }

        if (circles.isEmpty()) return;

        class_4587 matrices = e.getStack();
        class_4597.class_4598 immediate = mc.method_22940().method_23000();
        class_243 cameraPos = mc.field_1773.method_19418().method_71156();

        for (Circle circle : circles) {
            renderSingleCircle(matrices, immediate, circle, cameraPos);
        }

        immediate.method_22993();
    }

    private void renderSingleCircle(class_4587 matrices, class_4597.class_4598 immediate, Circle circle, class_243 cameraPos) {
        float lifeTime = circle.timer.elapsedTime();
        float maxTime = speed.getValue();
        float progress = Math.min(lifeTime / maxTime, 1f);

        if (progress >= 1f) return;

        float easedProgress = bounceOut(progress);
        float scale = easedProgress * maxSize.getValue();

        float fadeInDuration = 0.15f;
        float glowStart = 0.65f;
        float fadeOutStart = 0.85f;
        float alpha;

        if (progress < fadeInDuration) {
            alpha = progress / fadeInDuration;
        } else if (progress >= fadeOutStart) {
            float fadeOutProgress = (progress - fadeOutStart) / (1f - fadeOutStart);
            alpha = 1f - fadeOutProgress;

            if (progress > glowStart) {
                float glowProgress = (progress - glowStart) / (fadeOutStart - glowStart);
                float glowPulse = (float) (Math.sin(glowProgress * Math.PI * 3) * 0.3 + 0.3);
                alpha += glowPulse * (1f - fadeOutProgress);
            }
        } else if (progress > glowStart) {
            float glowProgress = (progress - glowStart) / (fadeOutStart - glowStart);
            float glowPulse = (float) (Math.sin(glowProgress * Math.PI * 3) * 0.3 + 0.3);
            alpha = 1f + glowPulse;
        } else {
            alpha = 1f;
        }

        alpha = Math.max(0f, Math.min(1f, alpha));

        float rotationOffset = (lifeTime / 1000f) * 0.5f * 360f;

        class_243 circlePos = circle.pos();

        if (glow.isValue()) {
            renderGradientGlow(matrices, immediate, circlePos, scale, alpha * 0.1f, rotationOffset, cameraPos);
        }

        renderGradientCircle(matrices, immediate, circlePos, scale, alpha, rotationOffset, cameraPos);
    }

    private void renderGradientCircle(class_4587 matrices, class_4597.class_4598 immediate,
                                      class_243 pos, float size, float alpha, float rotationOffset, class_243 cameraPos) {
        class_4588 buffer = immediate.method_73477(ClientPipelines.BLOOM_ESP.apply(circleTexture));

        matrices.method_22903();

        float x = (float) (pos.field_1352 - cameraPos.field_1352);
        float y = (float) (pos.field_1351 - cameraPos.field_1351);
        float z = (float) (pos.field_1350 - cameraPos.field_1350);

        matrices.method_46416(x, y, z);
        matrices.method_22907(class_7833.field_40714.rotationDegrees(90f));

        Matrix4f matrix = matrices.method_23760().method_23761();
        float radius = size / 2f;

        int c1 = color1.getColor();
        int c2 = color2.getColor();

        for (int i = 0; i < SEGMENTS; i++) {
            float angle1 = (float) (2 * Math.PI * i / SEGMENTS);
            float angle2 = (float) (2 * Math.PI * (i + 1) / SEGMENTS);

            float t = (float) i / SEGMENTS;
            float tNext = (float) (i + 1) / SEGMENTS;

            float adjustedT = (t + rotationOffset / 360f) % 1f;
            float adjustedTNext = (tNext + rotationOffset / 360f) % 1f;

            int currentColor = getGradientColor(c1, c2, adjustedT, alpha);
            int nextColor = getGradientColor(c1, c2, adjustedTNext, alpha);

            float x1 = (float) (Math.cos(angle1) * radius);
            float z1 = (float) (Math.sin(angle1) * radius);
            float x2 = (float) (Math.cos(angle2) * radius);
            float z2 = (float) (Math.sin(angle2) * radius);

            float u1 = (float) (0.5 + 0.5 * Math.cos(angle1));
            float v1 = (float) (0.5 + 0.5 * Math.sin(angle1));
            float u2 = (float) (0.5 + 0.5 * Math.cos(angle2));
            float v2 = (float) (0.5 + 0.5 * Math.sin(angle2));

            int centerColor = ColorUtil.lerpColor(currentColor, nextColor, 0.5f);

            buffer.method_22918(matrix, 0, 0, 0).method_22913(0.5f, 0.5f).method_39415(centerColor);
            buffer.method_22918(matrix, x1, z1, 0).method_22913(u1, v1).method_39415(currentColor);
            buffer.method_22918(matrix, x2, z2, 0).method_22913(u2, v2).method_39415(nextColor);
            buffer.method_22918(matrix, x2, z2, 0).method_22913(u2, v2).method_39415(nextColor);
        }

        matrices.method_22909();
    }

    private void renderGradientGlow(class_4587 matrices, class_4597.class_4598 immediate,
                                    class_243 pos, float scale, float alpha, float rotationOffset, class_243 cameraPos) {
        int c1 = color1.getColor();
        int c2 = color2.getColor();

        for (int layer = 0; layer < 3; layer++) {
            float layerScale = scale * (1.3f + layer * 0.4f);
            float layerAlpha = alpha * (0.35f - layer * 0.1f);

            renderGlowLayer(matrices, immediate, pos, layerScale, layerAlpha, rotationOffset, c1, c2, cameraPos);
        }

        float coreAlpha = alpha * 0.2f;
        int coreColor1 = ColorUtil.multAlpha(c1, coreAlpha);
        int coreColor2 = ColorUtil.multAlpha(c2, coreAlpha);
        int mixedCore = ColorUtil.lerpColor(coreColor1, coreColor2, 0.5f);
        renderTexturedQuad(matrices, immediate, pos, scale * 2.5f, mixedCore, glowTexture, cameraPos);
    }

    private void renderGlowLayer(class_4587 matrices, class_4597.class_4598 immediate,
                                 class_243 pos, float size, float alpha, float rotationOffset,
                                 int c1, int c2, class_243 cameraPos) {
        class_4588 buffer = immediate.method_73477(ClientPipelines.BLOOM_ESP.apply(glowTexture));

        int glowSegments = 16;
        float radius = size / 2f;

        for (int i = 0; i < glowSegments; i++) {
            float angle = (float) (2 * Math.PI * i / glowSegments);
            float t = (float) i / glowSegments;

            float adjustedT = (t + rotationOffset / 360f) % 1f;
            int glowColor = getGradientColor(c1, c2, adjustedT, alpha);

            float glowX = (float) (pos.field_1352 + Math.cos(angle) * radius * 0.8f);
            float glowZ = (float) (pos.field_1350 + Math.sin(angle) * radius * 0.8f);
            class_243 glowPos = new class_243(glowX, pos.field_1351, glowZ);

            float glowSize = size * 0.4f;
            renderTexturedQuadAtPos(matrices, buffer, glowPos, glowSize, glowColor, cameraPos);
        }
    }

    private void renderTexturedQuadAtPos(class_4587 matrices, class_4588 buffer, class_243 pos, float size, int color, class_243 cameraPos) {
        matrices.method_22903();

        float x = (float) (pos.field_1352 - cameraPos.field_1352);
        float y = (float) (pos.field_1351 - cameraPos.field_1351);
        float z = (float) (pos.field_1350 - cameraPos.field_1350);

        matrices.method_46416(x, y, z);
        matrices.method_22907(class_7833.field_40714.rotationDegrees(90f));

        Matrix4f matrix = matrices.method_23760().method_23761();
        float half = size / 2f;

        buffer.method_22918(matrix, -half, -half, 0).method_22913(0, 0).method_39415(color);
        buffer.method_22918(matrix, half, -half, 0).method_22913(1, 0).method_39415(color);
        buffer.method_22918(matrix, half, half, 0).method_22913(1, 1).method_39415(color);
        buffer.method_22918(matrix, -half, half, 0).method_22913(0, 1).method_39415(color);

        matrices.method_22909();
    }

    private int getGradientColor(int c1, int c2, float t, float alpha) {
        float gradientT;
        if (t <= 0.5f) {
            gradientT = t * 2f;
        } else {
            gradientT = (1f - t) * 2f;
        }

        int color = ColorUtil.lerpColor(c1, c2, gradientT);
        return ColorUtil.multAlpha(color, alpha);
    }

    private void renderTexturedQuad(class_4587 matrices, class_4597.class_4598 immediate, class_243 pos, float size, int color, class_2960 texture, class_243 cameraPos) {
        class_4588 buffer = immediate.method_73477(ClientPipelines.BLOOM_ESP.apply(texture));

        matrices.method_22903();

        float x = (float) (pos.field_1352 - cameraPos.field_1352);
        float y = (float) (pos.field_1351 - cameraPos.field_1351);
        float z = (float) (pos.field_1350 - cameraPos.field_1350);

        matrices.method_46416(x, y, z);
        matrices.method_22907(class_7833.field_40714.rotationDegrees(90f));

        Matrix4f matrix = matrices.method_23760().method_23761();
        float half = size / 2f;

        buffer.method_22918(matrix, -half, -half, 0).method_22913(0, 0).method_39415(color);
        buffer.method_22918(matrix, half, -half, 0).method_22913(1, 0).method_39415(color);
        buffer.method_22918(matrix, half, half, 0).method_22913(1, 1).method_39415(color);
        buffer.method_22918(matrix, -half, half, 0).method_22913(0, 1).method_39415(color);

        matrices.method_22909();
    }

    private float bounceOut(float value) {
        float n1 = 7.5625f;
        float d1 = 2.75f;
        if (value < 1.0f / d1) {
            return n1 * value * value;
        } else if (value < 2.0f / d1) {
            return n1 * (value -= 1.5f / d1) * value + 0.75f;
        } else if (value < 2.5f / d1) {
            return n1 * (value -= 2.25f / d1) * value + 0.9375f;
        } else {
            return n1 * (value -= 2.625f / d1) * value + 0.984375f;
        }
    }

    public record Circle(class_243 pos, StopWatch timer) {}
}