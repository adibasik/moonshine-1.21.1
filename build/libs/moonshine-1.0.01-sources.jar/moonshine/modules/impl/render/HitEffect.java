package moonshine.modules.impl.render;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.AttackEvent;
import moonshine.events.impl.WorldRenderEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.ColorSetting;
import moonshine.util.ColorUtil;
import moonshine.util.Instance;
import moonshine.util.render.Render3D;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import java.awt.*;
import java.util.*;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class HitEffect extends ModuleStructure {
    public static HitEffect getInstance() {
        return Instance.get(HitEffect.class);
    }

    final List<WaveEffect> waveEffects = Collections.synchronizedList(new ArrayList<>());

    public ColorSetting colorSetting = new ColorSetting("Цвет", "Выберите цвет для эффекта")
            .setColor(new Color(137, 97, 72, 255).getRGB());

    public HitEffect() {
        super("HitEffect", "Hit Effect", ModuleCategory.RENDER);
        settings(colorSetting);
    }

    public void addWave(class_2338 pos) {
        if (mc.field_1687 != null && pos != null) {
            class_2338 groundPos = findGround(pos);
            if (groundPos != null) {
                waveEffects.add(new WaveEffect(groundPos, System.currentTimeMillis()));
            }
        }
    }

    private class_2338 findGround(class_2338 pos) {
        for (int y = 0; y <= 10; y++) {
            class_2338 down = pos.method_10087(y);
            if (mc.field_1687.method_24794(down) && !mc.field_1687.method_8320(down).method_26215()) {
                return down;
            }
        }
        return pos;
    }

    @EventHandler
    public void onAttack(AttackEvent e) {
        if (!isState()) return;
        if (e.getTarget() != null) {
            addWave(e.getTarget().getBlockPos());
        }
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        if (waveEffects.isEmpty() || mc.field_1687 == null) return;

        Iterator<WaveEffect> iterator = waveEffects.iterator();
        while (iterator.hasNext()) {
            WaveEffect wave = iterator.next();
            if (wave.isExpired()) {
                iterator.remove();
                continue;
            }
            wave.render();
        }
    }

    private class WaveEffect {
        private final class_2338 centerPos;
        private final long startTime;
        private final long duration = 475;
        private final int maxRadius = 8;
        private Map<Long, Integer> reachableBlocks;
        private boolean calculated = false;

        public WaveEffect(class_2338 centerPos, long startTime) {
            this.centerPos = centerPos;
            this.startTime = startTime;
        }

        public boolean isExpired() {
            return System.currentTimeMillis() - startTime > duration;
        }

        private void calculateReachableBlocks() {
            if (calculated) return;
            calculated = true;

            reachableBlocks = new HashMap<>();
            Queue<class_2338> queue = new LinkedList<>();
            Map<Long, Integer> visited = new HashMap<>();

            class_2338 startPos = centerPos;
            if (mc.field_1687.method_8320(startPos).method_26215()) {
                for (int y = 1; y <= 5; y++) {
                    class_2338 down = startPos.method_10087(y);
                    if (!mc.field_1687.method_8320(down).method_26215()) {
                        startPos = down;
                        break;
                    }
                }
            }

            queue.add(startPos);
            visited.put(startPos.method_10063(), 0);

            while (!queue.isEmpty()) {
                class_2338 current = queue.poll();
                int currentDistance = visited.get(current.method_10063());

                if (currentDistance > maxRadius) continue;

                class_2680 state = mc.field_1687.method_8320(current);
                if (!state.method_26215()) {
                    class_265 shape = state.method_26218(mc.field_1687, current);
                    if (!shape.method_1110()) {
                        reachableBlocks.put(current.method_10063(), currentDistance);
                    }
                }

                for (class_2350 dir : class_2350.values()) {
                    class_2338 neighbor = current.method_10093(dir);

                    if (!mc.field_1687.method_24794(neighbor)) continue;

                    long neighborLong = neighbor.method_10063();
                    int newDistance = currentDistance + 1;

                    if (visited.containsKey(neighborLong) && visited.get(neighborLong) <= newDistance) continue;
                    if (newDistance > maxRadius) continue;

                    class_2680 neighborState = mc.field_1687.method_8320(neighbor);

                    if (!neighborState.method_26215()) {
                        visited.put(neighborLong, newDistance);
                        queue.add(neighbor);
                    } else {
                        class_2338 below = neighbor.method_10074();
                        if (mc.field_1687.method_24794(below) && !mc.field_1687.method_8320(below).method_26215()) {
                            long belowLong = below.method_10063();
                            if (!visited.containsKey(belowLong) || visited.get(belowLong) > newDistance) {
                                visited.put(belowLong, newDistance);
                                queue.add(below);
                            }
                        }

                        class_2338 above = neighbor.method_10084();
                        if (mc.field_1687.method_24794(above) && !mc.field_1687.method_8320(above).method_26215()) {
                            long aboveLong = above.method_10063();
                            if (!visited.containsKey(aboveLong) || visited.get(aboveLong) > newDistance) {
                                visited.put(aboveLong, newDistance);
                                queue.add(above);
                            }
                        }
                    }
                }
            }
        }

        public void render() {
            if (mc.field_1687 == null) return;

            calculateReachableBlocks();

            if (reachableBlocks == null || reachableBlocks.isEmpty()) return;

            long elapsed = System.currentTimeMillis() - startTime;
            float progress = (float) elapsed / duration;
            float currentRadius = progress * maxRadius;
            float waveWidth = 2.5f;

            float globalAlpha = 1.0f - progress;
            globalAlpha = (float) Math.pow(globalAlpha, 0.5);

            int rendered = 0;
            int maxPerFrame = 500;

            for (Map.Entry<Long, Integer> entry : reachableBlocks.entrySet()) {
                if (rendered >= maxPerFrame) break;

                int blockDistance = entry.getValue();

                if (blockDistance < currentRadius - waveWidth || blockDistance > currentRadius + 0.5f) continue;

                class_2338 pos = class_2338.method_10092(entry.getKey());
                class_2680 state = mc.field_1687.method_8320(pos);

                if (state.method_26215()) continue;

                class_265 shape = state.method_26218(mc.field_1687, pos);
                if (shape.method_1110()) continue;

                rendered++;

                float localAlpha = 1.0f - Math.abs(blockDistance - currentRadius) / waveWidth;
                localAlpha = Math.max(0, Math.min(1, localAlpha));
                localAlpha *= globalAlpha;

                if (localAlpha > 0.02f) {
                    int baseColor = colorSetting.getColor();
                    int color = ColorUtil.setAlpha(baseColor, (int) (localAlpha * 75));

                    try {
                        Render3D.drawShapeAlternative(
                                pos,
                                shape,
                                color,
                                1f,
                                true,
                                true
                        );
                    } catch (Exception ignored) {
                    }
                }
            }
        }
    }
}