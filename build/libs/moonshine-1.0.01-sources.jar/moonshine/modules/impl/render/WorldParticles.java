package moonshine.modules.impl.render;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.TickEvent;
import moonshine.events.impl.WorldRenderEvent;
import moonshine.modules.impl.render.worldparticles.Particle;
import moonshine.modules.impl.render.worldparticles.ParticleSpawner;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.ColorSetting;
import moonshine.modules.module.setting.implement.SelectSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.Instance;
import moonshine.util.timer.StopWatch;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class WorldParticles extends ModuleStructure {

    public static WorldParticles getInstance() {
        return Instance.get(WorldParticles.class);
    }

    final List<Particle> particles = new ArrayList<>();
    final StopWatch timer = new StopWatch();

    class_243 lastPlayerPos = class_243.field_1353;
    class_243 playerVelocity = class_243.field_1353;
    double playerSpeed = 0;

    public SelectSetting mode = new SelectSetting("Режим", "Тип частиц")
            .value("3D Кубы", "Корона", "Куб", "Доллар", "Сердце", "Молния", "Линия", "Ромб", "Снежинка", "Звезда", "Звезда 2", "Треугольник", "Свечение", "Рандом")
            .selected("Звезда");

    public SliderSettings cubeCount = new SliderSettings("Количество", "Количество частиц")
            .range(10.0f, 500.0f)
            .setValue(100.0f);

    public SliderSettings lifeTime = new SliderSettings("Время жизни", "Время жизни (сек)")
            .range(2.0f, 60.0f)
            .setValue(10.0f);

    public SliderSettings size = new SliderSettings("Размер", "Размер частиц")
            .range(0.1f, 1.5f)
            .setValue(1.5f);

    public SliderSettings glowSize = new SliderSettings("Свечение", "Размер свечения")
            .range(0.1f, 5.0f)
            .setValue(3f);

    public BooleanSetting physics = new BooleanSetting("Физика", "Частицы падают вниз")
            .setValue(false);

    public BooleanSetting randomColor = new BooleanSetting("Рандомный цвет", "Каждая частица имеет случайный цвет")
            .setValue(false);

    public BooleanSetting whiteOnSpawn = new BooleanSetting("Белые при спавне", "Частицы белые при появлении и плавно меняют цвет")
            .setValue(true);

    public BooleanSetting whiteCenter = new BooleanSetting("Белый центр", "Белый центр у текстурных частиц")
            .setValue(false)
            .visible(() -> !mode.getSelected().equals("3D Кубы"));

    public ColorSetting cubeColor = new ColorSetting("Цвет", "Цвет частиц")
            .value(0xFF896148)
            .visible(() -> !randomColor.isValue());

    public WorldParticles() {
        super("WorldParticles", "Летающие частицы в мире", ModuleCategory.RENDER);
        settings(mode, cubeCount, lifeTime, size, glowSize, physics, randomColor, whiteOnSpawn, whiteCenter, cubeColor);
    }

    @Override
    public void deactivate() {
        particles.clear();
        lastPlayerPos = class_243.field_1353;
        playerVelocity = class_243.field_1353;
        playerSpeed = 0;
    }

    private Particle.ParticleType getParticleType() {
        String selected = mode.getSelected();
        return switch (selected) {
            case "3D Кубы" -> Particle.ParticleType.CUBE_3D;
            case "Корона" -> Particle.ParticleType.CROWN;
            case "Куб" -> Particle.ParticleType.CUBE_BLAST;
            case "Доллар" -> Particle.ParticleType.DOLLAR;
            case "Сердце" -> Particle.ParticleType.HEART;
            case "Молния" -> Particle.ParticleType.LIGHTNING;
            case "Линия" -> Particle.ParticleType.LINE;
            case "Ромб" -> Particle.ParticleType.RHOMBUS;
            case "Снежинка" -> Particle.ParticleType.SNOWFLAKE;
            case "Звезда" -> Particle.ParticleType.STAR;
            case "Звезда 2" -> Particle.ParticleType.STAR_ALT;
            case "Треугольник" -> Particle.ParticleType.TRIANGLE;
            case "Свечение" -> Particle.ParticleType.GLOW;
            case "Рандом" -> Particle.ParticleType.RANDOM;
            default -> Particle.ParticleType.CUBE_3D;
        };
    }

    @EventHandler
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        class_243 currentPos = mc.field_1724.method_73189();

        if (lastPlayerPos != class_243.field_1353) {
            playerVelocity = currentPos.method_1020(lastPlayerPos);
            playerSpeed = playerVelocity.method_37267();
        }
        lastPlayerPos = currentPos;

        double despawnDistSq = ParticleSpawner.getDespawnDistanceSquared();
        for (Particle p : particles) {
            if (!p.isFadingOut()) {
                double distSq = p.getHorizontalDistanceSquaredTo(currentPos);
                if (distSq > despawnDistSq) {
                    p.startFadeOut();
                }
            }
        }

        int actualDelay = ParticleSpawner.calculateSpawnDelay(playerSpeed);

        if (particles.size() < cubeCount.getValue() && timer.finished(actualDelay)) {
            int spawnCount = ParticleSpawner.calculateSpawnCount(playerSpeed, particles.size(), (int) cubeCount.getValue());
            long lifeTimeMs = (long) (lifeTime.getValue() * 1000);
            Particle.ParticleType type = getParticleType();

            for (int i = 0; i < spawnCount && particles.size() < cubeCount.getValue(); i++) {
                Particle particle = ParticleSpawner.createParticle(currentPos, playerVelocity, playerSpeed, lifeTimeMs, type);
                particle.setPhysics(physics.isValue());
                particle.setSize(size.getValue());
                particles.add(particle);
            }

            timer.reset();
        }
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        if (particles.isEmpty()) return;

        class_4597.class_4598 immediate = mc.method_22940().method_23000();
        class_4587 matrices = e.getStack();
        class_243 cameraPos = mc.field_1773.method_19418().method_71156();
        long now = System.currentTimeMillis();
        float cameraYaw = mc.field_1773.method_19418().method_19330();
        float cameraPitch = mc.field_1773.method_19418().method_19329();
        float rotation = (float) (now % 9000L) / 9000.0F * 360.0F;
        int baseColor = cubeColor.getColor();
        float glow = glowSize.getValue();
        boolean useRandomColor = randomColor.isValue();
        boolean useWhiteOnSpawn = whiteOnSpawn.isValue();
        boolean useWhiteCenter = whiteCenter.isValue();

        Iterator<Particle> iterator = particles.iterator();
        while (iterator.hasNext()) {
            Particle p = iterator.next();
            p.update(now);
            if (p.shouldRemove()) {
                iterator.remove();
            }
        }

        for (Particle p : particles) {
            double distSq = p.getDistanceSquaredTo(cameraPos);
            if (distSq < 150 * 150) {
                p.render(matrices, immediate, cameraPos, baseColor, rotation, cameraYaw, cameraPitch, glow, useRandomColor, useWhiteOnSpawn, useWhiteCenter);
            }
        }

        immediate.method_22993();
    }
}