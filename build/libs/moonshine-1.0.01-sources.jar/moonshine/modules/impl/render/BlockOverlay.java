package moonshine.modules.impl.render;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.WorldRenderEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.util.Instance;
import moonshine.util.render.Render3D;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import java.awt.*;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class BlockOverlay extends ModuleStructure {
    public static BlockOverlay getInstance() {
        return Instance.get(BlockOverlay.class);
    }

    public BlockOverlay() {
        super("BlockOverlay", "Block Overlay", ModuleCategory.RENDER);
    }

    @EventHandler
    public void onWorldRender(WorldRenderEvent e) {
        if (mc.field_1765 instanceof class_3965 result && result.method_17783().equals(class_239.class_240.field_1332)) {
            class_2338 pos = result.method_17777();
            Render3D.drawShapeAlternative(pos, mc.field_1687.method_8320(pos).method_26218(mc.field_1687, pos), new Color(109, 252, 255,230).getRGB(), 1.5f, true, true);
        }
    }
}
