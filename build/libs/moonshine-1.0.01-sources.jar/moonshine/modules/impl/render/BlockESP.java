package moonshine.modules.impl.render;

import moonshine.events.api.EventHandler;
import moonshine.events.impl.WorldRenderEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.modules.module.setting.implement.ColorSetting;
import moonshine.modules.module.setting.implement.SliderSettings;
import moonshine.util.ColorUtil;
import moonshine.util.config.impl.blockesp.BlockESPConfig;
import moonshine.util.render.Render3D;
import moonshine.util.string.chat.ChatMessage;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_7923;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

public class BlockESP extends ModuleStructure {
    ColorSetting color = new ColorSetting("Цвет", "Цвет подсветки блоков").value(ColorUtil.getColor(255, 0, 0, 255));
    SliderSettings range = new SliderSettings("Радиус", "Радиус поиска блоков").range(1, 128).setValue(32);
    BooleanSetting notifyInChat = new BooleanSetting("Уведомления", "Показывать координаты найденных блоков в чате").setValue(false);

    Set<String> blocksToHighlight = new CopyOnWriteArraySet<>();
    Map<class_2338, class_2680> renderBlocks = new HashMap<>();
    Set<class_2338> notifiedBlocks = new CopyOnWriteArraySet<>();
    long lastScanTime = 0;
    int checkCounter = 0;

    public BlockESP() {
        super("BlockESP", "Block ESP", ModuleCategory.RENDER);
        settings(color, range, notifyInChat);
    }

    public Set<String> getBlocksToHighlight() {
        return blocksToHighlight;
    }

    @Override
    public void activate() {
        blocksToHighlight.clear();
        blocksToHighlight.addAll(BlockESPConfig.getInstance().getBlocks());
        notifiedBlocks.clear();
    }

    @Override
    public void deactivate() {
        renderBlocks.clear();
        notifiedBlocks.clear();
    }

    @EventHandler
    public void onRender3D(WorldRenderEvent event) {
        if (!state || mc.field_1687 == null || mc.field_1724 == null) {
            renderBlocks.clear();
            return;
        }
        if (blocksToHighlight.isEmpty()) {
            renderBlocks.clear();
            return;
        }
        class_2338 playerPos = mc.field_1724.method_24515();
        long currentTime = System.nanoTime() / 1_000_000;
        if (currentTime - lastScanTime >= 2000) {
            renderBlocks.clear();
            int chunkRange = 2;
            int yRange = 48;
            for (int x = -chunkRange; x <= chunkRange; x++) {
                for (int z = -chunkRange; z <= chunkRange; z++) {
                    int chunkX = (playerPos.method_10263() >> 4) + x;
                    int chunkZ = (playerPos.method_10260() >> 4) + z;
                    if (!mc.field_1687.method_2935().method_12123(chunkX, chunkZ)) continue;
                    class_2818 chunk = mc.field_1687.method_2935().method_21730(chunkX, chunkZ);
                    if (chunk == null) continue;
                    int cx = chunk.method_12004().field_9181 << 4;
                    int cz = chunk.method_12004().field_9180 << 4;
                    for (int bx = 0; bx < 16; bx++) {
                        for (int bz = 0; bz < 16; bz++) {
                            int minY = Math.max(mc.field_1687.method_31607(), playerPos.method_10264() - yRange);
                            int maxY = Math.min(mc.field_1687.method_8624(class_2902.class_2903.field_13202, cx + bx, cz + bz), playerPos.method_10264() + yRange);
                            for (int by = minY; by <= maxY; by++) {
                                class_2338 pos = new class_2338(cx + bx, by, cz + bz);
                                double dist = mc.field_1724.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5);
                                if (dist > range.getValue() * range.getValue()) continue;
                                class_2248 block = mc.field_1687.method_8320(pos).method_26204();
                                String blockName = class_7923.field_41175.method_10221(block).toString();
                                if (blocksToHighlight.contains(blockName)) {
                                    renderBlocks.put(pos.method_10062(), mc.field_1687.method_8320(pos));
                                    if (notifyInChat.isValue() && !notifiedBlocks.contains(pos)) {
                                        notifyBlockFound(pos, blockName);
                                        notifiedBlocks.add(pos);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            lastScanTime = currentTime;
            checkCounter = 0;
        }
        if (checkCounter % 5 == 0) {
            int nearChunkRange = 1;
            for (int x = -nearChunkRange; x <= nearChunkRange; x++) {
                for (int z = -nearChunkRange; z <= nearChunkRange; z++) {
                    int chunkX = (playerPos.method_10263() >> 4) + x;
                    int chunkZ = (playerPos.method_10260() >> 4) + z;
                    if (!mc.field_1687.method_2935().method_12123(chunkX, chunkZ)) continue;
                    class_2818 chunk = mc.field_1687.method_2935().method_21730(chunkX, chunkZ);
                    if (chunk == null) continue;
                    int cx = chunk.method_12004().field_9181 << 4;
                    int cz = chunk.method_12004().field_9180 << 4;
                    for (int bx = 0; bx < 16; bx++) {
                        for (int bz = 0; bz < 16; bz++) {
                            int minY = Math.max(mc.field_1687.method_31607(), playerPos.method_10264() - 24);
                            int maxY = Math.min(mc.field_1687.method_8624(class_2902.class_2903.field_13202, cx + bx, cz + bz), playerPos.method_10264() + 24);
                            for (int by = minY; by <= maxY; by++) {
                                class_2338 pos = new class_2338(cx + bx, by, cz + bz);
                                double dist = mc.field_1724.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5);
                                if (dist > 4 * 4) continue;
                                class_2248 block = mc.field_1687.method_8320(pos).method_26204();
                                String blockName = class_7923.field_41175.method_10221(block).toString();
                                if (blocksToHighlight.contains(blockName) && !renderBlocks.containsKey(pos)) {
                                    renderBlocks.put(pos.method_10062(), mc.field_1687.method_8320(pos));
                                    if (notifyInChat.isValue() && !notifiedBlocks.contains(pos)) {
                                        notifyBlockFound(pos, blockName);
                                        notifiedBlocks.add(pos);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (checkCounter % 60 == 0) {
            renderBlocks.entrySet().removeIf(entry -> {
                class_2338 pos = entry.getKey();
                class_2248 block = mc.field_1687.method_8320(pos).method_26204();
                String blockName = class_7923.field_41175.method_10221(block).toString();
                boolean shouldRemove = !blocksToHighlight.contains(blockName);
                if (shouldRemove) {
                    notifiedBlocks.remove(pos);
                }
                return shouldRemove;
            });
        }
        checkCounter++;
        renderBlocks.forEach((pos, blockState) -> {
            Render3D.drawBox(new class_238(pos), color.getColor(), 1);
        });
    }

    private void notifyBlockFound(class_2338 pos, String blockName) {
        if (mc.field_1724 != null) {
            ChatMessage.brandmessage("Найден блок " + blockName + " -> " + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260());
        }
    }
}