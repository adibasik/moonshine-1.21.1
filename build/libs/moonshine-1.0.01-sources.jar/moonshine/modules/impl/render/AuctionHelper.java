package moonshine.modules.impl.render;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.HandledScreenEvent;
import moonshine.events.impl.PacketEvent;
import moonshine.events.impl.TickEvent;
import moonshine.modules.module.ModuleStructure;
import moonshine.modules.module.category.ModuleCategory;
import moonshine.modules.module.setting.implement.BooleanSetting;
import moonshine.screens.clickgui.impl.autobuy.AuctionUtils;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2653;
import net.minecraft.class_332;
import net.minecraft.class_476;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AuctionHelper extends ModuleStructure {

    final BooleanSetting filterThorns = new BooleanSetting("Фильтр шипов", "Не показывать броню с шипами")
            .setValue(true);

    final BooleanSetting showPricePerItem = new BooleanSetting("Цена за штуку", "Учитывать цену за 1 предмет")
            .setValue(false);

    class_1735 firstSlot = null;
    class_1735 secondSlot = null;
    class_1735 thirdSlot = null;

    boolean needUpdate = false;
    int updateDelay = 0;

    static final int GREEN_COLOR = 0xFF00FF00;
    static final int ORANGE_COLOR = 0xFFFF8C00;
    static final int RED_COLOR = 0xFFFF3333;

    public AuctionHelper() {
        super("AuctionHelper", "Auction Helper", ModuleCategory.RENDER);
        settings(filterThorns, showPricePerItem);
    }

    @Override
    public void activate() {
        firstSlot = null;
        secondSlot = null;
        thirdSlot = null;
        needUpdate = false;
        updateDelay = 0;
    }

    @Override
    public void deactivate() {
        firstSlot = null;
        secondSlot = null;
        thirdSlot = null;
    }

    @EventHandler
    public void onPacket(PacketEvent e) {
        if (e.getPacket() instanceof class_2653) {
            needUpdate = true;
            updateDelay = 2;
        }
    }

    @EventHandler
    public void onTick(TickEvent e) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (updateDelay > 0) {
            updateDelay--;
            return;
        }

        if (needUpdate && mc.field_1755 instanceof class_476 screen) {
            updateSlots(screen);
            needUpdate = false;
        }
    }

    private void updateSlots(class_476 screen) {
        List<SlotData> validSlots = new ArrayList<>();

        for (class_1735 slot : screen.method_17577().field_7761) {
            class_1799 stack = slot.method_7677();
            if (stack.method_7960()) continue;

            int price = AuctionUtils.getPrice(stack);
            if (price <= 0) continue;

            if (filterThorns.isValue() && AuctionUtils.isArmorItem(stack) && AuctionUtils.hasThornsEnchantment(stack)) {
                continue;
            }

            int effectivePrice = showPricePerItem.isValue() && stack.method_7947() > 1
                    ? price / stack.method_7947()
                    : price;

            validSlots.add(new SlotData(slot, effectivePrice));
        }

        validSlots.sort(Comparator.comparingInt(data -> data.price));

        firstSlot = validSlots.size() > 0 ? validSlots.get(0).slot : null;
        secondSlot = validSlots.size() > 1 ? validSlots.get(1).slot : null;
        thirdSlot = validSlots.size() > 2 ? validSlots.get(2).slot : null;
    }

    @EventHandler
    public void onHandledScreen(HandledScreenEvent e) {
        if (mc.field_1724 == null) return;
        if (!(mc.field_1755 instanceof class_476 screen)) return;

        class_332 context = e.getDrawContext();

        int offsetX = (screen.field_22789 - e.getBackgroundWidth()) / 2;
        int offsetY = (screen.field_22790 - e.getBackgroundHeight()) / 2;

        highlightSlot(context, firstSlot, offsetX, offsetY, getBlinkingColor(GREEN_COLOR));
        highlightSlot(context, secondSlot, offsetX, offsetY, getBlinkingColor(ORANGE_COLOR));
        highlightSlot(context, thirdSlot, offsetX, offsetY, getBlinkingColor(RED_COLOR));
    }

    private int getBlinkingColor(int color) {
        float alpha = (float) Math.abs(Math.sin(System.currentTimeMillis() / 800.0 * Math.PI));
        alpha = 0.1f + alpha * 0.4f;

        int a = (int) (((color >> 24) & 0xFF) * alpha);
        if (a < 50) a = 50;

        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;

        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private void highlightSlot(class_332 context, class_1735 slot, int offsetX, int offsetY, int color) {
        if (slot == null) return;

        int x1 = offsetX + slot.field_7873;
        int y1 = offsetY + slot.field_7872;
        int x2 = x1 + 16;
        int y2 = y1 + 16;

        context.method_25294(x1, y1, x2, y2, color);
    }

    private record SlotData(class_1735 slot, int price) {}
}