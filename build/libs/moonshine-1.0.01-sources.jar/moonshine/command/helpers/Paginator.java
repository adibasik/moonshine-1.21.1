package moonshine.command.helpers;

import moonshine.command.CommandManager;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_5250;
import java.util.List;
import java.util.function.Function;

import static moonshine.command.impl.HelpCommand.getLine;

/**
 *  © 2026 Copyright Moonshine Client 2.0
 *        All Rights Reserved ®
 */

public class Paginator<T> {

    private final List<T> items;
    private final int itemsPerPage;
    private int currentPage;

    public Paginator(List<T> items) {
        this(items, 8);
    }

    public Paginator(List<T> items, int itemsPerPage) {
        this.items = items;
        this.itemsPerPage = itemsPerPage;
        this.currentPage = 1;
    }

    public int getTotalPages() {
        return Math.max(1, (int) Math.ceil((double) items.size() / itemsPerPage));
    }

    public List<T> getCurrentPageItems() {
        int start = (currentPage - 1) * itemsPerPage;
        int end = Math.min(start + itemsPerPage, items.size());
        return items.subList(start, end);
    }

    public void setPage(int page) {
        this.currentPage = Math.max(1, Math.min(page, getTotalPages()));
    }

    public void display(
            Runnable header,
            Function<T, class_5250> itemFormatter,
            String commandPrefix
    ) {
        CommandManager manager = CommandManager.getInstance();

        if (header != null) {
            header.run();
        }

        for (T item : getCurrentPageItems()) {
            class_5250 formatted = itemFormatter.apply(item);
            manager.sendRaw(formatted);
        }

        if (getTotalPages() > 1) {
            displayNavigation(manager, commandPrefix);
        } else {
            manager.sendRaw(class_2561.method_43470(getLine()));
        }
    }

    private void displayNavigation(CommandManager manager, String commandPrefix) {
        manager.sendRaw(class_2561.method_43470(getLine()));

        class_5250 navigation = class_2561.method_43470("");

        if (currentPage > 1) {
            class_5250 prevButton = class_2561.method_43470("§8[§b◄ Назад§8]");
            String prevCommand = commandPrefix + " " + (currentPage - 1);
            prevButton.method_10862(prevButton.method_10866()
                    .method_10949(new class_2568.class_10613(
                            class_2561.method_43470("§7Страница " + (currentPage - 1))))
                    .method_10958(new class_2558.class_10609(prevCommand)));
            navigation.method_10852(prevButton);
        } else {
            navigation.method_10852(class_2561.method_43470("§8[§7◄ Назад§8]"));
        }

        navigation.method_10852(class_2561.method_43470(" §7Страница §b" + currentPage + "§7/§b" + getTotalPages() + " "));

        if (currentPage < getTotalPages()) {
            class_5250 nextButton = class_2561.method_43470("§8[§bВперёд ►§8]");
            String nextCommand = commandPrefix + " " + (currentPage + 1);
            nextButton.method_10862(nextButton.method_10866()
                    .method_10949(new class_2568.class_10613(
                            class_2561.method_43470("§7Страница " + (currentPage + 1))))
                    .method_10958(new class_2558.class_10609(nextCommand)));
            navigation.method_10852(nextButton);
        } else {
            navigation.method_10852(class_2561.method_43470("§8[§7Вперёд ►§8]"));
        }

        manager.sendRaw(navigation);
    }

    public static <T> void paginate(
            String[] args,
            Paginator<T> paginator,
            Runnable header,
            Function<T, class_5250> itemFormatter,
            String commandPrefix
    ) {
        if (args.length > 0) {
            try {
                int page = Integer.parseInt(args[0]);
                paginator.setPage(page);
            } catch (NumberFormatException ignored) {
            }
        }

        paginator.display(header, itemFormatter, commandPrefix);
    }
}