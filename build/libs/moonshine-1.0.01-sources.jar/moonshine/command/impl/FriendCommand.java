package moonshine.command.impl;

import moonshine.command.Command;
import moonshine.command.CommandManager;
import moonshine.command.helpers.Paginator;
import moonshine.command.helpers.TabCompleteHelper;
import moonshine.util.repository.friend.FriendUtils;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

import static moonshine.command.impl.HelpCommand.getLine;

public class FriendCommand extends Command {

    public FriendCommand() {
        super("friend", "Управление списком друзей", "f", "friends");
    }

    @Override
    public void execute(String label, String[] args) {
        CommandManager manager = CommandManager.getInstance();

        String arg = args.length > 0 ? args[0].toLowerCase(Locale.US) : "list";

        switch (arg) {
            case "add" -> {
                if (args.length < 2) {
                    logDirect("Использование: friend add <name>", class_124.field_1061);
                    return;
                }
                String name = args[1];
                if (FriendUtils.isFriend(name)) {
                    logDirect(String.format("Игрок %s уже в списке друзей!", name), class_124.field_1061);
                    return;
                }
                FriendUtils.addFriendAndSave(name);
                logDirect(String.format("Игрок %s добавлен в друзья!", name), class_124.field_1060);
            }
            case "remove", "del", "delete" -> {
                if (args.length < 2) {
                    logDirect("Использование: friend remove <name>", class_124.field_1061);
                    return;
                }
                String name = args[1];
                if (!FriendUtils.isFriend(name)) {
                    logDirect(String.format("Игрок %s не найден в списке друзей!", name), class_124.field_1061);
                    return;
                }
                FriendUtils.removeFriendAndSave(name);
                logDirect(String.format("Игрок %s удален из друзей!", name), class_124.field_1060);
            }
            case "clear" -> {
                int count = FriendUtils.size();
                FriendUtils.clearAndSave();
                logDirect(String.format("Список друзей очищен! Удалено: %d", count), class_124.field_1060);
            }
            case "list" -> {
                int page = 1;
                if (args.length > 1) {
                    try {
                        page = Integer.parseInt(args[1]);
                    } catch (NumberFormatException ignored) {}
                }

                List<String> friends = FriendUtils.getFriendNames();

                if (friends.isEmpty()) {
                    logDirect("Список друзей пуст!", class_124.field_1061);
                    return;
                }

                Paginator<String> paginator = new Paginator<>(friends);
                paginator.setPage(page);

                paginator.display(
                        () -> {
                            logDirectRaw(class_2561.method_43470(getLine()));
                            logDirect("§f§lСПИСОК ДРУЗЕЙ §7(" + friends.size() + ")");
                            logDirectRaw(class_2561.method_43470(getLine()));
                        },
                        friend -> {
                            class_5250 nameComponent = class_2561.method_43470("  §a● §f" + friend);

                            class_5250 hoverText = class_2561.method_43470("§7Нажмите чтобы удалить §f" + friend + " §7из друзей");
                            String removeCommand = manager.getPrefix() + "friend remove " + friend;

                            nameComponent.method_10862(nameComponent.method_10866()
                                    .method_10949(new class_2568.class_10613(hoverText))
                                    .method_10958(new class_2558.class_10609(removeCommand)));

                            return nameComponent;
                        },
                        manager.getPrefix() + label + " list"
                );
            }
            default -> {
                logDirectRaw(class_2561.method_43470(getLine()));
                logDirect("§f§lУПРАВЛЕНИЕ ДРУЗЬЯМИ");
                logDirectRaw(class_2561.method_43470(getLine()));
                logDirect("§7> friend add <name> §8- §fДобавить игрока в друзья");
                logDirect("§7> friend remove <name> §8- §fУдалить игрока из друзей");
                logDirect("§7> friend list §8- §fПоказать список друзей");
                logDirect("§7> friend clear §8- §fОчистить список друзей");
                logDirectRaw(class_2561.method_43470(getLine()));
            }
        }
    }

    @Override
    public Stream<String> tabComplete(String label, String[] args) {
        if (args.length == 1) {
            return new TabCompleteHelper()
                    .append("add", "remove", "list", "clear")
                    .sortAlphabetically()
                    .filterPrefix(args[0])
                    .stream();
        }
        if (args.length == 2) {
            String action = args[0].toLowerCase();
            if (action.equals("add")) {
                return new TabCompleteHelper()
                        .append(getOnlinePlayers().toArray(new String[0]))
                        .filterPrefix(args[1])
                        .stream();
            }
            if (action.equals("remove") || action.equals("del") || action.equals("delete")) {
                return new TabCompleteHelper()
                        .append(FriendUtils.getFriendNames().toArray(new String[0]))
                        .filterPrefix(args[1])
                        .stream();
            }
        }
        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Управление списком друзей";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "Команда для управления списком друзей",
                "Использование:",
                "> friend add <name> - Добавить игрока в друзья",
                "> friend remove <name> - Удалить игрока из друзей",
                "> friend list - Показать список друзей",
                "> friend clear - Очистить список друзей"
        );
    }

    private List<String> getOnlinePlayers() {
        List<String> players = new ArrayList<>();
        class_310 mc = class_310.method_1551();
        if (mc.method_1562() != null) {
            for (class_640 entry : mc.method_1562().method_2880()) {
                String name = entry.method_2966().name();
                if (!FriendUtils.isFriend(name)) {
                    players.add(name);
                }
            }
        }
        return players;
    }
}