package moonshine.command.impl;

import moonshine.command.Command;
import moonshine.command.CommandManager;
import moonshine.command.helpers.Paginator;
import moonshine.command.helpers.TabCompleteHelper;
import moonshine.util.repository.staff.StaffUtils;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

import static moonshine.command.impl.HelpCommand.getLine;

public class StaffCommand extends Command {

    public StaffCommand() {
        super("staff", "Управление списком персонала");
    }

    @Override
    public void execute(String label, String[] args) {
        CommandManager manager = CommandManager.getInstance();

        String action = args.length > 0 ? args[0].toLowerCase(Locale.US) : "list";

        switch (action) {
            case "add" -> {
                if (args.length < 2) {
                    logDirect("Использование: staff add <name>", class_124.field_1061);
                    return;
                }
                String name = args[1];
                if (StaffUtils.isStaff(name)) {
                    logDirect(String.format("Игрок %s уже в списке персонала!", name), class_124.field_1061);
                    return;
                }
                StaffUtils.addStaffAndSave(name);
                logDirect(String.format("Игрок %s добавлен в персонал!", name), class_124.field_1060);
            }
            case "remove", "del", "delete" -> {
                if (args.length < 2) {
                    logDirect("Использование: staff remove <name>", class_124.field_1061);
                    return;
                }
                String name = args[1];
                if (!StaffUtils.isStaff(name)) {
                    logDirect(String.format("Игрок %s не найден в списке персонала!", name), class_124.field_1061);
                    return;
                }
                StaffUtils.removeStaffAndSave(name);
                logDirect(String.format("Игрок %s удален из персонала!", name), class_124.field_1060);
            }
            case "clear" -> {
                int count = StaffUtils.size();
                StaffUtils.clearAndSave();
                logDirect(String.format("Список персонала очищен! Удалено: %d", count), class_124.field_1060);
            }
            case "list" -> {
                int page = 1;
                if (args.length > 1) {
                    try {
                        page = Integer.parseInt(args[1]);
                    } catch (NumberFormatException ignored) {}
                }

                List<String> staff = StaffUtils.getStaffNames();

                if (staff.isEmpty()) {
                    logDirect("Список персонала пуст!", class_124.field_1061);
                    return;
                }

                Paginator<String> paginator = new Paginator<>(staff);
                paginator.setPage(page);

                paginator.display(
                        () -> {
                            logDirectRaw(class_2561.method_43470(getLine()));
                            logDirect("§f§lСПИСОК ПЕРСОНАЛА §7(" + staff.size() + ")");
                            logDirectRaw(class_2561.method_43470(getLine()));
                        },
                        staffName -> {
                            class_5250 nameComponent = class_2561.method_43470("  §c● §f" + staffName);

                            class_5250 hoverText = class_2561.method_43470("§7Нажмите чтобы удалить §f" + staffName + " §7из персонала");
                            String removeCommand = manager.getPrefix() + "staff remove " + staffName;

                            nameComponent.method_10862(nameComponent.method_10866()
                                    .method_10949(new class_2568.class_10613(hoverText))
                                    .method_10958(new class_2558.class_10609(removeCommand)));

                            return nameComponent;
                        },
                        manager.getPrefix() + label + " list"
                );
            }
            default -> {
                logDirectRaw(class_2561.method_43470(getLine()));
                logDirect("§f§lУПРАВЛЕНИЕ ПЕРСОНАЛОМ");
                logDirectRaw(class_2561.method_43470(getLine()));
                logDirect("§7> staff add <name> §8- §fДобавить игрока в персонал");
                logDirect("§7> staff remove <name> §8- §fУдалить игрока из персонала");
                logDirect("§7> staff list §8- §fПоказать список персонала");
                logDirect("§7> staff clear §8- §fОчистить список персонала");
                logDirectRaw(class_2561.method_43470(getLine()));
            }
        }
    }

    @Override
    public Stream<String> tabComplete(String label, String[] args) {
        if (args.length == 1) {
            return new TabCompleteHelper()
                    .append("add", "remove", "list", "clear")
                    .sortAlphabetically()
                    .filterPrefix(args[0])
                    .stream();
        }
        if (args.length == 2) {
            String action = args[0].toLowerCase();
            if (action.equals("add")) {
                return new TabCompleteHelper()
                        .append(getOnlinePlayers().toArray(new String[0]))
                        .filterPrefix(args[1])
                        .stream();
            }
            if (action.equals("remove") || action.equals("del") || action.equals("delete")) {
                return new TabCompleteHelper()
                        .append(StaffUtils.getStaffNames().toArray(new String[0]))
                        .filterPrefix(args[1])
                        .stream();
            }
        }
        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Управление списком персонала";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "Команда для управления списком персонала сервера",
                "Использование:",
                "> staff add <name> - Добавить игрока в персонал",
                "> staff remove <name> - Удалить игрока из персонала",
                "> staff list - Показать список персонала",
                "> staff clear - Очистить список персонала"
        );
    }

    private List<String> getOnlinePlayers() {
        List<String> players = new ArrayList<>();
        class_310 mc = class_310.method_1551();
        if (mc.method_1562() != null) {
            for (class_640 entry : mc.method_1562().method_2880()) {
                String name = entry.method_2966().name();
                if (!StaffUtils.isStaff(name)) {
                    players.add(name);
                }
            }
        }
        return players;
    }
}