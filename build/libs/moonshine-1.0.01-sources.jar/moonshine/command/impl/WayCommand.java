package moonshine.command.impl;

import moonshine.IMinecraft;
import moonshine.command.Command;
import moonshine.command.CommandManager;
import moonshine.command.helpers.Paginator;
import moonshine.command.helpers.TabCompleteHelper;
import moonshine.util.repository.way.Way;
import moonshine.util.repository.way.WayRepository;
import net.minecraft.class_124;
import net.minecraft.class_2338;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_5250;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

import static moonshine.command.impl.HelpCommand.getLine;

public class WayCommand extends Command implements IMinecraft {

    public WayCommand() {
        super("way", "Управление точками на карте", "waypoint", "wp");
    }

    @Override
    public void execute(String label, String[] args) {
        CommandManager manager = CommandManager.getInstance();
        WayRepository repository = WayRepository.getInstance();

        if (mc.field_1724 == null) {
            logDirect("Вы должны быть в игре!", class_124.field_1061);
            return;
        }

        String action = args.length > 0 ? args[0].toLowerCase(Locale.US) : "list";

        switch (action) {
            case "add" -> {
                if (args.length < 2) {
                    logDirect("Использование: way add <name> [x] [y] [z]", class_124.field_1061);
                    return;
                }

                String name = args[1];
                class_2338 pos;

                if (args.length >= 5) {
                    try {
                        int x = Integer.parseInt(args[2]);
                        int y = Integer.parseInt(args[3]);
                        int z = Integer.parseInt(args[4]);
                        pos = new class_2338(x, y, z);
                    } catch (NumberFormatException e) {
                        logDirect("Неверные координаты!", class_124.field_1061);
                        return;
                    }
                } else {
                    pos = mc.field_1724.method_24515();
                }

                String server = repository.getCurrentServer();
                if (server.isEmpty()) {
                    logDirect("Не удалось определить сервер!", class_124.field_1061);
                    return;
                }

                if (repository.hasWay(name)) {
                    logDirect(String.format("Точка с именем %s уже существует!", name), class_124.field_1061);
                    return;
                }

                repository.addWayAndSave(name, pos, server);

                logDirect(String.format("§aТочка §f%s §aдобавлена на координатах §f%d %d %d",
                        name, pos.method_10263(), pos.method_10264(), pos.method_10260()), class_124.field_1060);
            }
            case "remove", "del", "delete" -> {
                if (args.length < 2) {
                    logDirect("Использование: way remove <name>", class_124.field_1061);
                    return;
                }

                String name = args[1];

                if (!repository.hasWay(name)) {
                    logDirect(String.format("Точка %s не найдена!", name), class_124.field_1061);
                    return;
                }

                repository.deleteWayAndSave(name);
                logDirect(String.format("Точка %s удалена!", name), class_124.field_1060);
            }
            case "clear" -> {
                String server = repository.getCurrentServer();
                int count = 0;

                List<Way> toRemove = repository.getWayList().stream()
                        .filter(way -> way.server().equalsIgnoreCase(server))
                        .toList();

                for (Way way : toRemove) {
                    repository.deleteWay(way.name());
                    count++;
                }

                if (count > 0) {
                    moonshine.util.config.impl.way.WayConfig.getInstance().save();
                }

                logDirect(String.format("Удалено точек для этого сервера: %d", count), class_124.field_1060);
            }
            case "clearall" -> {
                int count = repository.size();
                repository.clearListAndSave();
                logDirect(String.format("Все точки удалены! Удалено: %d", count), class_124.field_1060);
            }
            case "list" -> {
                int page = 1;
                if (args.length > 1) {
                    try {
                        page = Integer.parseInt(args[1]);
                    } catch (NumberFormatException ignored) {}
                }

                String server = repository.getCurrentServer();
                List<Way> serverWays = repository.getWayList().stream()
                        .filter(way -> way.server().equalsIgnoreCase(server))
                        .toList();

                if (serverWays.isEmpty()) {
                    logDirect("Нет точек для этого сервера!", class_124.field_1061);
                    return;
                }

                Paginator<Way> paginator = new Paginator<>(serverWays);
                paginator.setPage(page);

                paginator.display(
                        () -> {
                            logDirectRaw(class_2561.method_43470(getLine()));
                            logDirect("§f§lТОЧКИ §7(" + serverWays.size() + ")");
                            logDirectRaw(class_2561.method_43470(getLine()));
                        },
                        way -> {
                            String wayName = way.name();
                            class_2338 pos = way.pos();
                            double distance = mc.field_1724.method_73189().method_1022(pos.method_46558());

                            class_5250 component = class_2561.method_43470("  §d● §f" + wayName)
                                    .method_10852(class_2561.method_43470(String.format(" §8[§7%d %d %d§8]",
                                            pos.method_10263(), pos.method_10264(), pos.method_10260())))
                                    .method_10852(class_2561.method_43470(String.format(" §8(§7%.1fm§8)", distance)));

                            class_5250 hoverText = class_2561.method_43470("§7Нажмите чтобы удалить точку");
                            String removeCommand = manager.getPrefix() + "way remove " + wayName;

                            component.method_10862(component.method_10866()
                                    .method_10949(new class_2568.class_10613(hoverText))
                                    .method_10958(new class_2558.class_10609(removeCommand)));

                            return component;
                        },
                        manager.getPrefix() + label + " list"
                );
            }
            default -> {
                logDirectRaw(class_2561.method_43470(getLine()));
                logDirect("§f§lУПРАВЛЕНИЕ ТОЧКАМИ");
                logDirectRaw(class_2561.method_43470(getLine()));
                logDirect("§7> way add <name> [x y z] §8- §fДобавить точку");
                logDirect("§7> way remove <name> §8- §fУдалить точку");
                logDirect("§7> way list §8- §fПоказать список точек");
                logDirect("§7> way clear §8- §fУдалить точки для этого сервера");
                logDirect("§7> way clearall §8- §fУдалить все точки");
                logDirectRaw(class_2561.method_43470(getLine()));
            }
        }
    }

    @Override
    public Stream<String> tabComplete(String label, String[] args) {
        WayRepository repository = WayRepository.getInstance();

        if (args.length == 1) {
            return new TabCompleteHelper()
                    .append("add", "remove", "list", "clear", "clearall")
                    .sortAlphabetically()
                    .filterPrefix(args[0])
                    .stream();
        }
        if (args.length == 2) {
            String action = args[0].toLowerCase();
            if (action.equals("remove") || action.equals("del") || action.equals("delete")) {
                String server = repository.getCurrentServer();
                return new TabCompleteHelper()
                        .append(repository.getWayNamesForServer(server).toArray(new String[0]))
                        .filterPrefix(args[1])
                        .stream();
            }
        }
        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Управление точками на карте";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "Команда для управления waypoints (точками на карте)",
                "Точки отображаются на экране с расстоянием до них",
                "Использование:",
                "> way add <name> [x y z] - Добавить точку (без координат - текущая позиция)",
                "> way remove <name> - Удалить точку",
                "> way list - Показать список точек для текущего сервера",
                "> way clear - Удалить все точки для текущего сервера",
                "> way clearall - Удалить все точки"
        );
    }
}