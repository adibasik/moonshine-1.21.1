package moonshine.command.impl;

import moonshine.command.Command;
import moonshine.command.CommandManager;
import moonshine.command.helpers.Paginator;
import moonshine.command.helpers.TabCompleteHelper;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class HelpCommand extends Command {

    public HelpCommand() {
        super("help", "Показывает список всех доступных команд");
    }

    @Override
    public void execute(String label, String[] args) {
        CommandManager manager = CommandManager.getInstance();

        if (args.length == 0 || isInteger(args[0])) {
            int page = 1;
            if (args.length > 0 && isInteger(args[0])) {
                page = Integer.parseInt(args[0]);
            }

            List<Command> commands = manager.getCommands().stream()
                    .filter(cmd -> !cmd.hiddenFromHelp())
                    .collect(Collectors.toList());

            Paginator<Command> paginator = new Paginator<>(commands);
            paginator.setPage(page);

            paginator.display(
                    () -> {
                        logDirectRaw(class_2561.method_43470(getLine()));
                        logDirect("§f§lДОСТУПНЫЕ КОМАНДЫ");
                        logDirectRaw(class_2561.method_43470(getLine()));
                    },
                    command -> {
                        String name = command.getName();
                        String fullName = manager.getPrefix() + name;

                        class_5250 shortDescComponent = class_2561.method_43470(" §8- §7" + command.getShortDesc());

                        class_5250 hoverComponent = class_2561.method_43470("");
                        hoverComponent.method_10862(hoverComponent.method_10866().method_10977(class_124.field_1080));
                        hoverComponent.method_10852(class_2561.method_43470(fullName).method_27692(class_124.field_1068));
                        hoverComponent.method_27693("\n§7" + command.getShortDesc());
                        hoverComponent.method_27693("\n\n§8Нажмите, чтобы просмотреть полную справку о команде");

                        String clickCommand = manager.getPrefix() + String.format("%s %s", label, name);

                        class_5250 component = class_2561.method_43470("§f" + fullName);
                        component.method_10852(shortDescComponent);
                        component.method_10862(component.method_10866()
                                .method_10949(new class_2568.class_10613(hoverComponent))
                                .method_10958(new class_2558.class_10609(clickCommand)));

                        return component;
                    },
                    manager.getPrefix() + label
            );
        } else {
            String commandName = args[0].toLowerCase();
            Command command = manager.getCommand(commandName);

            if (command == null) {
                logDirect("Команда '" + commandName + "' не найдена!", class_124.field_1061);
                return;
            }

            logDirectRaw(class_2561.method_43470(getLine()));
            logDirect("§f§l" + command.getName().toUpperCase());
            logDirectRaw(class_2561.method_43470(getLine()));

            List<String> desc = command.getLongDesc();
            boolean firstLine = true;

            for (String line : desc) {
                if (line.isEmpty()) {
                    continue;
                }
                logDirect("§7" + line);
                if (firstLine) {
                    logDirectRaw(class_2561.method_43470(getLine()));
                    firstLine = false;
                }
            }

            logDirectRaw(class_2561.method_43470(getLine()));
        }
    }

    @Override
    public Stream<String> tabComplete(String label, String[] args) {
        if (args.length == 1) {
            return new TabCompleteHelper()
                    .filterPrefix(args[0])
                    .addCommands(CommandManager.getInstance())
                    .stream();
        }
        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Просмотр всех доступных команд";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "С помощью этой команды можно просмотреть подробную справочную информацию о том, как использовать определенные команды",
                "Использование:",
                "> help - Перечисляет все команды и их краткие описания.",
                "> help <command> - Отображение справочной информации по конкретной команде."
        );
    }

    private boolean isInteger(String s) {
        try {
            Integer.parseInt(s);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static String getLine() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1772 == null) {
            return "§8§m                    ";
        }

        int chatWidth = mc.field_1690.method_42556().method_41753().intValue();
        int scaledWidth = (int) (chatWidth * 280 + 40);

        int dashWidth = mc.field_1772.method_1727("-");
        if (dashWidth <= 0) {
            dashWidth = 4;
        }

        int dashCount = (scaledWidth / dashWidth) - 2;
        dashCount = Math.max(10, Math.min(dashCount, 80));

        StringBuilder sb = new StringBuilder("§8§m");
        for (int i = 0; i < dashCount; i++) {
            sb.append("-");
        }

        return sb.toString();
    }
}