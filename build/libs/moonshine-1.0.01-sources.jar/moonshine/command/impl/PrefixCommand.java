package moonshine.command.impl;

import moonshine.command.Command;
import moonshine.command.CommandManager;
import moonshine.util.config.impl.prefix.PrefixConfig;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static moonshine.command.impl.HelpCommand.getLine;

public class PrefixCommand extends Command {

    public PrefixCommand() {
        super("prefix", "Изменение префикса команд");
    }

    @Override
    public void execute(String label, String[] args) {
        CommandManager manager = CommandManager.getInstance();

        if (args.length == 0) {
            logDirectRaw(class_2561.method_43470(getLine()));
            logDirect("§f§lПРЕФИКС КОМАНД");
            logDirectRaw(class_2561.method_43470(getLine()));
            logDirect("§7Текущий префикс: §f" + manager.getPrefix());
            logDirect("§7> prefix set <symbol> §8- §fУстановить новый префикс");
            logDirectRaw(class_2561.method_43470(getLine()));
            return;
        }

        String action = args[0].toLowerCase();

        if (action.equals("set")) {
            if (args.length < 2) {
                logDirect("Использование: prefix set <symbol>", class_124.field_1061);
                return;
            }

            String newPrefix = args[1];

            if (newPrefix.length() > 3) {
                logDirect("Префикс не может быть длиннее 3 символов!", class_124.field_1061);
                return;
            }

            if (newPrefix.contains(" ")) {
                logDirect("Префикс не может содержать пробелы!", class_124.field_1061);
                return;
            }

            PrefixConfig.getInstance().setPrefixAndSave(newPrefix);
            logDirect(String.format("§aПрефикс изменен на: §f%s", newPrefix), class_124.field_1060);
            logDirect(String.format("§7Теперь команды вводятся как: §f%shelp", newPrefix), class_124.field_1060);
        } else {
            logDirect("Использование: prefix set <symbol>", class_124.field_1061);
        }
    }

    @Override
    public Stream<String> tabComplete(String label, String[] args) {
        if (args.length == 1) {
            return Stream.of("set").filter(s -> s.startsWith(args[0].toLowerCase()));
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("set")) {
            return Stream.of(".", "!", "$", "#", "-", "/").filter(s -> s.startsWith(args[1]));
        }
        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Изменение префикса команд";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "Команда для изменения префикса команд в чите",
                "Использование:",
                "> prefix - Показать текущий префикс",
                "> prefix set <symbol> - Установить новый префикс"
        );
    }
}