package moonshine.command.impl;

import moonshine.command.Command;
import moonshine.command.CommandManager;
import moonshine.command.helpers.Paginator;
import moonshine.command.helpers.TabCompleteHelper;
import moonshine.util.repository.macro.Macro;
import moonshine.util.repository.macro.MacroRepository;
import moonshine.util.string.KeyHelper;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_5250;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

import static moonshine.command.impl.HelpCommand.getLine;

public class MacroCommand extends Command {

    public MacroCommand() {
        super("macro", "Управление макросами", "macros");
    }

    @Override
    public void execute(String label, String[] args) {
        CommandManager manager = CommandManager.getInstance();
        MacroRepository macroRepository = MacroRepository.getInstance();

        String action = args.length > 0 ? args[0].toLowerCase(Locale.US) : "list";

        switch (action) {
            case "add" -> {
                if (args.length < 4) {
                    logDirect("Использование: macro add <key> <name> <message>", class_124.field_1061);
                    return;
                }

                String keyName = args[1];
                int key = KeyHelper.getKeyCode(keyName);

                if (key == -1) {
                    logDirect(String.format("Неизвестная клавиша: %s", keyName), class_124.field_1061);
                    return;
                }

                String name = args[2];

                StringBuilder messageBuilder = new StringBuilder();
                for (int i = 3; i < args.length; i++) {
                    if (i > 3) messageBuilder.append(" ");
                    messageBuilder.append(args[i]);
                }
                String message = messageBuilder.toString();

                if (macroRepository.hasMacro(name)) {
                    logDirect(String.format("Макрос с именем %s уже существует!", name), class_124.field_1061);
                    return;
                }

                macroRepository.addMacroAndSave(name, message, key);

                logDirect(String.format("§aДобавлен макрос §f%s §aна клавишу §f%s §aс командой §f%s",
                        name, KeyHelper.getKeyName(key).toLowerCase(), message), class_124.field_1060);
            }
            case "remove", "del", "delete" -> {
                if (args.length < 2) {
                    logDirect("Использование: macro remove <name>", class_124.field_1061);
                    return;
                }

                String name = args[1];

                if (!macroRepository.hasMacro(name)) {
                    logDirect(String.format("Макрос %s не найден!", name), class_124.field_1061);
                    return;
                }

                macroRepository.deleteMacroAndSave(name);
                logDirect(String.format("Макрос %s удален!", name), class_124.field_1060);
            }
            case "clear" -> {
                int count = macroRepository.size();
                macroRepository.clearListAndSave();
                logDirect(String.format("Все макросы удалены! Удалено: %d", count), class_124.field_1060);
            }
            case "list" -> {
                int page = 1;
                if (args.length > 1) {
                    try {
                        page = Integer.parseInt(args[1]);
                    } catch (NumberFormatException ignored) {}
                }

                List<Macro> macros = macroRepository.getMacroList();

                if (macros.isEmpty()) {
                    logDirect("Список макросов пуст!", class_124.field_1061);
                    return;
                }

                Paginator<Macro> paginator = new Paginator<>(macros);
                paginator.setPage(page);

                paginator.display(
                        () -> {
                            logDirectRaw(class_2561.method_43470(getLine()));
                            logDirect("§f§lСПИСОК МАКРОСОВ §7(" + macros.size() + ")");
                            logDirectRaw(class_2561.method_43470(getLine()));
                        },
                        macro -> {
                            String macroName = macro.name();
                            String keyName = KeyHelper.getKeyName(macro.key()).toLowerCase();
                            String message = macro.message();

                            class_5250 component = class_2561.method_43470("  §e● §f" + macroName)
                                    .method_10852(class_2561.method_43470(" §8[§7" + keyName + "§8]"))
                                    .method_10852(class_2561.method_43470(" §8-> §7" + message));

                            class_5250 hoverText = class_2561.method_43470("§7Нажмите чтобы удалить макрос §f" + macroName);
                            String removeCommand = manager.getPrefix() + "macro remove " + macroName;

                            component.method_10862(component.method_10866()
                                    .method_10949(new class_2568.class_10613(hoverText))
                                    .method_10958(new class_2558.class_10609(removeCommand)));

                            return component;
                        },
                        manager.getPrefix() + label + " list"
                );
            }
            default -> {
                logDirectRaw(class_2561.method_43470(getLine()));
                logDirect("§f§lУПРАВЛЕНИЕ МАКРОСАМИ");
                logDirectRaw(class_2561.method_43470(getLine()));
                logDirect("§7> macro add <key> <name> <message> §8- §fДобавить макрос");
                logDirect("§7> macro remove <name> §8- §fУдалить макрос");
                logDirect("§7> macro list §8- §fПоказать список макросов");
                logDirect("§7> macro clear §8- §fУдалить все макросы");
                logDirectRaw(class_2561.method_43470(getLine()));
            }
        }
    }

    @Override
    public Stream<String> tabComplete(String label, String[] args) {
        if (args.length == 1) {
            return new TabCompleteHelper()
                    .append("add", "remove", "list", "clear")
                    .sortAlphabetically()
                    .filterPrefix(args[0])
                    .stream();
        }
        if (args.length == 2) {
            String action = args[0].toLowerCase();
            if (action.equals("add")) {
                return new TabCompleteHelper()
                        .append(KeyHelper.getAllKeyNames())
                        .filterPrefix(args[1])
                        .stream();
            }
            if (action.equals("remove") || action.equals("del") || action.equals("delete")) {
                return new TabCompleteHelper()
                        .append(MacroRepository.getInstance().getMacroNames().toArray(new String[0]))
                        .filterPrefix(args[1])
                        .stream();
            }
        }
        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Управление макросами";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "Команда для управления макросами",
                "Использование:",
                "> macro add <key> <name> <message> - Добавить макрос",
                "> macro remove <name> - Удалить макрос",
                "> macro list - Показать список макросов",
                "> macro clear - Удалить все макросы"
        );
    }
}