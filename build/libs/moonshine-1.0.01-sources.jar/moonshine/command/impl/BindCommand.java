package moonshine.command.impl;

import org.lwjgl.glfw.GLFW;
import moonshine.Initialization;
import moonshine.command.Command;
import moonshine.command.CommandManager;
import moonshine.command.helpers.Paginator;
import moonshine.command.helpers.TabCompleteHelper;
import moonshine.modules.module.ModuleRepository;
import moonshine.modules.module.ModuleStructure;
import moonshine.util.config.ConfigSystem;
import moonshine.util.config.impl.bind.BindConfig;
import moonshine.util.string.KeyHelper;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_5250;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static moonshine.command.impl.HelpCommand.getLine;

public class BindCommand extends Command {

    public BindCommand() {
        super("bind", "Управление биндами модулей", "b");
    }

    @Override
    public void execute(String label, String[] args) {
        CommandManager manager = CommandManager.getInstance();
        ModuleRepository repository = getModuleRepository();

        if (repository == null) {
            logDirect("Репозиторий модулей не найден!", class_124.field_1061);
            return;
        }

        String action = args.length > 0 ? args[0].toLowerCase(Locale.US) : "list";

        switch (action) {
            case "add" -> {
                if (args.length < 3) {
                    logDirect("Использование: bind add <module> <key>", class_124.field_1061);
                    return;
                }

                String moduleName = args[1];
                String keyName = args[2];

                ModuleStructure module = findModule(repository, moduleName);
                if (module == null) {
                    logDirect(String.format("Модуль %s не найден!", moduleName), class_124.field_1061);
                    return;
                }

                int key = KeyHelper.getKeyCode(keyName);
                if (key == -1) {
                    logDirect(String.format("Неизвестная клавиша: %s", keyName), class_124.field_1061);
                    return;
                }

                module.setKey(key);
                ConfigSystem.getInstance().save();

                logDirect(String.format("§aМодуль §f%s §aпривязан к клавише §f%s",
                        module.getName(), KeyHelper.getKeyName(key).toLowerCase()), class_124.field_1060);
            }
            case "remove", "del", "delete" -> {
                if (args.length < 2) {
                    logDirect("Использование: bind remove <module>", class_124.field_1061);
                    return;
                }

                String moduleName = args[1];
                ModuleStructure module = findModule(repository, moduleName);

                if (module == null) {
                    logDirect(String.format("Модуль %s не найден!", moduleName), class_124.field_1061);
                    return;
                }

                module.setKey(GLFW.GLFW_KEY_UNKNOWN);
                ConfigSystem.getInstance().save();

                logDirect(String.format("Бинд для модуля %s удален!", module.getName()), class_124.field_1060);
            }
            case "clear" -> {
                int count = 0;
                for (ModuleStructure module : repository.modules()) {
                    if (module.getKey() != GLFW.GLFW_KEY_UNKNOWN) {
                        module.setKey(GLFW.GLFW_KEY_UNKNOWN);
                        count++;
                    }
                }
                ConfigSystem.getInstance().save();
                logDirect(String.format("Все бинды модулей удалены! Удалено: %d", count), class_124.field_1060);
            }
            case "set" -> {
                if (args.length < 3) {
                    logDirect("Использование: bind set <target> <key>", class_124.field_1061);
                    logDirect("Доступные цели: Bind", class_124.field_1061);
                    return;
                }

                String target = args[1].toLowerCase(Locale.US);
                String keyName = args[2];

                int key = KeyHelper.getKeyCode(keyName);
                if (key == -1) {
                    logDirect(String.format("Неизвестная клавиша: %s", keyName), class_124.field_1061);
                    return;
                }

                if (target.equals("Bind")) {
                    BindConfig.getInstance().setKeyAndSave(key);
                    logDirect(String.format("§aКлавиша для Bind изменена на: §f%s",
                            KeyHelper.getKeyName(key).toLowerCase()), class_124.field_1060);
                } else {
                    logDirect(String.format("Неизвестная цель: %s", target), class_124.field_1061);
                }
            }
            case "list" -> {
                int page = 1;
                if (args.length > 1) {
                    try {
                        page = Integer.parseInt(args[1]);
                    } catch (NumberFormatException ignored) {}
                }

                List<ModuleStructure> boundModules = repository.modules().stream()
                        .filter(m -> m.getKey() != GLFW.GLFW_KEY_UNKNOWN && m.getKey() != -1)
                        .collect(Collectors.toList());

                if (boundModules.isEmpty()) {
                    logDirect("Нет модулей с биндами!", class_124.field_1061);
                    return;
                }

                Paginator<ModuleStructure> paginator = new Paginator<>(boundModules);
                paginator.setPage(page);

                paginator.display(
                        () -> {
                            logDirectRaw(class_2561.method_43470(getLine()));
                            logDirect("§f§lСПИСОК БИНДОВ §7(" + boundModules.size() + ")");
                            logDirectRaw(class_2561.method_43470(getLine()));
                        },
                        module -> {
                            String name = module.getName();
                            String keyName = KeyHelper.getKeyName(module.getKey()).toLowerCase();

                            class_5250 component = class_2561.method_43470("  §b● §f" + name)
                                    .method_10852(class_2561.method_43470(" §8[§7" + keyName + "§8]"));

                            class_5250 hoverText = class_2561.method_43470("§7Нажмите чтобы удалить бинд для §f" + name);
                            String removeCommand = manager.getPrefix() + "bind remove " + name;

                            component.method_10862(component.method_10866()
                                    .method_10949(new class_2568.class_10613(hoverText))
                                    .method_10958(new class_2558.class_10609(removeCommand)));

                            return component;
                        },
                        manager.getPrefix() + label + " list"
                );
            }
            default -> {
                logDirectRaw(class_2561.method_43470(getLine()));
                logDirect("§f§lУПРАВЛЕНИЕ БИНДАМИ");
                logDirectRaw(class_2561.method_43470(getLine()));
                logDirect("§7> bind add <module> <key> §8- §fПривязать модуль к клавише");
                logDirect("§7> bind remove <module> §8- §fУдалить бинд модуля");
                logDirect("§7> bind list §8- §fПоказать список биндов");
                logDirect("§7> bind clear §8- §fУдалить все бинды");
                logDirect("§7> bind set Bind <key> §8- §fИзменить клавишу Bind");
                logDirectRaw(class_2561.method_43470(getLine()));
            }
        }
    }

    @Override
    public Stream<String> tabComplete(String label, String[] args) {
        ModuleRepository repository = getModuleRepository();

        if (args.length == 1) {
            return new TabCompleteHelper()
                    .append("add", "remove", "list", "clear", "set")
                    .sortAlphabetically()
                    .filterPrefix(args[0])
                    .stream();
        }
        if (args.length == 2) {
            String action = args[0].toLowerCase();
            if (action.equals("add")) {
                return new TabCompleteHelper()
                        .append(getModuleNames(repository))
                        .filterPrefix(args[1])
                        .stream();
            }
            if (action.equals("remove") || action.equals("del") || action.equals("delete")) {
                return new TabCompleteHelper()
                        .append(getBoundModuleNames(repository))
                        .filterPrefix(args[1])
                        .stream();
            }
            if (action.equals("set")) {
                return new TabCompleteHelper()
                        .append("Bind")
                        .filterPrefix(args[1])
                        .stream();
            }
        }
        if (args.length == 3) {
            String action = args[0].toLowerCase();
            if (action.equals("add") || action.equals("set")) {
                return new TabCompleteHelper()
                        .append(KeyHelper.getAllKeyNames())
                        .filterPrefix(args[2])
                        .stream();
            }
        }
        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Управление биндами модулей";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "Команда для управления биндами модулей и GUI",
                "Использование:",
                "> bind add <module> <key> - Привязать модуль к клавише",
                "> bind remove <module> - Удалить бинд модуля",
                "> bind list - Показать список биндов",
                "> bind clear - Удалить все бинды",
                "> bind set Bind <key> - Изменить клавишу Bind"
        );
    }

    private ModuleRepository getModuleRepository() {
        Initialization instance = Initialization.getInstance();
        if (instance != null && instance.getManager() != null) {
            return instance.getManager().getModuleRepository();
        }
        return null;
    }

    private ModuleStructure findModule(ModuleRepository repository, String name) {
        return repository.modules().stream()
                .filter(m -> m.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    private String[] getModuleNames(ModuleRepository repository) {
        if (repository == null) return new String[0];
        return repository.modules().stream()
                .map(ModuleStructure::getName)
                .toArray(String[]::new);
    }

    private String[] getBoundModuleNames(ModuleRepository repository) {
        if (repository == null) return new String[0];
        return repository.modules().stream()
                .filter(m -> m.getKey() != GLFW.GLFW_KEY_UNKNOWN && m.getKey() != -1)
                .map(ModuleStructure::getName)
                .toArray(String[]::new);
    }
}