package moonshine.command.impl;

import moonshine.Initialization;
import moonshine.command.Command;
import moonshine.command.CommandManager;
import moonshine.command.helpers.Paginator;
import moonshine.command.helpers.TabCompleteHelper;
import moonshine.modules.impl.render.BlockESP;
import moonshine.util.config.impl.blockesp.BlockESPConfig;
import net.minecraft.class_124;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_7923;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

import static moonshine.command.impl.HelpCommand.getLine;

public class BlockESPCommand extends Command {

    public BlockESPCommand() {
        super("blockesp", "Управление блоками для BlockESP", "besp");
    }

    @Override
    public void execute(String label, String[] args) {
        CommandManager manager = CommandManager.getInstance();
        BlockESPConfig config = BlockESPConfig.getInstance();

        String action = args.length > 0 ? args[0].toLowerCase(Locale.US) : "help";

        switch (action) {
            case "add" -> {
                if (args.length < 2) {
                    logDirect("Использование: blockesp add <block>", class_124.field_1061);
                    logDirect("Пример: blockesp add minecraft:diamond_ore", class_124.field_1061);
                    return;
                }

                String blockId = args[1].toLowerCase();
                if (!blockId.contains(":")) {
                    blockId = "minecraft:" + blockId;
                }

                class_2248 block = class_7923.field_41175.method_63535(class_2960.method_12829(blockId));
                if (block == null || block == class_2246.field_10124) {
                    logDirect(String.format("Блок %s не найден!", args[1]), class_124.field_1061);
                    return;
                }

                String registryName = class_7923.field_41175.method_10221(block).toString();

                if (config.hasBlock(registryName)) {
                    logDirect(String.format("Блок %s уже в списке!", registryName), class_124.field_1061);
                    return;
                }

                config.addBlockAndSave(registryName);
                syncWithModule();
                logDirect(String.format("§aБлок §f%s §aдобавлен в BlockESP!", registryName), class_124.field_1060);
            }
            case "remove", "del", "delete" -> {
                if (args.length < 2) {
                    logDirect("Использование: blockesp remove <block>", class_124.field_1061);
                    return;
                }

                String blockId = args[1].toLowerCase();
                if (!blockId.contains(":")) {
                    blockId = "minecraft:" + blockId;
                }

                class_2248 block = class_7923.field_41175.method_63535(class_2960.method_12829(blockId));
                String registryName = block != null ? class_7923.field_41175.method_10221(block).toString() : blockId;

                if (!config.hasBlock(registryName)) {
                    logDirect(String.format("Блок %s не найден в списке!", registryName), class_124.field_1061);
                    return;
                }

                config.removeBlockAndSave(registryName);
                syncWithModule();
                logDirect(String.format("Блок %s удален из BlockESP!", registryName), class_124.field_1060);
            }
            case "clear" -> {
                int count = config.size();
                config.clearAndSave();
                syncWithModule();
                logDirect(String.format("Список BlockESP очищен! Удалено: %d", count), class_124.field_1060);
            }
            case "list" -> {
                int page = 1;
                if (args.length > 1) {
                    try {
                        page = Integer.parseInt(args[1]);
                    } catch (NumberFormatException ignored) {}
                }

                List<String> blocks = config.getBlockList();

                if (blocks.isEmpty()) {
                    logDirect("Список BlockESP пуст!", class_124.field_1061);
                    return;
                }

                Paginator<String> paginator = new Paginator<>(blocks);
                paginator.setPage(page);

                paginator.display(
                        () -> {
                            logDirectRaw(class_2561.method_43470(getLine()));
                            logDirect("§f§lБЛОКИ BLOCKESP §7(" + blocks.size() + ")");
                            logDirectRaw(class_2561.method_43470(getLine()));
                        },
                        blockName -> {
                            String shortName = blockName.replace("minecraft:", "");

                            class_5250 component = class_2561.method_43470("  §6● §f" + shortName)
                                    .method_10852(class_2561.method_43470(" §8(" + blockName + ")"));

                            class_5250 hoverText = class_2561.method_43470("§7Нажмите чтобы удалить §f" + shortName);
                            String removeCommand = manager.getPrefix() + "blockesp remove " + blockName;

                            component.method_10862(component.method_10866()
                                    .method_10949(new class_2568.class_10613(hoverText))
                                    .method_10958(new class_2558.class_10609(removeCommand)));

                            return component;
                        },
                        manager.getPrefix() + label + " list"
                );
            }
            case "blocks", "allblocks" -> {
                int page = 1;
                if (args.length > 1) {
                    try {
                        page = Integer.parseInt(args[1]);
                    } catch (NumberFormatException ignored) {}
                }

                List<String> allBlocks = class_7923.field_41175.method_10235().stream()
                        .map(class_2960::toString)
                        .sorted()
                        .toList();

                Paginator<String> paginator = new Paginator<>(allBlocks, 15);
                paginator.setPage(page);

                paginator.display(
                        () -> {
                            logDirectRaw(class_2561.method_43470(getLine()));
                            logDirect("§f§lВСЕ БЛОКИ §7(" + allBlocks.size() + ")");
                            logDirectRaw(class_2561.method_43470(getLine()));
                        },
                        blockName -> {
                            boolean inList = config.hasBlock(blockName);
                            String prefix = inList ? "§a✓" : "§8○";

                            class_5250 component = class_2561.method_43470("  " + prefix + " §f" + blockName.replace("minecraft:", ""));

                            String command = inList
                                    ? manager.getPrefix() + "blockesp remove " + blockName
                                    : manager.getPrefix() + "blockesp add " + blockName;

                            class_5250 hoverText = class_2561.method_43470(inList
                                    ? "§7Нажмите чтобы удалить"
                                    : "§7Нажмите чтобы добавить");

                            component.method_10862(component.method_10866()
                                    .method_10949(new class_2568.class_10613(hoverText))
                                    .method_10958(new class_2558.class_10609(command)));

                            return component;
                        },
                        manager.getPrefix() + label + " blocks"
                );
            }
            default -> {
                logDirectRaw(class_2561.method_43470(getLine()));
                logDirect("§f§lBLOCKESP");
                logDirectRaw(class_2561.method_43470(getLine()));
                logDirect("§7> blockesp add <block> §8- §fДобавить блок");
                logDirect("§7> blockesp remove <block> §8- §fУдалить блок");
                logDirect("§7> blockesp list §8- §fПоказать добавленные блоки");
                logDirect("§7> blockesp clear §8- §fОчистить список");
                logDirect("§7> blockesp blocks §8- §fПоказать все блоки игры");
                logDirectRaw(class_2561.method_43470(getLine()));
                logDirect("§7Примеры:");
                logDirect("§8> §fblockesp add diamond_ore");
                logDirect("§8> §fblockesp add minecraft:ancient_debris");
                logDirectRaw(class_2561.method_43470(getLine()));
            }
        }
    }

    private void syncWithModule() {
        BlockESP module = getBlockESPModule();
        if (module != null) {
            module.getBlocksToHighlight().clear();
            module.getBlocksToHighlight().addAll(BlockESPConfig.getInstance().getBlocks());
        }
    }

    private BlockESP getBlockESPModule() {
        if (Initialization.getInstance() == null || Initialization.getInstance().getManager() == null) {
            return null;
        }
        return Initialization.getInstance().getManager().getModuleRepository().modules().stream()
                .filter(m -> m instanceof BlockESP)
                .map(m -> (BlockESP) m)
                .findFirst()
                .orElse(null);
    }

    @Override
    public Stream<String> tabComplete(String label, String[] args) {
        if (args.length == 1) {
            return new TabCompleteHelper()
                    .append("add", "remove", "list", "clear", "blocks")
                    .sortAlphabetically()
                    .filterPrefix(args[0])
                    .stream();
        }
        if (args.length == 2) {
            String action = args[0].toLowerCase();
            if (action.equals("add")) {
                return class_7923.field_41175.method_10235().stream()
                        .map(class_2960::toString)
                        .filter(name -> name.toLowerCase().contains(args[1].toLowerCase()))
                        .limit(50);
            }
            if (action.equals("remove") || action.equals("del") || action.equals("delete")) {
                return new TabCompleteHelper()
                        .append(BlockESPConfig.getInstance().getBlockList().toArray(new String[0]))
                        .filterPrefix(args[1])
                        .stream();
            }
        }
        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Управление блоками для BlockESP";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "Команда для управления списком блоков BlockESP",
                "Использование:",
                "> blockesp add <block> - Добавить блок в список",
                "> blockesp remove <block> - Удалить блок из списка",
                "> blockesp list - Показать добавленные блоки",
                "> blockesp clear - Очистить список",
                "> blockesp blocks - Показать все блоки игры"
        );
    }
}