package moonshine.command;

import moonshine.command.impl.*;
import moonshine.events.api.EventManager;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.ChatEvent;
import moonshine.events.impl.TabCompleteEvent;
import moonshine.util.config.impl.prefix.PrefixConfig;
import moonshine.util.selfdestruct.SelfDestructManager;
import moonshine.util.string.chat.ChatMessage;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Stream;

public class CommandManager {
    private static CommandManager instance;
    private final List<Command> commands;
    private String prefix;

    public CommandManager() {
        instance = this;
        this.commands = new CopyOnWriteArrayList<>();
        this.prefix = SelfDestructManager.isLocked() ? "." : PrefixConfig.getInstance().getPrefix();
    }

    public static CommandManager getInstance() {
        return instance;
    }

    public void init() {
        registerCommand(new HelpCommand());
        registerCommand(new ConfigCommand());
        registerCommand(new AutoBuyCommand());
        registerCommand(new FriendCommand());
        registerCommand(new MacroCommand());
        registerCommand(new BindCommand());
        registerCommand(new PrefixCommand());
        registerCommand(new WayCommand());
        registerCommand(new StaffCommand());
        registerCommand(new BlockESPCommand());
        registerCommand(new MoonshineCommand());

        EventManager.register(this);
    }

    public void registerCommand(Command command) {
        commands.add(command);
    }

    public void unregisterCommand(Command command) {
        commands.remove(command);
    }

    public Command getCommand(String name) {
        return commands.stream()
                .filter(cmd -> cmd.matches(name))
                .findFirst()
                .orElse(null);
    }

    public List<Command> getCommands() {
        return new ArrayList<>(commands);
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    @EventHandler
    public void onChat(ChatEvent event) {
        String msg = event.getMessage();
        if (msg.startsWith(prefix)) {
            event.cancel();
            String commandStr = msg.substring(prefix.length());

            if (SelfDestructManager.isLocked() && !isActivationCommand(commandStr)) {
                return;
            }

            if (commandStr.trim().isEmpty()) {
                execute("help");
                return;
            }

            if (!execute(commandStr)) {
                sendError("Неизвестная команда. Используйте " + prefix + "help для списка команд.");
            }
        }
    }

    @EventHandler
    public void onTabComplete(TabCompleteEvent event) {
        String eventPrefix = event.prefix;

        if (!eventPrefix.startsWith(prefix)) {
            return;
        }

        if (SelfDestructManager.isLocked()) {
            event.completions = new String[0];
            return;
        }

        String msg = eventPrefix.substring(prefix.length());
        Stream<String> stream = tabComplete(msg);

        String[] parts = msg.split(" ", -1);
        if (parts.length <= 1) {
            stream = stream.map(x -> prefix + x);
        }

        event.completions = stream.toArray(String[]::new);
    }

    public boolean execute(String input) {
        if (input == null || input.trim().isEmpty()) {
            return execute("help");
        }

        if (SelfDestructManager.isLocked() && !isActivationCommand(input)) {
            return false;
        }

        String[] parts = input.trim().split("\\s+", 2);
        String commandName = parts[0];
        String[] args = parts.length > 1 ? parts[1].split("\\s+") : new String[0];

        Command command = getCommand(commandName);
        if (command != null) {
            try {
                command.execute(commandName, args);
                return true;
            } catch (Exception e) {
                sendError("Ошибка при выполнении команды: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return false;
    }

    private boolean isActivationCommand(String input) {
        if (input == null) {
            return false;
        }

        String normalized = input.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
        return normalized.equals("moonshine activate moonshine")
                || normalized.equals("moonshine unlock moonshine")
                || normalized.equals("client activate moonshine")
                || normalized.equals("client unlock moonshine");
    }

    public Stream<String> tabComplete(String input) {
        if (input == null) {
            input = "";
        }

        String[] args = input.split("\\s+", -1);

        if (args.length <= 1) {
            String partial = args.length == 0 ? "" : args[0].toLowerCase();
            return getCommandSuggestions(partial);
        }

        String commandName = args[0];
        Command command = getCommand(commandName);

        if (command != null) {
            String[] subArgs = Arrays.copyOfRange(args, 1, args.length);
            return command.tabComplete(commandName, subArgs);
        }

        return Stream.empty();
    }

    private Stream<String> getCommandSuggestions(String partial) {
        if (partial.isEmpty()) {
            return commands.stream()
                    .map(Command::getName)
                    .sorted();
        }

        Set<String> suggestions = new LinkedHashSet<>();

        for (Command cmd : commands) {
            String mainName = cmd.getName();

            if (mainName.toLowerCase().startsWith(partial)) {
                suggestions.add(mainName);
            } else {
                for (String alias : cmd.getAliases()) {
                    if (alias.toLowerCase().startsWith(partial)) {
                        suggestions.add(alias);
                        break;
                    }
                }
            }
        }

        return suggestions.stream().sorted();
    }

    public void sendMessage(String message) {
        ChatMessage.brandmessage(message);
    }

    public void sendSuccess(String message) {
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefixText = ChatMessage.brandmessage();
            class_2561 formattedMessage = prefixText.method_27661()
                    .method_10852(class_2561.method_43470(" -> ").method_27692(class_124.field_1063))
                    .method_10852(class_2561.method_43470(message).method_27692(class_124.field_1060));
            class_310.method_1551().field_1724.method_7353(formattedMessage, false);
        }
    }

    public void sendError(String message) {
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefixText = ChatMessage.brandmessage();
            class_2561 formattedMessage = prefixText.method_27661()
                    .method_10852(class_2561.method_43470(" -> ").method_27692(class_124.field_1063))
                    .method_10852(class_2561.method_43470(message).method_27692(class_124.field_1061));
            class_310.method_1551().field_1724.method_7353(formattedMessage, false);
        }
    }

    public void sendRaw(class_2561 text) {
        if (class_310.method_1551().field_1724 != null) {
            class_310.method_1551().field_1724.method_7353(text, false);
        }
    }
}
