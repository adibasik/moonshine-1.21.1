package moonshine.events.impl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import moonshine.events.api.events.Event;
import net.minecraft.class_1297;

@Getter
@AllArgsConstructor
public class AttackEvent implements Event {
    private final class_1297 target;
}