package moonshine.events.impl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import moonshine.events.api.events.callables.EventCancellable;
import net.minecraft.class_243;

@Setter
@Getter
@AllArgsConstructor
public class SwimmingEvent extends EventCancellable {
    class_243 vector;
}
