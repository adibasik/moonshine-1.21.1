package moonshine.events.impl;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.events.callables.EventCancellable;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_4587;

@FieldDefaults(level = AccessLevel.PRIVATE)
@Getter
@Setter
public class HandOffsetEvent extends EventCancellable {
    class_4587 matrices;
    class_1799 stack;
    class_1268 hand;
    float scale;

    public HandOffsetEvent(class_4587 matrices, class_1799 stack, class_1268 hand) {
        this.matrices = matrices;
        this.stack = stack;
        this.hand = hand;
        this.scale = 1.0F;
    }
}