package moonshine.events.impl;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.events.Event;
import net.minecraft.class_1735;
import net.minecraft.class_332;

@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class HandledScreenEvent implements Event {
    class_332 drawContext;
    class_1735 slotHover;
    int backgroundWidth, backgroundHeight;
}
