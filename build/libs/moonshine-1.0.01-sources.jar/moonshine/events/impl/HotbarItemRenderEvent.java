package moonshine.events.impl;

import lombok.Getter;
import lombok.Setter;
import moonshine.events.api.events.Event;
import net.minecraft.class_1799;

@Getter
@Setter
public class HotbarItemRenderEvent implements Event {
    private class_1799 stack;
    private final int hotbarIndex;

    public HotbarItemRenderEvent(class_1799 stack, int hotbarIndex) {
        this.stack = stack;
        this.hotbarIndex = hotbarIndex;
    }
}