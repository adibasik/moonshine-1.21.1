package moonshine.events.impl;

import moonshine.IMinecraft;
import moonshine.events.api.events.Event;
import net.minecraft.class_3675;
import net.minecraft.class_437;

public record KeyEvent(class_437 screen, class_3675.class_307 type, int key, int action) implements Event, IMinecraft {
    public boolean isKeyDown(int key) {
        return isKeyDown(key, mc.field_1755 == null);
    }

    public boolean isKeyDown(int key, boolean screen) {
        return this.key == key && action == 1 && screen;
    }

    public boolean isKeyReleased(int key) {
        return isKeyReleased(key, mc.field_1755 == null);
    }

    public boolean isKeyReleased(int key, boolean screen) {
        return this.key == key && action == 0 && screen;
    }
}
