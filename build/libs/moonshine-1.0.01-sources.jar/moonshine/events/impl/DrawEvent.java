package moonshine.events.impl;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.events.Event;
import moonshine.util.render.draw.DrawEngine;
import net.minecraft.class_332;

@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class DrawEvent implements Event {
    class_332 drawContext;
    DrawEngine drawEngine;
    float partialTicks;
}
