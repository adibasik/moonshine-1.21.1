package moonshine.events.impl;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.events.callables.EventCancellable;
import net.minecraft.class_4587;

@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@Getter
@Setter
public class GlassHandsRenderEvent extends EventCancellable {

    public enum Phase {
        PRE,
        POST
    }

    Phase phase;
    class_4587 matrices;
    float tickDelta;
}