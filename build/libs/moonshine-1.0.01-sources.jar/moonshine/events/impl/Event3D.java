package moonshine.events.impl;

import moonshine.events.api.events.Event;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

public class Event3D implements Event {

    public class_4587 stack;
    public class_4597 buffer;

   public Event3D(class_4587 stack, class_4597 buffer) {
       this.stack = stack;
       this.buffer = buffer;
   }

}