package moonshine.events.impl;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.events.Event;
import net.minecraft.class_243;

@Getter
@Setter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PlayerVelocityStrafeEvent implements Event {
    final class_243 movementInput;
    final float speed;
    final float yaw;
    class_243 velocity;
}
