package moonshine.events.impl;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import moonshine.events.api.events.callables.EventCancellable;
import net.minecraft.class_10185;

@Getter
@Setter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class InputEvent extends EventCancellable {
    class_10185 input;

    public void setJumping(boolean jump) {
        input = new class_10185(input.comp_3159(), input.comp_3160(), input.comp_3161(), input.comp_3162(), jump, input.comp_3164(), input.comp_3165());
    }

    public void setSprinting(boolean sprint) {
        input = new class_10185(input.comp_3159(), input.comp_3160(), input.comp_3161(), input.comp_3162(), input.comp_3163(), input.comp_3164(), sprint);
    }

    public void setDirectional(boolean forward, boolean backward, boolean left, boolean right, boolean sneak, boolean sprint, boolean jump) {
        input = new class_10185(forward, backward, left, right, jump, sneak, sprint);
    }

    public void setDirectionalLow(boolean forward, boolean backward, boolean left, boolean right) {
        input = new class_10185(forward, backward, left, right, input.comp_3163(), input.comp_3164(), input.comp_3165());
    }

    public void inputNone() {
        input = new class_10185(false, false, false, false, false, false, false);
    }

    public int forward() {
        return input.comp_3159() ? 1 : input.comp_3160() ? -1 : 0;
    }

    public float sideways() {
        return input.comp_3161() ? 1 : input.comp_3162() ? -1 : 0;
    }
}