package moonshine.events.api.types;

import moonshine.Initialization;
import moonshine.events.api.EventHandler;
import moonshine.events.impl.PacketEvent;
import moonshine.events.impl.TickEvent;
import moonshine.events.impl.UsingItemEvent;
import net.minecraft.class_2848;
import net.minecraft.class_2868;

public class EventListener implements Listener {
    public static boolean serverSprint;
    public static int selectedSlot;

    @EventHandler
    public void onTick(TickEvent e) {
        Initialization.getInstance().getManager().getAttackPerpetrator().tick();
        if (Initialization.getInstance().getManager().getHudManager() != null) {
            Initialization.getInstance().getManager().getHudManager().tick();
        }
    }

    @EventHandler
    public void onPacket(PacketEvent e) {
        switch (e.getPacket()) {
            case class_2848 command -> serverSprint = switch (command.method_12365()) {
                case class_2848.class_2849.field_12981 -> true;
                case class_2848.class_2849.field_12985 -> false;
                default -> serverSprint;
            };
            case class_2868 slot -> selectedSlot = slot.method_12442();
            default -> {}
        }

        Initialization.getInstance().getManager().getAttackPerpetrator().onPacket(e);
        Initialization.getInstance().getManager().getHudManager().onPacket(e);
    }

    @EventHandler
    public void onUsingItemEvent(UsingItemEvent e) {
        Initialization.getInstance().getManager().getAttackPerpetrator().onUsingItem(e);
    }

}