package moonshine.util.session;

import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.class_320;

public class SessionChanger {

    private static Consumer<class_320> sessionSetter;

    public static void setSessionSetter(Consumer<class_320> setter) {
        sessionSetter = setter;
    }

    public static void changeUsername(String newUsername) {
        if (sessionSetter == null || newUsername == null || newUsername.isEmpty()) return;

        UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + newUsername).getBytes());

        class_320 newSession = new class_320(
                newUsername,
                uuid,
                "",
                Optional.empty(),
                Optional.empty()
        );

        sessionSetter.accept(newSession);
    }

    public static String getCurrentUsername() {
        net.minecraft.class_310 mc = net.minecraft.class_310.method_1551();
        if (mc != null && mc.method_1548() != null) {
            return mc.method_1548().method_1676();
        }
        return "";
    }
}