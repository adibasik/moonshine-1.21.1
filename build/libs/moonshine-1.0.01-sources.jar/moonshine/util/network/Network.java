package moonshine.util.network;

import lombok.Getter;
import lombok.experimental.UtilityClass;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_2761;
import net.minecraft.class_3532;
import net.minecraft.class_8646;
import net.minecraft.class_9011;
import net.minecraft.scoreboard.*;
import org.apache.commons.lang3.StringUtils;
import moonshine.IMinecraft;
import moonshine.events.impl.PacketEvent;
import moonshine.util.string.PlayerInteractionHelper;
import moonshine.util.timer.StopWatch;


@Getter
@UtilityClass
public class Network implements IMinecraft {
    private final StopWatch pvpWatch = new StopWatch();
    public String server = "Vanilla";
    public float TPS = 20;
    public long timestamp;
    @Getter
    public int anarchy;
    @Getter
    public boolean pvpEnd;

    public void tick() {
        anarchy = getAnarchyMode();
        server = getServer();
        pvpEnd = inPvpEnd();
        if (inPvp()) pvpWatch.reset();
    }

    public void packet(PacketEvent e) {
        switch (e.getPacket()) {
            case class_2761 time -> {
                long nanoTime = System.nanoTime();

                float maxTPS = 20;
                float rawTPS = maxTPS * (1e9f / (nanoTime - timestamp));

                TPS = class_3532.method_15363(rawTPS, 0, maxTPS);
                timestamp = nanoTime;
            }
            default -> {}
        }
    }

    public String getServer() {
        if (PlayerInteractionHelper.nullCheck() || mc.method_1562() == null || mc.method_1562().method_45734() == null || mc.method_1562().method_52790() == null) return "Vanilla";
        String serverIp = mc.method_1562().method_45734().field_3761.toLowerCase();
        String brand = mc.method_1562().method_52790().toLowerCase();

        if (brand.contains("botfilter")) return "FunTime";
        else if (brand.contains("§6spooky§ccore")) return "SpookyTime";
        else if (serverIp.contains("funtime") || serverIp.contains("skytime") || serverIp.contains("space-times") || serverIp.contains("funsky")) return "CopyTime";
        else if (brand.contains("holyworld") || brand.contains("vk.com/idwok")) return "HolyWorld";
        else if (serverIp.contains("reallyworld")) return "ReallyWorld";
        else if (serverIp.contains("gulpvp")) return "GulPvP";
        return "Vanilla";
    }

    private int getAnarchyMode() {
        class_269 scoreboard = mc.field_1687.method_8428();
        class_266 objective = scoreboard.method_1189(class_8646.field_45157);
        switch (server) {
            case "FunTime" -> {
                if (objective != null) {
                    String[] string = objective.method_1114().getString().split("-");
                    if (string.length > 1) return Integer.parseInt(string[1]);
                }
            }
            case "HolyWorld" -> {
                for (class_9011 scoreboardEntry : scoreboard.method_1184(objective)) {
                    String text = class_268.method_1142(scoreboard.method_1164(scoreboardEntry.comp_2127()), scoreboardEntry.method_55387()).getString();
                    if (!text.isEmpty()) {
                        String string = StringUtils.substringBetween(text, "#", " -◆-");
                        if (string != null && !string.isEmpty()) return Integer.parseInt(string.replace(" (1.20)", ""));
                    }
                }
            }
        }
        return -1;
    }

    public boolean isPvp() {
        return !pvpWatch.finished(500);
    }

    private boolean inPvp() {
        return mc.field_1705.method_1740().field_2060.values().stream().map(c -> c.method_5414().getString().toLowerCase()).anyMatch(s -> s.contains("pvp") || s.contains("пвп"));
    }

    private boolean inPvpEnd() {
        return mc.field_1705.method_1740().field_2060.values().stream().map(c -> c.method_5414().getString().toLowerCase())
                .anyMatch(s -> (s.contains("pvp") || s.contains("пвп")) && (s.contains("0") || s.contains("1")));
    }

    public String getWorldType() {
        return mc.field_1687.method_27983().method_29177().method_12832();
    }

    public boolean isCopyTime() {return server.equals("CopyTime") || server.equals("SpookyTime") || server.equals("FunTime");}
    public boolean isFunTime() {return server.equals("FunTime");}
    public boolean isReallyWorld() {return server.equals("ReallyWorld");}
    public boolean isGulPvP() {return server.equals("GulPvP");}
    public boolean isHolyWorld() {return server.equals("HolyWorld");}
    public boolean isSpookyTime() {return server.equals("SpookyTime");}
    public boolean isAresMine() {return server.equals("aresmine");}
    public boolean isVanilla() {return server.equals("Vanilla");}
}
