package moonshine.util.network;

import lombok.Getter;
import lombok.experimental.UtilityClass;
import net.minecraft.class_10185;
import net.minecraft.class_1268;
import net.minecraft.class_2596;
import net.minecraft.class_2761;
import net.minecraft.class_2813;
import net.minecraft.class_2828;
import net.minecraft.class_2851;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_3965;
import net.minecraft.class_634;
import net.minecraft.class_7202;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.network.packet.s2c.play.*;
import moonshine.IMinecraft;
import moonshine.mixin.ClientConnectionAccessor;
import moonshine.mixin.IClientWorld;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.util.timer.TimerUtil;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

@UtilityClass
public class NetworkUtility implements IMinecraft {
    private boolean shouldTriggerEvent = true;
    private boolean serverSprinting = false;

    @Getter
    private float tpsFactor = 0;
    private int received = 0;
    private long lastReceive = 0;
    private TimerUtil tpsTimer = new TimerUtil();

    public void pauseEvents() {
        shouldTriggerEvent = false;
    }

    public void resumeEvents() {
        shouldTriggerEvent = true;
    }

    public boolean shouldTriggerEvent() {
        return shouldTriggerEvent;
    }

    public void updateServerSprint(boolean sprint) {
        serverSprinting = sprint;
    }

    public boolean serverSprinting() {
        return serverSprinting;
    }

    public void sendWithoutEvent(Runnable runnable) {
        pauseEvents();
        runnable.run();
        resumeEvents();
    }

    public void sendWithoutEvent(class_2596<?> packet) {
        pauseEvents();
        send(packet);
        resumeEvents();
    }

    public void send(class_2596<?> packet) {
        if (mc.method_1562() == null) return;

        if (packet instanceof class_2813 click) {
            mc.field_1761.method_2906(click.comp_3842(), click.comp_3844(), click.comp_3845(), click.comp_3846(), mc.field_1724);
        } else {
            mc.method_1562().method_52787(packet);
        }
    }

    public void sendInputPacket(boolean forward, boolean backward, boolean left, boolean right, boolean jump, boolean sneak, boolean sprint) {
        class_10185 input = new class_10185(forward, backward, left, right, jump, sneak, sprint);
        mc.method_1562().method_52787(new class_2851(input));
    }

    public void sendOnlySneak(boolean sneak) {
        class_10185 playerInput = mc.field_1724.field_3913.field_54155;
        sendInputPacket(playerInput.comp_3159(), playerInput.comp_3160(), playerInput.comp_3161(), playerInput.comp_3162(), playerInput.comp_3163(), sneak, playerInput.comp_3165());
    }

    public void sendUse(class_1268 hand) {
        sendUse(hand, new Angle(mc.field_1724.method_36454(), mc.field_1724.method_36455()));
    }

    public void sendUse(class_1268 hand, Angle angle) {
        try (class_7202 pendingUpdateManager = ((IClientWorld)mc.field_1687).client$pending().method_41937()) {
            int i = pendingUpdateManager.method_41942();
            class_2886 packet = new class_2886(hand, i, angle.getYaw(), angle.getPitch());
            NetworkUtility.send(packet);
        }
    }

    public void sendUse(class_1268 hand, class_3965 hitResult) {
        try (class_7202 pendingUpdateManager = ((IClientWorld)mc.field_1687).client$pending().method_41937()) {
            int i = pendingUpdateManager.method_41942();
            class_2885 packet = new class_2885(hand, hitResult, i);
            NetworkUtility.send(packet);
        }
    }

    public boolean is(String server) {
        return mc.method_1562() != null && mc.method_1562().method_45734() != null && mc.method_1562().method_45734().field_3761.contains(server);
    }

    public void handleCPacket(class_2596<?> packet) {
        if (packet instanceof class_2828 e) {
            PlayerState.lastGround = e.method_12273();
            PlayerState.lastVertical = mc.field_1724.field_5992;
        }
    }

    public void handleSPacket(class_2596<?> packet) {
        if (packet instanceof class_2761 e) {
            lastReceive = System.currentTimeMillis();
        }
    }

    public void handlePacket(class_2596<?> packet) {
        if (!(mc.method_1562() instanceof class_634 net)) return;
        if (mc.method_18854()) {
            ClientConnectionAccessor.handlePacket(packet, net);
        } else {
            mc.execute(() -> ClientConnectionAccessor.handlePacket(packet, net));
        }
    }

    @UtilityClass
    public class PlayerState {
        public boolean lastGround = false, lastVertical = false;
        public int lastTp = 0;
    }

    public UUID offlineUUID(String name) {
        return UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
    }
}