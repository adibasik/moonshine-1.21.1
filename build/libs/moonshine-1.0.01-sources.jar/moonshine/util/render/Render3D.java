package moonshine.util.render;

import lombok.Setter;
import lombok.experimental.UtilityClass;
import net.minecraft.class_12249;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_3532;
import net.minecraft.class_3545;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import moonshine.IMinecraft;
import moonshine.events.impl.WorldRenderEvent;
import moonshine.util.ColorUtil;
import moonshine.util.math.MathUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@UtilityClass
public class Render3D implements IMinecraft {
    private final Map<class_265, class_3545<List<class_238>, List<Line>>> SHAPE_OUTLINES = new HashMap<>();
    private final Map<class_265, List<class_238>> SHAPE_BOXES = new HashMap<>();

    public final List<Line> LINE_DEPTH = new ArrayList<>();
    public final List<Line> LINE = new ArrayList<>();
    public final List<Quad> QUAD_DEPTH = new ArrayList<>();
    public final List<Quad> QUAD = new ArrayList<>();
    public final List<GradientQuad> GRADIENT_QUAD = new ArrayList<>();
    public final List<GradientQuad> GRADIENT_QUAD_DEPTH = new ArrayList<>();

    public final Matrix4f lastProjMat = new Matrix4f();
    public final Matrix4f lastModMat = new Matrix4f();
    public final Matrix4f lastWorldSpaceMatrix = new Matrix4f();

    @Setter
    public class_4587.class_4665 lastWorldSpaceEntry = new class_4587().method_23760();
    @Setter
    public float lastTickDelta = 1.0f;
    @Setter
    public class_243 lastCameraPos = class_243.field_1353;
    @Setter
    public Quaternionf lastCameraRotation = new Quaternionf();

    private float espValue = 1f;
    private float espSpeed = 1f;
    private float prevEspValue;
    private float circleStep;
    private boolean flipSpeed;

    private double smoothY = 0;
    private double smoothY2 = 0;

    public void updateTargetEsp(float deltaTime) {
        prevEspValue = espValue;
        espValue += espSpeed * deltaTime;
        if (espSpeed > 25) flipSpeed = true;
        if (espSpeed < -25) flipSpeed = false;
        espSpeed = flipSpeed ? espSpeed - 0.5f * deltaTime : espSpeed + 0.5f * deltaTime;
        circleStep += 0.06f * deltaTime;
    }

    public void updateTargetEsp() {
        updateTargetEsp(1.0f);
    }

    public float getEspValue() {
        return espValue;
    }

    public float getPrevEspValue() {
        return prevEspValue;
    }

    public float getCircleStep() {
        return circleStep;
    }

    private double easeInOutSine(double t) {
        return -(Math.cos(Math.PI * t) - 1) / 2;
    }

    private double smoothSinAnimation(double input) {
        double sin = (Math.sin(input) + 1) / 2;
        return easeInOutSine(sin);
    }

    public void onWorldRender(WorldRenderEvent e) {
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        class_4587 matrices = e.getStack();
        class_4597.class_4598 immediate = mc.method_22940().method_23000();

        class_243 cameraPos = lastCameraPos;

        renderGradientQuads(matrices, immediate, cameraPos);
        renderQuads(matrices, immediate, cameraPos);
        renderLines(matrices, immediate, cameraPos);

        immediate.method_22993();
    }

    private void renderLines(class_4587 matrices, class_4597.class_4598 immediate, class_243 cameraPos) {
        if (LINE.isEmpty() && LINE_DEPTH.isEmpty()) return;

        class_4588 buffer = immediate.method_73477(class_12249.method_76015());

        for (Line line : LINE) {
            drawLineVertex(matrices, buffer, line, cameraPos);
        }
        for (Line line : LINE_DEPTH) {
            drawLineVertex(matrices, buffer, line, cameraPos);
        }

        LINE.clear();
        LINE_DEPTH.clear();
    }

    private void drawLineVertex(class_4587 matrices, class_4588 buffer, Line line, class_243 cameraPos) {
        class_4587.class_4665 entry = matrices.method_23760();
        Vector3f normal = getNormal(line.start.method_46409(), line.end.method_46409());

        float x1 = (float) (line.start.field_1352 - cameraPos.field_1352);
        float y1 = (float) (line.start.field_1351 - cameraPos.field_1351);
        float z1 = (float) (line.start.field_1350 - cameraPos.field_1350);

        float x2 = (float) (line.end.field_1352 - cameraPos.field_1352);
        float y2 = (float) (line.end.field_1351 - cameraPos.field_1351);
        float z2 = (float) (line.end.field_1350 - cameraPos.field_1350);

        buffer.method_56824(entry, x1, y1, z1)
                .method_39415(line.colorStart)
                .method_61959(entry, normal)
                .method_75298(line.width);
        buffer.method_56824(entry, x2, y2, z2)
                .method_39415(line.colorEnd)
                .method_61959(entry, normal)
                .method_75298(line.width);
    }

    private void renderQuads(class_4587 matrices, class_4597.class_4598 immediate, class_243 cameraPos) {
        if (QUAD.isEmpty() && QUAD_DEPTH.isEmpty()) return;

        class_4588 buffer = immediate.method_73477(class_12249.method_76019());

        for (Quad quad : QUAD) {
            drawQuadVertex(matrices, buffer, quad, cameraPos);
        }
        for (Quad quad : QUAD_DEPTH) {
            drawQuadVertex(matrices, buffer, quad, cameraPos);
        }

        QUAD.clear();
        QUAD_DEPTH.clear();
    }

    private void drawQuadVertex(class_4587 matrices, class_4588 buffer, Quad quad, class_243 cameraPos) {
        class_4587.class_4665 entry = matrices.method_23760();

        float x1 = (float) (quad.x.field_1352 - cameraPos.field_1352);
        float y1 = (float) (quad.x.field_1351 - cameraPos.field_1351);
        float z1 = (float) (quad.x.field_1350 - cameraPos.field_1350);

        float x2 = (float) (quad.y.field_1352 - cameraPos.field_1352);
        float y2 = (float) (quad.y.field_1351 - cameraPos.field_1351);
        float z2 = (float) (quad.y.field_1350 - cameraPos.field_1350);

        float x3 = (float) (quad.w.field_1352 - cameraPos.field_1352);
        float y3 = (float) (quad.w.field_1351 - cameraPos.field_1351);
        float z3 = (float) (quad.w.field_1350 - cameraPos.field_1350);

        float x4 = (float) (quad.z.field_1352 - cameraPos.field_1352);
        float y4 = (float) (quad.z.field_1351 - cameraPos.field_1351);
        float z4 = (float) (quad.z.field_1350 - cameraPos.field_1350);

        buffer.method_56824(entry, x1, y1, z1).method_39415(quad.color);
        buffer.method_56824(entry, x2, y2, z2).method_39415(quad.color);
        buffer.method_56824(entry, x3, y3, z3).method_39415(quad.color);
        buffer.method_56824(entry, x4, y4, z4).method_39415(quad.color);
    }

    private void renderGradientQuads(class_4587 matrices, class_4597.class_4598 immediate, class_243 cameraPos) {
        if (GRADIENT_QUAD.isEmpty() && GRADIENT_QUAD_DEPTH.isEmpty()) return;

        class_4588 buffer = immediate.method_73477(class_12249.method_76019());

        for (GradientQuad quad : GRADIENT_QUAD) {
            drawGradientQuadVertex(matrices, buffer, quad, cameraPos);
        }
        for (GradientQuad quad : GRADIENT_QUAD_DEPTH) {
            drawGradientQuadVertex(matrices, buffer, quad, cameraPos);
        }

        GRADIENT_QUAD.clear();
        GRADIENT_QUAD_DEPTH.clear();
    }

    private void drawGradientQuadVertex(class_4587 matrices, class_4588 buffer, GradientQuad quad, class_243 cameraPos) {
        class_4587.class_4665 entry = matrices.method_23760();

        float x1 = (float) (quad.p1.field_1352 - cameraPos.field_1352);
        float y1 = (float) (quad.p1.field_1351 - cameraPos.field_1351);
        float z1 = (float) (quad.p1.field_1350 - cameraPos.field_1350);

        float x2 = (float) (quad.p2.field_1352 - cameraPos.field_1352);
        float y2 = (float) (quad.p2.field_1351 - cameraPos.field_1351);
        float z2 = (float) (quad.p2.field_1350 - cameraPos.field_1350);

        float x3 = (float) (quad.p3.field_1352 - cameraPos.field_1352);
        float y3 = (float) (quad.p3.field_1351 - cameraPos.field_1351);
        float z3 = (float) (quad.p3.field_1350 - cameraPos.field_1350);

        float x4 = (float) (quad.p4.field_1352 - cameraPos.field_1352);
        float y4 = (float) (quad.p4.field_1351 - cameraPos.field_1351);
        float z4 = (float) (quad.p4.field_1350 - cameraPos.field_1350);

        buffer.method_56824(entry, x1, y1, z1).method_39415(quad.c1);
        buffer.method_56824(entry, x2, y2, z2).method_39415(quad.c2);
        buffer.method_56824(entry, x3, y3, z3).method_39415(quad.c3);
        buffer.method_56824(entry, x4, y4, z4).method_39415(quad.c4);
    }

    public void drawCircle(class_4587 matrix, class_1309 lastTarget, float anim, float red, int baseColor1, int baseColor2) {
        double cs = MathUtils.interpolate(circleStep - 0.17, circleStep);
        class_243 target = MathUtils.interpolate(lastTarget);
        boolean canSee = mc.field_1724 != null && mc.field_1724.method_6057(lastTarget);

        float hitEffect = Math.min(red * 2f, 1f);
        float distanceMultiplier = 1.0f + (float) Math.sin(hitEffect * Math.PI) * 0.18f;

        int size = 64;

        float entityWidth = lastTarget.method_17681() * distanceMultiplier;
        float entityHeight = lastTarget.method_17682();

        double targetY = smoothSinAnimation(cs) * entityHeight;
        double targetY2 = smoothSinAnimation(cs - 0.35) * entityHeight;

        smoothY = lerp(smoothY, targetY, 0.12);
        smoothY2 = lerp(smoothY2, targetY2, 0.10);

        int color1 = ColorUtil.multRed(baseColor1, 1 + red * 125);
        int color2 = ColorUtil.multRed(baseColor2, 1 + red * 125);

        for (int i = 0; i < size; i++) {
            float t = (float) i / size;
            float tNext = (float) ((i + 1) % size) / size;

            float gradientT = (float) (0.5 - 0.5 * Math.cos(t * Math.PI * 2));
            float gradientTNext = (float) (0.5 - 0.5 * Math.cos(tNext * Math.PI * 2));

            int currentColor = ColorUtil.lerpColor(color1, color2, gradientT);
            int nextColor = ColorUtil.lerpColor(color1, color2, gradientTNext);

            int brightColor = ColorUtil.multAlpha(currentColor, 0.8f * anim);
            int brightColorNext = ColorUtil.multAlpha(nextColor, 0.8f * anim);
            int fadeColor = ColorUtil.multAlpha(currentColor, 0f);
            int fadeColorNext = ColorUtil.multAlpha(nextColor, 0f);

            class_243 cosSin = MathUtils.cosSin(i, size, entityWidth);
            class_243 nextCosSin = MathUtils.cosSin((i + 1) % size, size, entityWidth);

            class_243 circlePoint = target.method_1031(cosSin.field_1352, smoothY, cosSin.field_1350);
            class_243 trailPoint = target.method_1031(cosSin.field_1352, smoothY2, cosSin.field_1350);
            class_243 nextCirclePoint = target.method_1031(nextCosSin.field_1352, smoothY, nextCosSin.field_1350);
            class_243 nextTrailPoint = target.method_1031(nextCosSin.field_1352, smoothY2, nextCosSin.field_1350);

            drawGradientQuad(
                    circlePoint,
                    nextCirclePoint,
                    nextTrailPoint,
                    trailPoint,
                    brightColor,
                    brightColorNext,
                    fadeColorNext,
                    fadeColor,
                    canSee
            );

            drawGradientQuad(
                    trailPoint,
                    nextTrailPoint,
                    nextCirclePoint,
                    circlePoint,
                    fadeColor,
                    fadeColorNext,
                    brightColorNext,
                    brightColor,
                    canSee
            );

            int trailColorTop = ColorUtil.multAlpha(currentColor, 0.15f * anim);
            int trailColorBottom = ColorUtil.multAlpha(currentColor, 0f);
            drawLineGradient(circlePoint, trailPoint, trailColorTop, trailColorBottom, 6f, canSee);

            int circleColor = ColorUtil.multAlpha(currentColor, 1f * anim);
            int circleColorNext = ColorUtil.multAlpha(nextColor, 1f * anim);
            drawLineGradient(circlePoint, nextCirclePoint, circleColor, circleColorNext, 2f, canSee);
        }
    }

    public void drawRadiusCircle(class_243 center, float radius, int color) {
        if (mc.field_1724 == null) return;

        double baseY = center.field_1351;
        int fillColor = ColorUtil.multAlpha(color, 0.25f);

        int radiusInt = (int) Math.ceil(radius) + 1;

        for (int dx = -radiusInt; dx <= radiusInt; dx++) {
            for (int dz = -radiusInt; dz <= radiusInt; dz++) {
                boolean hasCornerInside = false;
                boolean hasCornerOutside = false;

                for (double ox = -0.5; ox <= 0.5; ox += 1.0) {
                    for (double oz = -0.5; oz <= 0.5; oz += 1.0) {
                        double cornerDist = Math.sqrt((dx + ox) * (dx + ox) + (dz + oz) * (dz + oz));
                        if (cornerDist <= radius) {
                            hasCornerInside = true;
                        } else {
                            hasCornerOutside = true;
                        }
                    }
                }

                if (hasCornerInside && hasCornerOutside) {
                    double x = center.field_1352 + dx;
                    double z = center.field_1350 + dz;

                    class_238 box = new class_238(
                            x - 0.5, baseY, z - 0.5,
                            x + 0.5, baseY + 1, z + 0.5
                    );

                    drawBoxWithCross(box, color, fillColor, 2f);
                }
            }
        }
    }

    public void drawBoxWithCross(class_238 box, int lineColor, int fillColor, float lineWidth) {
        double x1 = box.field_1323;
        double y1 = box.field_1322;
        double z1 = box.field_1321;
        double x2 = box.field_1320;
        double y2 = box.field_1325;
        double z2 = box.field_1324;

        drawQuad(new class_243(x1, y1, z1), new class_243(x2, y1, z1), new class_243(x2, y1, z2), new class_243(x1, y1, z2), fillColor, false);
        drawQuad(new class_243(x1, y1, z1), new class_243(x1, y2, z1), new class_243(x2, y2, z1), new class_243(x2, y1, z1), fillColor, false);
        drawQuad(new class_243(x2, y1, z1), new class_243(x2, y2, z1), new class_243(x2, y2, z2), new class_243(x2, y1, z2), fillColor, false);
        drawQuad(new class_243(x1, y1, z2), new class_243(x2, y1, z2), new class_243(x2, y2, z2), new class_243(x1, y2, z2), fillColor, false);
        drawQuad(new class_243(x1, y1, z1), new class_243(x1, y1, z2), new class_243(x1, y2, z2), new class_243(x1, y2, z1), fillColor, false);
        drawQuad(new class_243(x1, y2, z1), new class_243(x1, y2, z2), new class_243(x2, y2, z2), new class_243(x2, y2, z1), fillColor, false);

        drawLine(new class_243(x1, y1, z1), new class_243(x2, y1, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x2, y1, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x1, y1, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y1, z2), new class_243(x1, y1, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y1, z2), new class_243(x1, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y1, z1), new class_243(x1, y2, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x2, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x2, y2, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y2, z1), new class_243(x2, y2, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y2, z1), new class_243(x2, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y2, z2), new class_243(x1, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y2, z2), new class_243(x1, y2, z1), lineColor, lineWidth, false);

        int crossColor = ColorUtil.multAlpha(lineColor, 0.6f);
        float crossWidth = lineWidth * 0.8f;

        drawLine(new class_243(x1, y1, z1), new class_243(x2, y1, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x1, y1, z2), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y2, z1), new class_243(x2, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y2, z1), new class_243(x1, y2, z2), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y1, z1), new class_243(x2, y2, z1), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x1, y2, z1), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y1, z2), new class_243(x2, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x1, y2, z2), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y1, z1), new class_243(x1, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x1, y1, z2), new class_243(x1, y2, z1), crossColor, crossWidth, false);

        drawLine(new class_243(x2, y1, z1), new class_243(x2, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x2, y2, z1), crossColor, crossWidth, false);
    }

    public void drawBoxWithCrossFull(class_238 box, int lineColor, int fillColor, float lineWidth) {
        double x1 = box.field_1323;
        double y1 = box.field_1322;
        double z1 = box.field_1321;
        double x2 = box.field_1320;
        double y2 = box.field_1325;
        double z2 = box.field_1324;

        drawQuad(new class_243(x1, y1, z1), new class_243(x2, y1, z1), new class_243(x2, y1, z2), new class_243(x1, y1, z2), fillColor, false);
        drawQuad(new class_243(x1, y1, z1), new class_243(x1, y2, z1), new class_243(x2, y2, z1), new class_243(x2, y1, z1), fillColor, false);
        drawQuad(new class_243(x2, y1, z1), new class_243(x2, y2, z1), new class_243(x2, y2, z2), new class_243(x2, y1, z2), fillColor, false);
        drawQuad(new class_243(x1, y1, z2), new class_243(x2, y1, z2), new class_243(x2, y2, z2), new class_243(x1, y2, z2), fillColor, false);
        drawQuad(new class_243(x1, y1, z1), new class_243(x1, y1, z2), new class_243(x1, y2, z2), new class_243(x1, y2, z1), fillColor, false);
        drawQuad(new class_243(x1, y2, z1), new class_243(x1, y2, z2), new class_243(x2, y2, z2), new class_243(x2, y2, z1), fillColor, false);

        drawQuad(new class_243(x1, y1, z2), new class_243(x2, y1, z2), new class_243(x2, y1, z1), new class_243(x1, y1, z1), fillColor, false);
        drawQuad(new class_243(x2, y1, z1), new class_243(x2, y2, z1), new class_243(x1, y2, z1), new class_243(x1, y1, z1), fillColor, false);
        drawQuad(new class_243(x2, y1, z2), new class_243(x2, y2, z2), new class_243(x2, y2, z1), new class_243(x2, y1, z1), fillColor, false);
        drawQuad(new class_243(x1, y2, z2), new class_243(x2, y2, z2), new class_243(x2, y1, z2), new class_243(x1, y1, z2), fillColor, false);
        drawQuad(new class_243(x1, y2, z1), new class_243(x1, y2, z2), new class_243(x1, y1, z2), new class_243(x1, y1, z1), fillColor, false);
        drawQuad(new class_243(x2, y2, z1), new class_243(x2, y2, z2), new class_243(x1, y2, z2), new class_243(x1, y2, z1), fillColor, false);

        drawLine(new class_243(x1, y1, z1), new class_243(x2, y1, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x2, y1, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x1, y1, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y1, z2), new class_243(x1, y1, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y1, z2), new class_243(x1, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y1, z1), new class_243(x1, y2, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x2, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x2, y2, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y2, z1), new class_243(x2, y2, z1), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y2, z1), new class_243(x2, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x2, y2, z2), new class_243(x1, y2, z2), lineColor, lineWidth, false);
        drawLine(new class_243(x1, y2, z2), new class_243(x1, y2, z1), lineColor, lineWidth, false);

        int crossColor = ColorUtil.multAlpha(lineColor, 0.6f);
        float crossWidth = lineWidth * 0.8f;

        drawLine(new class_243(x1, y1, z1), new class_243(x2, y1, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x1, y1, z2), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y2, z1), new class_243(x2, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y2, z1), new class_243(x1, y2, z2), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y1, z1), new class_243(x2, y2, z1), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z1), new class_243(x1, y2, z1), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y1, z2), new class_243(x2, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x1, y2, z2), crossColor, crossWidth, false);

        drawLine(new class_243(x1, y1, z1), new class_243(x1, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x1, y1, z2), new class_243(x1, y2, z1), crossColor, crossWidth, false);

        drawLine(new class_243(x2, y1, z1), new class_243(x2, y2, z2), crossColor, crossWidth, false);
        drawLine(new class_243(x2, y1, z2), new class_243(x2, y2, z1), crossColor, crossWidth, false);
    }

    public void drawPlastShape(class_2338 playerPos, class_243 smooth, int lineColor, int fillColor) {
        if (mc.field_1724 == null) return;

        float yaw = class_3532.method_15393(mc.field_1724.method_36454());

        if (Math.abs(mc.field_1724.method_36455()) > 60) {
            class_2338 blockPos = playerPos.method_10084().method_10079(mc.field_1724.method_58149(), 3);
            class_243 pos1 = class_243.method_24954(blockPos.method_10089(3).method_10077(3).method_10074()).method_1019(smooth);
            class_243 pos2 = class_243.method_24954(blockPos.method_10088(2).method_10076(2).method_10084()).method_1019(smooth);
            drawBoxWithCrossFull(new class_238(pos1, pos2), lineColor, fillColor, 3);
        } else if (yaw <= -157.5F || yaw >= 157.5F) {
            class_2338 blockPos = playerPos.method_10076(3).method_10084();
            class_243 pos1 = class_243.method_24954(blockPos.method_10087(2).method_10089(3)).method_1019(smooth);
            class_243 pos2 = class_243.method_24954(blockPos.method_10086(3).method_10088(2).method_10077(2)).method_1019(smooth);
            drawBoxWithCrossFull(new class_238(pos1, pos2), lineColor, fillColor, 3);
        } else if (yaw <= -112.5F) {
            drawSidePlast(playerPos.method_10089(5).method_10072().method_10074(), smooth, lineColor, fillColor, -1, true);
        } else if (yaw <= -67.5F) {
            class_2338 blockPos = playerPos.method_10089(2).method_10084();
            class_243 pos1 = class_243.method_24954(blockPos.method_10087(2).method_10077(3)).method_1019(smooth);
            class_243 pos2 = class_243.method_24954(blockPos.method_10086(3).method_10076(2).method_10089(2)).method_1019(smooth);
            drawBoxWithCrossFull(new class_238(pos1, pos2), lineColor, fillColor, 3);
        } else if (yaw <= -22.5F) {
            drawSidePlast(playerPos.method_10089(5).method_10074(), smooth, lineColor, fillColor, 1, false);
        } else if (yaw >= -22.5 && yaw <= 22.5) {
            class_2338 blockPos = playerPos.method_10077(2).method_10084();
            class_243 pos1 = class_243.method_24954(blockPos.method_10087(2).method_10089(3)).method_1019(smooth);
            class_243 pos2 = class_243.method_24954(blockPos.method_10086(3).method_10088(2).method_10077(2)).method_1019(smooth);
            drawBoxWithCrossFull(new class_238(pos1, pos2), lineColor, fillColor, 3);
        } else if (yaw <= 67.5F) {
            drawSidePlast(playerPos.method_10088(4).method_10074(), smooth, lineColor, fillColor, 1, true);
        } else if (yaw <= 112.5F) {
            class_2338 blockPos = playerPos.method_10088(3).method_10084();
            class_243 pos1 = class_243.method_24954(blockPos.method_10087(2).method_10077(3)).method_1019(smooth);
            class_243 pos2 = class_243.method_24954(blockPos.method_10086(3).method_10076(2).method_10089(2)).method_1019(smooth);
            drawBoxWithCrossFull(new class_238(pos1, pos2), lineColor, fillColor, 3);
        } else if (yaw <= 157.5F) {
            drawSidePlast(playerPos.method_10088(4).method_10072().method_10074(), smooth, lineColor, fillColor, -1, false);
        }
    }

    private void drawSidePlast(class_2338 blockPos, class_243 smooth, int lineColor, int fillColor, int i, boolean ff) {
        class_243 vec3d = class_243.method_24954(blockPos).method_1019(smooth);
        int crossColor = ColorUtil.multAlpha(lineColor, 0.6f);

        List<class_243> horizontalPoints = new ArrayList<>();

        float x = ff ? i : -i;
        class_243 current = vec3d;

        horizontalPoints.add(current);
        current = current.method_1031(x, 0, 0);
        horizontalPoints.add(current);

        for (int f = 0; f < 4; f++) {
            current = current.method_1031(0, 0, i);
            horizontalPoints.add(current);
            current = current.method_1031(x, 0, 0);
            horizontalPoints.add(current);
        }

        current = current.method_1031(0, 0, i);
        horizontalPoints.add(current);
        current = current.method_1031(x * -2, 0, 0);
        horizontalPoints.add(current);

        for (int f = 0; f < 3; f++) {
            current = current.method_1031(0, 0, i * -1);
            horizontalPoints.add(current);
            current = current.method_1031(x * -1, 0, 0);
            horizontalPoints.add(current);
        }

        current = current.method_1031(0, 0, i * -2);
        horizontalPoints.add(current);

        for (int p = 0; p < horizontalPoints.size() - 1; p++) {
            class_243 p1 = horizontalPoints.get(p);
            class_243 p2 = horizontalPoints.get(p + 1);
            drawLine(p1, p2, lineColor, 2f, false);
            drawLine(p1.method_1031(0, 5, 0), p2.method_1031(0, 5, 0), lineColor, 2f, false);
        }

        for (class_243 point : horizontalPoints) {
            drawLine(point, point.method_1031(0, 5, 0), lineColor, 2f, false);
        }

        for (int p = 0; p < horizontalPoints.size() - 1; p++) {
            class_243 p1 = horizontalPoints.get(p);
            class_243 p2 = horizontalPoints.get(p + 1);
            class_243 p1Top = p1.method_1031(0, 5, 0);
            class_243 p2Top = p2.method_1031(0, 5, 0);

            drawQuad(p1, p2, p2Top, p1Top, fillColor, false);
            drawQuad(p1Top, p2Top, p2, p1, fillColor, false);

            drawLine(p1, p2Top, crossColor, 1.6f, false);
            drawLine(p2, p1Top, crossColor, 1.6f, false);
        }

        current = vec3d;
        drawQuad(current, current.method_1031(x, 0, 0), current.method_1031(x, 0, i * 2), current.method_1031(0, 0, i * 2), fillColor, false);
        drawQuad(current.method_1031(0, 0, i * 2), current.method_1031(x, 0, i * 2), current.method_1031(x, 0, 0), current, fillColor, false);
        drawLine(current, current.method_1031(x, 0, i * 2), crossColor, 1.6f, false);
        drawLine(current.method_1031(x, 0, 0), current.method_1031(0, 0, i * 2), crossColor, 1.6f, false);

        for (int f = 0; f < 3; f++) {
            current = current.method_1031(x, 0, i);
            drawQuad(current, current.method_1031(x, 0, 0), current.method_1031(x, 0, i * 2), current.method_1031(0, 0, i * 2), fillColor, false);
            drawQuad(current.method_1031(0, 0, i * 2), current.method_1031(x, 0, i * 2), current.method_1031(x, 0, 0), current, fillColor, false);
            drawLine(current, current.method_1031(x, 0, i * 2), crossColor, 1.6f, false);
            drawLine(current.method_1031(x, 0, 0), current.method_1031(0, 0, i * 2), crossColor, 1.6f, false);
        }
        current = current.method_1031(x, 0, i);
        drawQuad(current, current.method_1031(x, 0, 0), current.method_1031(x, 0, i), current.method_1031(0, 0, i), fillColor, false);
        drawQuad(current.method_1031(0, 0, i), current.method_1031(x, 0, i), current.method_1031(x, 0, 0), current, fillColor, false);
        drawLine(current, current.method_1031(x, 0, i), crossColor, 1.6f, false);
        drawLine(current.method_1031(x, 0, 0), current.method_1031(0, 0, i), crossColor, 1.6f, false);

        current = vec3d.method_1031(0, 5, 0);
        drawQuad(current, current.method_1031(0, 0, i * 2), current.method_1031(x, 0, i * 2), current.method_1031(x, 0, 0), fillColor, false);
        drawQuad(current.method_1031(x, 0, 0), current.method_1031(x, 0, i * 2), current.method_1031(0, 0, i * 2), current, fillColor, false);
        drawLine(current, current.method_1031(x, 0, i * 2), crossColor, 1.6f, false);
        drawLine(current.method_1031(x, 0, 0), current.method_1031(0, 0, i * 2), crossColor, 1.6f, false);

        for (int f = 0; f < 3; f++) {
            current = current.method_1031(x, 0, i);
            drawQuad(current, current.method_1031(0, 0, i * 2), current.method_1031(x, 0, i * 2), current.method_1031(x, 0, 0), fillColor, false);
            drawQuad(current.method_1031(x, 0, 0), current.method_1031(x, 0, i * 2), current.method_1031(0, 0, i * 2), current, fillColor, false);
            drawLine(current, current.method_1031(x, 0, i * 2), crossColor, 1.6f, false);
            drawLine(current.method_1031(x, 0, 0), current.method_1031(0, 0, i * 2), crossColor, 1.6f, false);
        }
        current = current.method_1031(x, 0, i);
        drawQuad(current, current.method_1031(0, 0, i), current.method_1031(x, 0, i), current.method_1031(x, 0, 0), fillColor, false);
        drawQuad(current.method_1031(x, 0, 0), current.method_1031(x, 0, i), current.method_1031(0, 0, i), current, fillColor, false);
        drawLine(current, current.method_1031(x, 0, i), crossColor, 1.6f, false);
        drawLine(current.method_1031(x, 0, 0), current.method_1031(0, 0, i), crossColor, 1.6f, false);
    }

    private double lerp(double start, double end, double delta) {
        return start + (end - start) * delta;
    }

    public void drawGradientQuad(class_243 p1, class_243 p2, class_243 p3, class_243 p4, int c1, int c2, int c3, int c4, boolean depth) {
        GradientQuad quad = new GradientQuad(p1, p2, p3, p4, c1, c2, c3, c4);
        if (depth) GRADIENT_QUAD_DEPTH.add(quad);
        else GRADIENT_QUAD.add(quad);
    }

    public void drawLineGradient(class_243 start, class_243 end, int colorStart, int colorEnd, float width, boolean depth) {
        Line line = new Line(null, start, end, colorStart, colorEnd, width);
        if (depth) LINE_DEPTH.add(line);
        else LINE.add(line);
    }

    public Vector3f getNormal(Vector3f start, Vector3f end) {
        Vector3f normal = new Vector3f(start).sub(end);
        float sqrt = class_3532.method_15355(normal.lengthSquared());
        if (sqrt < 0.0001f) return new Vector3f(0, 1, 0);
        return normal.div(sqrt);
    }

    public void drawShape(class_2338 blockPos, class_265 voxelShape, int color, float width) {
        drawShape(blockPos, voxelShape, color, width, true, false);
    }

    public void drawShape(class_2338 blockPos, class_265 voxelShape, int color, float width, boolean fill, boolean depth) {
        if (SHAPE_BOXES.containsKey(voxelShape)) {
            SHAPE_BOXES.get(voxelShape).forEach(box -> {
                class_238 offsetBox = box.method_996(blockPos);
                drawBox(offsetBox, color, width, true, fill, depth);
            });
            return;
        }
        SHAPE_BOXES.put(voxelShape, voxelShape.method_1090());
    }

    public void drawShapeAlternative(class_2338 blockPos, class_265 voxelShape, int color, float width, boolean fill, boolean depth) {
        class_243 vec3d = class_243.method_24954(blockPos);

        if (SHAPE_OUTLINES.containsKey(voxelShape)) {
            class_3545<List<class_238>, List<Line>> pair = SHAPE_OUTLINES.get(voxelShape);
            if (fill) {
                pair.method_15442().forEach(box -> drawBox(box.method_997(vec3d), color, width, false, true, depth));
            }
            pair.method_15441().forEach(line -> drawLine(line.start.method_1019(vec3d), line.end.method_1019(vec3d), color, width, depth));
            return;
        }
        List<Line> lines = new ArrayList<>();
        voxelShape.method_1104((minX, minY, minZ, maxX, maxY, maxZ) ->
                lines.add(new Line(null, new class_243(minX, minY, minZ), new class_243(maxX, maxY, maxZ), 0, 0, 0)));
        SHAPE_OUTLINES.put(voxelShape, new class_3545<>(voxelShape.method_1090(), lines));
    }

    public void drawBox(class_238 box, int color, float width) {
        drawBox(box, color, width, true, true, false);
    }

    public void drawBox(class_238 box, int color, float width, boolean line, boolean fill, boolean depth) {
        drawBox(null, box, color, width, line, fill, depth);
    }

    public void drawBox(class_4587.class_4665 entry, class_238 box, int color, float width, boolean line, boolean fill, boolean depth) {
        double x1 = box.field_1323;
        double y1 = box.field_1322;
        double z1 = box.field_1321;
        double x2 = box.field_1320;
        double y2 = box.field_1325;
        double z2 = box.field_1324;

        if (fill) {
            int fillColor = ColorUtil.multAlpha(color, 0.3f);
            drawQuad(entry, new class_243(x1, y1, z1), new class_243(x2, y1, z1), new class_243(x2, y1, z2), new class_243(x1, y1, z2), fillColor, depth);
            drawQuad(entry, new class_243(x1, y1, z1), new class_243(x1, y2, z1), new class_243(x2, y2, z1), new class_243(x2, y1, z1), fillColor, depth);
            drawQuad(entry, new class_243(x2, y1, z1), new class_243(x2, y2, z1), new class_243(x2, y2, z2), new class_243(x2, y1, z2), fillColor, depth);
            drawQuad(entry, new class_243(x1, y1, z2), new class_243(x2, y1, z2), new class_243(x2, y2, z2), new class_243(x1, y2, z2), fillColor, depth);
            drawQuad(entry, new class_243(x1, y1, z1), new class_243(x1, y1, z2), new class_243(x1, y2, z2), new class_243(x1, y2, z1), fillColor, depth);
            drawQuad(entry, new class_243(x1, y2, z1), new class_243(x1, y2, z2), new class_243(x2, y2, z2), new class_243(x2, y2, z1), fillColor, depth);
        }

        if (line) {
            drawLine(entry, x1, y1, z1, x2, y1, z1, color, width, depth);
            drawLine(entry, x2, y1, z1, x2, y1, z2, color, width, depth);
            drawLine(entry, x2, y1, z2, x1, y1, z2, color, width, depth);
            drawLine(entry, x1, y1, z2, x1, y1, z1, color, width, depth);
            drawLine(entry, x1, y1, z2, x1, y2, z2, color, width, depth);
            drawLine(entry, x1, y1, z1, x1, y2, z1, color, width, depth);
            drawLine(entry, x2, y1, z2, x2, y2, z2, color, width, depth);
            drawLine(entry, x2, y1, z1, x2, y2, z1, color, width, depth);
            drawLine(entry, x1, y2, z1, x2, y2, z1, color, width, depth);
            drawLine(entry, x2, y2, z1, x2, y2, z2, color, width, depth);
            drawLine(entry, x2, y2, z2, x1, y2, z2, color, width, depth);
            drawLine(entry, x1, y2, z2, x1, y2, z1, color, width, depth);
        }
    }

    public void drawLine(class_4587.class_4665 entry, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, int color, float width, boolean depth) {
        drawLine(entry, new class_243(minX, minY, minZ), new class_243(maxX, maxY, maxZ), color, color, width, depth);
    }

    public void drawLine(class_243 start, class_243 end, int color, float width, boolean depth) {
        drawLine(null, start, end, color, color, width, depth);
    }

    public void drawLine(class_4587.class_4665 entry, class_243 start, class_243 end, int colorStart, int colorEnd, float width, boolean depth) {
        Line line = new Line(entry, start, end, colorStart, colorEnd, width);
        if (depth) LINE_DEPTH.add(line);
        else LINE.add(line);
    }

    public void drawQuad(class_243 x, class_243 y, class_243 w, class_243 z, int color, boolean depth) {
        drawQuad(null, x, y, w, z, color, depth);
    }

    public void drawQuad(class_4587.class_4665 entry, class_243 x, class_243 y, class_243 w, class_243 z, int color, boolean depth) {
        Quad quad = new Quad(entry, x, y, w, z, color);
        if (depth) QUAD_DEPTH.add(quad);
        else QUAD.add(quad);
    }

    public void resetCircleSmoothing() {
        smoothY = 0;
        smoothY2 = 0;
    }

    public record Line(class_4587.class_4665 entry, class_243 start, class_243 end, int colorStart, int colorEnd, float width) {
    }

    public record Quad(class_4587.class_4665 entry, class_243 x, class_243 y, class_243 w, class_243 z, int color) {
    }

    public record GradientQuad(class_243 p1, class_243 p2, class_243 p3, class_243 p4, int c1, int c2, int c3, int c4) {
    }
}