package moonshine.util.render.fakeplayer;

import com.mojang.blaze3d.opengl.GlConst;
import com.mojang.blaze3d.opengl.GlStateManager;
import lombok.experimental.UtilityClass;
import org.joml.Matrix4f;
import moonshine.IMinecraft;
import moonshine.modules.impl.player.FreeCam;
import moonshine.util.ColorUtil;
import moonshine.util.render.сliemtpipeline.ClientPipelines;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;


@UtilityClass
public class FakePlayerRenderer implements IMinecraft {

        private static final float HEAD_SIZE = 0.5f;
        private static final float BODY_WIDTH = 0.5f;
        private static final float BODY_HEIGHT = 0.75f;
        private static final float BODY_DEPTH = 0.25f;
        private static final float ARM_WIDTH = 0.25f;
        private static final float ARM_HEIGHT = 0.75f;
        private static final float LEG_HEIGHT = 0.75f;

        private static final float MODEL_CENTER_Y = LEG_HEIGHT + BODY_HEIGHT / 2;

        private static int currentAlpha = 255;

        public void render(class_243 position, float alpha) {
                if (mc.field_1724 == null || alpha <= 0.001f)
                        return;

                currentAlpha = (int) (Math.min(1f, Math.max(0f, alpha)) * 255);

                class_243 camPos = mc.field_1773.method_19418().method_71156();

                class_4597.class_4598 immediate = mc.method_22940().method_23000();
                class_4587 stack = new class_4587();

                GlStateManager._disableCull();
                GlStateManager._enableBlend();
                GlStateManager._blendFuncSeparate(
                                GlConst.GL_SRC_ALPHA,
                                GlConst.GL_ONE_MINUS_SRC_ALPHA,
                                GlConst.GL_ONE,
                                GlConst.GL_ZERO);

                stack.method_22903();
                stack.method_22904(position.field_1352 - camPos.field_1352, position.field_1351 - camPos.field_1351, position.field_1350 - camPos.field_1350);

                renderPlayerModel(stack, immediate);

                stack.method_22909();
                immediate.method_22993();

                GlStateManager._disableBlend();
                GlStateManager._enableCull();
        }

        private void renderPlayerModel(class_4587 stack, class_4597.class_4598 immediate) {
                class_238 leftLeg = new class_238(-0.25, 0, -0.125, 0, LEG_HEIGHT, 0.125);
                class_238 rightLeg = new class_238(0, 0, -0.125, 0.25, LEG_HEIGHT, 0.125);
                class_238 body = new class_238(-BODY_WIDTH / 2, LEG_HEIGHT, -BODY_DEPTH / 2,
                                BODY_WIDTH / 2, LEG_HEIGHT + BODY_HEIGHT, BODY_DEPTH / 2);
                class_238 head = new class_238(-HEAD_SIZE / 2, LEG_HEIGHT + BODY_HEIGHT, -HEAD_SIZE / 2,
                                HEAD_SIZE / 2, LEG_HEIGHT + BODY_HEIGHT + HEAD_SIZE, HEAD_SIZE / 2);
                class_238 leftArm = new class_238(-BODY_WIDTH / 2 - ARM_WIDTH, LEG_HEIGHT + BODY_HEIGHT - ARM_HEIGHT,
                                -ARM_WIDTH / 2,
                                -BODY_WIDTH / 2, LEG_HEIGHT + BODY_HEIGHT, ARM_WIDTH / 2);
                class_238 rightArm = new class_238(BODY_WIDTH / 2, LEG_HEIGHT + BODY_HEIGHT - ARM_HEIGHT, -ARM_WIDTH / 2,
                                BODY_WIDTH / 2 + ARM_WIDTH, LEG_HEIGHT + BODY_HEIGHT, ARM_WIDTH / 2);

                class_238[] bodyParts = { leftLeg, rightLeg, body, head, leftArm, rightArm };

                class_4588 consumer = immediate.method_73477(ClientPipelines.CRYSTAL_FILLED);
                Matrix4f matrix = stack.method_23760().method_23761();

                float centerX = 0;
                float centerY = MODEL_CENTER_Y;
                float centerZ = 0;
                float maxDist = 1.0f;

                for (class_238 part : bodyParts) {
                        drawBoxWithVignette(matrix, consumer, part, centerX, centerY, centerZ, maxDist);
                }
        }

        private void drawBoxWithVignette(Matrix4f matrix, class_4588 consumer, class_238 box,
                        float centerX, float centerY, float centerZ, float maxDist) {
                float x1 = (float) box.field_1323;
                float y1 = (float) box.field_1322;
                float z1 = (float) box.field_1321;
                float x2 = (float) box.field_1320;
                float y2 = (float) box.field_1325;
                float z2 = (float) box.field_1324;

                drawQuadVignette(matrix, consumer, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, centerX, centerY,
                                centerZ, maxDist);
                drawQuadVignette(matrix, consumer, x1, y2, z2, x2, y2, z2, x2, y2, z1, x1, y2, z1, centerX, centerY,
                                centerZ, maxDist);
                drawQuadVignette(matrix, consumer, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1, centerX, centerY,
                                centerZ, maxDist);
                drawQuadVignette(matrix, consumer, x2, y1, z2, x2, y2, z2, x1, y2, z2, x1, y1, z2, centerX, centerY,
                                centerZ, maxDist);
                drawQuadVignette(matrix, consumer, x1, y1, z2, x1, y2, z2, x1, y2, z1, x1, y1, z1, centerX, centerY,
                                centerZ, maxDist);
                drawQuadVignette(matrix, consumer, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2, centerX, centerY,
                                centerZ, maxDist);
        }

        private void drawQuadVignette(Matrix4f matrix, class_4588 consumer,
                        float x1, float y1, float z1,
                        float x2, float y2, float z2,
                        float x3, float y3, float z3,
                        float x4, float y4, float z4,
                        float centerX, float centerY, float centerZ, float maxDist) {

                consumer.method_22918(matrix, x1, y1, z1)
                                .method_39415(getVignetteColor(x1, y1, z1, centerX, centerY, centerZ, maxDist));
                consumer.method_22918(matrix, x2, y2, z2)
                                .method_39415(getVignetteColor(x2, y2, z2, centerX, centerY, centerZ, maxDist));
                consumer.method_22918(matrix, x3, y3, z3)
                                .method_39415(getVignetteColor(x3, y3, z3, centerX, centerY, centerZ, maxDist));
                consumer.method_22918(matrix, x4, y4, z4)
                                .method_39415(getVignetteColor(x4, y4, z4, centerX, centerY, centerZ, maxDist));
        }

        private int getVignetteColor(float x, float y, float z,
                        float centerX, float centerY, float centerZ, float maxDist) {

                float modelHalfWidth = 0.7f;
                float modelHalfHeight = 1f;
                float modelHalfDepth = 1f;

                float dx = Math.abs(x - centerX) / modelHalfWidth;
                float dy = Math.abs(y - centerY) / modelHalfHeight;
                float dz = Math.abs(z - centerZ) / modelHalfDepth;

                float t = Math.max(Math.max(dx, dy), dz);
                t = Math.min(1f, t);

                float colorIntensity = 0.6f;
                t = t * colorIntensity;

                FreeCam freeCam = new FreeCam();
                
                int clientColor = freeCam.fakeplayer.getColor();
                int white = ColorUtil.rgba(255, 255, 255, currentAlpha);

                return ColorUtil.interpolateColor(white, clientColor, t);
        }

        public void renderFromBox(class_238 playerBox, float alpha) {
                double centerX = (playerBox.field_1323 + playerBox.field_1320) / 2;
                double bottomY = playerBox.field_1322;
                double centerZ = (playerBox.field_1321 + playerBox.field_1324) / 2;

                render(new class_243(centerX, bottomY, centerZ), alpha);
        }
}
