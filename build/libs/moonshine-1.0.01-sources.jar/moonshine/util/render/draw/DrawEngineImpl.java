package moonshine.util.render.draw;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import org.joml.Matrix4f;
import org.joml.Vector4i;
import moonshine.IMinecraft;
import net.minecraft.class_287;
import net.minecraft.class_4587;

import static com.mojang.blaze3d.vertex.VertexFormat.class_5596.field_27382;
import static net.minecraft.class_290.field_1575;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class DrawEngineImpl implements DrawEngine, IMinecraft {
    @Override
    public void quad(Matrix4f matrix4f, class_287 buffer, float x, float y, float width, float height) {
        buffer.method_22918(matrix4f, x, y, 0);
        buffer.method_22918(matrix4f, x, y + height, 0);
        buffer.method_22918(matrix4f, x + width, y + height, 0);
        buffer.method_22918(matrix4f, x + width, y, 0);
    }

    @Override
    public void quad(Matrix4f matrix4f, class_287 buffer, float x, float y, float width, float height, int color) {
        buffer.method_22918(matrix4f, x, y, 0).method_39415(color);
        buffer.method_22918(matrix4f, x, y + height, 0).method_39415(color);
        buffer.method_22918(matrix4f, x + width, y + height, 0).method_39415(color);
        buffer.method_22918(matrix4f, x + width, y, 0).method_39415(color);
    }

    @Override
    public void quad(Matrix4f matrix4f, float x, float y, float width, float height, int color) {
        class_287 buffer = tessellator.method_60827(field_27382, field_1575);
        buffer.method_22918(matrix4f, x, y + height, 0).method_22913(0, 0).method_39415(color);
        buffer.method_22918(matrix4f, x + width, y + height, 0).method_22913(0, 1).method_39415(color);
        buffer.method_22918(matrix4f, x + width, y, 0).method_22913(1, 1).method_39415(color);
        buffer.method_22918(matrix4f, x, y, 0).method_22913(1, 0).method_39415(color);

    }

    @Override
    public void quadTexture(class_4587.class_4665 entry, class_287 buffer, float x, float y, float width, float height, Vector4i color) {
        buffer.method_56824(entry, x, y + height, 0).method_22913(0, 0).method_39415(color.x);
        buffer.method_56824(entry, x + width, y + height, 0).method_22913(0, 1).method_39415(color.y);
        buffer.method_56824(entry, x + width, y, 0).method_22913(1, 1).method_39415(color.w);
        buffer.method_56824(entry, x, y, 0).method_22913(1, 0).method_39415(color.z);
    }
}