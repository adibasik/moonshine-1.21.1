package moonshine.util.render.draw;

import net.minecraft.class_287;
import net.minecraft.class_4587;
import org.joml.Matrix4f;
import org.joml.Vector4i;

public interface DrawEngine {

    void quad(Matrix4f matrix4f, class_287 buffer, float x, float y, float width, float height);

    void quad(Matrix4f matrix4f, class_287 buffer, float x, float y, float width, float height, int color);
    void quadTexture(class_4587.class_4665 entry, class_287 buffer, float x, float y, float width, float height, Vector4i color);

    void quad(Matrix4f matrix4f, float x, float y, float width, float height, int color);
}
