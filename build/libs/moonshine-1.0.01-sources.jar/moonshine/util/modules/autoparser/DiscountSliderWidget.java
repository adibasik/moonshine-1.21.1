package moonshine.util.modules.autoparser;

import moonshine.modules.impl.misc.autoparser.AutoParser;
import net.minecraft.class_2561;
import net.minecraft.class_357;

public class DiscountSliderWidget extends class_357 {

    public DiscountSliderWidget(int x, int y, int width, int height, int initialValue) {
        super(x, y, width, height, class_2561.method_43470("Уменьшить цены на: " + initialValue + "%"), (initialValue - 10) / 80.0);
    }

    @Override
    protected void method_25346() {
        int percent = (int) (this.field_22753 * 80) + 10;
        this.method_25355(class_2561.method_43470("Уменьшить цены на: " + percent + "%"));
    }

    @Override
    protected void method_25344() {
        int percent = (int) (this.field_22753 * 80) + 10;
        AutoParser parser = AutoParser.getInstance();
        if (parser != null) {
            parser.setDiscountPercent(percent);
        }
    }
}