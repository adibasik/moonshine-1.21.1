package moonshine.util.modules.autobuy;

import moonshine.util.timer.TimerUtil;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_8646;
import java.util.ArrayList;
import java.util.List;

public class ServerManager {
    private List<String> anarchyServers165 = new ArrayList<>();
    private List<String> anarchyServers214 = new ArrayList<>();
    private int currentServerIndex = 0;
    private String currentServer = "";
    private boolean inHub = false;
    private boolean waitingForServerLoad = false;

    private TimerUtil hubCheckTimer = TimerUtil.create();
    private TimerUtil serverSwitchCooldown = TimerUtil.create();

    public ServerManager() {
        initializeServers();
    }

    private void initializeServers() {
        anarchyServers165.addAll(List.of("/an102", "/an103", "/an104", "/an105", "/an106", "/an107"));
        for (int i = 203; i <= 221; i++) {
            anarchyServers165.add("/an" + i);
        }
        for (int i = 302; i <= 313; i++) {
            anarchyServers165.add("/an" + i);
        }
        anarchyServers165.addAll(List.of("/an502", "/an503", "/an504", "/an505", "/an506", "/an507", "/an602"));

        for (int i = 11; i <= 14; i++) {
            anarchyServers214.add("/an" + i);
        }
        for (int i = 21; i <= 27; i++) {
            anarchyServers214.add("/an" + i);
        }
        for (int i = 31; i <= 34; i++) {
            anarchyServers214.add("/an" + i);
        }
        for (int i = 51; i <= 53; i++) {
            anarchyServers214.add("/an" + i);
        }
        anarchyServers214.add("/an91");
    }

    public void resetTimers() {
        hubCheckTimer.resetCounter();
        serverSwitchCooldown.resetCounter();
    }

    public void reset() {
        currentServerIndex = 0;
        currentServer = "";
        inHub = false;
        waitingForServerLoad = false;
        resetTimers();
    }

    public void updateHubStatus(class_638 world) {
        inHub = isInHubInternal(world);
    }

    private boolean isInHubInternal(class_638 world) {
        if (world == null) return true;
        class_269 scoreboard = world.method_8428();
        class_266 objective = scoreboard.method_1189(class_8646.field_45157);
        if (objective == null) {
            return true;
        }
        String displayName = objective.method_1114().getString();
        return !displayName.contains("Анархия-");
    }

    private int getCurrentAnarchyNumber(class_638 world) {
        if (world == null) return -1;
        class_269 scoreboard = world.method_8428();
        class_266 objective = scoreboard.method_1189(class_8646.field_45157);
        if (objective != null) {
            String displayName = objective.method_1114().getString();
            if (displayName.contains("Анархия-")) {
                String[] parts = displayName.split("-");
                if (parts.length > 1) {
                    try {
                        return Integer.parseInt(parts[1].trim());
                    } catch (NumberFormatException e) {
                        return -1;
                    }
                }
            }
        }
        return -1;
    }

    private String getNextServer(List<String> servers, class_638 world) {
        if (servers.isEmpty()) return null;

        int currentAnarchy = getCurrentAnarchyNumber(world);

        if (currentAnarchy != -1) {
            String currentServerCmd = "/an" + currentAnarchy;
            int currentIdx = servers.indexOf(currentServerCmd);
            if (currentIdx != -1) {
                currentServerIndex = currentIdx;
            }
        }

        currentServerIndex = (currentServerIndex + 1) % servers.size();
        return servers.get(currentServerIndex);
    }

    public void switchToNextServer(class_746 player, NetworkManager networkManager, String serverType) {
        if (!serverSwitchCooldown.hasTimeElapsed(3000)) {
            return;
        }

        List<String> availableServers = getAvailableServers(serverType);
        if (availableServers == null || availableServers.isEmpty()) return;

        class_638 world = (class_638) player.method_73183();
        String newServer = getNextServer(availableServers, world);

        if (newServer != null) {
            currentServer = newServer;
            player.field_3944.method_45730(newServer.substring(1));
            networkManager.sendServerSwitch(newServer);
            waitingForServerLoad = true;
            serverSwitchCooldown.resetCounter();
        }
    }

    public void joinAnarchyFromHub(class_746 player, String serverType) {
        List<String> availableServers = getAvailableServers(serverType);
        if (availableServers == null || availableServers.isEmpty()) return;

        String server = availableServers.get(0);
        player.field_3944.method_45730(server.substring(1));
        waitingForServerLoad = true;
        hubCheckTimer.resetCounter();
    }

    private List<String> getAvailableServers(String serverType) {
        if (serverType.equals("1.21.4")) {
            return new ArrayList<>(anarchyServers214);
        } else if (serverType.equals("1.16.5")) {
            return new ArrayList<>(anarchyServers165);
        }
        return null;
    }

    public boolean shouldJoinAnarchy(String serverType) {
        boolean hasServerType = serverType.equals("1.16.5") || serverType.equals("1.21.4");
        return inHub && hubCheckTimer.hasTimeElapsed(3000) && hasServerType;
    }

    public boolean isInHub() {
        return inHub;
    }

    public boolean isWaitingForServerLoad() {
        return waitingForServerLoad;
    }

    public void setWaitingForServerLoad(boolean value) {
        waitingForServerLoad = value;
    }

    public String getCurrentServer() {
        return currentServer;
    }
}