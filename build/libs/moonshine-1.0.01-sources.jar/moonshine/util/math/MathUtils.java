package moonshine.util.math;

import lombok.Getter;
import lombok.experimental.UtilityClass;
import org.joml.Matrix3x2fStack;
import org.joml.Vector3d;
import moonshine.IMinecraft;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_9848;
import java.util.concurrent.ThreadLocalRandom;

import static net.minecraft.class_3532.method_16436;

@UtilityClass
public class MathUtils implements IMinecraft {
    public double PI2 = Math.PI * 2;

    @Getter
    private static float contextAlpha = 1.0f;

    public boolean isHovered(double mouseX, double mouseY, double x, double y, double width, double height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

    public static float clamp(float num, float min, float max) {
        return num < min ? min : Math.min(num, max);
    }

    public double computeGcd() {
        return (Math.pow(mc.field_1690.method_42495().method_41753() * 0.6 + 0.2, 3.0)) * 1.2;
    }

    public int getRandom(int min, int max) {
        return (int) getRandom((float) min, (float) max + 1);
    }

    public float getRandom(float min, float max) {
        return (float) getRandom(min, (double) max);
    }

    public double getRandom(double min, double max) {
        if (min == max) {
            return min;
        } else {
            if (min > max) {
                double d = min;
                min = max;
                max = d;
            }
            return ThreadLocalRandom.current().nextDouble(min, max);
        }
    }

    public void scale(Matrix3x2fStack stack, float x, float y, float scaleX, float scaleY, Runnable data) {
        float sumScale = scaleX * scaleY;
        if (sumScale != 1 && sumScale > 0) {
            float prevAlpha = contextAlpha;
            contextAlpha = sumScale;

            stack.pushMatrix();
            stack.translate(x, y);
            stack.scale(scaleX, scaleY);
            stack.translate(-x, -y);
            data.run();
            stack.popMatrix();

            contextAlpha = prevAlpha;
        } else if (sumScale >= 1) {
            data.run();
        }
    }

    public float textScrolling(float textWidth) {
        int speed = (int) (textWidth * 75);
        return (float) class_3532.method_15350((System.currentTimeMillis() % speed * Math.PI / speed), 0, 1) * textWidth;
    }

    public double round(double num, double increment) {
        double rounded = Math.round(num / increment) * increment;
        return Math.round(rounded * 100.0) / 100.0;
    }

    public int floorNearestMulN(int x, int n) {
        return n * (int) Math.floor((double) x / (double) n);
    }

    public int getRed(int hex) {
        return hex >> 16 & 255;
    }

    public int getGreen(int hex) {
        return hex >> 8 & 255;
    }

    public int getBlue(int hex) {
        return hex & 255;
    }

    public int getAlpha(int hex) {
        return hex >> 24 & 255;
    }

    public int applyOpacity(int color, float opacity) {
        return class_9848.method_61324((int) (getAlpha(color) * opacity / 255), getRed(color), getGreen(color), getBlue(color));
    }

    public int applyContextAlpha(int color) {
        int a = (int) (getAlpha(color) * contextAlpha);
        return class_9848.method_61324(a, getRed(color), getGreen(color), getBlue(color));
    }

    public class_243 cosSin(int i, int size, double width) {
        int index = Math.min(i, size);
        float cos = (float) (Math.cos(index * MathUtils.PI2 / size) * width);
        float sin = (float) (-Math.sin(index * MathUtils.PI2 / size) * width);
        return new class_243(cos, 0, sin);
    }

    public double absSinAnimation(double input) {
        return Math.abs(1 + Math.sin(input)) / 2;
    }

    public Vector3d interpolate(Vector3d prevPos, Vector3d pos) {
        return new Vector3d(interpolate(prevPos.x, pos.x), interpolate(prevPos.y, pos.y), interpolate(prevPos.z, pos.z));
    }

    public static float interpolate(float prev, float to, float value) {
        return prev + (to - prev) * value;
    }

    public class_243 interpolate(class_243 prevPos, class_243 pos) {
        return new class_243(interpolate(prevPos.field_1352, pos.field_1352), interpolate(prevPos.field_1351, pos.field_1351), interpolate(prevPos.field_1350, pos.field_1350));
    }

    public class_243 interpolate(class_1297 entity) {
        if (entity == null) return class_243.field_1353;
        return new class_243(
                interpolate(entity.field_6014, entity.method_23317()),
                interpolate(entity.field_6036, entity.method_23318()),
                interpolate(entity.field_5969, entity.method_23321())
        );
    }

    public float interpolate(float prev, float orig) {
        return method_16439(tickCounter.method_60637(false), prev, orig);
    }

    public double interpolate(double prev, double orig) {
        return method_16436(tickCounter.method_60637(false), prev, orig);
    }

    public float interpolateSmooth(double smooth, float prev, float orig) {
        return (float) method_16436(tickCounter.method_60638() / smooth, prev, orig);
    }
}