package moonshine.util.math;

import lombok.experimental.UtilityClass;
import org.joml.Matrix4d;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4d;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;
import moonshine.IMinecraft;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.MathAngle;
import moonshine.util.render.Render3D;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4604;

@UtilityClass
public class Projection implements IMinecraft {

    private static final double NEAR_PLANE = 0.05;

    public class_243 worldSpaceToScreenSpace(class_243 pos) {
        class_4184 camera = mc.method_1561().field_4686;
        if (camera == null) return class_243.field_1353;

        int displayHeight = mc.method_22683().method_4507();
        int[] viewport = new int[4];
        GL11.glGetIntegerv(GL11.GL_VIEWPORT, viewport);
        Vector3f target = new Vector3f();

        double deltaX = pos.field_1352 - camera.method_71156().field_1352;
        double deltaY = pos.field_1351 - camera.method_71156().field_1351;
        double deltaZ = pos.field_1350 - camera.method_71156().field_1350;

        Vector4f transformedCoordinates = new Vector4f((float) deltaX, (float) deltaY, (float) deltaZ, 1.0F);
        transformedCoordinates.mul(Render3D.lastWorldSpaceMatrix);

        Matrix4f matrixProj = new Matrix4f(Render3D.lastProjMat);
        Matrix4f matrixModel = new Matrix4f(Render3D.lastModMat);

        matrixProj.mul(matrixModel).project(transformedCoordinates.x(), transformedCoordinates.y(), transformedCoordinates.z(), viewport, target);

        return new class_243(
                target.x / mc.method_22683().method_4495(),
                (displayHeight - target.y) / mc.method_22683().method_4495(),
                target.z
        );
    }

    private Matrix4d toMatrix4d(Matrix4f mat) {
        Matrix4d result = new Matrix4d();
        result.m00(mat.m00()).m01(mat.m01()).m02(mat.m02()).m03(mat.m03());
        result.m10(mat.m10()).m11(mat.m11()).m12(mat.m12()).m13(mat.m13());
        result.m20(mat.m20()).m21(mat.m21()).m22(mat.m22()).m23(mat.m23());
        result.m30(mat.m30()).m31(mat.m31()).m32(mat.m32()).m33(mat.m33());
        return result;
    }

    private double getViewZ(class_243 pos, class_243 cameraPos) {
        double deltaX = pos.field_1352 - cameraPos.field_1352;
        double deltaY = pos.field_1351 - cameraPos.field_1351;
        double deltaZ = pos.field_1350 - cameraPos.field_1350;

        Matrix4d worldSpace = toMatrix4d(Render3D.lastWorldSpaceMatrix);
        Vector4d view = new Vector4d(deltaX, deltaY, deltaZ, 1.0);
        worldSpace.transform(view);

        return -view.z;
    }

    private ClipResult worldSpaceToClipSpaceDouble(class_243 pos, class_243 cameraPos) {
        double deltaX = pos.field_1352 - cameraPos.field_1352;
        double deltaY = pos.field_1351 - cameraPos.field_1351;
        double deltaZ = pos.field_1350 - cameraPos.field_1350;

        Matrix4d worldSpace = toMatrix4d(Render3D.lastWorldSpaceMatrix);
        Vector4d view = new Vector4d(deltaX, deltaY, deltaZ, 1.0);
        worldSpace.transform(view);

        Matrix4d proj = toMatrix4d(Render3D.lastProjMat);
        Matrix4d model = toMatrix4d(Render3D.lastModMat);
        Matrix4d combined = new Matrix4d(proj).mul(model);

        double clipX = combined.m00() * view.x + combined.m10() * view.y + combined.m20() * view.z + combined.m30() * view.w;
        double clipY = combined.m01() * view.x + combined.m11() * view.y + combined.m21() * view.z + combined.m31() * view.w;
        double clipZ = combined.m02() * view.x + combined.m12() * view.y + combined.m22() * view.z + combined.m32() * view.w;
        double clipW = combined.m03() * view.x + combined.m13() * view.y + combined.m23() * view.z + combined.m33() * view.w;

        return new ClipResult(clipX, clipY, clipZ, clipW, -view.z);
    }

    private class_243 clipToScreenDouble(ClipResult clip, int[] viewport, int displayHeight, double scale) {
        double w = clip.w;
        if (Math.abs(w) < 1e-14) {
            return new class_243(viewport[2] / scale / 2.0, displayHeight / scale / 2.0, 0);
        }

        double invW = 1.0 / w;
        double ndcX = clip.x * invW;
        double ndcY = clip.y * invW;
        double ndcZ = clip.z * invW;

        double screenX = (ndcX * 0.5 + 0.5) * viewport[2] / scale;
        double screenY = (displayHeight - (ndcY * 0.5 + 0.5) * viewport[3]) / scale;
        double screenZ = ndcZ * 0.5 + 0.5;

        return new class_243(screenX, screenY, w > 0 ? screenZ : -1);
    }

    public static double getDistanceToGround() {
        if (mc.field_1724 == null || mc.field_1687 == null) return 256;
        for (double y = mc.field_1724.method_23318(); y > 0; y -= 0.1) {
            if (!mc.field_1687.method_8320(mc.field_1724.method_24515().method_10087((int) ((mc.field_1724.method_23318() - y) + 1))).method_26215()) {
                return mc.field_1724.method_23318() - y;
            }
        }
        return 256;
    }

    public class_243 interpolate(class_1297 entity) {
        float tickDelta = mc.method_61966().method_60637(true);
        return entity.method_30950(tickDelta);
    }

    public class_243 interpolate(class_1297 entity, float tickDelta) {
        return entity.method_30950(tickDelta);
    }

    public Vector4d getVector4D(class_1297 ent) {
        return getVector4D(ent, mc.method_61966().method_60637(true));
    }

    public Vector4d getVector4D(class_1297 ent, float tickDelta) {
        if (ent == null) return null;
        class_4184 camera = mc.method_1561().field_4686;
        if (camera == null) return null;

        class_243 cameraPos = camera.method_71156();
        class_243 interp = ent.method_30950(tickDelta);
        class_243 entityPos = ent.method_73189();
        class_238 box = ent.method_5829().method_997(interp.method_1020(entityPos));

        class_243 boxCenter = box.method_1005();

        double centerViewZ = getViewZ(boxCenter, cameraPos);
        if (centerViewZ < -5.0) {
            return null;
        }

        int displayHeight = mc.method_22683().method_4507();
        int[] viewport = new int[4];
        GL11.glGetIntegerv(GL11.GL_VIEWPORT, viewport);
        double scale = mc.method_22683().method_4495();

        double screenW = mc.method_22683().method_4486();
        double screenH = mc.method_22683().method_4502();

        class_243[] corners = new class_243[]{
                new class_243(box.field_1323, box.field_1322, box.field_1321),
                new class_243(box.field_1323, box.field_1322, box.field_1324),
                new class_243(box.field_1320, box.field_1322, box.field_1321),
                new class_243(box.field_1320, box.field_1322, box.field_1324),
                new class_243(box.field_1323, box.field_1325, box.field_1321),
                new class_243(box.field_1323, box.field_1325, box.field_1324),
                new class_243(box.field_1320, box.field_1325, box.field_1321),
                new class_243(box.field_1320, box.field_1325, box.field_1324)
        };

        int[][] edges = {
                {0, 1}, {0, 2}, {1, 3}, {2, 3},
                {4, 5}, {4, 6}, {5, 7}, {6, 7},
                {0, 4}, {1, 5}, {2, 6}, {3, 7}
        };

        ClipResult[] clipResults = new ClipResult[8];
        for (int i = 0; i < 8; i++) {
            clipResults[i] = worldSpaceToClipSpaceDouble(corners[i], cameraPos);
            if (clipResults[i] == null) return null;
        }

        double minX = Double.MAX_VALUE;
        double minY = Double.MAX_VALUE;
        double maxX = -Double.MAX_VALUE;
        double maxY = -Double.MAX_VALUE;

        int visibleCount = 0;

        for (int i = 0; i < 8; i++) {
            ClipResult clip = clipResults[i];
            if (clip.viewZ > NEAR_PLANE) {
                visibleCount++;
                class_243 screen = clipToScreenDouble(clip, viewport, displayHeight, scale);
                double px = clampScreenX(screen.field_1352, screenW);
                double py = clampScreenY(screen.field_1351, screenH);

                minX = Math.min(minX, px);
                minY = Math.min(minY, py);
                maxX = Math.max(maxX, px);
                maxY = Math.max(maxY, py);
            }
        }

        for (int[] edge : edges) {
            ClipResult c0 = clipResults[edge[0]];
            ClipResult c1 = clipResults[edge[1]];

            boolean v0 = c0.viewZ > NEAR_PLANE;
            boolean v1 = c1.viewZ > NEAR_PLANE;

            if (v0 != v1) {
                double denom = c1.viewZ - c0.viewZ;
                if (Math.abs(denom) < 1e-14) continue;

                double t = (NEAR_PLANE - c0.viewZ) / denom;
                t = Math.max(0.0, Math.min(1.0, t));

                ClipResult clipped = new ClipResult(
                        c0.x + t * (c1.x - c0.x),
                        c0.y + t * (c1.y - c0.y),
                        c0.z + t * (c1.z - c0.z),
                        c0.w + t * (c1.w - c0.w),
                        NEAR_PLANE
                );

                class_243 screen = clipToScreenDouble(clipped, viewport, displayHeight, scale);
                double px = clampScreenX(screen.field_1352, screenW);
                double py = clampScreenY(screen.field_1351, screenH);

                minX = Math.min(minX, px);
                minY = Math.min(minY, py);
                maxX = Math.max(maxX, px);
                maxY = Math.max(maxY, py);
            }
        }

        if (visibleCount == 0 && minX == Double.MAX_VALUE) {
            return null;
        }

        if (maxX <= minX || maxY <= minY) return null;

        minX = Math.max(-screenW, minX);
        minY = Math.max(-screenH, minY);
        maxX = Math.min(screenW * 2, maxX);
        maxY = Math.min(screenH * 2, maxY);

        return new Vector4d(minX, minY, maxX, maxY);
    }

    private double clampScreenX(double x, double screenW) {
        return Math.max(-screenW * 2, Math.min(screenW * 3, x));
    }

    private double clampScreenY(double y, double screenH) {
        return Math.max(-screenH * 2, Math.min(screenH * 3, y));
    }

    private boolean isPointInFrontDouble(class_243 point, class_243 cameraPos, class_4184 camera) {
        double toPointX = point.field_1352 - cameraPos.field_1352;
        double toPointY = point.field_1351 - cameraPos.field_1351;
        double toPointZ = point.field_1350 - cameraPos.field_1350;

        double yaw = camera.method_19330();
        double pitch = camera.method_19329();

        double yawRad = Math.toRadians(yaw);
        double pitchRad = Math.toRadians(pitch);

        double cosPitch = Math.cos(pitchRad);
        double lookX = -Math.sin(yawRad) * cosPitch;
        double lookY = -Math.sin(pitchRad);
        double lookZ = Math.cos(yawRad) * cosPitch;

        double dot = lookX * toPointX + lookY * toPointY + lookZ * toPointZ;

        return dot > -10.0;
    }

    public boolean canSee(class_243 vec3d) {
        class_4184 camera = mc.field_1773.method_19418();
        if (camera == null) return false;
        Angle angle = MathAngle.fromVec3d(vec3d.method_1020(camera.method_71156()));
        return (Math.abs(class_3532.method_15392(angle.getYaw() - camera.method_19330())) < 90 &&
                Math.abs(class_3532.method_15392(angle.getPitch() - camera.method_19329())) < 60) ||
                canSee(new class_238(class_2338.method_49638(vec3d)));
    }

    public boolean canSee(class_238 box) {
        if (box == null || mc.field_1773 == null) return false;

        class_4184 camera = mc.field_1773.method_19418();
        if (camera == null || !camera.method_19332()) return false;

        class_243 cameraPos = camera.method_71156();

        Matrix4f viewMatrix = new Matrix4f().rotation(camera.method_23767());
        Matrix4f projectionMatrix = mc.field_1773.method_22973(mc.field_1690.method_41808().method_41753().floatValue());

        class_4604 frustum = new class_4604(viewMatrix, projectionMatrix);
        frustum.method_23088(cameraPos.field_1352, cameraPos.field_1351, cameraPos.field_1350);

        return frustum.method_23093(box);
    }

    public boolean cantSee(Vector4d vec) {
        if (vec == null) return true;

        double screenWidth = mc.method_22683().method_4486();
        double screenHeight = mc.method_22683().method_4502();

        if (Double.isNaN(vec.x) || Double.isNaN(vec.y) || Double.isNaN(vec.z) || Double.isNaN(vec.w)) return true;
        if (Double.isInfinite(vec.x) || Double.isInfinite(vec.y) || Double.isInfinite(vec.z) || Double.isInfinite(vec.w)) return true;

        if (vec.z < -screenWidth || vec.x > screenWidth * 2) return true;
        if (vec.w < -screenHeight || vec.y > screenHeight * 2) return true;

        return false;
    }

    public double centerX(Vector4d vec) {
        return vec.x + (vec.z - vec.x) / 2;
    }

    public boolean isInFrontOfCamera(class_243 worldPos) {
        class_4184 camera = mc.field_1773.method_19418();
        if (camera == null || !camera.method_19332()) return false;

        return isPointInFrontDouble(worldPos, camera.method_71156(), camera);
    }

    private record ClipResult(double x, double y, double z, double w, double viewZ) {}
}