package moonshine.util.move;

import moonshine.IMinecraft;
import moonshine.modules.impl.combat.aura.AngleConnection;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_744;
import java.util.Objects;

import static net.minecraft.class_3532.method_15338;

public class MoveUtil implements IMinecraft {

    public static boolean hasPlayerMovement() {
        class_744 input = mc.field_1724.field_3913;
        if (input.method_20622()) {
            return true;
        }
        class_241 vec = input.method_3128();
        return vec.field_1343 != 0f || vec.field_1342 != 0f;
    }

    public static double getDistanceToGround() {
        for (double y = mc.field_1724.method_23318(); y > 0; y -= 0.1) {
            if (!mc.field_1687.method_8320(mc.field_1724.method_24515().method_10087((int) ((mc.field_1724.method_23318() - y) + 1))).method_26215()) {
                return mc.field_1724.method_23318() - y;
            }
        }
        return 256;
    }

    public static double getDegreesRelativeToView(
            class_243 positionRelativeToPlayer,
            float yaw) {

        float optimalYaw =
                (float) Math.atan2(-positionRelativeToPlayer.field_1352, positionRelativeToPlayer.field_1350);
        double currentYaw = Math.toRadians(method_15393(yaw));

        return Math.toDegrees(method_15338((optimalYaw - currentYaw)));
    }

    public static void setVelocity(double velocity) {
        final double[] direction = calculateDirection(velocity);
        Objects.requireNonNull(mc.field_1724).method_18800(direction[0], mc.field_1724.method_18798().method_10214(), direction[1]);
    }

    public static double[] forward(final double d) {
        class_241 movement = mc.field_1724.field_3913.method_3128();
        float f = movement.field_1342;
        float f2 = movement.field_1343;
        float f3 = AngleConnection.INSTANCE.getRotation().getYaw();
        if (f != 0.0f) {
            if (f2 > 0.0f) {
                f3 += ((f > 0.0f) ? -45 : 45);
            } else if (f2 < 0.0f) {
                f3 += ((f > 0.0f) ? 45 : -45);
            }
            f2 = 0.0f;
            if (f > 0.0f) {
                f = 1.0f;
            } else if (f < 0.0f) {
                f = -1.0f;
            }
        }
        final double d2 = Math.sin(Math.toRadians(f3 + 90.0f));
        final double d3 = Math.cos(Math.toRadians(f3 + 90.0f));
        final double d4 = f * d * d3 + f2 * d * d2;
        final double d5 = f * d * d2 - f2 * d * d3;
        return new double[]{d4, d5};
    }

    public static double[] calculateDirection(double distance) {
        class_241 movement = mc.field_1724.field_3913.method_3128();
        float forward = movement.field_1342;
        float sideways = movement.field_1343;
        return calculateDirection(forward, sideways, distance);
    }

    public static double[] calculateDirection(float forward, float sideways, double distance) {
        float yaw = AngleConnection.INSTANCE.getRotation().getYaw();
        if (forward != 0.0f) {
            if (sideways > 0.0f) {
                yaw += (forward > 0.0f) ? -45 : 45;
            } else if (sideways < 0.0f) {
                yaw += (forward > 0.0f) ? 45 : -45;
            }
            sideways = 0.0f;
            forward = (forward > 0.0f) ? 1.0f : -1.0f;
        }

        double sinYaw = Math.sin(Math.toRadians(yaw + 90.0f));
        double cosYaw = Math.cos(Math.toRadians(yaw + 90.0f));
        double xMovement = forward * distance * cosYaw + sideways * distance * sinYaw;
        double zMovement = forward * distance * sinYaw - sideways * distance * cosYaw;

        return new double[]{xMovement, zMovement};
    }

    public static final boolean moveKeyPressed(int keyNumber) {
        boolean w = mc.field_1690.field_1894.method_1434();
        boolean a = mc.field_1690.field_1913.method_1434();
        boolean s = mc.field_1690.field_1881.method_1434();
        boolean d = mc.field_1690.field_1849.method_1434();
        return keyNumber == 0 ? w : (keyNumber == 1 ? a : (keyNumber == 2 ? s : keyNumber == 3 && d));
    }

    public static final boolean w() {
        return moveKeyPressed(0);
    }

    public static final boolean a() {
        return moveKeyPressed(1);
    }

    public static final boolean s() {
        return moveKeyPressed(2);
    }

    public static final boolean d() {
        return moveKeyPressed(3);
    }

    public static final float moveYaw(float entityYaw) {
        return entityYaw + (float)(!a() || !d() || w() && s() || !w() && !s() ? (w() && s() && (!a() || !d()) && (a() || d()) ? (a() ? -90 : (d() ? 90 : 0)) : (a() && d() && (!w() || !s()) || w() && s() && (!a() || !d()) ? 0 : (!a() && !d() && !s() ? 0 : (w() && !s() ? 45 : (s() && !w() ? (!a() && !d() ? 180 : 135) : ((w() || s()) && (!w() || !s()) ? 0 : 90))) * (a() ? -1 : 1)))) : (w() ? 0 : (s() ? 180 : 0)));
    }

    public static float calculateBodyYaw(float yaw, float prevBodyYaw, double prevX, double prevZ, double currentX, double currentZ, float handSwingProgress) {
        double motionX = currentX - prevX;
        double motionZ = currentZ - prevZ;
        float motionSquared = (float)(motionX * motionX + motionZ * motionZ);
        float bodyYaw = prevBodyYaw;
        float swing = mc.field_1724.field_6251;

        if (motionSquared > 0.0025000002F) {
            float movementYaw = (float) class_3532.method_15349(motionZ, motionX) * (180F / (float)Math.PI) - 90.0F;
            float yawDiff = class_3532.method_15379(class_3532.method_15393(yaw) - movementYaw);
            if (95.0F < yawDiff && yawDiff < 265.0F) {
                bodyYaw = movementYaw - 180.0F;
            } else {
                bodyYaw = movementYaw;
            }
        }

        if (mc.field_1724 != null && mc.field_1724.field_6251 - 0.2F > 0F) {
            bodyYaw = yaw;
        }

        float deltaYaw = class_3532.method_15393(bodyYaw - prevBodyYaw);
        bodyYaw = prevBodyYaw + deltaYaw * 0.3F;

        float yawOffsetDiff = class_3532.method_15393(yaw - bodyYaw);
        float maxHeadRotation = 52.0F;
        if (Math.abs(yawOffsetDiff) > maxHeadRotation) {
            bodyYaw += yawOffsetDiff - (float)class_3532.method_17822((double)yawOffsetDiff) * maxHeadRotation;
        }

        return bodyYaw;
    }

    public static class_10185 getDirectionalInputForDegrees(class_10185 input, double dgs, float deadAngle) {
        boolean forwards = input.comp_3159();
        boolean backwards = input.comp_3160();
        boolean left = input.comp_3161();
        boolean right = input.comp_3162();

        if (dgs >= (-90.0F + deadAngle) && dgs <= (90.0F - deadAngle)) {
            forwards = true;
        } else if (dgs < (-90.0F - deadAngle) || dgs > (90.0F + deadAngle)) {
            backwards = true;
        }

        if (dgs >= (0.0F + deadAngle) && dgs <= (180.0F - deadAngle)) {
            right = true;
        } else if (dgs >= (-180.0F + deadAngle) && dgs <= (0.0F - deadAngle)) {
            left = true;
        }

        return new class_10185(forwards, backwards, left, right, input.comp_3163(), input.comp_3164(), input.comp_3165());
    }

    public static class_10185 getDirectionalInputForDegrees(class_10185 input, double dgs) {
        return getDirectionalInputForDegrees(input, dgs, 20.0F);
    }
}
