package moonshine.util.string.chat;

import moonshine.util.string.chat.helper.TextHelper;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_5250;

public class ChatMessage {
    public static class_5250 brandmessage() {
        return (class_5250) TextHelper.applyPredefinedGradient("Moonshine Client", "black_light_purple", true);
    }

    public static class_5250 blockesp() {
        return (class_5250) TextHelper.applyPredefinedGradient("Block Esp", "black_light_purple", true);
    }

    public static class_5250 autobuy() {
        return (class_5250) TextHelper.applyPredefinedGradient("Auto Buy", "black_light_purple", true);
    }

    public static class_5250 autobuiparcer() {
        return (class_5250) TextHelper.applyPredefinedGradient("Parce price", "black_light_purple", true);
    }

    public static void brandmessage(String message) {
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("Moonshine Client -> ", "black_light_purple", true);
            class_2561 formattedMessage = prefix.method_27661().method_10852(class_2561.method_43470(message));
            class_310.method_1551().field_1724.method_7353(formattedMessage, false);
        }
    }

    public static void autobuymessage(String message) {
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("AutoBuy -> ", "black_light_purple", true);
            class_2561 formattedMessage = prefix.method_27661().method_10852(class_2561.method_43470(message));
            class_310.method_1551().field_1724.method_7353(formattedMessage, false);
        }
    }

    public static void autobuymessageSuccess(String message) {
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("AutoBuy -> ", "black_light_purple", true);
            class_2561 formattedMessage = prefix.method_27661().method_10852(class_2561.method_43470(message).method_10862(class_2583.field_24360.method_10977(class_124.field_1060)));
            class_310.method_1551().field_1724.method_7353(formattedMessage, false);
        }
    }

    public static void autobuymessageError(String message) {
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("AutoBuy -> ", "black_light_purple", true);
            class_2561 formattedMessage = prefix.method_27661().method_10852(class_2561.method_43470(message).method_10862(class_2583.field_24360.method_10977(class_124.field_1061)));
            class_310.method_1551().field_1724.method_7353(formattedMessage, false);
        }
    }

    public static void autobuymessageWarning(String message) {
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("AutoBuy -> ", "black_light_purple", true);
            class_2561 formattedMessage = prefix.method_27661().method_10852(class_2561.method_43470(message).method_10862(class_2583.field_24360.method_10977(class_124.field_1054)));
            class_310.method_1551().field_1724.method_7353(formattedMessage, false);
        }
    }

    public static void ancientmessage(String message) {
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("Ancient Xray -> ", "black_light_purple", true);
            class_2561 formattedMessage = prefix.method_27661().method_10852(class_2561.method_43470(message));
            class_310.method_1551().field_1724.method_7353(formattedMessage, false);
        }
    }

    public static void helpmessage(String message) {
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("Help -> ", "black_light_purple", true);
            class_2561 formattedMessage = prefix.method_27661().method_10852(class_2561.method_43470(message));
            class_310.method_1551().field_1724.method_7353(formattedMessage, false);
        }
    }

    public static void swapmessage(String message) {
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("AutoSwap -> ", "black_light_purple", true);
            class_2561 formattedMessage = prefix.method_27661().method_10852(class_2561.method_43470(message));
            class_310.method_1551().field_1724.method_7353(formattedMessage, false);
        }
    }

    public static void ircmessage(String message) {
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("[IRC] ", "black_light_purple", true);
            class_2561 formattedMessage = prefix.method_27661().method_10852(class_2561.method_43470(message));
            class_310.method_1551().field_1724.method_7353(formattedMessage, false);
        }
    }

    public static void ircmessageWithGreen(String message) {
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("[IRC] ", "black_light_purple", true);
            class_2561 formattedMessage = prefix.method_27661().method_10852(class_2561.method_43470(message).method_10862(class_2583.field_24360.method_10977(class_124.field_1060)));
            class_310.method_1551().field_1724.method_7353(formattedMessage, false);
        }
    }

    public static void ircmessageWithRed(String message) {
        if (class_310.method_1551().field_1724 != null) {
            class_2561 prefix = TextHelper.applyPredefinedGradient("[IRC] ", "black_light_purple", true);
            class_2561 formattedMessage = prefix.method_27661().method_10852(class_2561.method_43470(message).method_10862(class_2583.field_24360.method_10977(class_124.field_1061)));
            class_310.method_1551().field_1724.method_7353(formattedMessage, false);
        }
    }

    public static class_2561 ircprefixDeveloper(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("Developer ", "dark_red_bright_red", false);
        return prefix.method_27661().method_10852(class_2561.method_43470(message));
    }

    public static class_2561 ircprefixCurator(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("Куратор ", "dark_red", false);
        return prefix.method_27661().method_10852(class_2561.method_43470(message));
    }

    public static class_2561 ircprefixYouTube(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("YouTube ", "red_white", false);
        return prefix.method_27661().method_10852(class_2561.method_43470(message));
    }

    public static class_2561 ircprefixPikmi(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("Пикми ", "purple_bright_pink", false);
        return prefix.method_27661().method_10852(class_2561.method_43470(message));
    }

    public static class_2561 ircprefixLabuba(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("Лабуба ", "pink_dark_pink", false);
        return prefix.method_27661().method_10852(class_2561.method_43470(message));
    }

    public static class_2561 ircprefixZapen(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("Запен ", "bright_red", false);
        return prefix.method_27661().method_10852(class_2561.method_43470(message));
    }

    public static class_2561 ircprefixBoost(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("Буст ", "dark_green_bright_green", false);
        return prefix.method_27661().method_10852(class_2561.method_43470(message));
    }

    public static class_2561 ircprefixMoonshine(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("Рич ", "red_orange", false);
        return prefix.method_27661().method_10852(class_2561.method_43470(message));
    }

    public static class_2561 ircprefixPanda(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("Панда ", "white_black", false);
        return prefix.method_27661().method_10852(class_2561.method_43470(message));
    }

    public static class_2561 ircprefixSmiley(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("(●'◡'●) ", "turquoise_blue", true);
        return prefix.method_27661().method_10852(class_2561.method_43470(message));
    }

    public static class_2561 ircprefixBibi(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("Биби...! ", "cyan_orange_fade", false);
        return prefix.method_27661().method_10852(class_2561.method_43470(message));
    }

    public static class_2561 ircprefixBenena(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("Бэнена ", "yellow_cyan", false);
        return prefix.method_27661().method_10852(class_2561.method_43470(message));
    }

    public static class_2561 ircprefixBlyabuba(String message) {
        class_2561 prefix = TextHelper.applyPredefinedGradient("Блябуба ", "purple_red_fade", false);
        return prefix.method_27661().method_10852(class_2561.method_43470(message));
    }
}