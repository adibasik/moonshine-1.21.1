package moonshine.util.inventory;

import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class MovementController {
    private static final class_310 mc = class_310.method_1551();

    private boolean forward, back, left, right, jump, sprint;
    private boolean saved = false;
    private boolean blocked = false;

    public void saveState() {
        if (mc.field_1724 == null) return;
        forward = isKeyPressed(mc.field_1690.field_1894);
        back = isKeyPressed(mc.field_1690.field_1881);
        left = isKeyPressed(mc.field_1690.field_1913);
        right = isKeyPressed(mc.field_1690.field_1849);
        jump = isKeyPressed(mc.field_1690.field_1903);
        sprint = mc.field_1724.method_5624();
        saved = true;
    }

    public void block() {
        if (mc.field_1724 == null) return;
        mc.field_1690.field_1894.method_23481(false);
        mc.field_1690.field_1881.method_23481(false);
        mc.field_1690.field_1913.method_23481(false);
        mc.field_1690.field_1849.method_23481(false);
        mc.field_1690.field_1903.method_23481(false);
        mc.field_1690.field_1867.method_23481(false);
        blocked = true;
    }

    public void stopSprint() {
        if (mc.field_1724 != null) {
            mc.field_1724.method_5728(false);
            mc.field_1690.field_1867.method_23481(false);
        }
    }

    public void restore() {
        if (!saved) return;
        mc.field_1690.field_1894.method_23481(forward && isCurrentlyPressed(mc.field_1690.field_1894));
        mc.field_1690.field_1881.method_23481(back && isCurrentlyPressed(mc.field_1690.field_1881));
        mc.field_1690.field_1913.method_23481(left && isCurrentlyPressed(mc.field_1690.field_1913));
        mc.field_1690.field_1849.method_23481(right && isCurrentlyPressed(mc.field_1690.field_1849));
        mc.field_1690.field_1903.method_23481(jump && isCurrentlyPressed(mc.field_1690.field_1903));
        blocked = false;
        saved = false;
    }

    public void restoreFromCurrent() {
        mc.field_1690.field_1894.method_23481(isCurrentlyPressed(mc.field_1690.field_1894));
        mc.field_1690.field_1881.method_23481(isCurrentlyPressed(mc.field_1690.field_1881));
        mc.field_1690.field_1913.method_23481(isCurrentlyPressed(mc.field_1690.field_1913));
        mc.field_1690.field_1849.method_23481(isCurrentlyPressed(mc.field_1690.field_1849));
        mc.field_1690.field_1903.method_23481(isCurrentlyPressed(mc.field_1690.field_1903));
        mc.field_1690.field_1867.method_23481(isCurrentlyPressed(mc.field_1690.field_1867));
        blocked = false;
    }

    public boolean isPlayerStopped(double threshold) {
        if (mc.field_1724 == null) return true;
        double vx = Math.abs(mc.field_1724.method_18798().field_1352);
        double vz = Math.abs(mc.field_1724.method_18798().field_1350);
        return vx < threshold && vz < threshold;
    }

    public boolean isBlocked() {
        return blocked;
    }

    public void reset() {
        saved = false;
        blocked = false;
    }

    private boolean isKeyPressed(class_304 key) {
        return key.method_1434();
    }

    private boolean isCurrentlyPressed(class_304 key) {
        return class_3675.method_15987(
                mc.method_22683(),
                class_3675.method_15981(key.method_1428()).method_1444()
        );
    }
}