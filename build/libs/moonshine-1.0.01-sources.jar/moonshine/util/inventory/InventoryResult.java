package moonshine.util.inventory;

import net.minecraft.class_1799;

public record InventoryResult(int slot, boolean found, class_1799 stack) {
    private static final InventoryResult NOT_FOUND = new InventoryResult(-1, false, class_1799.field_8037);

    public static InventoryResult notFound() {
        return NOT_FOUND;
    }

    public static InventoryResult of(int slot, class_1799 stack) {
        return new InventoryResult(slot, true, stack);
    }

    public boolean isHotbar() {
        return slot >= 0 && slot < 9;
    }

    public int toScreenSlot() {
        return slot < 9 ? slot + 36 : slot;
    }
}