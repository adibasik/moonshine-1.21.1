package moonshine.util.inventory;

import moonshine.mixin.ClientWorldAccessor;
import net.minecraft.class_10192;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2815;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_310;
import net.minecraft.class_408;
import net.minecraft.class_7202;
import net.minecraft.class_9334;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

public final class InventoryUtils {
    private static final class_310 mc = class_310.method_1551();
    private static final class_1304[] ARMOR_SLOTS = {
            class_1304.field_6166, class_1304.field_6172, class_1304.field_6174, class_1304.field_6169
    };
    private static int savedSlot = -1;
    private static int silentSlot = -1;

    private InventoryUtils() {}

    public static int findItemInHotbar(class_1792 item) {
        if (mc.field_1724 == null) return -1;
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() == item) {
                return i;
            }
        }
        return -1;
    }

    public static int findItemInInventory(class_1792 item) {
        if (mc.field_1724 == null) return -1;
        for (int i = 9; i < 36; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() == item) {
                return i;
            }
        }
        return -1;
    }

    public static int findItemAnywhere(class_1792 item) {
        int hotbar = findItemInHotbar(item);
        if (hotbar != -1) return hotbar;
        return findItemInInventory(item);
    }

    public static InventoryResult find(class_1792 item) {
        return find(stack -> stack.method_7909() == item);
    }

    public static InventoryResult find(class_1792... items) {
        return find(Arrays.asList(items));
    }

    public static InventoryResult find(List<class_1792> items) {
        return find(stack -> items.contains(stack.method_7909()));
    }

    public static boolean hasElytra() {
        if (mc.field_1724 == null) return false;
        return mc.field_1724.method_6118(class_1304.field_6174).method_58694(class_9334.field_54197) != null;
    }

    public static int findHotbarItem(class_1792 item) {
        if (mc.field_1724 == null) return -1;

        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() == item) {
                return i;
            }
        }
        return -1;
    }

    public static int findElytraSlot() {
        if (mc.field_1724 == null) return -1;

        for (int i = 0; i < 46; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_8833) {
                return i;
            }
        }
        return -1;
    }

    public static int findChestArmorSlot() {
        if (mc.field_1724 == null) return -1;

        for (int i = 0; i < 46; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            class_10192 component = stack.method_58694(class_9334.field_54196);
            if (component != null && component.comp_3174() == class_1304.field_6174 && stack.method_7909() != class_1802.field_8833) {
                return i;
            }
        }
        return -1;
    }

    public static InventoryResult find(ItemSearcher searcher) {
        if (mc.field_1724 == null) return InventoryResult.notFound();

        for (class_1304 slot : ARMOR_SLOTS) {
            class_1799 stack = mc.field_1724.method_6118(slot);
            if (isValid(stack) && searcher.matches(stack)) {
                return new InventoryResult(-2, true, stack);
            }
        }

        for (int i = 35; i >= 0; i--) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (isValid(stack) && searcher.matches(stack)) {
                int slot = i < 9 ? i + 36 : i;
                return InventoryResult.of(slot, stack);
            }
        }
        return InventoryResult.notFound();
    }

    public static InventoryResult findHotbar(class_1792 item) {
        return findHotbar(stack -> stack.method_7909() == item);
    }

    public static InventoryResult findHotbar(ItemSearcher searcher) {
        if (mc.field_1724 == null) return InventoryResult.notFound();

        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (isValid(stack) && searcher.matches(stack)) {
                return InventoryResult.of(i, stack);
            }
        }
        return InventoryResult.notFound();
    }

    public static class_1735 findSlot(class_1792 item) {
        return findSlot(s -> s.method_7677().method_7909() == item, null);
    }

    public static class_1735 findSlot(Predicate<class_1735> filter) {
        return findSlot(filter, null);
    }

    public static class_1735 findSlot(Predicate<class_1735> filter, Comparator<class_1735> comparator) {
        if (mc.field_1724 == null) return null;
        var stream = mc.field_1724.field_7512.field_7761.stream().filter(filter);
        return comparator != null ? stream.max(comparator).orElse(null) : stream.findFirst().orElse(null);
    }

    public static class_1735 findSlot(class_1792 item, Predicate<class_1735> extraFilter, Comparator<class_1735> comparator) {
        Predicate<class_1735> combined = s -> s.method_7677().method_7909() == item && extraFilter.test(s);
        return findSlot(combined, comparator);
    }

    public static class_1735 findSlotInHotbar(class_1792 item) {
        if (mc.field_1724 == null) return null;
        for (int i = 36; i <= 44; i++) {
            class_1735 slot = mc.field_1724.field_7498.method_7611(i);
            if (slot != null && !slot.method_7677().method_7960() && slot.method_7677().method_7909() == item) {
                return slot;
            }
        }
        return null;
    }

    public static class_1735 findSlotInInventory(class_1792 item) {
        if (mc.field_1724 == null) return null;
        for (int i = 9; i <= 35; i++) {
            class_1735 slot = mc.field_1724.field_7498.method_7611(i);
            if (slot != null && !slot.method_7677().method_7960() && slot.method_7677().method_7909() == item) {
                return slot;
            }
        }
        return null;
    }

    public static class_1735 findSlotAnywhere(class_1792 item) {
        class_1735 hotbar = findSlotInHotbar(item);
        if (hotbar != null) return hotbar;
        return findSlotInInventory(item);
    }

    public static class_1735 findRegularTotemSlot() {
        if (mc.field_1724 == null) return null;

        for (int i = 36; i <= 44; i++) {
            class_1735 slot = mc.field_1724.field_7498.method_7611(i);
            if (slot != null && !slot.method_7677().method_7960()
                    && slot.method_7677().method_7909() == class_1802.field_8288
                    && !slot.method_7677().method_7942()) {
                return slot;
            }
        }

        for (int i = 9; i <= 35; i++) {
            class_1735 slot = mc.field_1724.field_7498.method_7611(i);
            if (slot != null && !slot.method_7677().method_7960()
                    && slot.method_7677().method_7909() == class_1802.field_8288
                    && !slot.method_7677().method_7942()) {
                return slot;
            }
        }

        return null;
    }

    public static class_1735 findEnchantedTotemSlot() {
        if (mc.field_1724 == null) return null;

        for (int i = 36; i <= 44; i++) {
            class_1735 slot = mc.field_1724.field_7498.method_7611(i);
            if (slot != null && !slot.method_7677().method_7960()
                    && slot.method_7677().method_7909() == class_1802.field_8288
                    && slot.method_7677().method_7942()) {
                return slot;
            }
        }

        for (int i = 9; i <= 35; i++) {
            class_1735 slot = mc.field_1724.field_7498.method_7611(i);
            if (slot != null && !slot.method_7677().method_7960()
                    && slot.method_7677().method_7909() == class_1802.field_8288
                    && slot.method_7677().method_7942()) {
                return slot;
            }
        }

        return null;
    }

    public static class_1735 findTotemSlot(boolean preferNonEnchanted) {
        if (mc.field_1724 == null) return null;

        class_1735 regularTotem = null;
        class_1735 enchantedTotem = null;

        for (int i = 36; i <= 44; i++) {
            class_1735 slot = mc.field_1724.field_7498.method_7611(i);
            if (slot != null && !slot.method_7677().method_7960() && slot.method_7677().method_7909() == class_1802.field_8288) {
                if (!slot.method_7677().method_7942()) {
                    if (regularTotem == null) regularTotem = slot;
                } else {
                    if (enchantedTotem == null) enchantedTotem = slot;
                }
            }
        }

        for (int i = 9; i <= 35; i++) {
            class_1735 slot = mc.field_1724.field_7498.method_7611(i);
            if (slot != null && !slot.method_7677().method_7960() && slot.method_7677().method_7909() == class_1802.field_8288) {
                if (!slot.method_7677().method_7942()) {
                    if (regularTotem == null) regularTotem = slot;
                } else {
                    if (enchantedTotem == null) enchantedTotem = slot;
                }
            }
        }

        if (preferNonEnchanted) {
            return regularTotem != null ? regularTotem : enchantedTotem;
        } else {
            return regularTotem != null ? regularTotem : enchantedTotem;
        }
    }

    public static boolean hasEnchantedTotemInOffhand() {
        if (mc.field_1724 == null) return false;
        class_1799 offhand = mc.field_1724.method_6079();
        return offhand.method_7909() == class_1802.field_8288 && offhand.method_7942();
    }

    public static boolean hasRegularTotemInOffhand() {
        if (mc.field_1724 == null) return false;
        class_1799 offhand = mc.field_1724.method_6079();
        return offhand.method_7909() == class_1802.field_8288 && !offhand.method_7942();
    }

    public static void swap(int from, int to) {
        click(from, 0, class_1713.field_7790);
        click(to, 0, class_1713.field_7790);
        click(from, 0, class_1713.field_7790);
    }

    public static void swapHotbar(int slot, int hotbarSlot) {
        click(slot, hotbarSlot, class_1713.field_7791);
    }

    public static void swapToOffhand(int slot) {
        click(slot, 40, class_1713.field_7791);
    }

    public static void swapToOffhand(class_1735 slot) {
        if (slot != null) {
            click(slot.field_7874, 40, class_1713.field_7791);
        }
    }

    public static void swapOffhandWithSlot(int slotId) {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        int syncId = mc.field_1724.field_7498.field_7763;
        mc.field_1761.method_2906(syncId, slotId, 40, class_1713.field_7791, mc.field_1724);
    }

    public static void moveToSlot(int from, int to) {
        swap(from, to);
    }

    public static void click(int slot, int button, class_1713 type) {
        if (mc.field_1724 == null || mc.field_1761 == null || slot == -1) return;
        mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slot, button, type, mc.field_1724);
    }

    public static void selectSlot(int slot) {
        if (mc.field_1724 == null || slot < 0 || slot > 8) return;
        if (mc.field_1724.method_31548().method_67532() != slot) {
            mc.field_1724.method_31548().method_61496(slot);
        }
    }

    public static void selectSlotSilent(int slot) {
        if (mc.field_1724 == null || mc.method_1562() == null || slot < 0 || slot > 8) return;
        mc.method_1562().method_52787(new class_2868(slot));
    }

    public static void saveSlot() {
        if (mc.field_1724 != null) {
            savedSlot = mc.field_1724.method_31548().method_67532();
        }
    }

    public static void restoreSlot() {
        if (savedSlot != -1) {
            selectSlot(savedSlot);
            savedSlot = -1;
        }
    }

    public static void restoreSlotSilent() {
        if (savedSlot != -1) {
            selectSlotSilent(savedSlot);
            savedSlot = -1;
        }
    }

    public static void silentUseHotbarItem(int hotbarSlot) {
        if (mc.field_1724 == null || mc.method_1562() == null) return;

        int currentSlot = mc.field_1724.method_31548().method_67532();

        if (hotbarSlot != currentSlot) {
            mc.method_1562().method_52787(new class_2868(hotbarSlot));
        }

        sendUsePacket(class_1268.field_5808);

        if (hotbarSlot != currentSlot) {
            mc.method_1562().method_52787(new class_2868(currentSlot));
        }
    }

    public static void silentSwapUseAndReturn(int inventorySlot) {
        if (mc.field_1724 == null || mc.method_1562() == null) return;

        int currentHotbarSlot = mc.field_1724.method_31548().method_67532();

        click(inventorySlot, currentHotbarSlot, class_1713.field_7791);

        sendUsePacket(class_1268.field_5808);

        click(inventorySlot, currentHotbarSlot, class_1713.field_7791);
    }

    public static void silentUseItem(class_1792 item) {
        if (mc.field_1724 == null) return;

        int hotbarSlot = findItemInHotbar(item);
        if (hotbarSlot != -1) {
            silentUseHotbarItem(hotbarSlot);
            return;
        }

        int invSlot = findItemInInventory(item);
        if (invSlot != -1) {
            int wrappedSlot = wrapSlot(invSlot);
            silentSwapUseAndReturn(wrappedSlot);
            closeScreen();
        }
    }

    public static void sendUsePacket(class_1268 hand) {
        if (mc.field_1724 == null || mc.method_1562() == null || mc.field_1687 == null) return;

        try {
            ClientWorldAccessor worldAccessor = (ClientWorldAccessor) mc.field_1687;
            class_7202 pendingUpdateManager = worldAccessor.getPendingUpdateManager().method_41937();

            int sequence = pendingUpdateManager.method_41942();
            mc.method_1562().method_52787(new class_2886(
                    hand,
                    sequence,
                    mc.field_1724.method_36454(),
                    mc.field_1724.method_36455()
            ));

            pendingUpdateManager.close();
        } catch (Exception e) {
            mc.method_1562().method_52787(new class_2886(
                    hand,
                    0,
                    mc.field_1724.method_36454(),
                    mc.field_1724.method_36455()
            ));
        }
    }

    public static void use(class_1268 hand) {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        mc.field_1761.method_2919(mc.field_1724, hand);
    }

    public static void closeScreen() {
        if (mc.field_1724 == null || mc.method_1562() == null) return;
        mc.method_1562().method_52787(new class_2815(mc.field_1724.field_7512.field_7763));
    }

    public static boolean isScreenOpen() {
        return mc.field_1755 != null && !(mc.field_1755 instanceof class_408);
    }

    public static int wrapSlot(int slot) {
        return slot < 9 ? slot + 36 : slot;
    }

    public static int currentSlot() {
        return mc.field_1724 != null ? mc.field_1724.method_31548().method_67532() : 0;
    }

    public static class_1799 offhandStack() {
        return mc.field_1724 != null ? mc.field_1724.method_6079() : class_1799.field_8037;
    }

    public static class_1799 mainhandStack() {
        return mc.field_1724 != null ? mc.field_1724.method_6047() : class_1799.field_8037;
    }

    public static boolean hasTotemInOffhand() {
        return mc.field_1724 != null && mc.field_1724.method_6079().method_7909() == class_1802.field_8288;
    }

    public static class_1792 getOffhandItem() {
        return mc.field_1724 != null ? mc.field_1724.method_6079().method_7909() : class_1802.field_8162;
    }

    private static boolean isValid(class_1799 stack) {
        return !stack.method_7960() && stack.method_7919() < stack.method_7936() - 10;
    }
}