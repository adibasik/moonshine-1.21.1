package moonshine.util.proxy;

import org.apache.commons.lang3.StringUtils;
import moonshine.util.config.impl.proxy.ProxyConfig;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_4286;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;

public class GuiProxy extends class_437 {
    private boolean isSocks4 = false;

    private class_342 ipPort;
    private class_342 username;
    private class_342 password;
    private class_4286 enabledCheck;

    private class_437 parentScreen;

    private String msg = "";

    private int[] positionY;
    private int positionX;

    private static String text_proxy = class_2561.method_43471("PROXY").getString();

    public GuiProxy(class_437 parentScreen) {
        super(class_2561.method_43470(text_proxy));
        this.parentScreen = parentScreen;
    }

    private static boolean isValidIpPort(String ipP) {
        if (ipP == null || ipP.isEmpty()) return false;
        String[] split = ipP.split(":");
        if (split.length > 1) {
            if (!StringUtils.isNumeric(split[1])) return false;
            try {
                int port = Integer.parseInt(split[1]);
                if (port < 0 || port > 0xFFFF) return false;
                return true;
            } catch (NumberFormatException e) {
                return false;
            }
        }
        return false;
    }

    private boolean checkProxy() {
        if (!isValidIpPort(ipPort.method_1882())) {
            this.ipPort.method_25365(true);
            return false;
        }
        return true;
    }

    private void centerButtons(int amount, int buttonLength, int gap) {
        positionX = (this.field_22789 / 2) - (buttonLength / 2);
        positionY = new int[amount];
        int center = (this.field_22790 + amount * gap) / 2;
        int buttonStarts = center - (amount * gap);
        for (int i = 0; i != amount; i++) {
            positionY[i] = buttonStarts + (gap * i);
        }
    }

    @Override
    public boolean method_25404(class_11908 input) {
        if (input.method_74231()) {
            class_310.method_1551().method_1507(parentScreen);
            return true;
        }
        super.method_25404(input);
        msg = "";
        return true;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float partialTicks) {
        super.method_25394(context, mouseX, mouseY, partialTicks);

        if (enabledCheck.method_20372() && !isValidIpPort(ipPort.method_1882())) {
            enabledCheck.method_25306(null);
        }

        context.method_25303(this.field_22793, class_2561.method_43471("Введите айпи адрес и порт. Пример ниже").getString(), this.field_22789 / 2 - 106, positionY[3] - 15, 0xA0A0A0);
        context.method_25303(this.field_22793, class_2561.method_43471("Айпи:Порт ▸").getString(), this.field_22789 / 2 - 140, positionY[3] + 15, 0xA0A0A0);

        this.ipPort.method_25394(context, mouseX, mouseY, partialTicks);

        context.method_25303(this.field_22793, class_2561.method_43471("Никнейм ▸").getString(), this.field_22789 / 2 - 131, positionY[4] + 15, 0xA0A0A0);
        context.method_25303(this.field_22793, class_2561.method_43471("Пароль ▸").getString(), this.field_22789 / 2 - 126, positionY[5] + 15, 0xA0A0A0);
        this.username.method_25394(context, mouseX, mouseY, partialTicks);
        this.password.method_25394(context, mouseX, mouseY, partialTicks);

        context.method_25300(this.field_22793, msg, this.field_22789 / 2, positionY[6] + 5, 0xA0A0A0);
    }

    @Override
    public void method_25426() {
        int buttonLength = 160;
        centerButtons(10, buttonLength, 26);

        ProxyConfig config = ProxyConfig.getInstance();
        Proxy currentProxy = config.getDefaultProxy();

        isSocks4 = currentProxy.type == Proxy.ProxyType.SOCKS4;

        this.ipPort = new class_342(this.field_22793, positionX, positionY[3] + 10, buttonLength, 20, class_2561.method_43470(""));
        this.ipPort.method_1852(currentProxy.ipPort);
        this.ipPort.method_1880(1024);
        this.ipPort.method_25365(true);
        this.method_25429(this.ipPort);

        this.username = new class_342(this.field_22793, positionX, positionY[4] + 10, buttonLength, 20, class_2561.method_43470(""));
        this.username.method_1880(255);
        this.username.method_1852(currentProxy.username);
        this.method_25429(this.username);

        this.password = new class_342(this.field_22793, positionX, positionY[5] + 10, buttonLength, 20, class_2561.method_43470(""));
        this.password.method_1880(255);
        this.password.method_1852(currentProxy.password);
        this.method_25429(this.password);

        int posXButtons = (this.field_22789 / 2) - (((buttonLength / 2) * 3) / 2);

        class_4185 apply = class_4185.method_46430(class_2561.method_43471("Применить"), button -> {
            ProxyConfig cfg = ProxyConfig.getInstance();

            if (enabledCheck.method_20372()) {
                if (checkProxy()) {
                    Proxy newProxy = new Proxy(isSocks4, ipPort.method_1882(), username.method_1882(), password.method_1882());
                    cfg.setDefaultProxy(newProxy);
                    cfg.setProxyEnabled(true);
                    cfg.save();
                    class_310.method_1551().method_1507(new class_500(new class_442()));
                }
            } else {
                Proxy newProxy = new Proxy(isSocks4, ipPort.method_1882(), username.method_1882(), password.method_1882());
                cfg.setDefaultProxy(newProxy);
                cfg.setProxyEnabled(false);
                cfg.save();
                class_310.method_1551().method_1507(new class_500(new class_442()));
            }
        }).method_46434(posXButtons + (buttonLength / 2 - 62) * 2, positionY[7] - 10, buttonLength / 2 + 3, 20).method_46431();
        this.method_37063(apply);

        class_4286.class_8929 checkboxBuilder = class_4286.method_54787(class_2561.method_43471("Включить прокси"), this.field_22793);
        checkboxBuilder.method_54789((this.field_22789 / 2 - 34) - (13 + field_22793.method_27525(class_2561.method_43471("Включить прокси"))) / 2, positionY[7] + 15);
        if (config.isProxyEnabled()) {
            checkboxBuilder.method_54794(true);
        }
        this.enabledCheck = checkboxBuilder.method_54788();
        this.method_37063(this.enabledCheck);

        class_4185 cancel = class_4185.method_46430(class_2561.method_43471("Отменить"), (button) -> {
            class_310.method_1551().method_1507(parentScreen);
        }).method_46434(posXButtons + (buttonLength / 2 - 16) * 2, positionY[7] - 10, buttonLength / 2 - 3, 20).method_46431();
        this.method_37063(cancel);
    }

    @Override
    public void method_25419() {
        msg = "";
        class_310.method_1551().method_1507(parentScreen);
    }
}