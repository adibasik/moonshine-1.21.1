package moonshine.util.sounds;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.UtilityClass;
import moonshine.IMinecraft;
import moonshine.util.string.PlayerInteractionHelper;
import net.minecraft.class_1109;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_7923;

@Setter
@Getter
@UtilityClass
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class SoundManager implements IMinecraft {
    public class_3414 KOLOKOLNIA_KILL = class_3414.method_47908(class_2960.method_60654("moonshine:kolokolnia_kill"));
    public class_3414 MOAN1 = class_3414.method_47908(class_2960.method_60654("moonshine:moan1"));
    public class_3414 MOAN2 = class_3414.method_47908(class_2960.method_60654("moonshine:moan2"));
    public class_3414 MOAN3 = class_3414.method_47908(class_2960.method_60654("moonshine:moan3"));
    public class_3414 MOAN4 = class_3414.method_47908(class_2960.method_60654("moonshine:moan4"));
    public class_3414 MODULE_DISABLE = class_3414.method_47908(class_2960.method_60654("moonshine:module_disable"));
    public class_3414 MODULE_ENABLE = class_3414.method_47908(class_2960.method_60654("moonshine:module_enable"));
    public class_3414 OFF = class_3414.method_47908(class_2960.method_60654("moonshine:off"));
    public class_3414 ON = class_3414.method_47908(class_2960.method_60654("moonshine:on"));
    public class_3414 CRIME = class_3414.method_47908(class_2960.method_60654("moonshine:crime"));
    public class_3414 METALLIC = class_3414.method_47908(class_2960.method_60654("moonshine:metallic"));
    public class_3414 WELCOME = class_3414.method_47908(class_2960.method_60654("moonshine:welcome"));

    public void init() {
        class_2378.method_10230(class_7923.field_41172, KOLOKOLNIA_KILL.comp_3319(), KOLOKOLNIA_KILL);
        class_2378.method_10230(class_7923.field_41172, MOAN1.comp_3319(), MOAN1);
        class_2378.method_10230(class_7923.field_41172, MOAN2.comp_3319(), MOAN2);
        class_2378.method_10230(class_7923.field_41172, MOAN3.comp_3319(), MOAN3);
        class_2378.method_10230(class_7923.field_41172, MOAN4.comp_3319(), MOAN4);
        class_2378.method_10230(class_7923.field_41172, MODULE_DISABLE.comp_3319(), MODULE_DISABLE);
        class_2378.method_10230(class_7923.field_41172, MODULE_ENABLE.comp_3319(), MODULE_ENABLE);
        class_2378.method_10230(class_7923.field_41172, OFF.comp_3319(), OFF);
        class_2378.method_10230(class_7923.field_41172, ON.comp_3319(), ON);
        class_2378.method_10230(class_7923.field_41172, CRIME.comp_3319(), CRIME);
        class_2378.method_10230(class_7923.field_41172, METALLIC.comp_3319(), METALLIC);
        class_2378.method_10230(class_7923.field_41172, WELCOME.comp_3319(), WELCOME);
    }

    public void playSound(class_3414 sound) {
        playSound(sound, 1, 1);
    }

    public void playSound(class_3414 sound, float volume, float pitch) {
        if (!PlayerInteractionHelper.nullCheck()) {
            mc.field_1687.method_8396(mc.field_1724, mc.field_1724.method_24515(), sound, class_3419.field_15245, volume, pitch);
        }
    }

    public void playSoundDirect(class_3414 sound, float volume, float pitch) {
        mc.method_1483().method_4873(class_1109.method_4757(sound, pitch, volume));
    }
}