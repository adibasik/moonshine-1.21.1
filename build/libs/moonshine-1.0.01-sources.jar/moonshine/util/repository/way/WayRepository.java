package moonshine.util.repository.way;

import lombok.Getter;
import moonshine.IMinecraft;
import moonshine.events.api.EventHandler;
import moonshine.events.api.EventManager;
import moonshine.events.impl.DrawEvent;
import moonshine.util.config.impl.way.WayConfig;
import moonshine.util.math.Projection;
import moonshine.util.render.Render2D;
import moonshine.util.render.font.Font;
import moonshine.util.render.font.Fonts;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Getter
public class WayRepository implements IMinecraft {
    private static WayRepository instance;
    private final List<Way> wayList = new ArrayList<>();

    public WayRepository() {
        instance = this;
    }

    public static WayRepository getInstance() {
        if (instance == null) {
            instance = new WayRepository();
        }
        return instance;
    }

    public void init() {
        EventManager.register(this);
        WayConfig.getInstance().load();
    }

    public boolean isEmpty() {
        return wayList.isEmpty();
    }

    public void addWay(String name, class_2338 pos, String server) {
        wayList.add(new Way(name, pos, server));
    }

    public void addWayAndSave(String name, class_2338 pos, String server) {
        addWay(name, pos, server);
        WayConfig.getInstance().save();
    }

    public boolean hasWay(String name) {
        return wayList.stream().anyMatch(way -> way.name().equalsIgnoreCase(name));
    }

    public Optional<Way> getWay(String name) {
        return wayList.stream()
                .filter(way -> way.name().equalsIgnoreCase(name))
                .findFirst();
    }

    public void deleteWay(String name) {
        wayList.removeIf(way -> way.name().equalsIgnoreCase(name));
    }

    public void deleteWayAndSave(String name) {
        deleteWay(name);
        WayConfig.getInstance().save();
    }

    public void clearList() {
        wayList.clear();
    }

    public void clearListAndSave() {
        clearList();
        WayConfig.getInstance().save();
    }

    public int size() {
        return wayList.size();
    }

    public List<String> getWayNames() {
        return wayList.stream().map(Way::name).collect(Collectors.toList());
    }

    public List<String> getWayNamesForServer(String server) {
        return wayList.stream()
                .filter(way -> way.server().equalsIgnoreCase(server))
                .map(Way::name)
                .collect(Collectors.toList());
    }

    public void setWays(List<Way> ways) {
        wayList.clear();
        wayList.addAll(ways);
    }

    public String getCurrentServer() {
        if (mc.method_1562() == null || mc.method_1562().method_45734() == null) {
            return "";
        }
        return mc.method_1562().method_45734().field_3761;
    }

    private boolean isInFrontOfCamera(class_243 worldPos) {
        class_4184 camera = mc.field_1773.method_19418();
        if (camera == null || !camera.method_19332()) return false;

        class_243 cameraPos = camera.method_71156();
        class_243 toPoint = worldPos.method_1020(cameraPos);

        float yaw = camera.method_19330();
        float pitch = camera.method_19329();

        double yawRad = Math.toRadians(yaw);
        double pitchRad = Math.toRadians(pitch);

        double lookX = -Math.sin(yawRad) * Math.cos(pitchRad);
        double lookY = -Math.sin(pitchRad);
        double lookZ = Math.cos(yawRad) * Math.cos(pitchRad);

        class_243 lookDir = new class_243(lookX, lookY, lookZ);

        return lookDir.method_1026(toPoint) > 0;
    }

    @EventHandler
    public void onRender2D(DrawEvent event) {
        if (isEmpty() || mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.method_1562() == null || mc.method_1562().method_45734() == null) return;

        String currentServer = getCurrentServer();

        for (Way way : wayList) {
            if (!way.server().equalsIgnoreCase(currentServer)) continue;

            class_243 wayVec = way.pos().method_46558();

            if (!isInFrontOfCamera(wayVec)) continue;

            class_243 screenPos = Projection.worldSpaceToScreenSpace(wayVec);

            if (screenPos.field_1350 <= 0 || screenPos.field_1350 >= 1) continue;

            double distance = mc.field_1724.method_73189().method_1022(wayVec);
            String text = way.name() + " - " + String.format("%.1f", distance) + "m";

            Font font = Fonts.BOLD;
            float fontSize = 6f;
            float textWidth = font.getWidth(text, fontSize);
            float textHeight = font.getHeight(fontSize);
            float padding = 3f;

            float x = (float) screenPos.field_1352 - textWidth / 2;
            float y = (float) screenPos.field_1351 - textHeight / 2;

            Render2D.rect(
                    x - padding,
                    y - padding + 0.5f,
                    textWidth + padding * 2,
                    textHeight + padding * 2,
                    0xE0131315,
                    2f
            );


            font.drawCentered(text, (float) screenPos.field_1352, y + 1f, fontSize, 0xFFFFFFFF);
        }
    }
}