package moonshine.util.repository.friend;

import lombok.Getter;
import lombok.experimental.UtilityClass;
import moonshine.util.config.impl.friend.FriendConfig;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@UtilityClass
public class FriendUtils {
    @Getter
    private final List<Friend> friends = new ArrayList<>();

    public void addFriend(class_1657 player) {
        addFriend(player.method_5477().getString());
    }

    public void addFriend(String name) {
        if (!isFriend(name)) {
            friends.add(new Friend(name));
        }
    }

    public void addFriendAndSave(String name) {
        addFriend(name);
        FriendConfig.getInstance().save();
    }

    public void removeFriend(class_1657 player) {
        removeFriend(player.method_5477().getString());
    }

    public void removeFriend(String name) {
        friends.removeIf(friend -> friend.getName().equalsIgnoreCase(name));
    }

    public void removeFriendAndSave(String name) {
        removeFriend(name);
        FriendConfig.getInstance().save();
    }

    public boolean isFriend(class_1297 entity) {
        if (entity instanceof class_1657 player) {
            return isFriend(player.method_5477().getString());
        }
        return false;
    }

    public boolean isFriend(String friend) {
        return friends.stream().anyMatch(isFriend -> isFriend.getName().equalsIgnoreCase(friend));
    }

    public void clear() {
        friends.clear();
    }

    public void clearAndSave() {
        clear();
        FriendConfig.getInstance().save();
    }

    public List<String> getFriendNames() {
        return friends.stream().map(Friend::getName).collect(Collectors.toList());
    }

    public int size() {
        return friends.size();
    }

    public void setFriends(List<String> names) {
        friends.clear();
        for (String name : names) {
            friends.add(new Friend(name));
        }
    }
}