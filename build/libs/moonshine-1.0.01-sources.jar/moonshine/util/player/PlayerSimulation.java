package moonshine.util.player;

import it.unimi.dsi.fastutil.objects.Object2DoubleArrayMap;
import it.unimi.dsi.fastutil.objects.Object2DoubleMap;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import moonshine.IMinecraft;
import moonshine.util.move.MoveUtil;
import net.minecraft.class_10185;
import net.minecraft.class_10255;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1320;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2399;
import net.minecraft.class_243;
import net.minecraft.class_2533;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_5134;
import net.minecraft.class_5635;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_744;
import net.minecraft.class_746;

@SuppressWarnings("deprecation")
public class PlayerSimulation implements Simulation, IMinecraft {

    public final class_1657 player;
    public final SimulatedPlayerInput input;
    public class_243 pos;
    public class_243 velocity;
    public class_238 boundingBox;
    public float yaw;
    public float pitch;
    public boolean sprinting;
    public float fallDistance;
    public int jumpingCooldown;
    public boolean isJumping;
    public boolean isFallFlying;
    public boolean onGround;
    public boolean horizontalCollision;
    public boolean verticalCollision;
    public boolean touchingWater;
    public boolean isSwimming;
    public boolean submergedInWater;
    private final Object2DoubleMap<class_6862<class_3611>> fluidHeight;
    private final HashSet<class_6862<class_3611>> submergedFluidTag;

    private int simulatedTicks = 0;
    private boolean clipLedged = false;

    private static final double STEP_HEIGHT = 0.5;

    public PlayerSimulation(class_1657 player,
                            SimulatedPlayerInput input,
                            class_243 pos,
                            class_243 velocity,
                            class_238 boundingBox,
                            float yaw,
                            float pitch,
                            boolean sprinting,
                            float fallDistance,
                            int jumpingCooldown,
                            boolean isJumping,
                            boolean isFallFlying,
                            boolean onGround,
                            boolean horizontalCollision,
                            boolean verticalCollision,
                            boolean touchingWater,
                            boolean isSwimming,
                            boolean submergedInWater,
                            Object2DoubleMap<class_6862<class_3611>> fluidHeight,
                            HashSet<class_6862<class_3611>> submergedFluidTag) {
        this.player = player;
        this.input = input;
        this.pos = pos;
        this.velocity = velocity;
        this.boundingBox = boundingBox;
        this.yaw = yaw;
        this.pitch = pitch;
        this.sprinting = sprinting;
        this.fallDistance = fallDistance;
        this.jumpingCooldown = jumpingCooldown;
        this.isJumping = isJumping;
        this.isFallFlying = isFallFlying;
        this.onGround = onGround;
        this.horizontalCollision = horizontalCollision;
        this.verticalCollision = verticalCollision;
        this.touchingWater = touchingWater;
        this.isSwimming = isSwimming;
        this.submergedInWater = submergedInWater;
        this.fluidHeight = fluidHeight;
        this.submergedFluidTag = submergedFluidTag;
    }

    public static PlayerSimulation simulateLocalPlayer(int ticks) {
        PlayerSimulation simulatedPlayer = PlayerSimulation.fromClientPlayer(PlayerSimulation.SimulatedPlayerInput.fromClientPlayer(mc.field_1724.field_3913.field_54155));

        for (int i = 0; i < ticks; i++) {
            simulatedPlayer.tick();
        }

        return simulatedPlayer;
    }

    public static PlayerSimulation simulateOtherPlayer(class_1657 player, int ticks) {
        PlayerSimulation simulatedPlayer = PlayerSimulation.fromOtherPlayer(player, PlayerSimulation.SimulatedPlayerInput.guessInput(player));

        for (int i = 0; i < ticks; i++) {
            simulatedPlayer.tick();
        }

        return simulatedPlayer;
    }

    public static PlayerSimulation fromClientPlayer(SimulatedPlayerInput input) {
        class_746 player = mc.field_1724;
        return new PlayerSimulation(
                player,
                input,
                player.method_73189(),
                player.method_18798(),
                player.method_5829(),
                player.method_36454(),
                player.method_36455(),
                player.method_5624(),
                (float) player.field_6017,
                player.field_6228,
                player.field_6282,
                player.method_6128(),
                player.method_24828(),
                player.field_5976,
                player.field_5992,
                player.method_5799(),
                player.method_5681(),
                player.method_5869(),
                new Object2DoubleArrayMap<>(player.field_5964),
                new HashSet<>(player.field_25599)
        );
    }

    public static PlayerSimulation fromOtherPlayer(class_1657 player, SimulatedPlayerInput input) {
        return new PlayerSimulation(
                player,
                input,
                player.method_73189(),
                player.method_73189().method_1020(new class_243(player.field_6014, player.field_6036, player.field_5969)),
                player.method_5829(),
                player.method_36454(),
                player.method_36455(),
                player.method_5624(),
                (float) player.field_6017,
                player.field_6228,
                player.field_6282,
                player.method_6128(),
                player.method_24828(),
                player.field_5976,
                player.field_5992,
                player.method_5799(),
                player.method_5681(),
                player.method_5869(),
                new Object2DoubleArrayMap<>(player.field_5964),
                new HashSet<>(player.field_25599)
        );
    }

    @Override
    public class_243 pos() {
        return player.method_73189();
    }

    @Override
    public void tick() {
        simulatedTicks++;
        clipLedged = false;
        if (pos.field_1351 <= -70) {
            return;
        }
        input.update();
        checkWaterState();
        updateSubmergedInWaterState();
        updateSwimming();

        if (jumpingCooldown > 0) {
            jumpingCooldown--;
        }
        isJumping = input.field_54155.comp_3163();
        double newX = velocity.field_1352;
        double newY = velocity.field_1351;
        double newZ = velocity.field_1350;
        if (Math.abs(velocity.field_1352) < 0.003) newX = 0.0;
        if (Math.abs(velocity.field_1351) < 0.003) newY = 0.0;
        if (Math.abs(velocity.field_1350) < 0.003) newZ = 0.0;
        if (onGround) {
            isFallFlying = false;
        }
        velocity = new class_243(newX, newY, newZ);

        if (isJumping) {
            double fluidLevel = isInLava() ? getFluidHeight(class_3486.field_15518) : getFluidHeight(class_3486.field_15517);
            boolean inWater = isTouchingWater() && fluidLevel > 0.0;
            double swimHeight = getSwimHeight();
            if (inWater && (!onGround || fluidLevel > swimHeight)) {
                swimUpward(class_3486.field_15517);
            } else if (isInLava() && (!onGround || fluidLevel > swimHeight)) {
                swimUpward(class_3486.field_15518);
            } else if ((onGround || (inWater && fluidLevel <= swimHeight)) && jumpingCooldown == 0) {
                jump();
                if (player.equals(mc.field_1724)) {
                    jumpingCooldown = 10;
                }
            }
        }

        float sidewaysSpeed = input.movementSideways * 0.98f;
        float forwardSpeed = input.movementForward * 0.98f;
        float upwardsSpeed = 0.0f;

        if (hasStatusEffect(class_1294.field_5906) || hasStatusEffect(class_1294.field_5902)) {
            onLanding();
        }

        travel(new class_243(sidewaysSpeed, upwardsSpeed, forwardSpeed));
    }

    private void travel(class_243 movementInput) {
        if (isSwimming && !player.method_5765()) {
            double g = getRotationVector().field_1351;
            double h = (g < -0.2) ? 0.085 : 0.06;
            class_2338 posAbove = new class_2338(class_3532.method_15357(pos.field_1352),
                    class_3532.method_15357(pos.field_1351 + 1.0 - 0.1),
                    class_3532.method_15357(pos.field_1350));
            if (g <= 0.0 || input.field_54155.comp_3163() ||
                    !player.method_73183().method_8320(posAbove).method_26227().method_15769()) {
                velocity = velocity.method_1031(0.0, (g - velocity.field_1351) * h, 0.0);
            }
        }

        double beforeTravelVelocityY = velocity.field_1351;
        double d = 0.08;
        boolean falling = velocity.field_1351 <= 0.0;
        if (velocity.field_1351 <= 0.0 && hasStatusEffect(class_1294.field_5906)) {
            d = 0.01;
            onLanding();
        }

        if (isTouchingWater() && player.method_29920()) {
            double e = pos.field_1351;
            float f = isSprinting() ? 0.9f : 0.8f;
            float g = 0.02f;
            float h = (float) getAttributeValue(class_5134.field_51578);
            if (!onGround) {
                h *= 0.5f;
            }
            if (h > 0.0f) {
                f += (0.54600006f - f) * h / 3.0f;
                g += (getMovementSpeed() - g) * h / 3.0f;
            }
            if (hasStatusEffect(class_1294.field_5900)) {
                f = 0.96f;
            }
            updateVelocity(g, movementInput);
            move(velocity);
            class_243 tempVel = velocity;
            if (horizontalCollision && isClimbing()) {
                tempVel = new class_243(tempVel.field_1352, 0.2, tempVel.field_1350);
            }
            velocity = tempVel.method_18805(f, 0.8, f);
            class_243 vec3d2 = player.method_26317(d, falling, velocity);
            velocity = vec3d2;
            if (horizontalCollision && doesNotCollide(vec3d2.field_1352, vec3d2.field_1351 + 0.6 - pos.field_1351 + e, vec3d2.field_1350)) {
                velocity = new class_243(vec3d2.field_1352, 0.3, vec3d2.field_1350);
            }
        } else if (isInLava() && player.method_29920()) {
            double e = pos.field_1351;
            updateVelocity(0.02f, movementInput);
            move(velocity);
            if (getFluidHeight(class_3486.field_15518) <= getSwimHeight()) {
                velocity = velocity.method_18805(0.5, 0.8, 0.5);
                velocity = player.method_26317(d, falling, velocity);
            } else {
                velocity = velocity.method_1021(0.5);
            }
            if (!player.method_5740()) {
                velocity = velocity.method_1031(0.0, -d / 4.0, 0.0);
            }
            if (horizontalCollision && doesNotCollide(velocity.field_1352, velocity.field_1351 + 0.6 - pos.field_1351 + e, velocity.field_1350)) {
                velocity = new class_243(velocity.field_1352, 0.3, velocity.field_1350);
            }
        } else if (isFallFlying) {
            double k;
            class_243 e = velocity;
            if (e.field_1351 > -0.5) {
                fallDistance = 1.0f;
            }
            class_243 vec3d3 = getRotationVector();
            float f = pitch * ((float) Math.PI / 180f);
            double g = Math.sqrt(vec3d3.field_1352 * vec3d3.field_1352 + vec3d3.field_1350 * vec3d3.field_1350);
            double horizontalSpeed = velocity.method_37267();
            double i = vec3d3.method_1033();
            float j = class_3532.method_15362(f);
            j = (float) (j * (j * Math.min(1.0, i / 0.4)));
            e = velocity.method_1031(0.0, d * (-1.0 + j * 0.75), 0.0);
            if (e.field_1351 < 0.0 && g > 0.0) {
                k = e.field_1351 * -0.1 * j;
                e = e.method_1031(vec3d3.field_1352 * k / g, k, vec3d3.field_1350 * k / g);
            }
            if (f < 0.0f && g > 0.0) {
                k = horizontalSpeed * (-class_3532.method_15374(f)) * 0.04;
                e = e.method_1031(-vec3d3.field_1352 * k / g, k * 3.2, -vec3d3.field_1350 * k / g);
            }
            if (g > 0.0) {
                e = e.method_1031((vec3d3.field_1352 / g * horizontalSpeed - e.field_1352) * 0.1, 0.0, (vec3d3.field_1350 / g * horizontalSpeed - e.field_1350) * 0.1);
            }
            velocity = e.method_18805(0.99, 0.98, 0.99);
            move(velocity);
        } else {
            class_2338 blockPos = getVelocityAffectingPos();
            float p = player.method_73183().method_8320(blockPos).method_26204().method_9499();
            float f = onGround ? p * 0.91f : 0.91f;
            class_243 vec3d6 = applyMovementInput(movementInput, p);
            double q = vec3d6.field_1351;
            if (hasStatusEffect(class_1294.field_5902)) {
                class_1293 levitation = getStatusEffect(class_1294.field_5902);
                if (levitation != null) {
                    q += (0.05 * (levitation.method_5578() + 1) - vec3d6.field_1351) * 0.2;
                }
            } else if (player.method_73183().method_8608() && !player.method_73183().method_22340(blockPos)) {
                q = (pos.field_1351 > player.method_73183().method_31607()) ? -0.1 : 0.0;
            } else if (!player.method_5740()) {
                q -= d;
            }
            if (player.method_35053()) {
                velocity = new class_243(vec3d6.field_1352, q, vec3d6.field_1350);
            } else {
                velocity = new class_243(vec3d6.field_1352 * f, q * 0.9800000190734863, vec3d6.field_1350 * f);
            }
        }

        if (player.method_31549().field_7479 && !player.method_5765()) {
            velocity = new class_243(velocity.field_1352, beforeTravelVelocityY * 0.6, velocity.field_1350);
            onLanding();
        }
    }

    private class_243 applyMovementInput(class_243 movementInput, float slipperiness) {
        updateVelocity(getMovementSpeed(slipperiness), movementInput);
        velocity = applyClimbingSpeed(velocity);
        move(velocity);
        class_243 result = velocity;
        class_2338 posBlock = posToBlockPos(pos);
        class_2680 state = getState(posBlock);
        if ((horizontalCollision || isJumping) &&
                (isClimbing() || (state != null && state.method_27852(class_2246.field_27879) &&
                        class_5635.method_32355(player)))) {
            result = new class_243(result.field_1352, 0.2, result.field_1350);
        }
        return result;
    }

    private void updateVelocity(float speed, class_243 movementInput) {
        class_243 vec = class_1297.method_18795(movementInput, speed, yaw);
        velocity = velocity.method_1019(vec);
    }

    private float getMovementSpeed(float slipperiness) {
        return onGround ? getMovementSpeed() * (0.21600002f / (slipperiness * slipperiness * slipperiness))
                : getAirStrafingSpeed();
    }

    private float getAirStrafingSpeed() {
        float speed = 0.02f;
        if (input.field_54155.comp_3165()) {
            return speed + 0.005999999865889549f;
        }
        return speed;
    }

    private float getMovementSpeed() {
        return 0.10000000149011612f;
    }

    private void move(class_243 movement) {
        class_243 modifiedMovement = movement;
        modifiedMovement = adjustMovementForSneaking(modifiedMovement);
        class_243 adjustedMovement = adjustMovementForCollisions(modifiedMovement);
        if (adjustedMovement.method_1027() > 1.0E-7) {
            pos = pos.method_1019(adjustedMovement);
            boundingBox = player.method_18377(player.method_18376()).method_30757(pos);
        }
        boolean xCollision = !class_3532.method_20390(movement.field_1352, adjustedMovement.field_1352);
        boolean zCollision = !class_3532.method_20390(movement.field_1350, adjustedMovement.field_1350);
        horizontalCollision = xCollision || zCollision;
        verticalCollision = (movement.field_1351 != adjustedMovement.field_1351);
        onGround = verticalCollision && movement.field_1351 < 0.0;
        if (!isTouchingWater()) {
            checkWaterState();
        }
        if (onGround) {
            onLanding();
        } else if (movement.field_1351 < 0) {
            fallDistance -= (float) movement.field_1351;
        }
        class_243 currentVel = velocity;
        if (horizontalCollision || verticalCollision) {
            velocity = new class_243(xCollision ? 0.0 : currentVel.field_1352,
                    onGround ? 0.0 : currentVel.field_1351,
                    zCollision ? 0.0 : currentVel.field_1350);
        }
    }

    private class_243 adjustMovementForCollisions(class_243 movement) {
        class_238 box = new class_238(-0.3, 0.0, -0.3, 0.3, 1.8, 0.3).method_997(pos);
        List<class_265> collisionShapes = Collections.emptyList();
        class_243 adjusted;
        if (movement.method_1027() == 0.0) {
            adjusted = movement;
        } else {
            adjusted = class_1297.method_20736(player, movement, box, player.method_73183(), collisionShapes);
        }
        boolean xCollide = movement.field_1352 != adjusted.field_1352;
        boolean yCollide = movement.field_1351 != adjusted.field_1351;
        boolean zCollide = movement.field_1350 != adjusted.field_1350;
        boolean stepPossible = onGround || (yCollide && movement.field_1351 < 0.0);
        if (player.method_49476() > 0.0f && stepPossible && (xCollide || zCollide)) {
            class_243 stepAdjust = class_1297.method_20736(player,
                    new class_243(movement.field_1352, player.method_49476(), movement.field_1350),
                    box, player.method_73183(), collisionShapes);
            class_243 stepOffset = class_1297.method_20736(player,
                    new class_243(0.0, player.method_49476(), 0.0),
                    box.method_1012(movement.field_1352, 0.0, movement.field_1350), player.method_73183(), collisionShapes);
            class_243 combined = class_1297.method_20736(player,
                    new class_243(movement.field_1352, 0.0, movement.field_1350),
                    box.method_997(stepOffset), player.method_73183(), collisionShapes).method_1019(stepOffset);
            if (stepOffset.field_1351 < player.method_49476() && combined.method_37268() > stepAdjust.method_37268()) {
                stepAdjust = combined;
            }
            if (stepAdjust.method_37268() > adjusted.method_37268()) {
                return stepAdjust.method_1019(class_1297.method_20736(player,
                        new class_243(0.0, -stepAdjust.field_1351 + movement.field_1351, 0.0),
                        box.method_997(stepAdjust), player.method_73183(), collisionShapes));
            }
        }
        return adjusted;
    }

    private void onLanding() {
        fallDistance = 0.0f;
    }

    public void jump() {
        velocity = velocity.method_1031(0.0, getJumpVelocity() - velocity.field_1351, 0.0);
        if (isSprinting()) {
            float rad = (float) Math.toRadians(yaw);
            velocity = velocity.method_1031(-class_3532.method_15374(rad) * 0.2, 0.0, class_3532.method_15362(rad) * 0.2);
        }
    }

    private class_243 applyClimbingSpeed(class_243 motion) {
        if (!isClimbing()) {
            return motion;
        }
        onLanding();
        double clampedX = class_3532.method_15350(motion.field_1352, -0.15000000596046448, 0.15000000596046448);
        double clampedZ = class_3532.method_15350(motion.field_1350, -0.15000000596046448, 0.15000000596046448);
        double clampedY = Math.max(motion.field_1351, -0.15000000596046448);
        if (clampedY < 0.0 && !getState(posToBlockPos(pos)).method_27852(class_2246.field_16492) && player.method_21754()) {
            clampedY = 0.0;
        }
        return new class_243(clampedX, clampedY, clampedZ);
    }

    public boolean isClimbing() {
        class_2338 posBlock = posToBlockPos(pos);
        class_2680 state = getState(posBlock);
        if (state.method_26164(class_3481.field_22414)) {
            return true;
        } else return state.method_26204() instanceof class_2533 && canEnterTrapdoor(posBlock, state);
    }

    private boolean canEnterTrapdoor(class_2338 pos, class_2680 state) {
        if (!state.method_11654(class_2533.field_11631)) {
            return false;
        }
        class_2680 below = player.method_73183().method_8320(pos.method_10074());
        return below.method_27852(class_2246.field_9983) && below.method_11654(class_2399.field_11253).equals(state.method_11654(class_2533.field_11177));
    }

    private class_243 adjustMovementForSneaking(class_243 movement) {
        if (movement.field_1351 <= 0.0 && method_30263()) {
            double dx = movement.field_1352;
            double dz = movement.field_1350;
            double step = 0.05;
            while (dx != 0.0 && player.method_73183().method_8587(player, boundingBox.method_989(dx, -STEP_HEIGHT, 0.0))) {
                if (dx < step && dx >= -step) {
                    dx = 0.0;
                    break;
                }
                dx += (dx > 0 ? -step : step);
            }
            while (dz != 0.0 && player.method_73183().method_8587(player, boundingBox.method_989(0.0, -STEP_HEIGHT, dz))) {
                if (dz < step && dz >= -step) {
                    dz = 0.0;
                    break;
                }
                dz += (dz > 0 ? -step : step);
            }
            while (dx != 0.0 && dz != 0.0 && player.method_73183().method_8587(player, boundingBox.method_989(dx, -STEP_HEIGHT, dz))) {
                dx = (dx < step && dx >= -step) ? 0.0 : (dx > 0 ? dx - step : dx + step);
                if (dz < step && dz >= -step) {
                    dz = 0.0;
                    break;
                }
                dz += (dz > 0 ? -step : step);
            }
            if (movement.field_1352 != dx || movement.field_1350 != dz) {
                clipLedged = true;
            }
            if (shouldClipAtLedge()) {
                movement = new class_243(dx, movement.field_1351, dz);
            }
        }
        return movement;
    }

    protected boolean shouldClipAtLedge() {
        return input.field_54155.comp_3164() || input.forceSafeWalk;
    }

    private boolean method_30263() {
        return onGround || (fallDistance < STEP_HEIGHT &&
                !player.method_73183().method_8587(player, boundingBox.method_989(0.0, fallDistance - STEP_HEIGHT, 0.0)));
    }

    private boolean isSprinting() {
        return sprinting;
    }

    private float getJumpVelocity() {
        return 0.42f * getJumpVelocityMultiplier() + getJumpBoostVelocityModifier();
    }

    private float getJumpBoostVelocityModifier() {
        if (hasStatusEffect(class_1294.field_5913)) {
            class_1293 boost = getStatusEffect(class_1294.field_5913);
            return 0.1f * (boost.method_5578() + 1);
        }
        return 0f;
    }

    private float getJumpVelocityMultiplier() {
        float multiplier1 = 0f;
        class_2248 block = getState(posToBlockPos(pos)).method_26204();
        if (block != null) {
            multiplier1 = block.method_23350();
        }
        float multiplier2 = 0f;
        class_2248 block2 = getState(getVelocityAffectingPos()).method_26204();
        if (block2 != null) {
            multiplier2 = block2.method_23350();
        }
        return (multiplier1 == 1.0f) ? multiplier2 : multiplier1;
    }

    private boolean doesNotCollide(double offsetX, double offsetY, double offsetZ) {
        return doesNotCollide(boundingBox.method_989(offsetX, offsetY, offsetZ));
    }

    private boolean doesNotCollide(class_238 box) {
        return player.method_73183().method_8587(player, box) && !player.method_73183().method_22345(box);
    }

    private void swimUpward(class_6862<class_3611> fluidTag) {
        velocity = velocity.method_1031(0.0, 0.03999999910593033, 0.0);
    }

    private class_2338 getVelocityAffectingPos() {
        return class_2338.method_49637(pos.field_1352, boundingBox.field_1322 - 0.5000001, pos.field_1350);
    }

    private double getSwimHeight() {
        return (player.method_5751() < 0.4) ? 0.0 : 0.4;
    }

    private boolean isTouchingWater() {
        return touchingWater;
    }

    public boolean isInLava() {
        return fluidHeight.getDouble(class_3486.field_15518) > 0.0;
    }

    private void checkWaterState() {
        class_1297 vehicle = player.method_5854();
        if (vehicle instanceof class_10255 boat) {
            if (!boat.method_5869()) {
                touchingWater = false;
                return;
            }
        }
        if (updateMovementInFluid(class_3486.field_15517, 0.014)) {
            onLanding();
            touchingWater = true;
        } else {
            touchingWater = false;
        }
    }

    private void updateSwimming() {
        if (isSwimming) {
            isSwimming = isSprinting() && isTouchingWater() && !player.method_5765();
        } else {
            isSwimming = isSprinting() && isSubmergedInWater() &&
                    !player.method_5765() &&
                    player.method_73183().method_8316(posToBlockPos(pos)).method_15767(class_3486.field_15517);
        }
    }

    private void updateSubmergedInWaterState() {
        submergedInWater = submergedFluidTag.contains(class_3486.field_15517);
        submergedFluidTag.clear();
        double eyeLevel = getEyeY() - 0.1111111119389534;
        class_1297 vehicle = player.method_5854();
        if (vehicle instanceof class_10255 boat) {
            if (!boat.method_5869() &&
                    boat.method_5829().field_1325 >= eyeLevel &&
                    boat.method_5829().field_1322 <= eyeLevel) {
                return;
            }
        }
        class_2338 posEye = class_2338.method_49637(pos.field_1352, eyeLevel, pos.field_1350);
        class_3610 fluidState = player.method_73183().method_8316(posEye);
        double height = posEye.method_10264() + fluidState.method_15763(player.method_73183(), posEye);
        if (height > eyeLevel) {
            submergedFluidTag.addAll(fluidState.method_40181().toList());
        }
    }

    private double getEyeY() {
        return pos.field_1351 + player.method_5751();
    }

    public boolean isSubmergedInWater() {
        return submergedInWater && isTouchingWater();
    }

    private double getFluidHeight(class_6862<class_3611> tag) {
        return fluidHeight.getDouble(tag);
    }

    private boolean updateMovementInFluid(class_6862<class_3611> tag, double speed) {
        if (isRegionUnloaded()) {
            return false;
        }
        class_238 box = boundingBox.method_1011(0.001);
        int i = class_3532.method_15357(box.field_1323);
        int j = class_3532.method_15384(box.field_1320);
        int k = class_3532.method_15357(box.field_1322);
        int l = class_3532.method_15384(box.field_1325);
        int m = class_3532.method_15357(box.field_1321);
        int n = class_3532.method_15384(box.field_1324);
        double d = 0.0;
        boolean pushedByFluids = true;
        boolean foundFluid = false;
        class_243 fluidVelocity = class_243.field_1353;
        int count = 0;
        class_2338.class_2339 mutable = new class_2338.class_2339();
        for (int p = i; p < j; p++) {
            for (int q = k; q < l; q++) {
                for (int r = m; r < n; r++) {
                    mutable.method_10103(p, q, r);
                    class_3610 fluidState = player.method_73183().method_8316(mutable);
                    if (fluidState.method_15767(tag)) {
                        double e = q + fluidState.method_15763(player.method_73183(), mutable);
                        if (e >= box.field_1322) {
                            foundFluid = true;
                            d = Math.max(e - box.field_1322, d);
                            if (pushedByFluids) {
                                class_243 vel = fluidState.method_15758(player.method_73183(), mutable);
                                if (d < 0.4) {
                                    vel = vel.method_1021(d);
                                }
                                fluidVelocity = fluidVelocity.method_1019(vel);
                                count++;
                            }
                        }
                    }
                }
            }
        }
        if (fluidVelocity.method_1033() > 0.0) {
            if (count > 0) {
                fluidVelocity = fluidVelocity.method_1021(1.0 / count);
            }
            fluidVelocity = fluidVelocity.method_1021(speed);
            if (Math.abs(velocity.field_1352) < 0.003 && Math.abs(velocity.field_1350) < 0.003 &&
                    fluidVelocity.method_1033() < 0.0045) {
                fluidVelocity = fluidVelocity.method_1029().method_1021(0.0045);
            }
            velocity = velocity.method_1019(fluidVelocity);
        }
        fluidHeight.put(tag, d);
        return foundFluid;
    }

    private boolean isRegionUnloaded() {
        class_238 box = boundingBox.method_1014(1.0);
        int i = class_3532.method_15357(box.field_1323);
        int j = class_3532.method_15384(box.field_1320);
        int k = class_3532.method_15357(box.field_1321);
        int l = class_3532.method_15384(box.field_1324);
        return !player.method_73183().method_33597(i, k, j, l);
    }

    private class_243 getRotationVector() {
        return getRotationVector(pitch, yaw);
    }

    private class_243 getRotationVector(float pitch, float yaw) {
        float f = (float) (pitch * Math.PI / 180.0);
        float g = (float) (-yaw * Math.PI / 180.0);
        float h = class_3532.method_15362(g);
        float i = class_3532.method_15374(g);
        float j = class_3532.method_15362(f);
        float k = class_3532.method_15374(f);
        return new class_243(i * j, -k, h * j);
    }

    public boolean hasStatusEffect(class_6880<class_1291> effect) {
        class_1293 instance = player.method_6112(effect);
        return instance != null && instance.method_5584() >= simulatedTicks;
    }

    private class_1293 getStatusEffect(class_6880<class_1291> effect) {
        class_1293 instance = player.method_6112(effect);
        if (instance == null || instance.method_5584() < simulatedTicks) {
            return null;
        }
        return instance;
    }

    public double getAttributeValue(class_6880<class_1320> attribute) {
        return player.method_6127().method_26852(attribute);
    }

    @Override
    public PlayerSimulation clone() {
        return new PlayerSimulation(
                player,
                input,
                pos,
                velocity,
                boundingBox,
                yaw,
                pitch,
                sprinting,
                fallDistance,
                jumpingCooldown,
                isJumping,
                isFallFlying,
                onGround,
                horizontalCollision,
                verticalCollision,
                touchingWater,
                isSwimming,
                submergedInWater,
                new Object2DoubleArrayMap<>(fluidHeight),
                new HashSet<>(submergedFluidTag)
        );
    }

    public class_2338 posToBlockPos(class_243 pos) {
        return new class_2338(class_3532.method_15357(pos.field_1352), class_3532.method_15357(pos.field_1351), class_3532.method_15357(pos.field_1350));
    }

    public class_2680 getState(class_2338 pos) {
        return player.method_73183().method_8320(pos);
    }

    public static class SimulatedPlayerInput extends class_744 {
        public boolean forceSafeWalk = false;
        public float movementForward;
        public float movementSideways;
        public class_10185 field_54155;
        public static final double MAX_WALKING_SPEED = 0.121;

        public SimulatedPlayerInput(class_10185 input) {
            this.field_54155 = input;
        }

        public void update() {
            if (field_54155.comp_3159() != field_54155.comp_3160()) {
                movementForward = field_54155.comp_3159() ? 1.0f : -1.0f;
            } else {
                movementForward = 0.0f;
            }
            if (field_54155.comp_3161() == field_54155.comp_3162()) {
                movementSideways = 0.0f;
            } else {
                movementSideways = field_54155.comp_3161() ? 1.0f : -1.0f;
            }
            if (field_54155.comp_3164()) {
                movementSideways *= 0.3f;
                movementForward *= 0.3f;
            }
        }

        @Override
        public String toString() {
            return "SimulatedPlayerInput(forwards={" + field_54155.comp_3159() + "}, backwards={" + field_54155.comp_3160() +
                    "}, left={" + field_54155.comp_3161() + "}, right={" + field_54155.comp_3162() + "}, jumping={" + field_54155.comp_3163() +
                    "}, sprinting=" + field_54155.comp_3165() + ", slowDown=" + field_54155.comp_3164() + ")";
        }

        public static SimulatedPlayerInput fromClientPlayer(class_10185 input) {
            return new SimulatedPlayerInput(input);
        }

        public static SimulatedPlayerInput guessInput(class_1657 entity) {
            class_243 velocity = entity.method_73189().method_1020(new class_243(entity.field_6014, entity.field_6036, entity.field_5969));
            double horizontalVelocity = velocity.method_37268();
            class_10185 input = new class_10185(false, false, false, false, !entity.method_24828(), entity.method_5715(), horizontalVelocity >= MAX_WALKING_SPEED * MAX_WALKING_SPEED);
            if (horizontalVelocity > 0.05 * 0.05) {
                double velocityAngle = MoveUtil.getDegreesRelativeToView(velocity, entity.method_36454());
                double wrappedAngle = class_3532.method_15338(velocityAngle);
                input = MoveUtil.getDirectionalInputForDegrees(input, wrappedAngle);
            }
            return new SimulatedPlayerInput(input);
        }
    }
}