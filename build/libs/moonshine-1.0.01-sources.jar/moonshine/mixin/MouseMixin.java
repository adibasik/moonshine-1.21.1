package moonshine.mixin;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.events.api.EventManager;
import moonshine.events.impl.FovEvent;
import moonshine.events.impl.HotBarScrollEvent;
import moonshine.events.impl.KeyEvent;
import moonshine.events.impl.MouseRotationEvent;
import moonshine.screens.clickgui.ClickGui;
import net.minecraft.class_11910;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_3675;
import net.minecraft.class_746;

@Mixin(class_312.class)
public abstract class MouseMixin {
    @Final
    @Shadow
    private class_310 client;

    @Shadow
    private boolean cursorLocked;

    @Shadow
    private double x;

    @Shadow
    private double y;

    @Shadow
    private double cursorDeltaX;

    @Shadow
    private double cursorDeltaY;

    @Shadow
    private boolean hasResolutionChanged;

    @Inject(method = "onMouseButton", at = @At("HEAD"))
    public void onMouseButtonHook(long window, class_11910 input, int action, CallbackInfo ci) {
        if (input.comp_4801() != GLFW.GLFW_KEY_UNKNOWN && window == client.method_22683().method_4490()) {
            EventManager.callEvent(new KeyEvent(client.field_1755, class_3675.class_307.field_1672, input.comp_4801(), action));
        }
    }

    @Inject(method = "onMouseScroll", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;getInventory()Lnet/minecraft/entity/player/PlayerInventory;"), cancellable = true)
    public void onMouseScrollHook(long window, double horizontal, double vertical, CallbackInfo ci) {
        HotBarScrollEvent event = new HotBarScrollEvent(horizontal, vertical);
        EventManager.callEvent(event);
        if (event.isCancelled()) ci.cancel();
    }

    @Inject(method = "lockCursor", at = @At("HEAD"), cancellable = true)
    private void onLockCursor(CallbackInfo ci) {
        if (client.field_1755 instanceof ClickGui clickGui) {
            if (clickGui.isClosing()) {
                this.cursorLocked = true;
                this.cursorDeltaX = 0;
                this.cursorDeltaY = 0;
                this.x = client.method_22683().method_4480() / 2.0;
                this.y = client.method_22683().method_4507() / 2.0;
                this.hasResolutionChanged = true;
                ci.cancel();
            }
        }
    }

    @Inject(method = "updateMouse", at = @At(value = "HEAD"))
    private void onUpdateMouse(double timeDelta, CallbackInfo ci) {
        FovEvent event = new FovEvent();
        EventManager.callEvent(event);
        if (event.isCancelled()) {
            double slowdown = (double) event.getFov() / client.field_1690.method_41808().method_41753();
            this.cursorDeltaX *= slowdown;
            this.cursorDeltaY *= slowdown;
        }
    }

    @WrapWithCondition(method = "updateMouse", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;changeLookDirection(DD)V"), require = 1, allow = 1)
    private boolean modifyMouseRotationInput(class_746 instance, double cursorDeltaX, double cursorDeltaY) {
        MouseRotationEvent event = new MouseRotationEvent((float) cursorDeltaX, (float) cursorDeltaY);
        EventManager.callEvent(event);
        if (event.isCancelled()) return false;
        instance.method_5872(event.getCursorDeltaX(), event.getCursorDeltaY());
        return false;
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        if (client.field_1755 instanceof ClickGui clickGui) {
            if (clickGui.isClosing() && !this.cursorLocked) {
                this.cursorLocked = true;
                this.cursorDeltaX = 0;
                this.cursorDeltaY = 0;
                this.hasResolutionChanged = true;
            }
        }
    }
}