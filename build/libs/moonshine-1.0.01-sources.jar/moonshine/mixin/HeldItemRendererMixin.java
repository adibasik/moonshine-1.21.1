package moonshine.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.events.api.EventManager;
import moonshine.events.impl.GlassHandsRenderEvent;
import moonshine.events.impl.HandAnimationEvent;
import moonshine.events.impl.HandOffsetEvent;
import moonshine.events.impl.HeldItemUpdateEvent;
import moonshine.events.impl.ItemRendererEvent;
import moonshine.modules.impl.render.GlassHands;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_759;

@Mixin(class_759.class)
public abstract class HeldItemRendererMixin {

    @Shadow
    private class_1799 mainHand;

    @Shadow
    private class_1799 offHand;

    @Unique
    private boolean moonshineCustomAnimation = false;

    @Inject(method = "updateHeldItems", at = @At("TAIL"))
    private void onUpdateHeldItems(CallbackInfo ci) {
        HeldItemUpdateEvent event = new HeldItemUpdateEvent(this.mainHand, this.offHand);
        EventManager.callEvent(event);

        if (event.getMainHand() != this.mainHand) {
            this.mainHand = event.getMainHand();
        }
        if (event.getOffHand() != this.offHand) {
            this.offHand = event.getOffHand();
        }
    }

    @Inject(method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V", at = @At("HEAD"))
    private void onRenderItemPre(float tickProgress, class_4587 matrices, class_11659 orderedRenderCommandQueue, class_746 player, int light, CallbackInfo ci) {
        GlassHands glassHands = GlassHands.getInstance();
        if (glassHands != null && glassHands.isState()) {
            GlassHandsRenderEvent event = new GlassHandsRenderEvent(GlassHandsRenderEvent.Phase.PRE, matrices, tickProgress);
            EventManager.callEvent(event);
        }
    }

    @Inject(method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V", at = @At("TAIL"))
    private void onRenderItemPost(float tickProgress, class_4587 matrices, class_11659 orderedRenderCommandQueue, class_746 player, int light, CallbackInfo ci) {
        GlassHands glassHands = GlassHands.getInstance();
        if (glassHands != null && glassHands.isState()) {
            GlassHandsRenderEvent event = new GlassHandsRenderEvent(GlassHandsRenderEvent.Phase.POST, matrices, tickProgress);
            EventManager.callEvent(event);
        }
    }

    @WrapOperation(method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V"))
    private void itemRenderHook(class_759 instance, class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_11659 orderedRenderCommandQueue, int light, Operation<Void> original) {
        ItemRendererEvent event = new ItemRendererEvent(player, item, hand);
        EventManager.callEvent(event);
        original.call(instance, event.getPlayer(), tickDelta, pitch, event.getHand(), swingProgress, event.getStack(), equipProgress, matrices, orderedRenderCommandQueue, light);
    }

    @Inject(method = "renderFirstPersonItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;push()V", shift = At.Shift.AFTER))
    private void renderFirstPersonItemHook(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 stack, float equipProgress, class_4587 matrices, class_11659 orderedRenderCommandQueue, int light, CallbackInfo ci) {
        HandOffsetEvent event = new HandOffsetEvent(matrices, stack, hand);
        EventManager.callEvent(event);

        float scale = event.getScale();
        if (scale != 1.0F) {
            matrices.method_22905(scale, scale, scale);
        }
    }

    @WrapOperation(method = "renderFirstPersonItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/HeldItemRenderer;applyEquipOffset(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/Arm;F)V"))
    private void wrapApplyEquipOffset(class_759 instance, class_4587 matrices, class_1306 arm, float equipProgress, Operation<Void> original, @Local(ordinal = 0, argsOnly = true) class_742 player, @Local(ordinal = 0, argsOnly = true) class_1268 hand, @Local(ordinal = 2, argsOnly = true) float swingProgress, @Local(ordinal = 0, argsOnly = true) class_1799 stack) {
        boolean isUsingItem = player.method_6115() && player.method_6058() == hand;

        if (isUsingItem) {
            moonshineCustomAnimation = false;
            original.call(instance, matrices, arm, equipProgress);
            return;
        }

        HandAnimationEvent event = new HandAnimationEvent(matrices, hand, swingProgress);
        EventManager.callEvent(event);

        if (event.isCancelled()) {
            moonshineCustomAnimation = true;
            return;
        }

        moonshineCustomAnimation = false;
        original.call(instance, matrices, arm, equipProgress);
    }

    @WrapOperation(method = "renderFirstPersonItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/HeldItemRenderer;swingArm(FLnet/minecraft/client/util/math/MatrixStack;ILnet/minecraft/util/Arm;)V"))
    private void wrapSwingArm(class_759 instance, float swingProgress, class_4587 matrices, int armX, class_1306 arm, Operation<Void> original) {
        if (moonshineCustomAnimation) {
            return;
        }
        original.call(instance, swingProgress, matrices, armX, arm);
    }
}