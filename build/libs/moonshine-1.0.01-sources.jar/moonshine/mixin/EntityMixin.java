package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import moonshine.IMinecraft;
import moonshine.events.api.EventManager;
import moonshine.events.impl.BoundingBoxControlEvent;
import moonshine.events.impl.PlayerVelocityStrafeEvent;
import moonshine.modules.impl.combat.aura.AngleConnection;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Mixin(class_1297.class)
public abstract class EntityMixin implements IMinecraft {

    @Shadow private class_238 boundingBox;
    @Shadow public float yaw;
    @Unique
    private boolean client$local;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void onInit(class_1299<?> type, class_1937 world, CallbackInfo ci) {
        client$local = (class_1297)(Object)this instanceof class_746;
    }
   
    @Unique
    private final class_310 client = class_310.method_1551();
  
    @Inject(method = "getBoundingBox", at = @At("HEAD"), cancellable = true)
    public final void getBoundingBox(CallbackInfoReturnable<class_238> cir) {
        BoundingBoxControlEvent event = new BoundingBoxControlEvent(boundingBox, (class_1297) (Object) this);
        EventManager.callEvent(event);
        cir.setReturnValue(event.getBox());
    }
    
    @Redirect(method = "updateVelocity", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;movementInputToVelocity(Lnet/minecraft/util/math/Vec3d;FF)Lnet/minecraft/util/math/Vec3d;"))
    public class_243 hookVelocity(class_243 movementInput, float speed, float yaw) {
        if ((Object) this == mc.field_1724) {
            PlayerVelocityStrafeEvent event = new PlayerVelocityStrafeEvent(movementInput, speed, yaw, class_1297.method_18795(movementInput, speed, yaw));
            EventManager.callEvent(event);
            return event.getVelocity();
        }
        return class_1297.method_18795(movementInput, speed, yaw);
    }
    
    @ModifyVariable(method = "getRotationVector(FF)Lnet/minecraft/util/math/Vec3d;", at = @At("HEAD"), ordinal = 0, argsOnly = true)
    private float modifyPitch(float pitch) {
        if ((Object) this instanceof class_746 && AngleConnection.INSTANCE.getCurrentAngle() !=null) {
            return AngleConnection.INSTANCE.getCurrentAngle().getPitch();
        }
        return pitch;
    }
}
