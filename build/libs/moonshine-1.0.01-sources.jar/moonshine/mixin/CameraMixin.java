package moonshine.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.events.api.EventManager;
import moonshine.events.impl.CameraEvent;
import moonshine.events.impl.CameraPositionEvent;
import moonshine.modules.impl.combat.aura.Angle;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_746;


@Mixin(class_4184.class)
public abstract class CameraMixin {

    @Shadow private class_243 pos;

    @Shadow @Final private class_2338.class_2339 blockPos;

    @Shadow public abstract void setRotation(float yaw, float pitch);

    @Shadow protected abstract void moveBy(float f, float g, float h);

    @Shadow protected abstract float clipToSpace(float f);
    @Shadow private float yaw;
    @Shadow private float pitch;

    @Inject(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setPos(DDD)V", shift = At.Shift.AFTER), cancellable = true)
    private void updateHook(class_1937 area, class_1297 focusedEntity, boolean thirdPerson, boolean inverseView, float tickProgress, CallbackInfo ci) {
        CameraEvent event = new CameraEvent(false, 4, new Angle(yaw, pitch));
        EventManager.callEvent(event);
        Angle angle = event.getAngle();
        if (event.isCancelled() && focusedEntity instanceof class_746 player && !player.method_6113() && thirdPerson) {
            float pitch = inverseView ? -angle.getPitch() : angle.getPitch();
            float yaw = angle.getYaw() - (inverseView ? 180 : 0);
            float distance = event.getDistance();
            setRotation(yaw, pitch);
            moveBy(event.isCameraClip() ? -distance : -clipToSpace(distance), 0.0F, 0.0F);
            ci.cancel();
        }
    }

    @Inject(method = "setPos(Lnet/minecraft/util/math/Vec3d;)V", at = @At("HEAD"), cancellable = true)
    private void posHook(class_243 pos, CallbackInfo ci) {
        CameraPositionEvent event = new CameraPositionEvent(pos);
        EventManager.callEvent(event);
        this.pos = pos = event.getPos();
        blockPos.method_10102(pos.field_1352,pos.field_1351,pos.field_1350);
        ci.cancel();
    }

}