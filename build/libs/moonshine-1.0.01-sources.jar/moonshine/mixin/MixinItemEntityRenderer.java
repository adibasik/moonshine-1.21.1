package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.modules.impl.render.ItemPhysic;
import net.minecraft.class_10039;
import net.minecraft.class_10428;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1542;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import net.minecraft.class_5819;
import net.minecraft.class_7833;
import net.minecraft.class_916;
import java.util.WeakHashMap;

@Mixin(class_916.class)
public abstract class MixinItemEntityRenderer {

    @Unique
    private static final WeakHashMap<class_10039, Boolean> groundStateMap = new WeakHashMap<>();

    @Unique
    private class_10039 currentState = null;

    @Inject(method = "updateRenderState(Lnet/minecraft/entity/ItemEntity;Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;F)V", at = @At("HEAD"))
    private void captureGroundState(class_1542 entity, class_10039 state, float tickDelta, CallbackInfo ci) {
        groundStateMap.put(state, entity.method_24828());
    }

    @Redirect(method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V", ordinal = 0))
    private void redirectTranslate(class_4587 matrices, float x, float y, float z, class_10039 state, class_4587 matricesArg, class_11659 queue, class_12075 cameraState) {
        currentState = state;

        ItemPhysic itemPhysic = ItemPhysic.getInstance();

        if (itemPhysic != null && itemPhysic.isState() && itemPhysic.mode.isSelected("Обычная")) {
            class_238 box = state.field_55310.method_72173();
            float f = -((float) box.field_1322) + 0.0625F;
            matrices.method_46416(x, f, z);
        } else {
            matrices.method_46416(x, y, z);
        }
    }

    @Redirect(method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/ItemEntityRenderer;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/ItemStackEntityRenderState;Lnet/minecraft/util/math/random/Random;Lnet/minecraft/util/math/Box;)V"))
    private void redirectRender(class_4587 matrices, class_11659 queue, int light, class_10428 stackState, class_5819 random, class_238 box) {
        ItemPhysic itemPhysic = ItemPhysic.getInstance();

        if (itemPhysic != null && itemPhysic.isState() && itemPhysic.mode.isSelected("Обычная") && currentState != null) {
            float age = currentState.field_53328;
            float offset = currentState.field_53435;

            boolean isOnGround = groundStateMap.getOrDefault(currentState, false);

            float rotation = class_1542.method_27314(age, offset);
            matrices.method_22907(class_7833.field_40716.rotation(-rotation));

            if (isOnGround) {
                matrices.method_22907(class_7833.field_40714.rotationDegrees(90));
                float yOffset = (float) box.method_17940() / 2.0f;
                matrices.method_46416(0, -yOffset + 0.0625f, 0);
            } else {
                float spinSpeed = 15.0f;
                float itemRotation = (age * spinSpeed + offset * 360.0f) % 360.0f;
                matrices.method_22907(class_7833.field_40714.rotationDegrees(itemRotation));
            }
        }

        class_916.method_72986(matrices, queue, light, stackState, random, box);
    }
}