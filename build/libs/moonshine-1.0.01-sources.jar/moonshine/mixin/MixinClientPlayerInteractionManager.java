package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.events.api.EventManager;
import moonshine.events.impl.AttackEvent;
import moonshine.events.impl.ClickSlotEvent;
import moonshine.events.impl.InteractEntityEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_636;

@Mixin(class_636.class)
public class MixinClientPlayerInteractionManager {

    @Inject(method = "attackEntity", at = @At("HEAD"),cancellable = true)
    public void attackEntityHook(class_1657 player, class_1297 target, CallbackInfo info) {
        InteractEntityEvent event = new InteractEntityEvent(target);
        EventManager.callEvent(event);
        if (event.isCancelled()) info.cancel();
    }

    @Inject(method = "attackEntity", at = @At("HEAD"))
    private void onAttackEntity(class_1657 player, class_1297 target, CallbackInfo ci) {
        AttackEvent event = new AttackEvent(target);
        EventManager.callEvent(event);
    }

    @Inject(method = "clickSlot", at = @At("HEAD"), cancellable = true)
    public void clickSlotHook(int syncId, int slotId, int button, class_1713 actionType, class_1657 player, CallbackInfo info) {
        ClickSlotEvent event = new ClickSlotEvent(syncId,slotId,button,actionType);
        EventManager.callEvent(event);
        if (event.isCancelled()) info.cancel();
    }

}