package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import moonshine.IMinecraft;
import moonshine.modules.impl.render.ChunkAnimator;
import moonshine.modules.impl.render.NoRender;
import net.minecraft.class_11282;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_4184;
import net.minecraft.class_761;

@Mixin(class_761.class)
public class WorldRendererMixin implements IMinecraft {

    @ModifyArg(method = "renderBlockLayers", at = @At(value = "INVOKE", target = "Ljava/util/List;add(Ljava/lang/Object;)Z", ordinal = 0), index = 0)
    private Object modifyChunkSectionsValue(Object value) {
        if (value instanceof class_11282.class_12294 original) {
            ChunkAnimator chunkAnimator = ChunkAnimator.getInstance();
            if (chunkAnimator != null && chunkAnimator.isState()) {
                float visibility = original.comp_5186();
                float animOffset = (1.0f - visibility) * 100f;
                int newY = original.comp_5184() - (int) animOffset;
                return new class_11282.class_12294(
                        original.comp_5182(),
                        original.comp_5183(),
                        newY,
                        original.comp_5185(),
                        original.comp_5186(),
                        original.comp_5187(),
                        original.comp_5188()
                );
            }
        }
        return value;
    }

    @Inject(method = "hasBlindnessOrDarkness", at = @At("HEAD"), cancellable = true)
    private void onHasBlindnessOrDarkness(class_4184 camera, CallbackInfoReturnable<Boolean> cir) {
        NoRender noRender = NoRender.getInstance();
        if (noRender == null || !noRender.isState()) return;

        class_1297 entity = camera.method_19331();
        if (!(entity instanceof class_1309 livingEntity)) return;

        boolean hasBlindness = livingEntity.method_6059(class_1294.field_5919);
        boolean hasDarkness = livingEntity.method_6059(class_1294.field_38092);

        if (noRender.modeSetting.isSelected("Bad Effects") && hasBlindness && !hasDarkness) {
            cir.setReturnValue(false);
        }

        if (noRender.modeSetting.isSelected("Darkness") && hasDarkness && !hasBlindness) {
            cir.setReturnValue(false);
        }

        if (noRender.modeSetting.isSelected("Bad Effects") && noRender.modeSetting.isSelected("Darkness")) {
            cir.setReturnValue(false);
        }
    }
}