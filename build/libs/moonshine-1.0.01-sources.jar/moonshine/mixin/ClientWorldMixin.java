package moonshine.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.IMinecraft;
import moonshine.events.api.EventManager;
import moonshine.events.impl.EntitySpawnEvent;
import moonshine.events.impl.WorldLoadEvent;
import moonshine.modules.impl.render.Ambience;
import moonshine.util.string.PlayerInteractionHelper;
import net.minecraft.class_1297;
import net.minecraft.class_638;

@Mixin(class_638.class)
public class ClientWorldMixin implements IMinecraft {

    @Shadow
    @Final
    private class_638.class_5271 clientWorldProperties;

    @Inject(method = "<init>", at = @At("RETURN"))
    public void initHook(CallbackInfo info) {
        EventManager.callEvent(new WorldLoadEvent());
    }

    @Inject(method = "addEntity", at = @At("HEAD"), cancellable = true)
    public void addEntityHook(class_1297 entity, CallbackInfo ci) {
        if (PlayerInteractionHelper.nullCheck()) return;
        EntitySpawnEvent event = new EntitySpawnEvent(entity);
        EventManager.callEvent(event);
        if (event.isCancelled()) ci.cancel();
    }

    @Inject(method = "tickTime", at = @At("HEAD"), cancellable = true)
    private void onTickTime(CallbackInfo ci) {
        Ambience ambience = Ambience.getInstance();
        if (ambience != null && ambience.isState()) {
            this.clientWorldProperties.method_165(ambience.getCustomTime());
            ci.cancel();
        }
    }
}