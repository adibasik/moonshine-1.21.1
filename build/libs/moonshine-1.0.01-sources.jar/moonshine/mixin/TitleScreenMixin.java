package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.screens.menu.MainMenuScreen;
import moonshine.util.selfdestruct.SelfDestructManager;
import net.minecraft.class_310;
import net.minecraft.class_442;

@Mixin(class_442.class)
public class TitleScreenMixin {

    @Unique
    private static boolean redirected = false;

    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void onInit(CallbackInfo ci) {
        if (SelfDestructManager.isLocked()) {
            return;
        }
        if (!redirected) {
            redirected = true;
            ci.cancel();
            class_310.method_1551().method_1507(new MainMenuScreen());
        }
    }
}
