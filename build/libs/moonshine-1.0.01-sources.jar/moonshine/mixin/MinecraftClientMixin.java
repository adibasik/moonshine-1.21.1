package moonshine.mixin;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import moonshine.Initialization;
import moonshine.events.api.EventManager;
import moonshine.events.impl.GameLeftEvent;
import moonshine.events.impl.HotBarUpdateEvent;
import moonshine.events.impl.SetScreenEvent;
import moonshine.modules.impl.combat.NoInteract;
import moonshine.modules.impl.render.Hud;
import moonshine.screens.clickgui.ClickGui;
import moonshine.screens.menu.MainMenuScreen;
import moonshine.util.config.ConfigSystem;
import moonshine.util.render.font.FontRenderer;
import moonshine.util.session.SessionChanger;
import moonshine.util.selfdestruct.SelfDestructManager;
import moonshine.util.window.WindowStyle;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_310;
import net.minecraft.class_320;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_757;
import antidaunleak.api.UserProfile;

import static moonshine.IMinecraft.mc;

@Mixin(class_310.class)
public abstract class MinecraftClientMixin {
    @Shadow
    @Nullable
    public class_746 player;

    @Shadow
    @Nullable
    public class_636 interactionManager;

    @Shadow
    @Final
    public class_757 gameRenderer;

    @Shadow
    public class_638 world;

    private static boolean fontsInitialized = false;

    @Shadow
    @Mutable
    private class_320 session;

    private void setSession(class_320 newSession) {
        this.session = newSession;
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void onInit(CallbackInfo ci) {
        new Initialization().init();
        SessionChanger.setSessionSetter(this::setSession);
    }

    @Inject(method = "stop", at = @At("HEAD"))
    private void onStop(CallbackInfo ci) {
        ConfigSystem configSystem = ConfigSystem.getInstance();
        if (configSystem != null) {
            configSystem.shutdown();
        }
    }

    @Inject(method = "setScreen", at = @At("HEAD"))
    private void onSetScreen(class_437 screen, CallbackInfo ci) {
        if (!fontsInitialized && screen != null) {
            try {
                FontRenderer fontRenderer = Initialization.getInstance().getManager().getRenderCore().getFontRenderer();
                if (fontRenderer != null && !fontRenderer.isInitialized()) {
                    fontRenderer.initialize();
                    fontsInitialized = true;
                }
            } catch (Exception ignored) {}
        }
    }

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void redirectTitleScreen(class_437 screen, CallbackInfo ci) {
        if (SelfDestructManager.isLocked()) {
            return;
        }
        if (screen instanceof class_442 && !(screen instanceof MainMenuScreen)) {
            ci.cancel();
            ((class_310)(Object)this).method_1507(new MainMenuScreen());
        }
    }

    @Inject(method = "disconnect(Lnet/minecraft/client/gui/screen/Screen;Z)V", at = @At("HEAD"))
    private void onDisconnect(class_437 screen, boolean transferring, CallbackInfo info) {
        if (world != null) {
            EventManager.callEvent(GameLeftEvent.get());
        }
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        Hud hud = Hud.getInstance();
        if (hud != null && hud.isState()) {
            if (Initialization.getInstance() != null
                    && Initialization.getInstance().getManager() != null
                    && Initialization.getInstance().getManager().getHudManager() != null) {
                Initialization.getInstance().getManager().getHudManager().tick();
            }
        }
    }

    @Inject(method = "setScreen", at = @At(value = "HEAD"), cancellable = true)
    public void setScreenHook(class_437 screen, CallbackInfo ci) {
        class_310 client = (class_310) (Object) this;

        if (SelfDestructManager.isLocked() && screen instanceof ClickGui) {
            ci.cancel();
            return;
        }

        if (client.field_1755 instanceof ClickGui clickGui) {
            if (clickGui.isClosing() && screen == null) {
                ci.cancel();
                return;
            }
        }

        SetScreenEvent event = new SetScreenEvent(screen);
        EventManager.callEvent(event);

        Initialization instance = Initialization.getInstance();

        class_437 eventScreen = event.getScreen();
        if (screen != eventScreen) {
            mc.method_1507(eventScreen);
            ci.cancel();
        }
    }

    @Inject(method = "getWindowTitle", at = @At("RETURN"), cancellable = true)
    private void getWindowTitle(CallbackInfoReturnable<String> cir) {
        UserProfile userProfile = UserProfile.getInstance();
        String username = userProfile.profile("username");
        String role = userProfile.profile("role");
        cir.setReturnValue(String.format("Moonshine Modern (%s - %s)", role, username));
    }

    @Inject(method = "handleInputEvents", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;getInventory()Lnet/minecraft/entity/player/PlayerInventory;"), cancellable = true)
    public void handleInputEventsHook(CallbackInfo ci) {
        HotBarUpdateEvent event = new HotBarUpdateEvent();
        EventManager.callEvent(event);
        if (event.isCancelled()) ci.cancel();
    }

    @Inject(method = "doItemUse", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/Hand;values()[Lnet/minecraft/util/Hand;"), cancellable = true)
    public void doItemUseHook(CallbackInfo ci) {
        if (NoInteract.getInstance().isState()) {
            for (class_1268 hand : class_1268.values()) {
                if (player.method_5998(hand).method_7960()) continue;
                class_1269 result = interactionManager.method_2919(player, hand);
                if (result.method_23665()) {
                    if (result instanceof class_1269.class_9860 success && success.comp_2909().equals(class_1269.class_9861.field_52427)) {
                        gameRenderer.field_4012.method_3215(hand);
                        player.method_6104(hand);
                    }
                    ci.cancel();
                }
            }
        }
    }

    @Inject(method = "onResolutionChanged", at = @At("TAIL"))
    private void applyDarkMode(CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        WindowStyle.setDarkMode(client.method_22683().method_4490());
    }
}
