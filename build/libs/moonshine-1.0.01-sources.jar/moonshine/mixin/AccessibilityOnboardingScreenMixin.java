package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.screens.menu.MainMenuScreen;
import moonshine.util.selfdestruct.SelfDestructManager;
import net.minecraft.class_310;
import net.minecraft.class_8032;

@Mixin(class_8032.class)
public class AccessibilityOnboardingScreenMixin {

    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void onInit(CallbackInfo ci) {
        if (SelfDestructManager.isLocked()) {
            return;
        }
        ci.cancel();
        class_310.method_1551().method_1507(new MainMenuScreen());
    }
}
