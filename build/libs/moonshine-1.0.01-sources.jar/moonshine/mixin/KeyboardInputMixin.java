package moonshine.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import moonshine.events.api.EventManager;
import moonshine.events.impl.InputEvent;
import moonshine.modules.impl.combat.aura.Angle;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.modules.impl.combat.aura.AngleConstructor;
import net.minecraft.class_10185;
import net.minecraft.class_3532;
import net.minecraft.class_743;

import static moonshine.IMinecraft.mc;

@Mixin(class_743.class)
public class KeyboardInputMixin {

    @ModifyExpressionValue(method = "tick", at = @At(value = "NEW", target = "(ZZZZZZZ)Lnet/minecraft/util/PlayerInput;"))
    private class_10185 tickHook(class_10185 original) {
        InputEvent event = new InputEvent(original);
        EventManager.callEvent(event);
        return transformInput(event.getInput());
    }

    @Unique
    private class_10185 transformInput(class_10185 input) {
        AngleConnection rotationController = AngleConnection.INSTANCE;
        Angle angle = rotationController.getCurrentAngle();
        AngleConstructor configurable = rotationController.getCurrentRotationPlan();

        if (mc.field_1724 == null || angle == null || configurable == null ||
                !(configurable.isMoveCorrection() && configurable.isFreeCorrection())) {
            return input;
        }

        float deltaYaw = mc.field_1724.method_36454() - angle.getYaw();
        float z = class_743.method_40218(input.comp_3159(), input.comp_3160());
        float x = class_743.method_40218(input.comp_3161(), input.comp_3162());
        float newX = x * class_3532.method_15362(deltaYaw * 0.017453292f) - z * class_3532.method_15374(deltaYaw * 0.017453292f);
        float newZ = z * class_3532.method_15362(deltaYaw * 0.017453292f) + x * class_3532.method_15374(deltaYaw * 0.017453292f);
        int movementSideways = Math.round(newX);
        int movementForward = Math.round(newZ);

        return new class_10185(
                movementForward > 0F,
                movementForward < 0F,
                movementSideways > 0F,
                movementSideways < 0F,
                input.comp_3163(),
                input.comp_3164(),
                input.comp_3165());
    }
}