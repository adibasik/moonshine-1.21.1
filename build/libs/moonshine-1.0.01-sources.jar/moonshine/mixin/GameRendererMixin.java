package moonshine.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.systems.RenderSystem;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.Initialization;
import moonshine.client.draggables.Drag;
import moonshine.events.api.EventManager;
import moonshine.events.impl.FovEvent;
import moonshine.events.impl.WorldRenderEvent;
import moonshine.modules.impl.player.NoEntityTrace;
import moonshine.modules.impl.render.Hud;
import moonshine.modules.impl.render.NoRender;
import moonshine.screens.clickgui.ClickGui;
import moonshine.util.render.Render3D;
import moonshine.util.selfdestruct.SelfDestructManager;
import net.minecraft.class_11228;
import net.minecraft.class_11246;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_4184;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_758;
import net.minecraft.class_7833;
import net.minecraft.class_9779;

@Mixin(class_757.class)
public abstract class GameRendererMixin {

    @Shadow
    @Final
    private class_310 client;

    @Shadow
    @Final
    private class_4184 camera;

    @Shadow
    @Final
    class_11246 guiState;

    @Shadow
    @Final
    private class_11228 guiRenderer;

    @Shadow
    @Final
    private class_758 fogRenderer;

    @Unique
    private final class_4587 matrices = new class_4587();

    @Shadow
    protected abstract void bobView(class_4587 matrices, float tickDelta);

    @Shadow
    protected abstract void tiltViewWhenHurt(class_4587 matrices, float tickDelta);

    @Shadow
    public abstract float getFov(class_4184 camera, float tickDelta, boolean changingFov);

    @Inject(method = "close", at = @At("RETURN"))
    private void onClose(CallbackInfo ci) {
        if (Initialization.getInstance() != null && Initialization.getInstance().getManager() != null && Initialization.getInstance().getManager().getRenderCore() != null) {
            Initialization.getInstance().getManager().getRenderCore().close();
        }
    }

    @ModifyExpressionValue(method = "getFov", at = @At(value = "INVOKE", target = "Ljava/lang/Integer;intValue()I", remap = false))
    private int hookGetFov(int original) {
        FovEvent event = new FovEvent();
        EventManager.callEvent(event);
        if (event.isCancelled()) return event.getFov();
        return original;
    }

    @Inject(method = "updateCrosshairTarget", at = @At("HEAD"), cancellable = true)
    private void updateCrosshairTargetHook(float tickProgress, CallbackInfo ci) {
        NoEntityTrace noEntityTrace = NoEntityTrace.getInstance();
        if (noEntityTrace != null && noEntityTrace.shouldIgnoreEntityTrace()) {
            class_1297 entity = this.client.method_1560();
            if (entity != null && this.client.field_1687 != null && this.client.field_1724 != null) {
                double range = Math.max(
                        this.client.field_1724.method_55754(),
                        this.client.field_1724.method_55755()
                );
                this.client.field_1765 = entity.method_5745(range, tickProgress, false);
                this.client.field_1692 = null;
                ci.cancel();
            }
        }
    }

    @Inject(method = "renderWorld", at = @At(value = "INVOKE_STRING", target = "Lnet/minecraft/util/profiler/Profiler;swap(Ljava/lang/String;)V", args = {"ldc=hand"}))
    public void hookWorldRender(class_9779 tickCounter, CallbackInfo ci, @Local(ordinal = 0) Matrix4f projection, @Local(ordinal = 1) Matrix4f view, @Local(ordinal = 0) float tickDelta, @Local class_4587 matrixStack) {
        if (client.field_1687 == null || client.field_1724 == null) return;

        class_4587 worldSpaceStack = new class_4587();
        worldSpaceStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        worldSpaceStack.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));

        Render3D.lastProjMat.set(client.field_1773.method_22973(getFov(camera, tickDelta, true)));
        Render3D.lastModMat.set(RenderSystem.getModelViewMatrix());
        Render3D.lastWorldSpaceMatrix.set(worldSpaceStack.method_23760().method_23761());

        Render3D.setLastWorldSpaceEntry(matrixStack.method_23760());
        Render3D.setLastTickDelta(tickDelta);
        Render3D.setLastCameraPos(camera.method_71156());
        Render3D.setLastCameraRotation(new Quaternionf(camera.method_23767()));

        Matrix4fStack modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.pushMatrix().mul(view);

        matrices.method_22903();
        tiltViewWhenHurt(matrices, camera.method_55437());
        if (client.field_1690.method_42448().method_41753()) {
            bobView(matrices, camera.method_55437());
        }
        modelViewStack.mul(matrices.method_23760().method_23761().invert(new Matrix4f()));
        matrices.method_22909();

        WorldRenderEvent event = new WorldRenderEvent(matrixStack, tickDelta);
        EventManager.callEvent(event);
        Render3D.onWorldRender(event);

        modelViewStack.popMatrix();
    }

    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void onTiltViewWhenHurt(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        NoRender noRender = NoRender.getInstance();
        if (noRender != null && noRender.isState() && noRender.modeSetting.isSelected("Damage")) {
            ci.cancel();
        }
    }

    @ModifyExpressionValue(method = "renderWorld", at = @At(value = "INVOKE", target = "Ljava/lang/Math;max(FF)F", ordinal = 0))
    private float onNauseaDistortion(float original) {
        NoRender noRender = NoRender.getInstance();
        if (noRender != null && noRender.isState() && noRender.modeSetting.isSelected("Nausea")) {
            return 0.0F;
        }
        return original;
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/render/GuiRenderer;render(Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V", shift = At.Shift.AFTER))
    private void afterGuiRender(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
        if (client.field_1687 == null || client.field_1724 == null) return;
        if (isLoadingScreen(client.field_1755)) return;
        if (client.method_18506() != null) return;
        if (!shouldRenderOnTop(client.field_1755)) return;

        guiState.method_70926();

        int mouseX = (int) client.field_1729.method_68879(client.method_22683());
        int mouseY = (int) client.field_1729.method_68883(client.method_22683());
        float tickDelta = tickCounter.method_60637(false);

        class_332 context = new class_332(client, guiState, mouseX, mouseY);

        Hud hud = Hud.getInstance();
        if (hud != null && hud.isState()) {
            boolean isChatScreen = client.field_1755 instanceof class_408;
            Drag.onDraw(context, mouseX, mouseY, tickDelta, isChatScreen);
        }

        if (client.field_1755 instanceof ClickGui clickGui) {
            if (SelfDestructManager.isLocked()) {
                client.method_1507(null);
                return;
            }
            clickGui.renderOverlay(context, tickCounter);
        }

        guiRenderer.method_70890(fogRenderer.method_71109(class_758.class_4596.field_60101));
    }

    @Unique
    private boolean shouldRenderOnTop(class_437 screen) {
        if (screen == null) return true;
        if (SelfDestructManager.isLocked() && screen instanceof ClickGui) return false;
        if (screen instanceof ClickGui) return true;
        if (screen instanceof class_408) return true;
        return false;
    }

    @Unique
    private boolean isLoadingScreen(class_437 screen) {
        if (screen == null) return false;
        String className = screen.getClass().getSimpleName().toLowerCase();
        String fullName = screen.getClass().getName().toLowerCase();
        if (className.contains("loading")) return true;
        if (className.contains("progress")) return true;
        if (className.contains("connecting")) return true;
        if (className.contains("downloading")) return true;
        if (className.contains("terrain")) return true;
        if (className.contains("generating")) return true;
        if (className.contains("saving")) return true;
        if (className.contains("reload")) return true;
        if (className.contains("resource")) return true;
        if (className.contains("pack")) return true;
        if (fullName.contains("mojang")) return true;
        return false;
    }
}
