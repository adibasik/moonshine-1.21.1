package moonshine.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import moonshine.IMinecraft;
import moonshine.events.api.EventManager;
import moonshine.events.impl.FireworkEvent;
import moonshine.modules.impl.combat.aura.AngleConnection;
import net.minecraft.class_1309;
import net.minecraft.class_1671;
import net.minecraft.class_243;

@Mixin(class_1671.class)
public class FireworkRocketEntityMixin implements IMinecraft {

    @Shadow @Nullable private class_1309 shooter;

    @WrapOperation(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getRotationVector()Lnet/minecraft/util/math/Vec3d;"))
    public class_243 getRotationVectorHook(class_1309 instance, Operation<class_243> original) {
        if (shooter == mc.field_1724 && shooter.method_6128()) {
            return AngleConnection.INSTANCE.getMoveRotation().toVector();
        }
        return original.call(instance);
    }

    @WrapOperation(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;setVelocity(Lnet/minecraft/util/math/Vec3d;)V"))
    public void setVelocityHook(class_1309 instance, class_243 velocity, Operation<Void> original) {
        if (shooter == mc.field_1724 && shooter.method_6128()) {
            FireworkEvent event = new FireworkEvent(velocity);
            EventManager.callEvent(event);
            original.call(instance, event.getVector());
        } else {
            original.call(instance, velocity);
        }
    }
}