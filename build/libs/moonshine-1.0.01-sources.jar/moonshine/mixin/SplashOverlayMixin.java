package moonshine.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.screens.loading.Loading;
import net.minecraft.class_156;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4011;
import net.minecraft.class_4071;
import net.minecraft.class_425;

@Mixin(class_425.class)
public abstract class SplashOverlayMixin {

    @Shadow @Final private class_310 client;
    @Shadow @Final private class_4011 reload;
    @Shadow @Final private boolean reloading;
    @Shadow private float progress;
    @Shadow private long reloadCompleteTime;
    @Shadow private long reloadStartTime;

    @Unique
    private Loading loadingScreen;

    @Unique
    private boolean resourcesMarkedComplete = false;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void onRender(class_332 context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        if (this.reloading) {
            return;
        }

        ci.cancel();

        if (loadingScreen == null) {
            loadingScreen = new Loading();
        }

        int width = context.method_51421();
        int height = context.method_51443();
        long currentTime = class_156.method_658();

        if (this.reloadStartTime == -1L) {
            this.reloadStartTime = currentTime;
        }

        float reloadProgress = this.reload.method_18229();
        this.progress = class_3532.method_15363(this.progress * 0.95F + reloadProgress * 0.05F, 0.0F, 1.0F);

        loadingScreen.setProgress(this.progress);

        if (this.reload.method_18787() && !resourcesMarkedComplete) {
            resourcesMarkedComplete = true;
            loadingScreen.markComplete();
            if (this.reloadCompleteTime == -1L) {
                this.reloadCompleteTime = currentTime;
            }
        }

        loadingScreen.render(width, height, 1.0f);

        if (loadingScreen.isReadyToClose()) {
            this.client.method_18502((class_4071) null);
            loadingScreen.reset();
            loadingScreen = null;
            resourcesMarkedComplete = false;
        }
    }
}