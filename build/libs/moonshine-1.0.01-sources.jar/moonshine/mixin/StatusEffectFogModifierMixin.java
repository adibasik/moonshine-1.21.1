package moonshine.mixin;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import moonshine.modules.impl.render.NoRender;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_5636;
import net.minecraft.class_6880;
import net.minecraft.class_7286;

@Mixin(class_7286.class)
public abstract class StatusEffectFogModifierMixin {

    @Shadow
    public abstract class_6880<class_1291> getStatusEffect();

    @Inject(method = "shouldApply", at = @At("HEAD"), cancellable = true)
    private void onShouldApply(@Nullable class_5636 submersionType, class_1297 cameraEntity, CallbackInfoReturnable<Boolean> cir) {
        NoRender noRender = NoRender.getInstance();
        if (!noRender.isState()) return;

        class_6880<class_1291> effect = this.getStatusEffect();

        if (noRender.modeSetting.isSelected("Bad Effects") && effect == class_1294.field_5919) {
            cir.setReturnValue(false);
        }

        if (noRender.modeSetting.isSelected("Darkness") && effect == class_1294.field_38092) {
            cir.setReturnValue(false);
        }
    }
}