package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import moonshine.util.interfaces.IBuiltChunkAnimator;
import net.minecraft.class_846;

@Mixin(class_846.class_851.class)
public class MixinBuiltChunk implements IBuiltChunkAnimator {
    @Unique
    private float animation = 100f;

    @Override
    public float getAnimation() {
        return animation;
    }

    @Override
    public void setAnimation(float value) {
        this.animation = value;
    }
}