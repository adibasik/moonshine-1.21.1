package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.IMinecraft;
import moonshine.events.api.EventManager;
import moonshine.events.impl.ChatEvent;
import moonshine.events.impl.GameLeftEvent;
import moonshine.events.impl.WorldChangeEvent;
import moonshine.modules.impl.render.Particles;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2663;
import net.minecraft.class_2678;
import net.minecraft.class_2724;
import net.minecraft.class_3417;
import net.minecraft.class_634;
import net.minecraft.class_638;

@Mixin(class_634.class)
public abstract class ClientPlayNetworkHandlerMixin implements IMinecraft {

    @Shadow
    private class_638 world;

    @Shadow
    private static class_1799 getActiveDeathProtector(class_1657 player) {
        return null;
    }

    @Unique
    private boolean worldNotNull;

    @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
    private void onSendChatMessage(String message, CallbackInfo ci) {
        ChatEvent event = new ChatEvent(message);
        EventManager.callEvent(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "onGameJoin", at = @At("HEAD"))
    private void onGameJoinHead(class_2678 packet, CallbackInfo info) {
        worldNotNull = world != null;
    }

    @Inject(method = "onGameJoin", at = @At("TAIL"))
    private void onGameJoinTail(class_2678 packet, CallbackInfo info) {
        if (worldNotNull) {
            EventManager.callEvent(GameLeftEvent.get());
        }
    }

    @Inject(method = "onGameJoin", at = @At("RETURN"))
    private void onGameJoin(class_2678 packet, CallbackInfo ci) {
        EventManager.callEvent(WorldChangeEvent.get());
    }

    @Inject(method = "onPlayerRespawn", at = @At("RETURN"))
    private void onPlayerRespawn(class_2724 packet, CallbackInfo ci) {
        EventManager.callEvent(WorldChangeEvent.get());
    }

    @Inject(method = "onEntityStatus", at = @At("HEAD"), cancellable = true)
    private void onEntityStatus(class_2663 packet, CallbackInfo ci) {
        if (packet.method_11470() == 35) {
            class_1297 entity = packet.method_11469(mc.field_1687);
            if (entity != null) {
                Particles particlesMod = Particles.getInstance();
                if (particlesMod != null && particlesMod.isState() && particlesMod.triggers.isSelected("Тотем")) {
                    particlesMod.onTotemPop(entity);

                    mc.field_1687.method_8486(entity.method_23317(), entity.method_23318(), entity.method_23321(), class_3417.field_14931, entity.method_5634(), 1.0F, 1.0F, false);

                    if (entity == mc.field_1724) {
                        mc.field_1773.method_3189(getActiveDeathProtector(mc.field_1724));
                    }

                    ci.cancel();
                }
            }
        }
    }
}