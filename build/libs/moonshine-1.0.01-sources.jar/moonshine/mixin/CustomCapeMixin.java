package moonshine.mixin;

import net.minecraft.class_12079;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_742.class)
public class CustomCapeMixin {

    @Unique
    private static final class_2960 CAPE_ID = class_2960.method_60655("moonshine", "capes/cape");
    @Unique
    private static final class_12079.class_10726 CAPE_ASSET = new class_12079.class_10726(CAPE_ID);

    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void replaceCape(CallbackInfoReturnable<class_8685> cir) {
        class_742 player = (class_742) (Object) this;
        class_310 client = class_310.method_1551();

        if (client.field_1724 == null || !player.method_5667().equals(client.field_1724.method_5667())) {
            return;
        }

        class_8685 old = cir.getReturnValue();
        cir.setReturnValue(new class_8685(
                old.comp_1626(),
                CAPE_ASSET,
                CAPE_ASSET,
                old.comp_1629(),
                old.comp_1630()
        ));
    }
}