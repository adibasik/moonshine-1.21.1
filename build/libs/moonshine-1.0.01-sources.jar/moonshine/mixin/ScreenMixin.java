package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.command.CommandManager;
import moonshine.screens.clickgui.ClickGui;
import net.minecraft.class_2558;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

@Mixin(class_437.class)
public class ScreenMixin {

    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
    private void disableBackgroundBlurAndDimming(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if ((Object) this instanceof ClickGui) {
            ci.cancel();
        }
    }

    @Inject(method = "handleClickEvent", at = @At("HEAD"), cancellable = true)
    private static void onHandleClickEvent(class_2558 clickEvent, class_310 client, class_437 screenAfterRun, CallbackInfo ci) {
        if (clickEvent instanceof class_2558.class_10609 runCommand) {
            String command = runCommand.comp_3506();
            CommandManager manager = CommandManager.getInstance();

            if (manager != null && command != null && command.startsWith(manager.getPrefix())) {
                manager.execute(command.substring(manager.getPrefix().length()));
                ci.cancel();
            }
        }
    }
}