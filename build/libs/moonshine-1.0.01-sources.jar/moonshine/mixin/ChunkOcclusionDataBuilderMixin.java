package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.events.api.EventManager;
import moonshine.events.impl.ChunkOcclusionEvent;
import net.minecraft.class_2338;
import net.minecraft.class_852;

@Mixin(class_852.class)
public abstract class ChunkOcclusionDataBuilderMixin {

    @Inject(method = "markClosed", at = @At("HEAD"), cancellable = true)
    private void onMarkClosed(class_2338 pos, CallbackInfo info) {
        ChunkOcclusionEvent event = ChunkOcclusionEvent.get();
        EventManager.callEvent(event);
        if (event.isCancelled()) {
            info.cancel();
        }
    }
}