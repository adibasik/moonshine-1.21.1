package moonshine.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import moonshine.IMinecraft;
import moonshine.events.api.EventManager;
import moonshine.events.impl.PlayerTravelEvent;
import moonshine.events.impl.PushEvent;
import moonshine.events.impl.SwimmingEvent;
import moonshine.modules.impl.combat.aura.AngleConnection;
import net.minecraft.class_1657;
import net.minecraft.class_243;


@Mixin(class_1657.class)
public abstract class PlayerEntityMixin implements IMinecraft {

    @Inject(method = "isPushedByFluids", at = @At("HEAD"), cancellable = true)
    public void isPushedByFluids(CallbackInfoReturnable<Boolean> cir) {
        PushEvent event = new PushEvent(PushEvent.Type.WATER);
        EventManager.callEvent(event);
        if (event.isCancelled()) cir.setReturnValue(false);
    }

    @ModifyExpressionValue(method = "knockbackTarget", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;getYaw()F"))
    private float hookKnockbackRotation(float original) {
        if ((Object) this == mc.field_1724 && AngleConnection.INSTANCE.getMoveRotation() != null) {
            return AngleConnection.INSTANCE.getMoveRotation().getYaw();
        }
        return original;
    }

    @ModifyExpressionValue(method = "doSweepingAttack", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;getYaw()F"))
    private float hookSweepRotation(float original) {
        if ((Object) this == mc.field_1724 && AngleConnection.INSTANCE.getMoveRotation() != null) {
            return AngleConnection.INSTANCE.getMoveRotation().getYaw();
        }
        return original;
    }

    @Inject(method = "travel", at = @At("HEAD"), cancellable = true)
    private void onTravelPre(class_243 movementInput, CallbackInfo ci) {
        if (mc.field_1724 == null) return;
        PlayerTravelEvent event = new PlayerTravelEvent(movementInput, true);
        EventManager.callEvent(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @ModifyExpressionValue(method = "travel", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;getRotationVector()Lnet/minecraft/util/math/Vec3d;"))
    public class_243 travelHook(class_243 vec3d) {
        SwimmingEvent event = new SwimmingEvent(vec3d);
        EventManager.callEvent(event);
        return event.getVector();
    }

    @Inject(method = "travel", at = @At("RETURN"))
    private void onTravelPost(class_243 movementInput, CallbackInfo ci) {
        if (mc.field_1724 == null) return;
        PlayerTravelEvent event = new PlayerTravelEvent(movementInput, false);
        EventManager.callEvent(event);
    }
}