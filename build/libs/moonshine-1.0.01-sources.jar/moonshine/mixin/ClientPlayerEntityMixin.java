package moonshine.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.mojang.authlib.GameProfile;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.events.api.EventManager;
import moonshine.events.api.types.EventType;
import moonshine.events.impl.*;
import moonshine.modules.impl.combat.aura.AngleConnection;
import moonshine.util.move.MoveUtil;
import net.minecraft.class_1313;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_744;
import net.minecraft.class_746;

import static moonshine.IMinecraft.mc;

@Mixin(class_746.class)
public abstract class ClientPlayerEntityMixin extends class_742 {

    @Shadow
    protected abstract void autoJump(float dx, float dz);

    @Shadow
    public abstract boolean method_6115();

    @Final
    @Shadow
    protected class_310 client;

    @Shadow
    public class_744 input;

    private double prevX = 0.0;
    private double prevZ = 0.0;
    private float prevBodyYaw = 0.0f;

    public ClientPlayerEntityMixin(class_638 world, GameProfile profile) {
        super(world, profile);
    }

    @Inject(method = "tick", at = @At("HEAD"))
    public void tick(CallbackInfo info) {
        if (client.field_1724 != null && client.field_1687 != null) {
            EventManager.callEvent(new TickEvent());
        }
    }

    @Inject(method = "tickMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/input/Input;tick()V", shift = At.Shift.AFTER))
    private void onInputTick(CallbackInfo ci) {
        if (mc.field_1724 == null)
            return;
        PlayerTravelEvent event = new PlayerTravelEvent(class_243.field_1353, false);
        EventManager.callEvent(event);
    }

    @Redirect(method = "applyMovementSpeedFactors", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/Vec2f;multiply(F)Lnet/minecraft/util/math/Vec2f;", ordinal = 1))
    private class_241 cancelItemSlowdown(class_241 vec2f, float multiplier) {
        UsingItemEvent event = new UsingItemEvent(EventType.ON);
        EventManager.callEvent(event);

        if (event.isCancelled() && this.method_6115() && !this.method_5765()) {
            return vec2f.method_35582(1.0F);
        }

        return vec2f.method_35582(multiplier);
    }

    @Inject(method = "closeHandledScreen", at = @At(value = "HEAD"), cancellable = true)
    private void closeHandledScreenHook(CallbackInfo info) {
        CloseScreenEvent event = new CloseScreenEvent(client.field_1755);
        EventManager.callEvent(event);
        if (event.isCancelled())
            info.cancel();
    }

    @Inject(method = "pushOutOfBlocks", at = @At("HEAD"), cancellable = true)
    public void pushOutOfBlocks(double x, double z, CallbackInfo ci) {
        PushEvent event = new PushEvent(PushEvent.Type.BLOCK);
        EventManager.callEvent(event);
        if (event.isCancelled())
            ci.cancel();
    }

    @Inject(method = "move", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;move(Lnet/minecraft/entity/MovementType;Lnet/minecraft/util/math/Vec3d;)V"), cancellable = true)
    public void onMoveHook(class_1313 movementType, class_243 movement, CallbackInfo ci) {
        MoveEvent event = new MoveEvent(movement);
        EventManager.callEvent(event);
        double d = this.method_23317();
        double e = this.method_23321();
        super.method_5784(movementType, event.getMovement());
        this.autoJump((float) (this.method_23317() - d), (float) (this.method_23321() - e));
        ci.cancel();
    }

    @ModifyExpressionValue(method = { "sendMovementPackets",
            "tick" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;getYaw()F"))
    private float hookSilentRotationYaw(float original) {
        if (mc.field_1724 != null && AngleConnection.INSTANCE.getRotation() != null) {
            float currentYaw = AngleConnection.INSTANCE.getRotation().getYaw();
            float newBodyYaw = MoveUtil.calculateBodyYaw(
                    currentYaw,
                    prevBodyYaw,
                    prevX,
                    prevZ,
                    mc.field_1724.method_23317(),
                    mc.field_1724.method_23321(),
                    mc.field_1724.field_6251);

            prevBodyYaw = newBodyYaw;
            prevX = mc.field_1724.method_23317();
            prevZ = mc.field_1724.method_23321();

            mc.field_1724.method_5636(newBodyYaw);
            return currentYaw;
        }

        return original;
    }

    @ModifyExpressionValue(method = { "sendMovementPackets",
            "tick" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;getPitch()F"))
    private float hookSilentRotationPitch(float original) {
        if (AngleConnection.INSTANCE.getRotation() != null) {
            return AngleConnection.INSTANCE.getRotation().getPitch();
        }
        return original;
    }
}