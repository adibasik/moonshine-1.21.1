package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.modules.impl.render.Esp;
import moonshine.modules.impl.render.chinahat.ChinaHatFeatureRenderer;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11659;
import net.minecraft.class_11890;
import net.minecraft.class_12075;
import net.minecraft.class_4587;
import net.minecraft.class_5617;

@Mixin(class_1007.class)
public class MixinPlayerEntityRenderer {

    @SuppressWarnings("unchecked")
    @Inject(method = "<init>", at = @At("TAIL"))
    private void onInit(class_5617.class_5618 ctx, boolean slim, CallbackInfo ci) {
        class_1007 renderer = (class_1007) (Object) this;
        renderer.method_4046(new ChinaHatFeatureRenderer(renderer));
    }

    @Inject(method = "renderLabelIfPresent(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V", at = @At("HEAD"), cancellable = true)
    private void hideBelownameScore(class_10055 state, class_4587 matrices, class_11659 queue, class_12075 cameraRenderState, CallbackInfo ci) {
        if (Esp.getInstance().isState()) {
            ci.cancel();
        }
    }

    @Inject(method = "updateRenderState(Lnet/minecraft/entity/PlayerLikeEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V", at = @At("TAIL"))
    private void onUpdateRenderState(class_11890 player, class_10055 state, float tickDelta, CallbackInfo ci) {
        if (Esp.getInstance().isState()) {
            state.field_53525 = null;
            state.field_53337 = null;
        }
    }
}