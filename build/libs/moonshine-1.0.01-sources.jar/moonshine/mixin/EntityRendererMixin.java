package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import moonshine.modules.impl.render.Esp;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_4587;
import net.minecraft.class_897;

@Mixin(class_897.class)
public class EntityRendererMixin<T extends class_1297, S extends class_10017> {

    @Inject(method = "renderLabelIfPresent", at = @At("HEAD"), cancellable = true)
    private void onRenderLabelIfPresent(S state, class_4587 matrices, class_11659 queue, class_12075 cameraRenderState, CallbackInfo ci) {
        Esp esp = Esp.getInstance();
        if (esp != null && esp.isState()) {
            if (state.field_58171 == class_1299.field_6097 && esp.entityType.isSelected("Player")) {
                ci.cancel();
            }
            if (state.field_58171 == class_1299.field_6052 && esp.entityType.isSelected("Item")) {
                ci.cancel();
            }
        }
    }

    @Inject(method = "getDisplayName", at = @At("HEAD"), cancellable = true)
    private void hookNametag(T entity, CallbackInfoReturnable<class_2561> cir) {
        Esp esp = Esp.getInstance();
        if (esp != null && esp.isState()) {
            if (entity instanceof class_1657 && esp.entityType.isSelected("Player")) {
                cir.setReturnValue(null);
            }

            if (entity instanceof class_1542 && esp.entityType.isSelected("Item")) {
                cir.setReturnValue(null);
            }
        }
    }
}