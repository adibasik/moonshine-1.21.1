package moonshine.mixin;

import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.events.api.EventManager;
import moonshine.events.impl.KeyEvent;
import moonshine.screens.clickgui.ClickGui;
import moonshine.util.config.impl.bind.BindConfig;
import moonshine.util.selfdestruct.SelfDestructManager;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_310;
import net.minecraft.class_3675;

@Mixin(class_309.class)
public class KeyboardMixin {

    @Final
    @Shadow
    private class_310 client;

    @Inject(method = "onKey", at = @At("HEAD"))
    private void onKey(long window, int action, class_11908 input, CallbackInfo ci) {
        if (input.comp_4795() != GLFW.GLFW_KEY_UNKNOWN && window == client.method_22683().method_4490()) {
            if (SelfDestructManager.isLocked()) {
                return;
            }

            if (action == 0 && input.comp_4795() == BindConfig.getInstance().getBindKey() && canOpenClickGui()) {
                ClickGui.INSTANCE.openGui();
            }

            EventManager.callEvent(new KeyEvent(client.field_1755, class_3675.class_307.field_1668, input.comp_4795(), action));
        }
    }

    private boolean canOpenClickGui() {
        if (client.field_1687 == null || client.field_1724 == null) return false;
        if (client.field_1755 != null) return false;
        return true;
    }
}
