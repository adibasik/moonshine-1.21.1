package moonshine.mixin;

import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2535.class)
public interface ClientConnectionAccessor {
    @Accessor("packetListener")
    class_2547 client$listener();

    @Invoker("handlePacket")
    static <T extends class_2547> void handlePacket(class_2596<T> packet, class_2547 listener) {
        throw new UnsupportedOperationException();
    }
}
