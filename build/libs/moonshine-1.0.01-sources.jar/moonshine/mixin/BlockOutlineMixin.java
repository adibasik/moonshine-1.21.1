package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.modules.impl.render.BlockOverlay;
import net.minecraft.class_12074;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_761;

@Mixin(class_761.class)
public class BlockOutlineMixin {

    @Inject(method = "drawBlockOutline", at = @At("HEAD"), cancellable = true)
    private void onDrawBlockOutline(class_4587 matrices, class_4588 vertexConsumer, double x, double y, double z, class_12074 state, int color, float lineWidth, CallbackInfo ci) {
        BlockOverlay blockOverlay = BlockOverlay.getInstance();
        if (blockOverlay != null && blockOverlay.isState()) {
            ci.cancel();
        }
    }
}
