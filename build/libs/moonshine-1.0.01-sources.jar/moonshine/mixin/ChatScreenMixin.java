package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import moonshine.Initialization;
import moonshine.client.draggables.Drag;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_437;

@Mixin(class_408.class)
public abstract class ChatScreenMixin extends class_437 {

    protected ChatScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_332 context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        Drag.onDraw(context, mouseX, mouseY, deltaTicks, true);
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void onMouseClicked(class_11909 click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
        int mouseX = (int) click.comp_4798();
        int mouseY = (int) click.comp_4799();
        int button = click.method_74245();

        if (Initialization.getInstance() != null && Initialization.getInstance().getManager() != null
                && Initialization.getInstance().getManager().getHudManager() != null) {
            if (Initialization.getInstance().getManager().getHudManager().mouseClicked(mouseX, mouseY, button)) {
                cir.setReturnValue(true);
                return;
            }
        }

        Drag.onMouseClick(click);
        if (Drag.isDragging()) {
            cir.setReturnValue(true);
        }
    }

    @Override
    public boolean method_25406(class_11909 click) {
        Drag.onMouseRelease(click);
        return super.method_25406(click);
    }

    @Override
    public boolean method_25403(class_11909 click, double deltaX, double deltaY) {
        return super.method_25403(click, deltaX, deltaY);
    }

    @Override
    public void method_25432() {
        Drag.resetDragging();
        super.method_25432();
    }

    @Override
    public void method_25419() {
        Drag.resetDragging();
        super.method_25419();
    }
}