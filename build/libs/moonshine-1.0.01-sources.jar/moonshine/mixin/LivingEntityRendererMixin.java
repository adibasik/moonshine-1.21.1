package moonshine.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Redirect;
import moonshine.IMinecraft;
import moonshine.events.api.EventManager;
import moonshine.events.impl.EntityColorEvent;
import moonshine.modules.impl.combat.aura.AngleConnection;
import net.minecraft.class_10042;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_3532;
import net.minecraft.class_465;
import net.minecraft.class_583;
import net.minecraft.class_922;

@SuppressWarnings("unchecked")
@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin<S extends class_10042, M extends class_583<? super S>> implements IMinecraft {

    @Shadow
    @Nullable
    protected abstract class_1921 getRenderLayer(S state, boolean showBody, boolean translucent, boolean showOutline);

    @ModifyExpressionValue(method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/MathHelper;lerpAngleDegrees(FFF)F"))
    private float lerpAngleDegreesHook(float original, @Local(ordinal = 0, argsOnly = true) class_1309 entity, @Local(ordinal = 0, argsOnly = true) float delta) {
        AngleConnection controller = AngleConnection.INSTANCE;

        if (entity.equals(mc.field_1724) && controller.getCurrentAngle() != null && !(mc.field_1755 instanceof class_465)) {
            float prevYaw = controller.getPreviousRotation().getYaw();
            float currentYaw = controller.getRotation().getYaw();
            return class_3532.method_17821(delta, prevYaw, currentYaw);
        }

        return original;
    }

    @ModifyExpressionValue(method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getLerpedPitch(F)F"))
    private float getLerpedPitchHook(float original, @Local(ordinal = 0, argsOnly = true) class_1309 entity, @Local(ordinal = 0, argsOnly = true) float delta) {
        AngleConnection controller = AngleConnection.INSTANCE;

        if (entity.equals(mc.field_1724) && controller.getCurrentAngle() != null && !(mc.field_1755 instanceof class_465)) {
            float prevPitch = controller.getPreviousRotation().getPitch();
            float currentPitch = controller.getRotation().getPitch();
            return class_3532.method_16439(delta, prevPitch, currentPitch);
        }

        return original;
    }

    @Redirect(method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/LivingEntityRenderer;getRenderLayer(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;ZZZ)Lnet/minecraft/client/render/RenderLayer;"))
    private class_1921 renderLayerHook(class_922<?, ?, ?> instance, class_10042 state, boolean showBody, boolean translucent, boolean showOutline) {
        if (!translucent && state.field_53329 == 0.6F) {
            EntityColorEvent event = new EntityColorEvent(-1);
            EventManager.callEvent(event);
            if (event.isCancelled()) {
                translucent = true;
            }
        }
        return this.getRenderLayer((S) state, showBody, translucent, showOutline);
    }

    @ModifyArg(method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/texture/Sprite;ILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V"), index = 6)
    private int modifyColor(int color, @Local(argsOnly = true) S renderState) {
        if (renderState.field_53461) {
            EntityColorEvent event = new EntityColorEvent(color);
            EventManager.callEvent(event);
            return event.getColor();
        }
        return color;
    }
}