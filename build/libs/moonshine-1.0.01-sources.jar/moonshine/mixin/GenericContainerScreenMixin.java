package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.modules.impl.misc.AutoBuy;
import moonshine.modules.impl.misc.autoparser.AutoParser;
import moonshine.modules.impl.misc.autoparser.dev.ItemParser;
import moonshine.screens.clickgui.impl.autobuy.manager.AutoBuyManager;
import moonshine.util.modules.autoparser.DiscountSliderWidget;
import moonshine.util.string.chat.ChatMessage;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import net.minecraft.class_476;
import net.minecraft.class_746;
import java.util.ArrayList;
import java.util.List;

@Mixin(class_476.class)
public abstract class GenericContainerScreenMixin extends class_465<class_1707> {

    @Unique
    private static long lastScreenOpenTime = 0;
    @Unique
    private static String lastScreenTitle = "";
    @Unique
    private static final long SCREEN_REOPEN_THRESHOLD = 500;

    @Unique
    private class_4185 takeAllButton;
    @Unique
    private class_4185 dropAllButton;
    @Unique
    private class_4185 storeAllButton;
    @Unique
    private class_4185 autoBuyButton;
    @Unique
    private class_4185 autoParserButton;
    @Unique
    private DiscountSliderWidget discountSlider;
    @Unique
    private class_4185 parseButton;
    @Unique
    private boolean buttonsAdded = false;
    @Unique
    private boolean isQuickReopen = false;
    @Unique
    private final AutoBuyManager autoBuyManager = AutoBuyManager.getInstance();

    public GenericContainerScreenMixin(class_1707 handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Inject(method = "<init>", at = @At("RETURN"))
    private void onInit(class_1707 handler, class_1661 inventory, class_2561 title, CallbackInfo ci) {
        long now = System.currentTimeMillis();
        String currentTitle = title.getString();

        if (currentTitle.equals(lastScreenTitle) && (now - lastScreenOpenTime) < SCREEN_REOPEN_THRESHOLD) {
            isQuickReopen = true;
        } else {
            isQuickReopen = false;
        }

        lastScreenOpenTime = now;
        lastScreenTitle = currentTitle;
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        String title = this.method_25440().getString();

        if (!buttonsAdded) {
            addButtons(mc, title);
            buttonsAdded = true;
        }

        updateAutoBuyButton();
        updateAutoParserButton();
        renderNetworkInfo(context, mc, title);
    }

    @Unique
    private void updateAutoBuyButton() {
        if (autoBuyButton == null) return;

        AutoBuy autoBuyModule = AutoBuy.getInstance();
        boolean moduleActive = autoBuyModule != null && autoBuyModule.isState();
        boolean buttonEnabled = autoBuyManager.isEnabled();

        String status;
        if (!moduleActive) {
            status = "§cOFF";
            autoBuyButton.field_22763 = false;
        } else if (buttonEnabled) {
            status = "§aON";
            autoBuyButton.field_22763 = true;
        } else {
            status = "§ePAUSE";
            autoBuyButton.field_22763 = true;
        }

        autoBuyButton.method_25355(class_2561.method_43470("AutoBuy: " + status));
    }

    @Unique
    private void updateAutoParserButton() {
        AutoParser parser = AutoParser.getInstance();
        if (autoParserButton == null || parser == null) return;

        boolean isRunning = parser.isRunning();
        autoParserButton.method_25355(class_2561.method_43470("AutoParser: " + (isRunning ? "§aON" : "§cOFF")));

        if (discountSlider != null) {
            discountSlider.field_22763 = !isRunning;
        }
    }

    @Unique
    private void renderNetworkInfo(class_332 context, class_310 mc, String title) {
        if (autoBuyButton == null || !title.contains("Аукцион")) return;

        AutoBuy autoBuyModule = AutoBuy.getInstance();
        if (autoBuyModule == null || !autoBuyModule.isState()) return;

        int clients = autoBuyModule.getNetworkManager().getConnectedClientCount();
        int inAuction = autoBuyModule.getNetworkManager().getClientsInAuctionCount();
        boolean connected = autoBuyModule.getNetworkManager().isConnectedToServer();
        boolean isServer = autoBuyModule.getNetworkManager().isServerRunning();

        String info;
        if (isServer) {
            info = "§7Клиентов: §b" + clients + " §7В аукционе: §b" + inAuction;
        } else if (connected) {
            info = "§aПодключён к серверу";
        } else {
            info = "§cНет подключения";
        }

        int infoX = (this.field_22789 - this.field_2792) / 2 + this.field_2792 / 2;
        int infoY = (this.field_22790 - this.field_2779) / 2 - 10;
        context.method_27534(mc.field_1772, class_2561.method_43470(info), infoX, infoY, 0xFFFFFF);
    }

    @Unique
    private void addButtons(class_310 mc, String titleText) {
        int baseX = (this.field_22789 + this.field_2792) / 2;
        int baseY = (this.field_22790 - this.field_2779) / 2;

        this.dropAllButton = class_4185.method_46430(
                class_2561.method_43470("Выбросить"),
                button -> dropAll(mc)
        ).method_46434(baseX, baseY, 80, 20).method_46431();

        this.takeAllButton = class_4185.method_46430(
                class_2561.method_43470("Взять всё"),
                button -> takeAll(mc)
        ).method_46434(baseX, baseY + 22, 80, 20).method_46431();

        this.storeAllButton = class_4185.method_46430(
                class_2561.method_43470("Сложить всё"),
                button -> storeAll(mc)
        ).method_46434(baseX, baseY + 44, 80, 20).method_46431();

        this.method_37063(dropAllButton);
        this.method_37063(takeAllButton);
        this.method_37063(storeAllButton);

        int autoBuyX = (this.field_22789 - this.field_2792) / 2 + this.field_2792 / 2 - 55;
        int autoBuyY = (this.field_22790 - this.field_2779) / 2 - 25;

        AutoBuy autoBuyModule = AutoBuy.getInstance();
        boolean moduleActive = autoBuyModule != null && autoBuyModule.isState();
        boolean buttonEnabled = autoBuyManager.isEnabled();

        ItemParser parser2 = ItemParser.getInstance();
        boolean parserActive = parser2 != null && parser2.isState();

//        this.parseButton = ButtonWidget.builder(
//                Text.literal(parserActive ? "§aПарсить всё" : "§7Парсить всё"),
//                button -> handleParseButtonClick()
//        ).dimensions(autoBuyX, autoBuyY - 22, 80, 20).build();
//        this.parseButton.active = parserActive;
//        this.addDrawableChild(parseButton);

        String initialStatus;
        if (!moduleActive) {
            initialStatus = "§cOFF";
        } else if (buttonEnabled) {
            initialStatus = "§aON";
        } else {
            initialStatus = "§ePAUSE";
        }

        this.autoBuyButton = class_4185.method_46430(
                class_2561.method_43470("AutoBuy: " + initialStatus),
                button -> handleAutoBuyButtonClick(button)
        ).method_46434(autoBuyX, autoBuyY, 110, 20).method_46431();

        this.autoBuyButton.field_22763 = moduleActive;
        this.method_37063(autoBuyButton);

        int leftX = (this.field_22789 - this.field_2792) / 2 - 100;
        int leftY = (this.field_22790 - this.field_2779) / 2;

        AutoParser parser = AutoParser.getInstance();
        int initialDiscount = parser != null ? parser.getDiscountPercent() : 60;

        this.autoParserButton = class_4185.method_46430(
                class_2561.method_43470("AutoParser: §cOFF"),
                button -> handleAutoParserButtonClick()
        ).method_46434(leftX, leftY, 95, 20).method_46431();
        this.method_37063(autoParserButton);

        this.discountSlider = new DiscountSliderWidget(leftX, leftY + 24, 95, 20, initialDiscount);
        this.method_37063(discountSlider);
    }

    @Unique
    private void handleAutoParserButtonClick() {
        AutoParser parser = AutoParser.getInstance();
        if (parser == null) {
            ChatMessage.autobuymessageError("AutoParser не инициализирован!");
            return;
        }

        if (parser.isRunning()) {
            parser.stopParsing();
        } else {
            parser.startParsing();
        }
    }

    @Unique
    private void handleParseButtonClick() {
        ItemParser parser = ItemParser.getInstance();
        if (parser == null || !parser.isState()) {
            ChatMessage.autobuymessageError("Сначала включите модуль Item Parser!");
            return;
        }

        int containerSize = this.field_2797.method_17388() * 9;

        List<class_1735> containerSlots = new ArrayList<>();
        for (int i = 0; i < containerSize && i < this.field_2797.field_7761.size(); i++) {
            containerSlots.add(this.field_2797.field_7761.get(i));
        }

        String containerTitle = this.method_25440().getString();

        parser.parseAllSlots(containerSlots, containerSize, containerTitle);
    }

    @Unique
    private void handleAutoBuyButtonClick(class_4185 button) {
        AutoBuy autoBuyModule = AutoBuy.getInstance();

        if (autoBuyModule == null || !autoBuyModule.isState()) {
            ChatMessage.autobuymessageError("Сначала включите модуль Auto Buy!");
            button.method_25355(class_2561.method_43470("AutoBuy: §cOFF"));
            button.field_22763 = false;
            return;
        }

        boolean currentState = autoBuyManager.isEnabled();
        boolean newState = !currentState;
        autoBuyManager.setEnabled(newState);

        String status;
        if (newState) {
            status = "§aON";
            ChatMessage.autobuymessageSuccess("AutoBuy включён!");
        } else {
            status = "§ePAUSE";
            ChatMessage.autobuymessageWarning("AutoBuy на паузе");
        }

        button.method_25355(class_2561.method_43470("AutoBuy: " + status));
    }

    @Unique
    private void takeAll(class_310 mc) {
        class_746 player = mc.field_1724;
        if (player == null || player.field_7512 == null) return;
        for (class_1735 slot : player.field_7512.field_7761) {
            if (slot.field_7871 != player.method_31548() && slot.method_7681()) {
                mc.field_1761.method_2906(
                        player.field_7512.field_7763,
                        slot.field_7874,
                        0,
                        class_1713.field_7794,
                        player
                );
            }
        }
    }

    @Unique
    private void dropAll(class_310 mc) {
        class_746 player = mc.field_1724;
        if (player == null || player.field_7512 == null) return;
        for (class_1735 slot : player.field_7512.field_7761) {
            if (slot.field_7871 != player.method_31548() && slot.method_7681()) {
                mc.field_1761.method_2906(
                        player.field_7512.field_7763,
                        slot.field_7874,
                        1,
                        class_1713.field_7795,
                        player
                );
            }
        }
    }

    @Unique
    private void storeAll(class_310 mc) {
        class_746 player = mc.field_1724;
        if (player == null || player.field_7512 == null) return;
        for (class_1735 slot : player.field_7512.field_7761) {
            if (slot.field_7871 == player.method_31548() && slot.method_7681()) {
                mc.field_1761.method_2906(
                        player.field_7512.field_7763,
                        slot.field_7874,
                        0,
                        class_1713.field_7794,
                        player
                );
            }
        }
    }
}