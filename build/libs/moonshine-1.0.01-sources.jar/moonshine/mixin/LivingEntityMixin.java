package moonshine.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import moonshine.events.api.EventManager;
import moonshine.events.impl.JumpEvent;
import moonshine.events.impl.PushEvent;
import moonshine.events.impl.SwingDurationEvent;
import moonshine.modules.impl.combat.aura.AngleConnection;
import net.minecraft.class_1291;
import net.minecraft.class_1292;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import java.lang.reflect.Method;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {
    @Shadow
    public abstract boolean hasStatusEffect(class_6880<class_1291> effect);
    @Shadow @Nullable
    public abstract class_1293 getStatusEffect(class_6880<class_1291> effect);
    @Shadow public float bodyYaw;
    @Shadow public abstract boolean isInSwimmingPose();
    @Shadow protected abstract double getEffectiveGravity();
    @Unique private final class_310 client = class_310.method_1551();

    @Unique private static boolean baritoneChecked = false;
    @Unique private static boolean baritoneAvailable = false;
    @Unique private static Method getProviderMethod;
    @Unique private static Method getPrimaryBaritoneMethod;
    @Unique private static Method getPathingBehaviorMethod;
    @Unique private static Method isPathingMethod;

    @Unique
    private boolean isBaritonePathing() {
        try {
            if (!baritoneChecked) {
                baritoneChecked = true;
                try {
                    Class<?> apiClass = Class.forName("baritone.api.BaritoneAPI");
                    getProviderMethod = apiClass.getMethod("getProvider");
                    Class<?> providerClass = Class.forName("baritone.api.IBaritoneProvider");
                    getPrimaryBaritoneMethod = providerClass.getMethod("getPrimaryBaritone");
                    Class<?> baritoneClass = Class.forName("baritone.api.IBaritone");
                    getPathingBehaviorMethod = baritoneClass.getMethod("getPathingBehavior");
                    Class<?> pathingClass = Class.forName("baritone.api.behavior.IPathingBehavior");
                    isPathingMethod = pathingClass.getMethod("isPathing");
                    baritoneAvailable = true;
                } catch (ClassNotFoundException | NoSuchMethodException e) {
                    baritoneAvailable = false;
                }
            }
            if (!baritoneAvailable) {
                return false;
            }
            Object provider = getProviderMethod.invoke(null);
            if (provider == null) return false;
            Object baritone = getPrimaryBaritoneMethod.invoke(provider);
            if (baritone == null) return false;
            Object pathingBehavior = getPathingBehaviorMethod.invoke(baritone);
            if (pathingBehavior == null) return false;
            Object result = isPathingMethod.invoke(pathingBehavior);
            return Boolean.TRUE.equals(result);
        } catch (Exception e) {
            return false;
        }
    }

    @Unique
    private boolean shouldApplyMoonshineMoveCorrection() {
        var rotationManager = AngleConnection.INSTANCE;
        var rotation = rotationManager.getRotation();
        var configurable = rotationManager.getCurrentRotationPlan();
        return rotation != null && configurable != null && configurable.isMoveCorrection();
    }

    @Inject(method = "isPushable", at = @At("HEAD"), cancellable = true)
    public void isPushable(CallbackInfoReturnable<Boolean> infoReturnable) {
        PushEvent event = new PushEvent(PushEvent.Type.COLLISION);
        EventManager.callEvent(event);
        if (event.isCancelled()) infoReturnable.setReturnValue(false);
    }

    @ModifyExpressionValue(method = "jump", at = @At(value = "NEW", target = "(DDD)Lnet/minecraft/util/math/Vec3d;"))
    private class_243 hookFixRotation(class_243 original) {
        if ((Object) this != client.field_1724) {
            return original;
        }
        if (isBaritonePathing()) {
            return original;
        }
        if (!shouldApplyMoonshineMoveCorrection()) {
            return original;
        }
        float yaw = AngleConnection.INSTANCE.getMoveRotation().getYaw() * 0.017453292F;
        return new class_243(-class_3532.method_15374(yaw) * 0.2F, 0.0, class_3532.method_15362(yaw) * 0.2F);
    }

    @Inject(method = "jump", at = @At("HEAD"), cancellable = true)
    private void jump(CallbackInfo info) {
        if ((Object) this instanceof class_746 player) {
            if (isBaritonePathing()) {
                return;
            }
            JumpEvent event = new JumpEvent(player);
            EventManager.callEvent(event);
            if (event.isCancelled()) info.cancel();
        }
    }

    @Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true)
    private void swingProgressHook(CallbackInfoReturnable<Integer> cir) {
        if ((Object) this != client.field_1724) {
            return;
        }
        SwingDurationEvent event = new SwingDurationEvent();
        EventManager.callEvent(event);
        if (event.isCancelled()) {
            float animation = event.getAnimation();
            if (class_1292.method_5576(client.field_1724)) animation *= (6 - (1 + class_1292.method_5575(client.field_1724)));
            else animation *= (hasStatusEffect(class_1294.field_5901) ? 6 + (1 + getStatusEffect(class_1294.field_5901).method_5578()) * 2 : 6);
            cir.setReturnValue((int) animation);
        }
    }

    @Inject(method = "calcGlidingVelocity", at = @At("HEAD"), cancellable = true)
    private void calcGlidingVelocityFull(class_243 oldVelocity, CallbackInfoReturnable<class_243> cir) {
        if ((Object) this != client.field_1724) {
            return;
        }
        if (isBaritonePathing()) {
            return;
        }
        var rotationManager = AngleConnection.INSTANCE;
        var rotation = rotationManager.getRotation();
        var configurable = rotationManager.getCurrentRotationPlan();
        if (rotation == null || configurable == null || !configurable.isMoveCorrection() || configurable.isChangeLook()) {
            return;
        }
        class_243 vec3d = rotation.toVector();
        float f = rotation.getPitch() * (float) (Math.PI / 180.0);
        double d = Math.sqrt(vec3d.field_1352 * vec3d.field_1352 + vec3d.field_1350 * vec3d.field_1350);
        double e = oldVelocity.method_37267();
        double g = this.getEffectiveGravity();
        double h = class_3532.method_33723(Math.cos(f));
        oldVelocity = oldVelocity.method_1031(0.0, g * (-1.0 + h * 0.75), 0.0);
        if (oldVelocity.field_1351 < 0.0 && d > 0.0) {
            double i = oldVelocity.field_1351 * -0.1 * h;
            oldVelocity = oldVelocity.method_1031(vec3d.field_1352 * i / d, i, vec3d.field_1350 * i / d);
        }
        if (f < 0.0F && d > 0.0) {
            double i = e * -class_3532.method_15374(f) * 0.04;
            oldVelocity = oldVelocity.method_1031(-vec3d.field_1352 * i / d, i * 3.2, -vec3d.field_1350 * i / d);
        }
        if (d > 0.0) {
            oldVelocity = oldVelocity.method_1031((vec3d.field_1352 / d * e - oldVelocity.field_1352) * 0.1, 0.0, (vec3d.field_1350 / d * e - oldVelocity.field_1350) * 0.1);
        }
        cir.setReturnValue(oldVelocity.method_18805(0.99F, 0.98F, 0.99F));
        cir.cancel();
    }
}