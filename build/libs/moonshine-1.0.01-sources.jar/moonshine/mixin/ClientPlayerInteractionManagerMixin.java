package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import moonshine.events.api.EventManager;
import moonshine.events.api.types.EventType;
import moonshine.events.impl.BlockBreakingEvent;
import moonshine.events.impl.ClickSlotEvent;
import moonshine.events.impl.UsingItemEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_636;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {

    @Inject(method = "interactItem", at = @At(value = "RETURN"))
    public void interactItemHook(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        if (cir.getReturnValue() instanceof class_1269.class_9860 success && !success.comp_2909().equals(class_1269.class_9861.field_52427)) {
            UsingItemEvent event = new UsingItemEvent(EventType.PRE);
            EventManager.callEvent(event);
        }
    }

    @Inject(method = "stopUsingItem", at = @At("HEAD"),cancellable = true)
    public void stopUsingItemHook(CallbackInfo ci) {
        UsingItemEvent event = new UsingItemEvent(EventType.POST);
        EventManager.callEvent(event);
    }

    @Inject(method = "interactItem", at = @At(value = "HEAD"), cancellable = true)
    private void gameModeHook(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        UsingItemEvent event = new UsingItemEvent(EventType.START);
        EventManager.callEvent(event);
        if (event.isCancelled()) cir.setReturnValue(class_1269.field_5811);
    }

    @Inject(method = "updateBlockBreakingProgress", at = @At(value = "HEAD"))
    private void injectBlockBreaking(class_2338 pos, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
        EventManager.callEvent(new BlockBreakingEvent(pos, direction));
    }

    @Inject(method = "clickSlot", at = @At("HEAD"), cancellable = true)
    public void clickSlotHook(int syncId, int slotId, int button, class_1713 actionType, class_1657 player, CallbackInfo info) {
        ClickSlotEvent event = new ClickSlotEvent(syncId,slotId,button,actionType);
        EventManager.callEvent(event);
        if (event.isCancelled()) info.cancel();
    }

}
