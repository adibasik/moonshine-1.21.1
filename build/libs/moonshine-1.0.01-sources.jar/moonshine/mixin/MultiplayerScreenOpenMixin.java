package moonshine.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.util.config.impl.proxy.ProxyConfig;
import moonshine.util.proxy.GuiProxy;
import moonshine.util.proxy.ProxyServer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_500;

@Mixin(class_500.class)
public class MultiplayerScreenOpenMixin {

    @Inject(method = "init()V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screen/multiplayer/MultiplayerScreen;updateButtonActivationStates()V"))
    public void multiplayerGuiOpen(CallbackInfo ci) {
        class_500 ms = (class_500) (Object) this;
        class_310 client = class_310.method_1551();

        ProxyConfig config = ProxyConfig.getInstance();

        String buttonText;
        if (config.isProxyEnabled() && !config.getDefaultProxy().isEmpty()) {
            buttonText = "§aПрокси: Активен";
        } else {
            buttonText = "§7Proxy";
        }

        ProxyServer.proxyMenuButton = class_4185.method_46430(class_2561.method_43470(buttonText), (buttonWidget) -> {
            class_310.method_1551().method_1507(new GuiProxy(ms));
        }).method_46434(5, 5, 100, 20).method_46431();

        IScreen si = (IScreen) ms;
        si.getDrawables().add(ProxyServer.proxyMenuButton);
        si.getSelectables().add(ProxyServer.proxyMenuButton);
        si.getChildren().add(ProxyServer.proxyMenuButton);
    }
}