package moonshine.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.IMinecraft;
import moonshine.Initialization;
import moonshine.events.api.EventManager;
import moonshine.events.impl.DrawEvent;
import moonshine.events.impl.HotbarItemRenderEvent;
import moonshine.modules.impl.render.Hud;
import moonshine.modules.impl.render.NoRender;
import moonshine.screens.clickgui.ClickGui;
import moonshine.util.render.Render2D;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_9779;

@Mixin(class_329.class)
public abstract class InGameHudMixin implements IMinecraft {

    @Shadow
    @Final
    private class_310 client;

    @Unique
    private int moonshineCurrentHotbarIndex = 0;

    @Inject(method = "renderHotbar", at = @At("HEAD"))
    private void onRenderHotbarStart(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        moonshineCurrentHotbarIndex = 0;
    }

    @WrapOperation(
            method = "renderHotbar",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/hud/InGameHud;renderHotbarItem(Lnet/minecraft/client/gui/DrawContext;IILnet/minecraft/client/render/RenderTickCounter;Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/item/ItemStack;I)V"
            )
    )
    private void onRenderHotbarItem(class_329 instance, class_332 context, int x, int y, class_9779 tickCounter, class_1657 player, class_1799 stack, int seed, Operation<Void> original) {
        int hotbarIndex = moonshineCurrentHotbarIndex;

        if (moonshineCurrentHotbarIndex < 9) {
            moonshineCurrentHotbarIndex++;
        }

        HotbarItemRenderEvent event = new HotbarItemRenderEvent(stack, hotbarIndex);
        EventManager.callEvent(event);
        original.call(instance, context, x, y, tickCounter, player, event.getStack(), seed);
    }

    @Inject(method = "renderNauseaOverlay", at = @At("HEAD"), cancellable = true)
    private void onRenderNauseaOverlay(class_332 context, float nauseaStrength, CallbackInfo ci) {
        NoRender noRender = NoRender.getInstance();
        if (noRender != null && noRender.isState() && noRender.modeSetting.isSelected("Nausea")) {
            ci.cancel();
        }
    }

    @Inject(method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V", at = @At("HEAD"), cancellable = true)
    private void onRenderScoreboard(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        NoRender noRender = NoRender.getInstance();
        if (noRender != null && noRender.isState() && noRender.modeSetting.isSelected("Scoreboard")) {
            ci.cancel();
        }
    }

    @Inject(method = "renderBossBarHud", at = @At("HEAD"), cancellable = true)
    private void onRenderBossBar(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        NoRender noRender = NoRender.getInstance();
        if (noRender != null && noRender.isState() && noRender.modeSetting.isSelected("BossBar")) {
            ci.cancel();
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    public void onRenderCustomHud(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (this.client.field_1690.field_1842) return;
        if (client.field_1687 == null || client.field_1724 == null) return;
        if (client.method_18506() != null) return;

        class_437 screen = client.field_1755;

        if (isLoadingScreen(screen)) return;

        context.method_71048();
        Render2D.beginOverlay();
        context.method_51448().pushMatrix();

        DrawEvent event = new DrawEvent(context, drawEngine, tickCounter.method_60637(false));
        EventManager.callEvent(event);

        context.method_51448().popMatrix();

        if (shouldRenderHud(screen)) {
            int mouseX = (int) client.field_1729.method_68879(client.method_22683());
            int mouseY = (int) client.field_1729.method_68883(client.method_22683());
            float tickDelta = tickCounter.method_60637(false);

            Hud hud = Hud.getInstance();
            if (hud != null && hud.isState() && Initialization.getInstance() != null
                    && Initialization.getInstance().getManager() != null
                    && Initialization.getInstance().getManager().getHudManager() != null) {
                Initialization.getInstance().getManager().getHudManager().render(context, tickDelta, mouseX, mouseY);
            }
        }

        Render2D.endOverlay();
    }

    @Unique
    private boolean shouldRenderHud(class_437 screen) {
        if (screen == null) return true;
        if (screen instanceof ClickGui) return false;
        if (screen instanceof class_408) return false;
        if (isLoadingScreen(screen)) return false;
        return true;
    }

    @Unique
    private boolean isLoadingScreen(class_437 screen) {
        if (screen == null) return false;
        String className = screen.getClass().getSimpleName().toLowerCase();
        String fullName = screen.getClass().getName().toLowerCase();
        if (className.contains("loading")) return true;
        if (className.contains("progress")) return true;
        if (className.contains("connecting")) return true;
        if (className.contains("downloading")) return true;
        if (className.contains("terrain")) return true;
        if (className.contains("generating")) return true;
        if (className.contains("saving")) return true;
        if (className.contains("reload")) return true;
        if (className.contains("resource")) return true;
        if (className.contains("pack")) return true;
        if (fullName.contains("mojang")) return true;
        return false;
    }
}