package moonshine.mixin;

import io.netty.channel.ChannelPipeline;
import io.netty.handler.proxy.Socks4ProxyHandler;
import io.netty.handler.proxy.Socks5ProxyHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import moonshine.events.api.EventManager;
import moonshine.events.impl.PacketEvent;
import moonshine.util.config.impl.proxy.ProxyConfig;
import moonshine.util.proxy.Proxy;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import net.minecraft.class_2598;
import net.minecraft.class_8762;
import java.net.InetSocketAddress;

@Mixin(class_2535.class)
public class ClientConnectionMixin {

    @Inject(method = "handlePacket", at = @At("HEAD"), cancellable = true)
    private static <T extends class_2547> void handlePacketPre(class_2596<T> packet, class_2547 listener, CallbackInfo info) {
        PacketEvent packetEvent = new PacketEvent(packet, PacketEvent.Type.RECEIVE);
        EventManager.callEvent(packetEvent);
        if (packetEvent.isCancelled()) {
            info.cancel();
        }
    }

    @Inject(method = "send(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), cancellable = true)
    private void sendPre(class_2596<?> packet, CallbackInfo info) {
        PacketEvent packetEvent = new PacketEvent(packet, PacketEvent.Type.SEND);
        EventManager.callEvent(packetEvent);
        if (packetEvent.isCancelled()) {
            info.cancel();
        }
    }

    @Inject(method = "addHandlers", at = @At("RETURN"))
    private static void addHandlersHook(ChannelPipeline pipeline, class_2598 side, boolean local, class_8762 packetSizeLogger, CallbackInfo ci) {
        ProxyConfig config = ProxyConfig.getInstance();
        Proxy proxy = config.getDefaultProxy();

        if (proxy != null && config.isProxyEnabled() && !proxy.isEmpty() && side == class_2598.field_11942 && !local) {
            InetSocketAddress proxyAddress = new InetSocketAddress(proxy.getIp(), proxy.getPort());

            if (proxy.type == Proxy.ProxyType.SOCKS4) {
                pipeline.addFirst("moonshine_socks4_proxy", new Socks4ProxyHandler(proxyAddress, proxy.username));
            } else {
                pipeline.addFirst("moonshine_socks5_proxy", new Socks5ProxyHandler(proxyAddress, proxy.username, proxy.password));
            }

            config.setLastUsedProxy(new Proxy(proxy));
        }
    }
}